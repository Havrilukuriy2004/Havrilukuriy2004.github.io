import pandas as pd
import numpy as np
import sys
from io import StringIO

# Для тесту Грейнджера потрібна бібліотека statsmodels
# Встановіть її, виконавши в терміналі: pip install statsmodels
from statsmodels.tsa.stattools import grangercausalitytests

# --- ЧАСТИНА 1: РОЗРАХУНОК СЕРЕДНЬОЗВАЖЕНОГО PD ---

# 1. Завантаження даних з файлу
bank_data_filename = 'interbank_modeling/network_data.csv'
try:
    df = pd.read_csv(bank_data_filename)
    print(f"Файл '{bank_data_filename}' успішно завантажено.")
except FileNotFoundError:
    print(f"ПОМИЛКА: Файл '{bank_data_filename}' не знайдено.")
    print("Будь ласка, перевірте шлях до файлу та його назву.")
    exit()

# Перетворюємо стовпець 'date', вказуючи формат 'рік місяць'
df['date'] = pd.to_datetime(df['date'], format='%Y %m')

# 2. Розрахунок середньозваженого PD
def weighted_average(group):
    weights = group['total_assets']
    values = group['pd']
    return (values * weights).sum() / weights.sum()

weighted_avg_pd = df.groupby('date').apply(weighted_average).rename('weighted_avg_pd').to_frame()

# 3. Збереження результату у файл CSV
output_filename_pd = 'weighted_average_pd.csv'
weighted_avg_pd.to_csv(output_filename_pd)
print(f"Середньозважений PD розраховано та збережено у файл '{output_filename_pd}'")
print(weighted_avg_pd)
print("-" * 40)


# --- ЧАСТИНА 2: ТЕСТ ГРЕЙНДЖЕРА (ОНОВЛЕНА ЛОГІКА) ---

# 4. Завантаження файлу з індексом фінансового стресу
stress_filename = 'financial_stress_index.csv'
try:
    # Завантажуємо дані, вказуючи формат дати 'рік місяць'
    stress_df = pd.read_csv(stress_filename)
    stress_df['date'] = pd.to_datetime(stress_df['date'], format='%Y %m')
    print(f"Файл '{stress_filename}' успішно завантажено.")
    print(stress_df)
except FileNotFoundError:
    print(f"ПОМИЛКА: Файл '{stress_filename}' не знайдено.")
    print("Будь ласка, створіть цей файл у форматі 'date,stress_index' або перевірте назву.")
    # Зупиняємо виконання, якщо файлу немає
    exit()
print("-" * 40)


# 5. Проведення тесту Грейнджера
# Об'єднуємо два набори даних за датою
merged_df = pd.merge(weighted_avg_pd, stress_df, on='date')

# Перевіряємо, чи є дані для тестування після об'єднання
if merged_df.empty:
    print("ПОМИЛКА: Не вдалося об'єднати дані. Перевірте, чи збігаються дати у ваших файлах.")
    exit()

print("Об'єднана таблиця для тесту:")
print(merged_df)
print("-" * 40)

# Дані для тесту: [змінна, яку прогнозують (stress_index), змінна, яка прогнозує (weighted_avg_pd)]
# Ми перевіряємо, чи допомагає PD прогнозувати майбутній стрес.
data_for_test = merged_df[['stress_index', 'weighted_avg_pd']].dropna()

# Тест не можна провести, якщо даних занадто мало
if len(data_for_test) < 3:
     print("ПОМИЛКА: Недостатньо даних для проведення тесту Грейнджера.")
     exit()

# Максимальний лаг для перевірки.
max_lag = 8
print(f"Проведення тесту причинності Грейнджера з максимальним лагом = {max_lag}\n")

# Створюємо буфер для перехоплення виводу
buffer = StringIO()
# Зберігаємо оригінальний stdout
original_stdout = sys.stdout
# Перенаправляємо stdout у буфер
sys.stdout = buffer

# Виконуємо тест, вивід якого тепер піде в буфер
test_result = grangercausalitytests(data_for_test, maxlag=max_lag, verbose=True)

# Повертаємо stdout до початкового стану
sys.stdout = original_stdout
# Отримуємо вміст буфера
granger_report = buffer.getvalue()

# Виводимо звіт на екран
print(granger_report)

# Зберігаємо звіт у файл
report_filename = 'granger_test_report.txt'
with open(report_filename, 'w') as f:
    f.write("Тест причинності Грейнджера: чи є PD причиною фінансового стресу?\n\n")
    f.write(granger_report)
print(f"\nЗвіт тесту Грейнджера збережено у файл '{report_filename}'")


# Інтерпретація:
# Ми дивимося на p-значення (Pr(>F)).
# Якщо p-значення < 0.05, ми відхиляємо нульову гіпотезу.
# Нульова гіпотеза (H0): 'weighted_avg_pd' не є причиною 'stress_index' за Грейнджером.
# Отже, якщо p < 0.05, ми можемо сказати, що 'weighted_avg_pd' допомагає прогнозувати 'stress_index'.
