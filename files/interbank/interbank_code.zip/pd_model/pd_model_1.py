"""
PD Modeling Pipeline v3.0
Дата: 24-08-2025
Опис: Повний Python-скрипт для побудови та валідації моделей прогнозування ймовірності дефолту банку
Вхід: banks_data.csv (див техзавдання)
Вихід: звіти по моделях, ROC/PR графіки, pd_predictions.csv, збережена найкраща модель

Інструкції: Запустіть у середовищі з встановленими бібліотеками: pandas, numpy, scikit-learn, xgboost, matplotlib, joblib
Пример: python pd_modeling_pipeline_v3.py --input banks_data.csv

"""

import argparse
import os
from datetime import timedelta
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    roc_auc_score, precision_recall_curve, auc, precision_score, recall_score,
    confusion_matrix, classification_report, average_precision_score, roc_curve
)
import matplotlib.pyplot as plt
import joblib
import xgboost as xgb

# ------------------------ Helpers ------------------------

def protected_divide(a, b):
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        res = np.where((b == 0) | ~np.isfinite(b), np.nan, a / b)
    return res


def safe_log(x):
    x = np.array(x, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        x = np.where(x <= 0, np.nan, x)
        return np.log(x)


# Threshold selection: maximize precision subject to recall >= min_recall
def select_threshold_by_precision(y_true, y_scores, min_recall=0.9):
    precisions, recalls, thresholds = precision_recall_curve(y_true, y_scores)
    # precision_recall_curve returns thresholds of length len(precisions)-1
    best_idx = None
    best_precision = -1
    best_threshold = 0.5
    for i, thr in enumerate(np.append(thresholds, 1.0)):
        prec = precisions[i]
        rec = recalls[i]
        if rec >= min_recall and prec > best_precision:
            best_precision = prec
            best_idx = i
            best_threshold = thr
    if best_idx is None:
        # fallback: choose threshold that maximizes F1
        f1s = 2 * (precisions * recalls) / (precisions + recalls + 1e-12)
        idx = np.nanargmax(f1s)
        # threshold corresponding to idx: thresholds[idx] (but handle last)
        if idx < len(thresholds):
            best_threshold = thresholds[idx]
        else:
            best_threshold = 0.5
    return best_threshold


# ------------------------ Data preparation ------------------------

def load_and_prepare(path, signal_quarters=4, date_format_dayfirst=True, periods_per_year=4, net_income_is_annual=True):
    """Load CSV and prepare features.
    periods_per_year: number of reporting periods per year (4 for quarterly)
    net_income_is_annual: if True, net_income is annualized and will be de-annualized to period value
    """
    df = pd.read_csv(path)
    # Ensure required columns exist
    required = ['bank_id', 'date', 'event', 'total_assets', 'equity', 'net_income', 'loans', 'deposits', 'total_reserves']
    for c in required:
        if c not in df.columns:
            raise ValueError(f"Відсутнє обов'язкове поле: {c}")

    # Parse dates (DD-MM-YYYY expected)
    df['date'] = pd.to_datetime(df['date'], dayfirst=date_format_dayfirst, errors='coerce')
    if df['date'].isna().any():
        raise ValueError('Деякі дати не вдалося розпарсити — перевірте формат DD-MM-YYYY')

    # Convert numeric fields
    num_fields = ['total_assets', 'equity', 'net_income', 'loans', 'deposits', 'total_reserves']
    for f in num_fields:
        df[f] = pd.to_numeric(df[f], errors='coerce')

    # Sort
    df = df.sort_values(['bank_id', 'date']).reset_index(drop=True)

    # Remove banks whose first record is D (creation scenario)
    first_events = df.groupby('bank_id').first().reset_index()[['bank_id', 'event']]
    banks_to_drop = first_events.loc[first_events['event'] == 'D', 'bank_id'].tolist()
    if banks_to_drop:
        df = df[~df['bank_id'].isin(banks_to_drop)].copy()

    # Identify default dates per bank (first occurrence of D)
    default_dates = df.loc[df['event'] == 'D'].groupby('bank_id')['date'].min()

    # Exclude observations at and after default date for each bank
    mask = []
    for idx, row in df.iterrows():
        bid = row['bank_id']
        d = row['date']
        if bid in default_dates.index:
            if d >= default_dates.loc[bid]:
                mask.append(False)
            else:
                mask.append(True)
        else:
            mask.append(True)
    df = df[pd.Series(mask, index=df.index)].copy()

    # Create Y label: for observations that fall within signal_quarters before default -> 1
    df['Y'] = 0
    delta = pd.DateOffset(months=signal_quarters * 3)
    for bid, d0 in default_dates.items():
        cond = (df['bank_id'] == bid) & (df['date'] >= (d0 - delta)) & (df['date'] < d0)
        df.loc[cond, 'Y'] = 1

    # --- Handle net_income annualization ---
    if net_income_is_annual:
        df['net_income_period'] = df['net_income'] / float(periods_per_year)
    else:
        df['net_income_period'] = df['net_income'].astype(float)

    # Feature engineering: base ratios
    df['equity_to_assets'] = protected_divide(df['equity'], df['total_assets'])

    # Average total assets over last 'periods_per_year' periods (for denominator stability)
    df['avg_total_assets'] = df.groupby('bank_id')['total_assets'].transform(lambda s: s.rolling(window=periods_per_year, min_periods=1).mean())

    # roa: use period profit divided by average assets
    df['roa'] = protected_divide(df['net_income_period'], df['avg_total_assets'])

    df['reserves_to_loans'] = protected_divide(df['total_reserves'], df['loans'])
    df['ldr'] = protected_divide(df['loans'], df['deposits'])
    df['ln_assets'] = safe_log(df['total_assets'])

    # Compute yoy change using shift(periods_per_year)
    for feat in ['roa', 'equity_to_assets', 'reserves_to_loans', 'ldr']:
        df[f'{feat}_yoy_change'] = df.groupby('bank_id')[feat].transform(lambda s: s - s.shift(periods_per_year))

    # Rolling volatility (std dev over last periods_per_year periods)
    for feat in ['equity_to_assets', 'roa', 'reserves_to_loans', 'ldr']:
        df[f'{feat}_vol_{periods_per_year}p'] = df.groupby('bank_id')[feat].transform(lambda s: s.rolling(window=periods_per_year, min_periods=1).std())

    # Impute remaining missing numeric values: use group median, fallback to global median
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if 'Y' in numeric_cols:
        numeric_cols.remove('Y')
    for col in numeric_cols:
        df[col] = df.groupby('bank_id')[col].transform(lambda s: s.fillna(s.median()))
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())

    # Final drop of any remaining NaN in Y
    df = df.dropna(subset=['Y']).copy()

    return df


# ------------------------ Modeling ------------------------

def build_and_evaluate(df, features, outdir='outputs', test_size=0.3, random_state=42, oot_date=None):
    os.makedirs(outdir, exist_ok=True)

    X = df[features]
    y = df['Y']

    # If out-of-time validation date provided -> split by date
    if oot_date is not None:
        oot_date = pd.to_datetime(oot_date)
        train_mask = df['date'] < oot_date
        X_train, X_test = X[train_mask], X[~train_mask]
        y_train, y_test = y[train_mask], y[~train_mask]
    else:
        X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=test_size, random_state=random_state)

    results = {}

    # 1) Logistic Regression
    pipe_log = Pipeline([('scaler', StandardScaler()), ('clf', LogisticRegression(class_weight='balanced', max_iter=1000))])
    param_grid_log = {
        'clf__C': [0.01, 0.1, 1.0, 10.0]
    }
    gs_log = GridSearchCV(pipe_log, param_grid_log, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_log.fit(X_train, y_train)
    best_log = gs_log.best_estimator_
    y_scores_log = best_log.predict_proba(X_test)[:,1]
    auc_log = roc_auc_score(y_test, y_scores_log)
    pr_auc_log = average_precision_score(y_test, y_scores_log)

    results['logistic'] = {'model': best_log, 'auc': auc_log, 'pr_auc': pr_auc_log, 'y_scores': y_scores_log}

    # 2) Random Forest
    rf = RandomForestClassifier(class_weight='balanced', n_jobs=-1, random_state=random_state)
    param_grid_rf = {
        'n_estimators': [100, 300],
        'max_depth': [5, 10, None]
    }
    gs_rf = GridSearchCV(rf, param_grid_rf, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_rf.fit(X_train, y_train)
    best_rf = gs_rf.best_estimator_
    y_scores_rf = best_rf.predict_proba(X_test)[:,1]
    auc_rf = roc_auc_score(y_test, y_scores_rf)
    pr_auc_rf = average_precision_score(y_test, y_scores_rf)

    results['rf'] = {'model': best_rf, 'auc': auc_rf, 'pr_auc': pr_auc_rf, 'y_scores': y_scores_rf}

    # 3) XGBoost
    xgb_clf = xgb.XGBClassifier(eval_metric='logloss', random_state=random_state, verbosity=0)
    # scale_pos_weight = (n_neg / n_pos)
    pos = y_train.sum()
    neg = len(y_train) - pos
    scale_pos_weight = max(1.0, neg / max(1.0, pos))
    xgb_clf.set_params(scale_pos_weight=scale_pos_weight)
    param_grid_xgb = {
        'n_estimators': [100, 300],
        'max_depth': [3, 6],
        'learning_rate': [0.01, 0.1]
    }
    gs_xgb = GridSearchCV(xgb_clf, param_grid_xgb, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_xgb.fit(X_train, y_train)
    best_xgb = gs_xgb.best_estimator_
    y_scores_xgb = best_xgb.predict_proba(X_test)[:,1]
    auc_xgb = roc_auc_score(y_test, y_scores_xgb)
    pr_auc_xgb = average_precision_score(y_test, y_scores_xgb)

    results['xgb'] = {'model': best_xgb, 'auc': auc_xgb, 'pr_auc': pr_auc_xgb, 'y_scores': y_scores_xgb}

    # Choose best model by AUC, break ties using PR-AUC
    summary = [(k, v['auc'], v['pr_auc']) for k, v in results.items()]
    summary_df = pd.DataFrame(summary, columns=['model', 'auc', 'pr_auc']).sort_values(['auc', 'pr_auc'], ascending=False)
    best_name = summary_df.iloc[0]['model']
    best = results[best_name]

    # Threshold selection per spec: maximize precision with recall >= 0.9
    thr = select_threshold_by_precision(y_test.values, best['y_scores'], min_recall=0.9)
    y_pred = (best['y_scores'] >= thr).astype(int)

    # Save model report
    report = {
        'best_model_name': best_name,
        'best_auc': float(best['auc']),
        'best_pr_auc': float(best['pr_auc']),
        'threshold_selected': float(thr)
    }
    pd.DataFrame(summary_df).to_csv(os.path.join(outdir, 'models_comparison.csv'), index=False)

    # Save logistic coefficients if logistic
    if 'logistic' in results:
        if isinstance(results['logistic']['model'], Pipeline):
            clf = results['logistic']['model'].named_steps['clf']
        else:
            clf = results['logistic']['model']
        if hasattr(clf, 'coef_'):
            coef = clf.coef_.ravel()
            coef_df = pd.DataFrame({'feature': features, 'coefficient': coef})
            coef_df.to_csv(os.path.join(outdir, 'logistic_coefficients.csv'), index=False)

    # Feature importance for tree models
    for name in ['rf', 'xgb']:
        if name in results:
            model = results[name]['model']
            if hasattr(model, 'feature_importances_'):
                fi = model.feature_importances_
                fi_df = pd.DataFrame({'feature': features, 'importance': fi}).sort_values('importance', ascending=False)
                fi_df.to_csv(os.path.join(outdir, f'{name}_feature_importance.csv'), index=False)

    # Confusion matrix and metrics at chosen threshold
    cm = confusion_matrix(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred)

    metrics_summary = {
        'precision': prec,
        'recall': rec,
        'confusion_matrix': cm.tolist()
    }
    # Save metrics
    with open(os.path.join(outdir, 'best_model_report.txt'), 'w') as f:
        f.write(str(report) + '\n')
        f.write('metrics:\n')
        f.write(str(metrics_summary) + '\n')

    # ROC curves for all models + individual plots
    aucs = {}
    plt.figure(figsize=(8,6))
    for name, res in results.items():
        try:
            fpr, tpr, _ = roc_curve(y_test, res['y_scores'])
            auc_val = auc(fpr, tpr)
            aucs[name] = float(auc_val)
            # Individual plot
            plt.figure(figsize=(6,6))
            plt.plot(fpr, tpr, label=f'{name} (AUC={auc_val:.3f})')
            plt.plot([0,1],[0,1],'--')
            plt.xlabel('FPR')
            plt.ylabel('TPR')
            plt.title(f'ROC curve - {name}')
            plt.grid(True)
            plt.legend(loc='lower right')
            plt.savefig(os.path.join(outdir, f'roc_{name}.png'))
            plt.close()
            # Add to combined plot
            plt.figure(1)
            plt.plot(fpr, tpr, label=f'{name} (AUC={auc_val:.3f})')
        except Exception as e:
            print(f'[WARN] ROC for {name} failed: {e}')

    # Combined ROC plot
    plt.figure(1)
    plt.plot([0,1],[0,1],'--', color='grey')
    plt.xlabel('FPR')
    plt.ylabel('TPR')
    plt.title('ROC curves - all models')
    plt.legend(loc='lower right')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, 'roc_all_models.png'))
    plt.close()

    # Save AUC summary
    auc_df = pd.DataFrame([{'model': k, 'auc': v} for k, v in aucs.items()]).sort_values('auc', ascending=False)
    auc_df.to_csv(os.path.join(outdir, 'models_auc_summary.csv'), index=False)

    # Precision-Recall curve for best model (unchanged)
    precision, recall, _ = precision_recall_curve(y_test, best['y_scores'])
    plt.figure(figsize=(6,6))
    plt.plot(recall, precision)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall curve - best model')
    plt.grid(True)
    plt.savefig(os.path.join(outdir, 'best_model_pr.png'))
    plt.close()

    # Save predictions for all observations using best model (apply to full df) model (apply to full df)
    full_scores = best['model'].predict_proba(df[features])[:,1]
    df_out = df[['bank_id', 'date']].copy()
    df_out['predicted_pd'] = full_scores
    df_out['predicted_label'] = (df_out['predicted_pd'] >= thr).astype(int)
    df_out.to_csv(os.path.join(outdir, 'pd_predictions.csv'), index=False)

    # Save best model
    joblib.dump(best['model'], os.path.join(outdir, f'best_model_{best_name}.joblib'))

    # Return summary
    return {'model_results': results, 'summary_df': summary_df, 'report': report, 'metrics': metrics_summary, 'outdir': outdir, 'aucs': aucs}


# ----------------- Interpretability / Feature effect analysis -----------------

def analyze_feature_effects(results, X_train, X_test, y_train, y_test, features, outdir='outputs'):
    """Додатковий аналіз сили та напряму впливу ознак для всіх моделей.
    Виводить:
      - для Logistic Regression: коефіцієнти і p-values (через statsmodels, якщо доступно)
      - для RandomForest та XGBoost: permutation importance + SHAP (strength: mean(|shap|); direction: mean(shap))
      - partial dependence plots для топ-3 ознак за mean(|shap|)
    Результати зберігаються у outdir/interpretability_*.csv/png
    """
    os.makedirs(outdir, exist_ok=True)
    from sklearn.inspection import permutation_importance, PartialDependenceDisplay
    # local imports that may be optional
    try:
        import shap
        shap_available = True
    except Exception:
        shap_available = False
    try:
        import statsmodels.api as sm
        sm_available = True
    except Exception:
        sm_available = False

    interp_summary_rows = []

    # --- Logistic: coefficients + optional statsmodels p-values ---
    if 'logistic' in results:
        mod = results['logistic']['model']
        if isinstance(mod, Pipeline):
            clf = mod.named_steps['clf']
            scaler = mod.named_steps.get('scaler', None)
        else:
            clf = mod
            scaler = None

        # coefficients (if available)
        if hasattr(clf, 'coef_'):
            coefs = clf.coef_.ravel()
            coef_df = pd.DataFrame({'feature': features, 'coef': coefs})
            # If scaler used, coefficients refer to scaled features; sign is preserved
            coef_df['abs_coef'] = coef_df['coef'].abs()
            coef_df = coef_df.sort_values('abs_coef', ascending=False)
            coef_df.to_csv(os.path.join(outdir, 'interpretability_logistic_coefficients.csv'), index=False)

            # Attempt statsmodels for p-values using same data (on training set)
            try:
                if sm_available:
                    Xtr = X_train.copy()
                    if scaler is not None:
                        # statsmodels expects unscaled data; standardize manually to match scikit if needed
                        Xtr_scaled = scaler.transform(Xtr)
                        Xtr = pd.DataFrame(Xtr_scaled, columns=features, index=Xtr.index)
                    Xtr = sm.add_constant(Xtr)
                    logit = sm.Logit(y_train, Xtr)
                    res_sm = logit.fit(disp=False)
                    pvals = res_sm.pvalues
                    coef_sm = res_sm.params
                    sm_df = pd.DataFrame({'feature': pvals.index, 'coef': coef_sm.values, 'pvalue': pvals.values})
                    sm_df.to_csv(os.path.join(outdir, 'interpretability_logistic_statsmodels.csv'), index=False)
                else:
                    # statsmodels not available
                    pass
            except Exception as e:
                print('[WARN] statsmodels Logit failed:', e)

            # Add summary rows
            for _, r in coef_df.iterrows():
                interp_summary_rows.append({'model': 'logistic', 'feature': r['feature'], 'measure': 'coef', 'value': float(r['coef'])})

    # --- Tree models: permutation importance + SHAP ---
    for name in ['rf', 'xgb']:
        if name in results:
            model = results[name]['model']
            # Permutation importance on test set
            try:
                perm = permutation_importance(model, X_test, y_test, n_repeats=30, random_state=0, n_jobs=-1)
                perm_means = perm.importances_mean
                perm_df = pd.DataFrame({'feature': features, 'perm_importance': perm_means})
                perm_df = perm_df.sort_values('perm_importance', ascending=False)
                perm_df.to_csv(os.path.join(outdir, f'interpretability_{name}_permutation_importance.csv'), index=False)
                for _, r in perm_df.iterrows():
                    interp_summary_rows.append({'model': name, 'feature': r['feature'], 'measure': 'perm_importance', 'value': float(r['perm_importance'])})
            except Exception as e:
                print(f'[WARN] permutation importance for {name} failed:', e)

            # SHAP analysis (preferred for direction + strength)
            if shap_available:
                try:
                    # use TreeExplainer for tree-based models
                    explainer = shap.TreeExplainer(model)
                    shap_values = explainer.shap_values(X_test)
                    # shap_values shape differs: for binary classification XGBoost returns array (2, n_samples, n_features) for some versions
                    # Normalize to 2D: use shap_values[1] if needed
                    if isinstance(shap_values, list) or (isinstance(shap_values, np.ndarray) and shap_values.ndim == 3):
                        sv = shap_values[1] if isinstance(shap_values, list) else shap_values[1]
                    else:
                        sv = shap_values
                    # mean absolute and mean signed
                    mean_abs = np.mean(np.abs(sv), axis=0)
                    mean_signed = np.mean(sv, axis=0)
                    shap_df = pd.DataFrame({'feature': features, 'shap_mean_abs': mean_abs, 'shap_mean_signed': mean_signed})
                    shap_df = shap_df.sort_values('shap_mean_abs', ascending=False)
                    shap_df.to_csv(os.path.join(outdir, f'interpretability_{name}_shap.csv'), index=False)

                    # Save SHAP summary plot (bar) and beeswarm
                    try:
                        plt.figure(figsize=(6,4))
                        shap.summary_plot(sv, X_test, plot_type='bar', show=False)
                        plt.tight_layout()
                        plt.savefig(os.path.join(outdir, f'interpretability_{name}_shap_bar.png'))
                        plt.close()
                    except Exception as e:
                        print(f'[WARN] shap bar plot failed for {name}:', e)

                    try:
                        plt.figure(figsize=(6,6))
                        shap.summary_plot(sv, X_test, show=False)
                        plt.tight_layout()
                        plt.savefig(os.path.join(outdir, f'interpretability_{name}_shap_beeswarm.png'))
                        plt.close()
                    except Exception as e:
                        print(f'[WARN] shap beeswarm plot failed for {name}:', e)

                    # Add to summary rows
                    for _, r in shap_df.iterrows():
                        interp_summary_rows.append({'model': name, 'feature': r['feature'], 'measure': 'shap_mean_abs', 'value': float(r['shap_mean_abs'])})
                        interp_summary_rows.append({'model': name, 'feature': r['feature'], 'measure': 'shap_mean_signed', 'value': float(r['shap_mean_signed'])})

                except Exception as e:
                    print(f'[WARN] SHAP analysis failed for {name}:', e)
            else:
                print('[WARN] shap not installed — SKIPPING SHAP analysis. Install via: pip install shap')

    # --- Aggregate summary and partial dependence for top features ---
    summary_df = pd.DataFrame(interp_summary_rows)
    if not summary_df.empty:
        summary_df.to_csv(os.path.join(outdir, 'interpretability_summary_long.csv'), index=False)
        # Pivot to wide table (mean across measures)
        pivot = summary_df.pivot_table(index=['model','feature'], columns='measure', values='value', aggfunc='mean').reset_index()
        pivot.to_csv(os.path.join(outdir, 'interpretability_summary_wide.csv'), index=False)

    # Partial dependence for top features (select top 3 by average shap_mean_abs across tree models, fallback to perm importance)
    try:
        # pick candidate features
        if shap_available and 'xgb' in results:
            df_sh = pd.read_csv(os.path.join(outdir, f'interpretability_xgb_shap.csv'))
            top_feats = df_sh.sort_values('shap_mean_abs', ascending=False)['feature'].tolist()[:3]
        elif os.path.exists(os.path.join(outdir, 'interpretability_rf_permutation_importance.csv')):
            dfp = pd.read_csv(os.path.join(outdir, 'interpretability_rf_permutation_importance.csv'))
            top_feats = dfp.sort_values('perm_importance', ascending=False)['feature'].tolist()[:3]
        else:
            top_feats = features[:3]

        for feat in top_feats:
            try:
                disp = PartialDependenceDisplay.from_estimator(results['xgb']['model'] if 'xgb' in results else (results['rf']['model'] if 'rf' in results else results['logistic']['model']), X_test, [feat])
                plt.tight_layout()
                plt.savefig(os.path.join(outdir, f'interpretability_pdp_{feat}.png'))
                plt.close()
            except Exception as e:
                print(f'[WARN] PDP failed for feature {feat}:', e)
    except Exception as e:
        print('[WARN] partial dependence generation failed:', e)

    print('Interpretability outputs saved to', outdir)
    return summary_df


def compute_directional_effects(results, df, features, outdir='outputs'):
    """Compute signed/directional effect of each feature for each model.
    Methods used (fallback chain):
      1. SHAP mean_signed (if shap available)
      2. Spearman correlation between feature and predicted probability
      3. Approximate PDP slope (linear fit on quantile-binned means)
    Output: outputs/directional_effects_summary.csv with columns:
      model, feature, shap_mean_signed, spearman_rho, spearman_p, pdp_slope, direction
    Direction is 'positive' if evidence of positive relation, 'negative' if negative, otherwise 'neutral'.
    """
    import scipy.stats as stats
    os.makedirs(outdir, exist_ok=True)
    X = df[features]
    directional = []

    # try SHAP first
    try:
        import shap
        shap_available = True
    except Exception:
        shap_available = False

    for name, res in results.items():
        model = res['model']
        # predict probabilities on df (full sample)
        try:
            probs = model.predict_proba(X)[:,1]
        except Exception as e:
            print(f'[WARN] model {name} predict_proba failed: {e}')
            continue

        # SHAP mean_signed if available and model supports it
        shap_mean_signed_map = {}
        if shap_available:
            try:
                explainer = shap.Explainer(model, X)
                sv = explainer(X)
                # sv.values shape: (n_samples, n_features) for Binary
                # take mean signed per feature
                mean_signed = np.mean(sv.values, axis=0)
                for feat, ms in zip(features, mean_signed):
                    shap_mean_signed_map[feat] = float(ms)
            except Exception as e:
                print(f'[WARN] shap explainer failed for {name}: {e}')

        # For each feature compute spearman and pdp_slope
        for feat in features:
            x = X[feat].values
            mask = (~np.isnan(x)) & (~np.isnan(probs))
            rho = np.nan
            pval = np.nan
            pdp_slope = np.nan
            if mask.sum() >= 5:
                try:
                    rho, pval = stats.spearmanr(x[mask], probs[mask])
                except Exception:
                    rho, pval = np.nan, np.nan
                # approximate PDP slope: bin into quantiles and fit linear
                try:
                    xb = pd.Series(x[mask])
                    pb = pd.Series(probs[mask])
                    bins = pd.qcut(xb, q=10, duplicates='drop')
                    grp = pd.DataFrame({'x': xb, 'p': pb, 'bin': bins})
                    mean = grp.groupby('bin').agg({'x':'mean','p':'mean'}).dropna()
                    if len(mean) >= 2:
                        coef = np.polyfit(mean['x'], mean['p'], 1)[0]
                        pdp_slope = float(coef)
                except Exception:
                    pdp_slope = np.nan

            shap_ms = shap_mean_signed_map.get(feat, np.nan)
            # combine evidence: positive if any (shap_ms>0 or rho>0 or pdp_slope>0)
            pos_votes = 0
            neg_votes = 0
            if not np.isnan(shap_ms):
                pos_votes += 1 if shap_ms > 0 else 0
                neg_votes += 1 if shap_ms < 0 else 0
            if not np.isnan(rho):
                pos_votes += 1 if rho > 0 else 0
                neg_votes += 1 if rho < 0 else 0
            if not np.isnan(pdp_slope):
                pos_votes += 1 if pdp_slope > 0 else 0
                neg_votes += 1 if pdp_slope < 0 else 0

            if pos_votes > neg_votes:
                direction = 'positive'
            elif neg_votes > pos_votes:
                direction = 'negative'
            else:
                direction = 'neutral'

            directional.append({
                'model': name,
                'feature': feat,
                'shap_mean_signed': float(shap_ms) if not np.isnan(shap_ms) else np.nan,
                'spearman_rho': float(rho) if not np.isnan(rho) else np.nan,
                'spearman_p': float(pval) if not np.isnan(pval) else np.nan,
                'pdp_slope': float(pdp_slope) if not np.isnan(pdp_slope) else np.nan,
                'direction': direction
            })

    dir_df = pd.DataFrame(directional)
    dir_df.to_csv(os.path.join(outdir, 'directional_effects_summary.csv'), index=False)
    print('Directional effects saved to', os.path.join(outdir, 'directional_effects_summary.csv'))

# ------------------------ Main CLI ------------------------

def main():
    parser = argparse.ArgumentParser(description='PD modeling pipeline — all-in-one run')
    parser.add_argument('--input', required=True, help='Path to banks_data.csv')
    parser.add_argument('--signal_quarters', type=int, default=4, help='Signal period in quarters')
    parser.add_argument('--outdir', default='outputs_1', help='Output directory')
    parser.add_argument('--oot_date', default=None, help='Out-of-time split date (YYYY-MM-DD). If provided, data before this date is training and after is test')
    parser.add_argument('--periods_per_year', type=int, default=4, help='Number of reporting periods per year (4 for quarterly)')
    parser.add_argument('--net_income_is_annual', choices=['yes','no'], default='yes', help='Whether net_income is annual (yes/no)')
    parser.add_argument('--run_interpret', action='store_true', help='If set, run interpretability analyses (SHAP/statsmodels).')
    args = parser.parse_args()

    print('Loading and preparing data...')
    net_income_annual_flag = True if args.net_income_is_annual == 'yes' else False
    df = load_and_prepare(args.input, signal_quarters=args.signal_quarters, periods_per_year=args.periods_per_year, net_income_is_annual=net_income_annual_flag)
    print('Data prepared. Sample:')
    print(df.head())

    # Choose features automatically: base + dynamics
    feature_cols = [
        'equity_to_assets', 'roa', 'reserves_to_loans', 'ldr', 'ln_assets',
        'roa_yoy_change', 'equity_to_assets_yoy_change', 'reserves_to_loans_yoy_change', 'ldr_yoy_change',
    ]
    # include vol columns with dynamic suffix
    vol_col = f'equity_to_assets_vol_{args.periods_per_year}p'
    vol_cols = [f'equity_to_assets_vol_{args.periods_per_year}p', f'roa_vol_{args.periods_per_year}p', f'reserves_to_loans_vol_{args.periods_per_year}p', f'ldr_vol_{args.periods_per_year}p']
    feature_cols += [c for c in vol_cols if c in df.columns]

    feature_cols = [c for c in feature_cols if c in df.columns]

    print('Training models with features:')
    print(feature_cols)

    res = build_and_evaluate(df, feature_cols, outdir=args.outdir, oot_date=args.oot_date)
    # Ensure model_results present for interpretability functions: build_and_evaluate now returns 'model_results' key,
    # but for backward compatibility, if it's not present attempt to recover models from res or wrap appropriately.
    if isinstance(res, dict) and 'model_results' in res:
        model_results = res['model_results']
    elif isinstance(res, dict):
        # maybe previous versions returned the models directly in the dict
        # collect keys that look like model keys
        candidate_keys = {k: v for k, v in res.items() if k in ['logistic','rf','xgb']}
        if candidate_keys:
            model_results = {k: res[k] for k in candidate_keys}
            res['model_results'] = model_results
        else:
            # fallback: set model_results = res to let interpretability functions try and fail gracefully
            model_results = res
            res['model_results'] = model_results
    else:
        model_results = res


    # If interpret requested, run feature effect analyses
    if args.run_interpret:
        print('Running interpretability analyses (may require shap, statsmodels)...')
        # We need X_train/X_test/y_train/y_test — re-create split similarly to build_and_evaluate
        X = df[feature_cols]
        y = df['Y']
        if args.oot_date is not None:
            oot_date = pd.to_datetime(args.oot_date)
            train_mask = df['date'] < oot_date
            X_train, X_test = X[train_mask], X[~train_mask]
            y_train, y_test = y[train_mask], y[~train_mask]
        else:
            X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.3, random_state=42)

        # call interpretability functions
        try:
            analyze_feature_effects(res, X_train, X_test, y_train, y_test, feature_cols, outdir=args.outdir)
        except Exception as e:
            print('[WARN] analyze_feature_effects failed:', e)
        try:
            compute_directional_effects(res, df[feature_cols + ['bank_id','date']] if 'bank_id' in df.columns else df, feature_cols, outdir=args.outdir)
        except Exception as e:
            print('[WARN] compute_directional_effects failed:', e)

    print('Done. Outputs saved to:', res['outdir'])
    print('Models comparison:')
    print(res['summary_df'])

if __name__ == '__main__':
    main()
