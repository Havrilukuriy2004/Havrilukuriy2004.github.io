"""
PD Modeling Pipeline v3.0
Дата: 24-08-2025
Опис: Повний Python-скрипт для побудови та валідації моделей прогнозування ймовірності дефолту банку
Вхід: banks_data.csv (див техзавдання)
Вихід: звіти по моделях, ROC/PR графіки, pd_predictions.csv, збережена найкраща модель

Інструкції: Запустіть у середовищі з встановленими бібліотеками: pandas, numpy, scikit-learn, xgboost, matplotlib, joblib
Пример: python pd_modeling_pipeline_v3.py --input banks_data.csv

"""

import argparse
import os
from datetime import timedelta
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    roc_auc_score, precision_recall_curve, auc, precision_score, recall_score,
    confusion_matrix, classification_report, average_precision_score, roc_curve
)
import matplotlib.pyplot as plt
import joblib
import xgboost as xgb

# ------------------------ Helpers ------------------------

def protected_divide(a, b):
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        res = np.where((b == 0) | ~np.isfinite(b), np.nan, a / b)
    return res


def safe_log(x):
    x = np.array(x, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        x = np.where(x <= 0, np.nan, x)
        return np.log(x)


# Threshold selection: maximize precision subject to recall >= min_recall
def select_threshold_by_precision(y_true, y_scores, min_recall=0.9):
    precisions, recalls, thresholds = precision_recall_curve(y_true, y_scores)
    # precision_recall_curve returns thresholds of length len(precisions)-1
    best_idx = None
    best_precision = -1
    best_threshold = 0.5
    for i, thr in enumerate(np.append(thresholds, 1.0)):
        prec = precisions[i]
        rec = recalls[i]
        if rec >= min_recall and prec > best_precision:
            best_precision = prec
            best_idx = i
            best_threshold = thr
    if best_idx is None:
        # fallback: choose threshold that maximizes F1
        f1s = 2 * (precisions * recalls) / (precisions + recalls + 1e-12)
        idx = np.nanargmax(f1s)
        # threshold corresponding to idx: thresholds[idx] (but handle last)
        if idx < len(thresholds):
            best_threshold = thresholds[idx]
        else:
            best_threshold = 0.5
    return best_threshold


# ------------------------ Data preparation ------------------------

def load_and_prepare(path, signal_quarters=4, date_format_dayfirst=True):
    df = pd.read_csv(path)
    # Ensure required columns exist
    required = ['bank_id', 'date', 'event', 'total_assets', 'equity', 'net_income', 'loans', 'deposits', 'total_reserves']
    for c in required:
        if c not in df.columns:
            raise ValueError(f"Відсутнє обов'язкове поле: {c}")

    # Parse dates (DD-MM-YYYY expected)
    df['date'] = pd.to_datetime(df['date'], dayfirst=date_format_dayfirst, errors='coerce')
    if df['date'].isna().any():
        raise ValueError('Деякі дати не вдалося розпарсити — перевірте формат DD-MM-YYYY')

    # Convert numeric fields
    num_fields = ['total_assets', 'equity', 'net_income', 'loans', 'deposits', 'total_reserves']
    for f in num_fields:
        df[f] = pd.to_numeric(df[f], errors='coerce')

    # Sort
    df = df.sort_values(['bank_id', 'date']).reset_index(drop=True)

    # Remove banks whose first record is D (creation scenario)
    first_events = df.groupby('bank_id').first().reset_index()[['bank_id', 'event']]
    banks_to_drop = first_events.loc[first_events['event'] == 'D', 'bank_id'].tolist()
    if banks_to_drop:
        df = df[~df['bank_id'].isin(banks_to_drop)].copy()

    # Identify default dates per bank (first occurrence of D)
    default_dates = df.loc[df['event'] == 'D'].groupby('bank_id')['date'].min()

    # Exclude observations at and after default date for each bank
    mask = []
    for idx, row in df.iterrows():
        bid = row['bank_id']
        d = row['date']
        if bid in default_dates.index:
            if d >= default_dates.loc[bid]:
                mask.append(False)
            else:
                mask.append(True)
        else:
            mask.append(True)
    df = df[pd.Series(mask, index=df.index)].copy()

    # Create Y label: for observations that fall within signal_quarters before default -> 1
    df['Y'] = 0
    delta = pd.DateOffset(months=signal_quarters * 3)
    for bid, d0 in default_dates.items():
        # Consider observations where date >= d0 - delta and date < d0
        cond = (df['bank_id'] == bid) & (df['date'] >= (d0 - delta)) & (df['date'] < d0)
        df.loc[cond, 'Y'] = 1

    # Feature engineering: base ratios
    df['equity_to_assets'] = protected_divide(df['equity'], df['total_assets'])
    df['roa'] = protected_divide(df['net_income'], df['total_assets'])
    df['reserves_to_loans'] = protected_divide(df['total_reserves'], df['loans'])
    df['ldr'] = protected_divide(df['loans'], df['deposits'])
    df['ln_assets'] = safe_log(df['total_assets'])

    # NOTE: use transform (not apply) to preserve the original index and avoid assignment/index-mismatch errors
    # Compute yoy change using shift(4) within each bank (quarterly frequency assumed)
    for feat in ['roa', 'equity_to_assets', 'reserves_to_loans', 'ldr']:
        df[f'{feat}_yoy_change'] = df.groupby('bank_id')[feat].transform(lambda s: s - s.shift(4))

    # Rolling volatility (std dev over last 4 quarters)
    for feat in ['equity_to_assets', 'roa', 'reserves_to_loans', 'ldr']:
        df[f'{feat}_vol_4q'] = df.groupby('bank_id')[feat].transform(lambda s: s.rolling(window=4, min_periods=1).std())

    # Impute remaining missing numeric values: use group median, fallback to global median
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if 'Y' in numeric_cols:
        numeric_cols.remove('Y')
    for col in numeric_cols:
        df[col] = df.groupby('bank_id')[col].transform(lambda s: s.fillna(s.median()))
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())

    # Final drop of any remaining NaN in features
    df = df.dropna(subset=['Y'])

    return df


# ------------------------ Modeling ------------------------

def build_and_evaluate(df, features, outdir='outputs', test_size=0.3, random_state=42, oot_date=None):
    os.makedirs(outdir, exist_ok=True)

    X = df[features]
    y = df['Y']

    # If out-of-time validation date provided -> split by date
    if oot_date is not None:
        oot_date = pd.to_datetime(oot_date)
        train_mask = df['date'] < oot_date
        X_train, X_test = X[train_mask], X[~train_mask]
        y_train, y_test = y[train_mask], y[~train_mask]
    else:
        X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=test_size, random_state=random_state)

    results = {}

    # 1) Logistic Regression
    pipe_log = Pipeline([('scaler', StandardScaler()), ('clf', LogisticRegression(class_weight='balanced', max_iter=1000))])
    param_grid_log = {
        'clf__C': [0.01, 0.1, 1.0, 10.0]
    }
    gs_log = GridSearchCV(pipe_log, param_grid_log, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_log.fit(X_train, y_train)
    best_log = gs_log.best_estimator_
    y_scores_log = best_log.predict_proba(X_test)[:,1]
    auc_log = roc_auc_score(y_test, y_scores_log)
    pr_auc_log = average_precision_score(y_test, y_scores_log)

    results['logistic'] = {'model': best_log, 'auc': auc_log, 'pr_auc': pr_auc_log, 'y_scores': y_scores_log}

    # 2) Random Forest
    rf = RandomForestClassifier(class_weight='balanced', n_jobs=-1, random_state=random_state)
    param_grid_rf = {
        'n_estimators': [100, 300],
        'max_depth': [5, 10, None]
    }
    gs_rf = GridSearchCV(rf, param_grid_rf, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_rf.fit(X_train, y_train)
    best_rf = gs_rf.best_estimator_
    y_scores_rf = best_rf.predict_proba(X_test)[:,1]
    auc_rf = roc_auc_score(y_test, y_scores_rf)
    pr_auc_rf = average_precision_score(y_test, y_scores_rf)

    results['rf'] = {'model': best_rf, 'auc': auc_rf, 'pr_auc': pr_auc_rf, 'y_scores': y_scores_rf}

    # 3) XGBoost
    xgb_clf = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=random_state)
    # scale_pos_weight = (n_neg / n_pos)
    pos = y_train.sum()
    neg = len(y_train) - pos
    scale_pos_weight = max(1.0, neg / max(1.0, pos))
    xgb_clf.set_params(scale_pos_weight=scale_pos_weight)
    param_grid_xgb = {
        'n_estimators': [100, 300],
        'max_depth': [3, 6],
        'learning_rate': [0.01, 0.1]
    }
    gs_xgb = GridSearchCV(xgb_clf, param_grid_xgb, scoring='roc_auc', cv=5, n_jobs=-1)
    gs_xgb.fit(X_train, y_train)
    best_xgb = gs_xgb.best_estimator_
    y_scores_xgb = best_xgb.predict_proba(X_test)[:,1]
    auc_xgb = roc_auc_score(y_test, y_scores_xgb)
    pr_auc_xgb = average_precision_score(y_test, y_scores_xgb)

    results['xgb'] = {'model': best_xgb, 'auc': auc_xgb, 'pr_auc': pr_auc_xgb, 'y_scores': y_scores_xgb}

    # Choose best model by AUC, break ties using PR-AUC
    summary = [(k, v['auc'], v['pr_auc']) for k, v in results.items()]
    summary_df = pd.DataFrame(summary, columns=['model', 'auc', 'pr_auc']).sort_values(['auc', 'pr_auc'], ascending=False)
    best_name = summary_df.iloc[0]['model']
    best = results[best_name]

    # Threshold selection per spec: maximize precision with recall >= 0.9
    thr = select_threshold_by_precision(y_test.values, best['y_scores'], min_recall=0.9)
    y_pred = (best['y_scores'] >= thr).astype(int)

    # Save model report
    report = {
        'best_model_name': best_name,
        'best_auc': float(best['auc']),
        'best_pr_auc': float(best['pr_auc']),
        'threshold_selected': float(thr)
    }
    pd.DataFrame(summary_df).to_csv(os.path.join(outdir, 'models_comparison.csv'), index=False)

    # Save logistic coefficients if logistic
    if 'logistic' in results:
        if isinstance(results['logistic']['model'], Pipeline):
            clf = results['logistic']['model'].named_steps['clf']
        else:
            clf = results['logistic']['model']
        if hasattr(clf, 'coef_'):
            coef = clf.coef_.ravel()
            coef_df = pd.DataFrame({'feature': features, 'coefficient': coef})
            coef_df.to_csv(os.path.join(outdir, 'logistic_coefficients.csv'), index=False)

    # Feature importance for tree models
    for name in ['rf', 'xgb']:
        if name in results:
            model = results[name]['model']
            if hasattr(model, 'feature_importances_'):
                fi = model.feature_importances_
                fi_df = pd.DataFrame({'feature': features, 'importance': fi}).sort_values('importance', ascending=False)
                fi_df.to_csv(os.path.join(outdir, f'{name}_feature_importance.csv'), index=False)

    # Confusion matrix and metrics at chosen threshold
    cm = confusion_matrix(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred)

    metrics_summary = {
        'precision': prec,
        'recall': rec,
        'confusion_matrix': cm.tolist()
    }
    # Save metrics
    with open(os.path.join(outdir, 'best_model_report.txt'), 'w') as f:
        f.write(str(report) + '\n')
        f.write('metrics:\n')
        f.write(str(metrics_summary) + '\n')

    # ROC and PR curves for best model
    fpr, tpr, _ = roc_curve(y_test, best['y_scores'])
    plt.figure(figsize=(6,6))
    plt.plot(fpr, tpr)
    plt.plot([0,1], [0,1], linestyle='--')
    plt.xlabel('FPR')
    plt.ylabel('TPR')
    plt.title('ROC curve - best model')
    plt.grid(True)
    plt.savefig(os.path.join(outdir, 'best_model_roc.png'))
    plt.close()

    precision, recall, _ = precision_recall_curve(y_test, best['y_scores'])
    plt.figure(figsize=(6,6))
    plt.plot(recall, precision)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall curve - best model')
    plt.grid(True)
    plt.savefig(os.path.join(outdir, 'best_model_pr.png'))
    plt.close()

    # Save predictions for all observations using best model (apply to full df)
    full_scores = best['model'].predict_proba(df[features])[:,1]
    df_out = df[['bank_id', 'date']].copy()
    df_out['predicted_pd'] = full_scores
    df_out['predicted_label'] = (df_out['predicted_pd'] >= thr).astype(int)
    df_out.to_csv(os.path.join(outdir, 'pd_predictions.csv'), index=False)

    # Save best model
    joblib.dump(best['model'], os.path.join(outdir, f'best_model_{best_name}.joblib'))

    # Return summary
    return {'summary_df': summary_df, 'report': report, 'metrics': metrics_summary, 'outdir': outdir}


# ------------------------ Main CLI ------------------------

def main():
    parser = argparse.ArgumentParser(description='PD modeling pipeline')
    parser.add_argument('--input', required=True, help='Path to banks_data.csv')
    parser.add_argument('--signal_quarters', type=int, default=4, help='Signal period in quarters')
    parser.add_argument('--outdir', default='outputs', help='Output directory')
    parser.add_argument('--oot_date', default=None, help='Out-of-time split date (YYYY-MM-DD). If provided, data before this date is training and after is test')
    args = parser.parse_args()

    print('Loading and preparing data...')
    df = load_and_prepare(args.input, signal_quarters=args.signal_quarters)
    print('Data prepared. Sample:')
    print(df.head())

    # Choose features automatically: base + dynamics
    feature_cols = [
        'equity_to_assets', 'roa', 'reserves_to_loans', 'ldr', 'ln_assets',
        'roa_yoy_change', 'equity_to_assets_yoy_change', 'reserves_to_loans_yoy_change', 'ldr_yoy_change',
        'equity_to_assets_vol_4q', 'roa_vol_4q', 'reserves_to_loans_vol_4q', 'ldr_vol_4q'
    ]
    # Ensure features exist in df
    feature_cols = [c for c in feature_cols if c in df.columns]

    print('Training models with features:')
    print(feature_cols)
    res = build_and_evaluate(df, feature_cols, outdir=args.outdir, oot_date=args.oot_date)

    print('Done. Outputs saved to:', res['outdir'])
    print('Models comparison:')
    print(res['summary_df'])

if __name__ == '__main__':
    main()
