import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import os
from tqdm import tqdm

# --- Глобальні Налаштування ---
# Вкажіть шлях до вашого файлу з даними
INPUT_CSV_PATH = 'interbank_modeling/network_data.csv'

# Папки для збереження результатів
OUTPUT_DIR_GRAVITY = 'interbank_modeling/outputs_by_date/scenario_1_gravity_sparse'
OUTPUT_DIR_LOW_PD = 'interbank_modeling/outputs_by_date/scenario_2_low_pd'
OUTPUT_DIR_HIGH_CAPITAL = 'interbank_modeling/outputs_by_date/scenario_3_high_capital'
OUTPUT_DIR_HOMOPHILY = 'interbank_modeling/outputs_by_date/scenario_4_homophily'

# --- Параметри Моделей ---
# Сценарій 1: Гравітаційна модель
SPARSITY_TARGET = 0.1

# Сценарій 2.1: Пріори на низький ПД
MAX_DEGREE_LOW_PD = 4

# Сценарій 2.2: Пріори на високу капіталізацію
MAX_DEGREE_HIGH_CAPITAL = 4

# Сценарій 4: Гомофілія за розміром активів
MAX_DEGREE_HOMOPHILY = 4


def load_and_prepare_data(filepath):
    """
    Завантажує та готує дані з CSV файлу.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Файл не знайдено: {filepath}. Будь ласка, перевірте шлях.")

    df = pd.read_csv(filepath, thousands=',')

    try:
        df['date'] = pd.to_datetime(df['date'], format='%Y %m')
    except ValueError as e:
        print(f"Помилка перетворення дати: {e}")
        print(
            "Будь ласка, переконайтеся, що всі дати у вашому файлі мають формат 'РІК ПРОБІЛ МІСЯЦЬ', наприклад '2010 1'.")
        raise

    duplicates = df[df.duplicated(subset=['date', 'bank_id'], keep=False)]
    if not duplicates.empty:
        print("ПОПЕРЕДЖЕННЯ: Знайдено дублікати записів для комбінацій date та bank_id.")
        print("Для кожної групи дублікатів залишаємо запис з найбільшим значенням 'total_assets'.")
        df = df.sort_values('total_assets', ascending=False)
        df = df.drop_duplicates(subset=['date', 'bank_id'], keep='first')

    df = df.sort_values(by=['date', 'bank_id']).reset_index(drop=True)

    required_cols = [
        'bank_id', 'date', 'pd', 'loans_to_banks', 'deposits_of_banks',
        'total_assets', 'equity_to_assets'
    ]
    if not all(col in df.columns for col in required_cols):
        missing = set(required_cols) - set(df.columns)
        raise ValueError(f"У вхідному файлі відсутні необхідні колонки: {missing}")

    print("Дані успішно завантажено та підготовлено.")
    return df


def reconstruct_gravity_sparse(df_t, sparsity=0.1):
    """
    Сценарій 1: Реконструює мережу за гравітаційною моделлю та робить її розрідженою.
    """
    df_t = df_t.set_index('bank_id')
    A = df_t['loans_to_banks']
    L = df_t['deposits_of_banks']
    sum_L = L.sum()

    if sum_L == 0:
        G = nx.DiGraph()
        G.add_nodes_from(df_t.index)
        return G

    W_dense = np.outer(A.values, L.values) / sum_L
    np.fill_diagonal(W_dense, 0)

    num_links_to_keep = int(sparsity * (len(df_t) * (len(df_t) - 1)))

    if num_links_to_keep > 0 and W_dense.size > 0:
        threshold = np.partition(W_dense.flatten(), -num_links_to_keep)[-num_links_to_keep]
    else:
        threshold = W_dense.max() + 1 if W_dense.size > 0 else 1

    W_sparse = np.where(W_dense >= threshold, W_dense, 0)

    G = nx.from_numpy_array(W_sparse, create_using=nx.DiGraph)
    nx.relabel_nodes(G, {i: bank_id for i, bank_id in enumerate(df_t.index)}, copy=False)

    return G


def reconstruct_with_priors(df_t, sort_by_col, ascending, max_degree):
    """
    Сценарій 2: Реконструює мережу на основі апріорних знань (низький ПД або високий капітал).
    """
    df_t = df_t.set_index('bank_id')
    A = df_t['loans_to_banks']
    L = df_t['deposits_of_banks']
    sum_L = L.sum()

    if sum_L == 0:
        G = nx.DiGraph()
        G.add_nodes_from(df_t.index)
        return G

    W_dense_np = np.outer(A.values, L.values) / sum_L
    W_gravity_dense_graph = nx.from_numpy_array(W_dense_np, create_using=nx.DiGraph)
    nx.relabel_nodes(W_gravity_dense_graph, {i: bank_id for i, bank_id in enumerate(df_t.index)}, copy=False)

    edgelist = []
    lenders = df_t

    for lender_id, lender_data in lenders.iterrows():
        potential_borrowers = lenders[lenders.index != lender_id]
        sorted_borrowers = potential_borrowers.sort_values(by=sort_by_col, ascending=ascending)
        top_partners = sorted_borrowers.head(max_degree)

        for borrower_id, _ in top_partners.iterrows():
            if W_gravity_dense_graph.has_edge(lender_id, borrower_id):
                weight = W_gravity_dense_graph[lender_id][borrower_id].get('weight', 0)
                if weight > 0:
                    edgelist.append((lender_id, borrower_id, weight))

    G = nx.DiGraph()
    G.add_weighted_edges_from(edgelist)
    G.add_nodes_from(lenders.index)

    return G


def reconstruct_homophily(df_t, max_degree):
    """
    Сценарій 4: Реконструює мережу на основі гомофілії (подібності за розміром активів).
    """
    df_t = df_t.set_index('bank_id')
    A = df_t['loans_to_banks']
    L = df_t['deposits_of_banks']
    sum_L = L.sum()

    if sum_L == 0:
        G = nx.DiGraph()
        G.add_nodes_from(df_t.index)
        return G

    W_dense_np = np.outer(A.values, L.values) / sum_L
    W_gravity_dense_graph = nx.from_numpy_array(W_dense_np, create_using=nx.DiGraph)
    nx.relabel_nodes(W_gravity_dense_graph, {i: bank_id for i, bank_id in enumerate(df_t.index)}, copy=False)

    edgelist = []
    lenders = df_t

    for lender_id, lender_data in lenders.iterrows():
        lender_assets = lender_data['total_assets']
        potential_borrowers = lenders[lenders.index != lender_id].copy()
        potential_borrowers['asset_diff'] = abs(potential_borrowers['total_assets'] - lender_assets)
        sorted_borrowers = potential_borrowers.sort_values(by='asset_diff', ascending=True)
        top_partners = sorted_borrowers.head(max_degree)

        for borrower_id, _ in top_partners.iterrows():
            if W_gravity_dense_graph.has_edge(lender_id, borrower_id):
                weight = W_gravity_dense_graph[lender_id][borrower_id].get('weight', 0)
                if weight > 0:
                    edgelist.append((lender_id, borrower_id, weight))

    G = nx.DiGraph()
    G.add_weighted_edges_from(edgelist)
    G.add_nodes_from(lenders.index)

    return G


def create_animation(graphs_over_time, dates, title, filename):
    """
    Створює та зберігає анімацію еволюції мережі у форматі GIF.
    Розмір вузла пропорційний логарифму активів.
    Колір вузла відображає ймовірність дефолту (PD).
    """
    if not graphs_over_time:
        print(f"Немає даних для створення анімації: {title}")
        return

    fig, ax = plt.subplots(figsize=(15, 15))

    all_nodes = sorted(list(set.union(*[set(g.nodes()) for g in graphs_over_time])))
    pos_graph = nx.Graph()
    pos_graph.add_nodes_from(all_nodes)

    # --- ОНОВЛЕНО: Використовуємо spring_layout з налаштованими параметрами для кращого вигляду ---
    # k - оптимальна відстань між вузлами. Збільшення k "розтягує" граф.
    # iterations - кількість ітерацій для стабілізації.
    pos = nx.spring_layout(pos_graph, seed=42, k=2.5, iterations=150)

    MIN_NODE_SIZE = 100
    MAX_NODE_SIZE = 5000

    global_min_pd = min(g.nodes[node].get('pd', 0) for g in graphs_over_time for node in g.nodes())
    global_max_pd = max(g.nodes[node].get('pd', 1) for g in graphs_over_time for node in g.nodes())

    cmap = plt.get_cmap('RdYlGn_r')
    norm = mcolors.Normalize(vmin=global_min_pd, vmax=global_max_pd)

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, orientation='vertical', fraction=0.046, pad=0.04)
    cbar.set_label('Ймовірність Дефолту (PD)', size=12)

    def update(frame):
        ax.clear()
        G = graphs_over_time[frame]
        date = dates[frame]
        date_title = date.strftime('%Y-%m')

        assets = np.array([G.nodes[node].get('total_assets', 0) for node in G.nodes()])
        log_assets = np.log1p(assets)
        min_log_assets = np.min(log_assets) if len(log_assets) > 0 else 0
        max_log_assets = np.max(log_assets) if len(log_assets) > 0 else 1

        node_sizes = []
        if max_log_assets > min_log_assets:
            normalized_assets = (log_assets - min_log_assets) / (max_log_assets - min_log_assets)
            node_sizes = normalized_assets * (MAX_NODE_SIZE - MIN_NODE_SIZE) + MIN_NODE_SIZE
        else:
            node_sizes = [(MIN_NODE_SIZE + MAX_NODE_SIZE) / 2 for _ in G.nodes()]

        node_colors = [cmap(norm(G.nodes[node].get('pd', 0))) for node in G.nodes()]

        edge_widths = [d['weight'] for _, _, d in G.edges(data=True)]
        if edge_widths:
            max_width = max(edge_widths) if max(edge_widths) > 0 else 1
            edge_widths = [w / max_width * 4 + 0.5 for w in edge_widths]

        nx.draw(G, pos, ax=ax, with_labels=True, node_color=node_colors,
                node_size=node_sizes,
                width=edge_widths,
                edge_color='gray',
                font_size=8,
                font_color='black',
                arrows=True,
                arrowstyle='->',
                arrowsize=12)

        ax.set_title(f"{title}\nДата: {date_title}", fontsize=20)

    ani = animation.FuncAnimation(fig, update, frames=len(graphs_over_time), interval=500)

    output_dir = os.path.dirname(filename)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print(f"Збереження анімації... {filename}")
    ani.save(filename, writer='pillow', fps=2)
    plt.close(fig)
    print("Анімацію збережено.")


def save_network_data(graphs_over_time, dates, output_dir):
    """
    Зберігає дані мережі (матриці суміжності та списки ребер) для кожного періоду.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print(f"Збереження даних мережі у папку: {output_dir}")
    for i, G in enumerate(tqdm(graphs_over_time, desc=f"Збереження {os.path.basename(output_dir)}")):
        date = dates[i]
        date_str = date.strftime('%Y_%m')

        adj_df = nx.to_pandas_adjacency(G, weight='weight')
        adj_df.to_csv(os.path.join(output_dir, f'adjacency_matrix_{date_str}.csv'))

        edgelist_df = nx.to_pandas_edgelist(G, source='source', target='target')
        edgelist_df.to_csv(os.path.join(output_dir, f'edgelist_{date_str}.csv'), index=False)
    print("Дані мережі збережено.")


def main():
    """
    Головна функція для запуску всього пайплайну.
    """
    try:
        df = load_and_prepare_data(INPUT_CSV_PATH)
    except (FileNotFoundError, ValueError) as e:
        print(f"Помилка: {e}")
        return

    unique_dates = sorted(df['date'].unique())

    print(f"Знайдено {len(unique_dates)} унікальних дат для аналізу.")

    graphs_gravity = []
    graphs_low_pd = []
    graphs_high_capital = []
    graphs_homophily = []

    for date in tqdm(unique_dates, desc="Реконструкція мереж по датах"):
        df_t = df[df['date'] == date].copy()

        G_gravity = reconstruct_gravity_sparse(df_t, sparsity=SPARSITY_TARGET)
        graphs_gravity.append(G_gravity)

        G_low_pd = reconstruct_with_priors(df_t, 'pd', ascending=True, max_degree=MAX_DEGREE_LOW_PD)
        graphs_low_pd.append(G_low_pd)

        G_high_capital = reconstruct_with_priors(df_t, 'equity_to_assets', ascending=False,
                                                 max_degree=MAX_DEGREE_HIGH_CAPITAL)
        graphs_high_capital.append(G_high_capital)

        G_homophily = reconstruct_homophily(df_t, max_degree=MAX_DEGREE_HOMOPHILY)
        graphs_homophily.append(G_homophily)

    all_graph_lists = [graphs_gravity, graphs_low_pd, graphs_high_capital, graphs_homophily]
    for graphs in all_graph_lists:
        for i, G in enumerate(graphs):
            date = unique_dates[i]
            data_for_date = df[df['date'] == date].set_index('bank_id')
            assets_data = data_for_date['total_assets'].to_dict()
            equity_ratio_data = data_for_date['equity_to_assets'].to_dict()
            pd_data = data_for_date['pd'].to_dict()
            nx.set_node_attributes(G, assets_data, 'total_assets')
            nx.set_node_attributes(G, equity_ratio_data, 'equity_to_assets')
            nx.set_node_attributes(G, pd_data, 'pd')

    create_animation(graphs_gravity, unique_dates, "Сценарій 1: Розріджена Гравітаційна Модель",
                     os.path.join(OUTPUT_DIR_GRAVITY, 'evolution_animation.gif'))
    create_animation(graphs_low_pd, unique_dates, "Сценарій 2: Пріоритет на Низький PD",
                     os.path.join(OUTPUT_DIR_LOW_PD, 'evolution_animation.gif'))
    create_animation(graphs_high_capital, unique_dates, "Сценарій 3: Пріоритет на Високу Капіталізацію",
                     os.path.join(OUTPUT_DIR_HIGH_CAPITAL, 'evolution_animation.gif'))
    create_animation(graphs_homophily, unique_dates, "Сценарій 4: Гомофілія (подібність за розміром)",
                     os.path.join(OUTPUT_DIR_HOMOPHILY, 'evolution_animation.gif'))

    save_network_data(graphs_gravity, unique_dates, OUTPUT_DIR_GRAVITY)
    save_network_data(graphs_low_pd, unique_dates, OUTPUT_DIR_LOW_PD)
    save_network_data(graphs_high_capital, unique_dates, OUTPUT_DIR_HIGH_CAPITAL)
    save_network_data(graphs_homophily, unique_dates, OUTPUT_DIR_HOMOPHILY)

    print("\nПайплайн першого етапу аналізу успішно завершено!")
    print(f"Результати для сценарію 1 збережено в: {OUTPUT_DIR_GRAVITY}")
    print(f"Результати для сценарію 2 збережено в: {OUTPUT_DIR_LOW_PD}")
    print(f"Результати для сценарію 3 збережено в: {OUTPUT_DIR_HIGH_CAPITAL}")
    print(f"Результати для сценарію 4 збережено в: {OUTPUT_DIR_HOMOPHILY}")


if __name__ == '__main__':
    main()
