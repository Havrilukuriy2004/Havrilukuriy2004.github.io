import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os
from tqdm import tqdm

# --- 1. ГОЛОВНІ НАЛАШТУВАННЯ ---

# Вкажіть шлях до вашого основного файлу з даними (для отримання equity, pd)
INPUT_CSV_PATH = 'interbank_modeling/network_data.csv'

# Вкажіть дати для аналізу (у форматі 'РІК-МІСЯЦЬ')
CRISIS_DATE_STR = '2014-07'
CURRENT_DATE_STR = '2025-04'

# Папки, звідки завантажувати реконструйовані мережі
BASE_INPUT_DIR = 'interbank_modeling/outputs_by_date'
SCENARIOS = {
    "Gravity": "scenario_1_gravity_sparse",
    "Low_PD": "scenario_2_low_pd",
    "High_Capital": "scenario_3_high_capital",
    "Homophily": "scenario_4_homophily"
}

# Папка для збереження результатів симуляцій та анімацій
BASE_OUTPUT_DIR = 'interbank_modeling/contagion_results_detailed_1'

# Параметри симуляції
LGD = 1.0  # Loss Given Default (1.0 = 100% втрат)


# --- 2. РЕАЛІЗАЦІЯ АЛГОРИТМІВ ЗАРАЖЕННЯ ---

def simulate_furfine(G, initial_shock_set, equity_map, lgd=1.0):
    """
    Симулює каскадні дефолти за алгоритмом Furfine.
    Повертає історію дефолтів по раундах та фінальні результати.
    """
    if not initial_shock_set or not any(node in G for node in initial_shock_set):
        return [set()], set(), 0.0

    defaulted_in_round = [initial_shock_set]
    all_defaulted = initial_shock_set.copy()
    current_equity = equity_map.copy()

    # --- ОНОВЛЕНО: Прямий розрахунок втрат ---
    total_loss = 0.0

    for round_num in range(1, len(G.nodes) + 1):
        newly_defaulted_this_round = set()
        banks_triggering_losses = defaulted_in_round[-1]

        for bank in set(G.nodes()) - all_defaulted:
            losses_this_round = 0
            for predecessor in G.predecessors(bank):
                if predecessor in banks_triggering_losses:
                    losses_this_round += G[predecessor][bank].get('weight', 0) * lgd

            if losses_this_round > 0:
                current_equity[bank] -= losses_this_round
                total_loss += losses_this_round  # Накопичуємо збитки

            if current_equity[bank] <= 0:
                newly_defaulted_this_round.add(bank)

        if not newly_defaulted_this_round:
            break

        defaulted_in_round.append(newly_defaulted_this_round)
        all_defaulted.update(newly_defaulted_this_round)

    return defaulted_in_round, all_defaulted, total_loss


def simulate_eisenberg_noe(G, equity_map, lgd=1.0, max_iter=100, tol=1e-6):
    """
    Симулює дефолти за алгоритмом Eisenberg-Noe.
    Повертає фінальний стан та результати.
    """
    bank_ids = list(G.nodes())
    if not bank_ids:
        return [set()], set(), 0.0

    p_bar = nx.to_numpy_array(G, nodelist=bank_ids, weight='weight')

    equity_vector = np.array([equity_map.get(b, 0) for b in bank_ids])
    total_nominal_obligations = p_bar.sum(axis=1)

    p_actual = p_bar.copy()

    for k in range(max_iter):
        p_prev = p_actual.copy()
        received_payments = p_prev.sum(axis=0)
        resources = np.maximum(0, equity_vector + received_payments)
        is_defaulted = (resources < total_nominal_obligations) & (total_nominal_obligations > 1e-9)

        for i in range(len(bank_ids)):
            if is_defaulted[i]:
                pro_rata = resources[i] / total_nominal_obligations[i] if total_nominal_obligations[i] > 1e-9 else 0
                p_actual[i, :] = p_bar[i, :] * pro_rata
            else:
                p_actual[i, :] = p_bar[i, :]

        if np.sum(np.abs(p_actual - p_prev)) < tol:
            break

    final_equity = equity_vector + p_actual.sum(axis=0) - p_actual.sum(axis=1)

    final_defaulted_mask = final_equity <= 0
    final_defaulted_set = {bank_ids[i] for i, is_def in enumerate(final_defaulted_mask) if is_def}

    # --- ОНОВЛЕНО: Коректний розрахунок втрат для E-N ---
    # Втрати = (сума номінальних зобов'язань) - (сума фактичних платежів)
    total_loss = np.sum(p_bar) - np.sum(p_actual)

    return [final_defaulted_set], final_defaulted_set, total_loss


# --- 3. ФУНКЦІЇ ВІЗУАЛІЗАЦІЇ ---

def create_contagion_animation(G, cascade_history, title, filename):
    """
    Створює та зберігає анімацію поширення зараження.
    """
    fig, ax = plt.subplots(figsize=(12, 12))
    pos = nx.spring_layout(G, seed=42, k=0.8, iterations=100)

    node_status = {node: 'healthy' for node in G.nodes()}
    if cascade_history and cascade_history[0]:
        for node in cascade_history[0]:
            node_status[node] = 'initial_shock'

    color_map = {'healthy': 'green', 'initial_shock': 'orange', 'contagion': 'red'}

    def update(frame):
        ax.clear()

        if frame > 0 and frame < len(cascade_history):
            for node in cascade_history[frame]:
                node_status[node] = 'contagion'

        colors = [color_map[node_status.get(node, 'healthy')] for node in G.nodes()]

        nx.draw(G, pos, ax=ax, with_labels=True, node_color=colors,
                node_size=800,
                width=0.5,
                edge_color='gray',
                font_size=8,
                arrows=True)

        round_num = frame
        total_defaulted = sum(len(s) for s in cascade_history[:frame + 1])
        ax.set_title(f"{title}\nРаунд: {round_num}, Загалом у дефолті: {total_defaulted}", fontsize=16)

    num_frames = len(cascade_history) if cascade_history and cascade_history[0] else 1
    ani = animation.FuncAnimation(fig, update, frames=num_frames, interval=1500)

    output_dir = os.path.dirname(filename)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print(f"Збереження анімації зараження... {filename}")
    ani.save(filename, writer='pillow')
    plt.close(fig)


# --- 4. ГОЛОВНИЙ ПАЙПЛАЙН ---

def main():
    """
    Головна функція для запуску симуляцій та анімацій.
    """
    try:
        df = pd.read_csv(INPUT_CSV_PATH, thousands=',')
        df['date'] = pd.to_datetime(df['date'], format='%Y %m')
    except (FileNotFoundError, ValueError) as e:
        print(f"Помилка завантаження даних: {e}")
        return

    dates_to_analyze = {
        "Crisis": pd.to_datetime(CRISIS_DATE_STR, format='%Y-%m'),
        "Current": pd.to_datetime(CURRENT_DATE_STR, format='%Y-%m')
    }

    if not os.path.exists(BASE_OUTPUT_DIR):
        os.makedirs(BASE_OUTPUT_DIR)

    report_data = []

    for period_name, date_obj in dates_to_analyze.items():
        print(f"\n--- АНАЛІЗ ПЕРІОДУ: {period_name.upper()} ({date_obj.strftime('%Y-%m')}) ---")

        df_t = df[df['date'] == date_obj]
        if df_t.empty:
            print(f"ПОПЕРЕДЖЕННЯ: Не знайдено даних для дати {date_obj.strftime('%Y-%m')}. Пропускаємо.")
            continue

        equity_map = df_t.set_index('bank_id')['equity'].to_dict()

        initial_shock_bank = df_t.loc[df_t['pd'].idxmax()]['bank_id']
        initial_shock_set = {initial_shock_bank}
        print(f"Початковий шок: дефолт банку {initial_shock_bank} (PD={df_t['pd'].max():.4f})")

        for scenario_name, scenario_folder in SCENARIOS.items():
            print(f"\n  Сценарій: {scenario_name}")

            date_str_file = date_obj.strftime('%Y_%m')
            edgelist_path = os.path.join(BASE_INPUT_DIR, scenario_folder, f"edgelist_{date_str_file}.csv")

            if not os.path.exists(edgelist_path):
                print(f"  ПОПЕРЕДЖЕННЯ: Файл мережі не знайдено: {edgelist_path}. Пропускаємо сценарій.")
                continue

            edge_df = pd.read_csv(edgelist_path)
            G = nx.from_pandas_edgelist(edge_df, source='source', target='target', edge_attr='weight',
                                        create_using=nx.DiGraph)
            G.add_nodes_from(df_t['bank_id'])

            # --- Симуляція Furfine ---
            furfine_cascade, furfine_final_set, furfine_loss = simulate_furfine(G, initial_shock_set, equity_map,
                                                                                lgd=LGD)
            print(f"    Furfine: {len(furfine_final_set)} дефолтів, Втрати капіталу: {furfine_loss:,.2f}")

            # --- Симуляція Eisenberg-Noe ---
            en_cascade, en_final_set, en_loss = simulate_eisenberg_noe(G, equity_map, lgd=LGD)
            print(f"    Eisenberg-Noe: {len(en_final_set)} дефолтів, Втрати капіталу: {en_loss:,.2f}")

            report_data.append({
                "Period": period_name, "Scenario": scenario_name, "Algorithm": "Furfine",
                "Initial_Shock": initial_shock_bank,
                "Total_Defaults": len(furfine_final_set),
                "Capital_Loss": furfine_loss,
                "Defaulted_Banks_List": "; ".join(map(str, sorted(list(furfine_final_set))))
            })
            report_data.append({
                "Period": period_name, "Scenario": scenario_name, "Algorithm": "Eisenberg-Noe",
                "Initial_Shock": initial_shock_bank,
                "Total_Defaults": len(en_final_set),
                "Capital_Loss": en_loss,
                "Defaulted_Banks_List": "; ".join(map(str, sorted(list(en_final_set))))
            })

            # --- Анімація для Furfine ---
            anim_filename_furfine = os.path.join(BASE_OUTPUT_DIR, f"anim_{period_name}_{scenario_name}_Furfine.gif")
            create_contagion_animation(G, furfine_cascade, f"Зараження Furfine\n{period_name} - {scenario_name}",
                                       anim_filename_furfine)

    report_df = pd.DataFrame(report_data)
    report_path = os.path.join(BASE_OUTPUT_DIR, "contagion_summary_report_detailed.csv")
    report_df.to_csv(report_path, index=False)
    print(f"\nДетальний зведений звіт збережено у: {report_path}")
    print("\n--- ПАЙПЛАЙН МОДЕЛЮВАННЯ ЗАРАЖЕННЯ ЗАВЕРШЕНО ---")


if __name__ == '__main__':
    main()
