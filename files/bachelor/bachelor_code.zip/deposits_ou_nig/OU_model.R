library(readxl)
library(dplyr)
library(ggplot2)
library(lubridate)
library(nlme)
library(stats)
library(forecast)
library(MASS)
library(tseries)
library(seasonal)
library(car)
library(extrafont)

windowsFonts(Arial = windowsFont("Arial"))
pdf(pdf_path, family = "Arial")

# === НАЛАШТУВАННЯ ШЛЯХІВ === #
output_folder <- "C:\\Users\\yurii\\OneDrive\\Документи\\university\\thesis_undergrad_2025\\OU_Model_Results_adv\\"
dir.create(output_folder, showWarnings = FALSE)

# === ЗАВАНТАЖЕННЯ ДАНИХ === #
df <- read_excel("C:\\Users\\yurii\\OneDrive\\Документи\\university\\thesis_undergrad_2025\\data_visualisation\\bank_FS_Prudentials\\data_for_r.xlsx")
df$report_date <- as.Date(paste0(df$report_date, "-01"), format="%Y-%m-%d")
df <- df %>% arrange(report_date, bank_name_ua)

# === ОБРОБКА ПРОПУЩЕНИХ ДАНИХ === #
df <- df %>% mutate(BS1_LiabilitiesDueCustomers = ifelse(BS1_LiabilitiesDueCustomers == 0, NA, BS1_LiabilitiesDueCustomers))
df <- df %>% group_by(bank_name_ua) %>% mutate(BS1_LiabilitiesDueCustomers = zoo::na.locf(BS1_LiabilitiesDueCustomers, na.rm = FALSE)) %>% ungroup()
df$log_deposits <- log(df$BS1_LiabilitiesDueCustomers)

# === ДОДАЄМО СУМАРНІ ДЕПОЗИТИ У СИСТЕМІ === #
df_system <- df %>% group_by(report_date) %>% summarise(BS1_LiabilitiesDueCustomers = sum(BS1_LiabilitiesDueCustomers, na.rm = TRUE))
df_system$log_deposits <- log(df_system$BS1_LiabilitiesDueCustomers)
df_system$bank_name_ua <- "Банківська система"
df <- bind_rows(df, df_system)

# === ОБЧИСЛЕННЯ ТРЕНДУ ДЛЯ СИСТЕМИ === #
df_system$time <- seq_along(df_system$report_date)
model <- lm(log_deposits ~ time, data=df_system)
df_system$trend <- predict(model)

# === ОПИСОВА СТАТИСТИКА === #
descriptive_stats <- df %>% summarise(
  Mean = mean(log_deposits, na.rm = TRUE),
  Median = median(log_deposits, na.rm = TRUE),
  Std_Dev = sd(log_deposits, na.rm = TRUE),
  Min = min(log_deposits, na.rm = TRUE),
  Max = max(log_deposits, na.rm = TRUE)
)

# === ОБЧИСЛЕННЯ МЕТРИК === #
metrics <- list(
  R2 = summary(model)$r.squared,
  Adjusted_R2 = summary(model)$adj.r.squared,
  AIC = AIC(model),
  BIC = BIC(model),
  p_value = summary(model)$coefficients[2, 4],
  MSE = mean(resid(model)^2),
  RMSE = sqrt(mean(resid(model)^2)),
  MAE = mean(abs(resid(model))),
  MAPE = mean(abs(resid(model) / df_system$log_deposits)) * 100,
  Durbin_Watson = durbinWatsonTest(model)$dw,
  Log_likelihood = logLik(model)
)

# === ФУНКЦІЯ ОЦІНКИ ПАРАМЕТРІВ OU === #
estimate_ou_params <- function(data) {
  ou_neg_log_likelihood <- function(params, data) {
    kappa <- params[1]
    theta <- params[2]
    sigma <- params[3]
    dt <- 1
    X <- head(data, -1)
    dX <- diff(data)
    mean_reverting_term <- kappa * (theta - X) * dt
    likelihoods <- -0.5 * log(2 * pi * sigma^2 * dt) - ((dX - mean_reverting_term)^2) / (2 * sigma^2 * dt)
    return(-sum(likelihoods))
  }
  initial_params <- c(0.1, mean(data, na.rm=TRUE), sd(data, na.rm=TRUE))
  opt_result <- optim(initial_params, ou_neg_log_likelihood, data=data, method="L-BFGS-B")
  return(opt_result$par)  # kappa, theta, sigma
}

# Оцінка параметрів OU для кожного банку
df_params <- df %>% group_by(bank_name_ua) %>% 
  filter(!is.na(log_deposits)) %>% 
  summarise(kappa = estimate_ou_params(log_deposits)[1],
            theta = estimate_ou_params(log_deposits)[2],
            sigma = estimate_ou_params(log_deposits)[3])

# === ПРОГНОЗИ === #
n_months <- 36
simulations <- 1000
dt <- 1

generate_forecast <- function(data) {
  params <- estimate_ou_params(data)
  simulated_paths <- matrix(0, nrow=n_months, ncol=simulations)
  simulated_paths[1, ] <- tail(data, 1)
  for (t in 2:n_months) {
    dW <- rnorm(simulations, mean=0, sd=sqrt(dt))
    simulated_paths[t, ] <- simulated_paths[t - 1, ] + params[1] * (params[2] - simulated_paths[t - 1, ]) * dt + params[3] * dW
  }
  return(exp(simulated_paths))
}

simulated_ns_deposits <- generate_forecast(df_system$log_deposits)
simulated_s_deposits <- generate_forecast(df_system$log_deposits - df_system$trend)

plot_pdf <- function(data, title, filename, output_folder = "plots/") {
  # Створюємо папку, якщо вона не існує
  if (!dir.exists(output_folder)) {
    dir.create(output_folder, recursive = TRUE)
  }
  
  pdf_path <- file.path(output_folder, filename)
  pdf(pdf_path, family = "Arial")  # Додаємо шрифт для коректного відображення
  
  # Автоматичне закриття PDF у разі помилки
  on.exit(dev.off(), add = TRUE)
  
  # Перевірка та очищення даних
  clean_data <- as.vector(data)
  clean_data <- clean_data[!is.na(clean_data) & is.finite(clean_data)]
  
  if (length(clean_data) == 0) {
    warning("Дані для побудови графіка пусті!")
    return(NULL)
  }
  
  # Побудова гістограми
  hist(clean_data, probability = TRUE, breaks = 30, col = "lightblue",
       main = title, xlab = "Обсяг депозитів", ylab = "Щільність")
  
  # Додаємо графік щільності (червоний)
  lines(density(clean_data), col = "red", lwd = 2)
  
  # Додаємо нормальний розподіл (зелений, пунктирний)
  curve(dnorm(x, mean = mean(clean_data), sd = sd(clean_data)), 
        add = TRUE, col = "green", lwd = 2, lty = 2)
}


# Використання оновленої функції
plot_pdf(simulated_s_deposits, "Ймовірнісна густина прогнозу (з сезонністю)", pdf_s.pdf")
plot_pdf(simulated_ns_deposits, "Ймовірнісна густина прогнозу (без сезонності)", "pdf_ns.pdf")



# === АНАЛІЗ ЧАСОВОГО РЯДУ ТА X-13 ARIMA SEATS === #
ts_data <- ts(df_system$log_deposits, frequency=12, start=c(year(min(df_system$report_date)), month(min(df_system$report_date))))
x13_result <- seas(ts_data)

# === ІСТОРИЧНА СИМУЛЯЦІЯ НА 1-3 РОКИ === #
historical_simulation <- simulate(x13_result, nsim=36, seed=123)

print("Результати збережено у 'OU_Model_Results_adv'")





