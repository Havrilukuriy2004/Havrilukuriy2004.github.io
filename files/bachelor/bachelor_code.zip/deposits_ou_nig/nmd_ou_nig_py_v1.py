import pandas as pd
import numpy as np
from scipy.stats import norminvgauss, t
from scipy.optimize import minimize, Bounds
from scipy.linalg import cholesky, solve_triangular, expm, logm
import statsmodels.api as sm
from statsmodels.tsa.api import VAR
import matplotlib.pyplot as plt
import warnings
import time
import traceback

# Додаємо openpyxl для роботи з Excel
try:
    import openpyxl
except ImportError:
    print("Будь ласка, встановіть бібліотеку openpyxl: pip install openpyxl")
    exit()


# --- 0. Допоміжні функції для конвертації параметрів OU <-> VAR ---
def params_var_to_ou(a_var, B_var, dt=1.0):
    """
    Конвертує параметри VAR(1) (a, B) у параметри неперервної моделі OU (mu_OU, Theta_OU).
    """
    n_vars = B_var.shape[0]
    I = np.eye(n_vars)
    try:
        log_B_var = logm(B_var)
        if np.iscomplexobj(log_B_var):
            warnings.warn(
                "Комплексні значення в logm(B_var) при конвертації VAR в OU. Використовується дійсна частина.")
            log_B_var = log_B_var.real

        Theta_OU = -log_B_var / dt

        if np.linalg.matrix_rank(I - B_var) < n_vars:
            warnings.warn(
                "Матриця (I - B_var) сингулярна або близька до сингулярної. Використовується псевдообернена для mu_OU.")
            mu_OU = np.linalg.pinv(I - B_var) @ a_var
        else:
            mu_OU = np.linalg.solve(I - B_var, a_var)

    except Exception as e:
        warnings.warn(f"Помилка в params_var_to_ou: {e}. Повертаються None для mu_OU, Theta_OU.")
        return None, None
    return mu_OU, Theta_OU


def params_ou_to_var(mu_OU, Theta_OU, dt=1.0):
    """
    Конвертує параметри неперервної моделі OU (mu_OU, Theta_OU) у параметри VAR(1) (a, B).
    """
    n_vars = Theta_OU.shape[0]
    I = np.eye(n_vars)
    try:
        B_var = expm(-Theta_OU * dt)
        a_var = (I - B_var) @ mu_OU
    except Exception as e:
        warnings.warn(f"Помилка в params_ou_to_var: {e}. Повертаються None для a_var, B_var.")
        return None, None
    return a_var, B_var


# --- 1. Функції для NIG Розподілу ---

def calculate_nig_params(gamma, beta, sigma_sq):
    """
    Обчислює повні параметри NIG (alpha, delta, mu) та параметри для scipy.stats.norminvgauss
    на основі gamma, beta, sigma_sq, забезпечуючи нульове середнє та задану дисперсію.
    """
    gamma_orig = gamma
    beta_orig = beta

    gamma = np.maximum(np.array(gamma).item() if isinstance(gamma, np.ndarray) and gamma.size == 1 else gamma, 1e-10)
    beta = np.array(beta).item() if isinstance(beta, np.ndarray) and beta.size == 1 else beta
    sigma_sq = np.maximum(
        np.array(sigma_sq).item() if isinstance(sigma_sq, np.ndarray) and sigma_sq.size == 1 else sigma_sq, 1e-10)

    alpha_sq = gamma ** 2 + beta ** 2
    alpha = np.sqrt(alpha_sq)

    if not (alpha > np.abs(beta) + 1e-9):
        beta_corrected = np.sign(beta) * alpha * 0.999
        alpha_sq_corrected = gamma ** 2 + beta_corrected ** 2
        alpha_corrected = np.sqrt(alpha_sq_corrected)

        if not (alpha_corrected > np.abs(beta_corrected) + 1e-9):
            beta_fallback = np.sign(beta) * gamma * 0.95
            alpha_fallback = np.sqrt(gamma ** 2 + beta_fallback ** 2)

            if not (alpha_fallback > np.abs(beta_fallback) + 1e-9):
                beta_near_zero = np.sign(beta) * gamma * 1e-4
                alpha_near_zero = np.sqrt(gamma ** 2 + beta_near_zero ** 2)
                if not (alpha_near_zero > np.abs(beta_near_zero) + 1e-9):
                    return None
                beta = beta_near_zero
                alpha = alpha_near_zero
            else:
                beta = beta_fallback
                alpha = alpha_fallback
        else:
            beta = beta_corrected
            alpha = alpha_corrected

    if alpha == 0:
        return None

    delta_val = (sigma_sq * (gamma ** 3)) / (alpha ** 2)
    delta = np.maximum(delta_val, 1e-15)
    mu = -(delta * beta) / gamma

    if not (np.isfinite(alpha) and np.isfinite(beta) and np.isfinite(delta) and np.isfinite(mu) and delta > 0):
        return None

    a_scipy = alpha * delta
    b_scipy = beta * delta

    return {
        'alpha': alpha, 'beta': beta, 'delta': delta, 'mu': mu,
        'gamma': gamma, 'sigma_sq': sigma_sq,
        'a_scipy': a_scipy, 'b_scipy': b_scipy, 'loc_scipy': mu, 'scale_scipy': delta
    }


def nig_pdf(x, params):
    """ Обчислює логарифм PDF NIG за допомогою scipy.stats.norminvgauss. """
    try:
        scale = np.maximum(params['scale_scipy'], 1e-15)
        return norminvgauss.logpdf(x, a=params['a_scipy'], b=params['b_scipy'],
                                   loc=params['loc_scipy'], scale=scale)
    except Exception as e:
        return np.full_like(x, -1e10)


def nig_rvs(n, params, dt=1.0):
    """
    Генерує випадкові числа NIG з урахуванням часового кроку dt.
    """
    if params is None or pd.isna(params.get('a_scipy')):
        raise ValueError(f"Invalid NIG parameters for rvs: {params}")

    loc_dt = params['loc_scipy'] * dt
    scale_dt = np.maximum(params['scale_scipy'] * dt, 1e-15)

    try:
        return norminvgauss.rvs(a=params['a_scipy'], b=params['b_scipy'],
                                loc=loc_dt, scale=scale_dt, size=n)
    except Exception as e:
        return np.zeros(n if isinstance(n, tuple) else (n,))


# --- 2. Спрощена оцінка параметрів (OLS + Cholesky) ---

def estimate_var_nig_simplified(X_ts):
    """
    Спрощена оцінка параметрів VAR(1) та початкових параметрів NIG.
    """
    n_obs, n_vars = X_ts.shape
    if n_obs <= n_vars + 1 + 5:
        warnings.warn(f"Недостатньо спостережень ({n_obs}) для спрощеної оцінки VAR. Потрібно > {n_vars + 1 + 5}.")
        return None

    model_sm = VAR(X_ts)
    try:
        results_sm = model_sm.fit(maxlags=1, ic=None)
        a_est = results_sm.params[0, :]
        B_est = results_sm.params[1:, :].T
        u_residuals = results_sm.resid
        Sigma_u_est = np.cov(u_residuals, rowvar=False)
    except Exception as e:
        warnings.warn(f"Помилка під час оцінки VAR за допомогою statsmodels: {e}. Спроба ручного OLS.")
        X_lagged = X_ts[:-1, :]
        X_current = X_ts[1:, :]
        X_lagged_const = sm.add_constant(X_lagged, prepend=True)

        if X_lagged_const.shape[0] < X_lagged_const.shape[1]:
            warnings.warn("Недостатньо залишкових спостережень для ручного OLS.")
            return None
        try:
            params_ols = np.linalg.lstsq(X_lagged_const, X_current, rcond=None)[0]
            a_est = params_ols[0, :]
            B_est = params_ols[1:, :].T
            u_residuals = X_current - X_lagged_const @ params_ols
            Sigma_u_est = np.cov(u_residuals, rowvar=False)
        except np.linalg.LinAlgError as lae:
            warnings.warn(f"Помилка LinAlgError в ручному OLS: {lae}")
            return None

    try:
        L_chol = cholesky(Sigma_u_est, lower=True)
    except np.linalg.LinAlgError:
        Sigma_u_est_reg = Sigma_u_est + np.eye(n_vars) * 1e-9
        try:
            L_chol = cholesky(Sigma_u_est_reg, lower=True)
        except np.linalg.LinAlgError:
            warnings.warn("Не вдалося зробити матрицю коваріацій позитивно визначеною навіть з поправкою.")
            return None

    sigma_est_diag_L = np.diag(L_chol)
    if np.any(np.abs(sigma_est_diag_L) < 1e-15):
        warnings.warn("Нульові діагональні елементи в L_chol. Неможливо обчислити S_est та sigma_est.")
        return None

    sigma_target_for_nig = np.maximum(sigma_est_diag_L, 1e-10)

    S_est = L_chol @ np.diag(1.0 / sigma_target_for_nig)
    np.fill_diagonal(S_est, 1.0)

    try:
        epsilon_residuals_for_nig_fit = np.linalg.solve(S_est, u_residuals.T).T
    except np.linalg.LinAlgError:
        warnings.warn("Матриця S_est (OLS) виявилася сингулярною при розрахунку epsilon для NIG.")
        return None

    nig_params_list = []
    for i in range(n_vars):
        eps_i = epsilon_residuals_for_nig_fit[:, i]
        sigma_sq_i_target = sigma_target_for_nig[i] ** 2
        skew_i = pd.Series(eps_i).skew()
        kurt_i = pd.Series(eps_i).kurtosis()

        if kurt_i > 0.1:
            gamma_i_est = np.sqrt(6 / max(kurt_i, 0.1))
            gamma_i_est = np.clip(gamma_i_est, 0.05, 10.0)
        else:
            gamma_i_est = 5.0

        beta_i_est = np.sign(skew_i) * min(abs(skew_i) * 0.4 * gamma_i_est, gamma_i_est * 0.95)

        nig_params_list.append({
            'gamma': gamma_i_est,
            'beta': beta_i_est,
            'sigma_sq': sigma_sq_i_target
        })

    return {
        'a': a_est, 'B': B_est, 'S': S_est,
        'sigma': sigma_target_for_nig,
        'NIG_params': nig_params_list,
        'Sigma_u_est': Sigma_u_est
    }


# --- 3. Функція Логарифмічної Правдоподібності (MLE) ---

def log_likelihood_var_nig(params_vec, X_ts, n_vars):
    """
    Обчислює ВІД'ЄМНУ логарифмічну правдоподібність для VAR(1)-NIG моделі.
    """
    n_obs_data = X_ts.shape[0]
    T_eff = n_obs_data - 1

    try:
        idx = 0
        a = params_vec[idx: idx + n_vars];
        idx += n_vars
        B_vec = params_vec[idx: idx + n_vars ** 2];
        idx += n_vars ** 2
        B = B_vec.reshape((n_vars, n_vars), order='F')

        n_S_params = n_vars * (n_vars - 1) // 2
        S_lower_params = params_vec[idx: idx + n_S_params];
        idx += n_S_params
        S = np.identity(n_vars)
        if n_S_params > 0:
            S[np.tril_indices(n_vars, k=-1)] = S_lower_params

        log_sigma_eps = params_vec[idx: idx + n_vars];
        idx += n_vars
        sigma_eps = np.exp(log_sigma_eps)
        sigma_sq_eps = sigma_eps ** 2

        log_gamma_nig = params_vec[idx: idx + n_vars];
        idx += n_vars
        gamma_nig = np.exp(log_gamma_nig)

        beta_nig = params_vec[idx: idx + n_vars];
        idx += n_vars

        X_lagged = X_ts[:-1, :]
        X_current = X_ts[1:, :]
        u_residuals = X_current - a - X_lagged @ B.T

        epsilon_residuals = np.linalg.solve(S, u_residuals.T).T

        total_log_lik = 0
        for i in range(n_vars):
            current_gamma = gamma_nig[i] if isinstance(gamma_nig, np.ndarray) else gamma_nig
            current_beta = beta_nig[i] if isinstance(beta_nig, np.ndarray) else beta_nig
            current_sigma_sq = sigma_sq_eps[i] if isinstance(sigma_sq_eps, np.ndarray) else sigma_sq_eps

            nig_full_params_i = calculate_nig_params(current_gamma, current_beta, current_sigma_sq)

            if nig_full_params_i is None:
                return 1e12

            log_pdf_i_values = nig_pdf(epsilon_residuals[:, i], nig_full_params_i)

            if np.any(~np.isfinite(log_pdf_i_values)):
                return 1e12

            total_log_lik += np.sum(log_pdf_i_values)

        if not np.isfinite(total_log_lik):
            return 1e12

        return -total_log_lik

    except (np.linalg.LinAlgError, ValueError, IndexError) as e:
        return 1e12

    # --- 4. Функція Оцінки Параметрів (Повна MLE) ---


def estimate_var_nig_mle(X_ts, initial_params_dict=None, maxiter=3000):
    """
    Оцінює параметри VAR(1)-NIG за допомогою MLE.
    """
    n_vars = X_ts.shape[1]

    if initial_params_dict is None:
        print("Використання спрощеної оцінки для отримання початкових значень MLE...")
        initial_params_dict = estimate_var_nig_simplified(X_ts)
        if initial_params_dict is None:
            warnings.warn("Спрощена оцінка не вдалася. Неможливо запустити MLE.")
            return None

    required_keys = ['a', 'B', 'S', 'sigma', 'NIG_params']
    if not all(key in initial_params_dict for key in required_keys):
        missing = [key for key in required_keys if key not in initial_params_dict]
        warnings.warn(f"Не вистачає ключів у initial_params_dict для MLE: {missing}")
        return None
    if not isinstance(initial_params_dict['NIG_params'], list) or len(initial_params_dict['NIG_params']) != n_vars:
        warnings.warn("initial_params_dict['NIG_params'] має бути списком словників довжини n_vars.")
        return None
    if not all(isinstance(p, dict) and 'gamma' in p and 'beta' in p and 'sigma_sq' in p
               for p in initial_params_dict['NIG_params']):
        warnings.warn("Не вистачає 'gamma', 'beta' або 'sigma_sq' у словниках initial_params_dict['NIG_params'].")
        return None

    try:
        S_init = initial_params_dict['S']
        if n_vars > 1 and S_init.shape == (n_vars, n_vars):
            S_init_lower_params = S_init[np.tril_indices(n_vars, k=-1)]
        else:
            S_init_lower_params = np.array([]) if n_vars > 1 else np.array([])

        initial_sigma_eps = np.array(initial_params_dict['sigma'])
        initial_gamma_nig = np.array([p['gamma'] for p in initial_params_dict['NIG_params']])
        initial_beta_nig = np.array([p['beta'] for p in initial_params_dict['NIG_params']])

        params0 = np.concatenate([
            initial_params_dict['a'],
            initial_params_dict['B'].flatten(order='F'),
            S_init_lower_params,
            np.log(np.maximum(initial_sigma_eps, 1e-10)),
            np.log(np.maximum(initial_gamma_nig, 1e-10)),
            initial_beta_nig
        ])
    except Exception as e:
        warnings.warn(f"Помилка формування початкового вектора параметрів для MLE: {e}")
        return None

    print("Запуск оптимізації MLE...")
    optim_method = 'Nelder-Mead'

    mle_result = minimize(
        log_likelihood_var_nig,
        params0,
        args=(X_ts, n_vars),
        method=optim_method,
        options={'maxiter': maxiter, 'disp': False,
                 'adaptive': True if optim_method == 'Nelder-Mead' else False,
                 'xatol': 1e-7, 'fatol': 1e-7}
    )

    if not mle_result.success or mle_result.fun > 1e9:
        warnings.warn(
            f"Оптимізація MLE ({optim_method}) не зійшлася або результат поганий: {mle_result.message}. Спроба з 'Powell'.")
        optim_method = 'Powell'
        mle_result = minimize(
            log_likelihood_var_nig,
            params0,
            args=(X_ts, n_vars),
            method=optim_method,
            options={'maxiter': maxiter * 2, 'disp': False, 'ftol': 1e-6}
        )
        if not mle_result.success:
            warnings.warn(f"Оптимізація MLE ({optim_method}) також не зійшлася: {mle_result.message}")

    print(
        f"Оптимізація MLE ({optim_method}) завершена. Статус: {mle_result.message}, Функція: {mle_result.fun:.4f}, Ітерацій: {mle_result.nit}")

    optimal_params_vec = mle_result.x
    idx = 0
    a_mle = optimal_params_vec[idx: idx + n_vars];
    idx += n_vars
    B_mle = optimal_params_vec[idx: idx + n_vars ** 2].reshape((n_vars, n_vars), order='F');
    idx += n_vars ** 2

    S_mle = np.identity(n_vars)
    n_S_params = n_vars * (n_vars - 1) // 2
    if n_S_params > 0:
        S_mle_lower = optimal_params_vec[idx: idx + n_S_params];
        idx += n_S_params
        S_mle[np.tril_indices(n_vars, k=-1)] = S_mle_lower

    log_sigma_eps_mle = optimal_params_vec[idx: idx + n_vars];
    idx += n_vars
    sigma_eps_mle = np.exp(log_sigma_eps_mle)
    sigma_sq_eps_mle = sigma_eps_mle ** 2

    log_gamma_nig_mle = optimal_params_vec[idx: idx + n_vars];
    idx += n_vars
    gamma_nig_mle = np.exp(log_gamma_nig_mle)
    beta_nig_mle = optimal_params_vec[idx: idx + n_vars];
    idx += n_vars

    nig_params_mle_list_output = []
    valid_final_nig_conversion = True
    for i in range(n_vars):
        gamma_i = gamma_nig_mle[i] if isinstance(gamma_nig_mle, np.ndarray) else gamma_nig_mle
        beta_i = beta_nig_mle[i] if isinstance(beta_nig_mle, np.ndarray) else beta_nig_mle
        sigma_sq_i = sigma_sq_eps_mle[i] if isinstance(sigma_sq_eps_mle, np.ndarray) else sigma_sq_eps_mle

        full_p_nig = calculate_nig_params(gamma_i, beta_i, sigma_sq_i)
        if full_p_nig is None:
            warnings.warn(
                f"Не вдалося обчислити фінальні параметри NIG для компонента {i + 1} з результатів MLE. gamma={gamma_i}, beta={beta_i}, sigma_sq={sigma_sq_i}")
            nig_params_mle_list_output.append({
                'gamma': gamma_i, 'beta': beta_i, 'sigma_sq': sigma_sq_i,
                'error_calculating': True
            })
            valid_final_nig_conversion = False
        else:
            nig_params_mle_list_output.append(full_p_nig)

    if not valid_final_nig_conversion:
        warnings.warn("Проблеми з обчисленням деяких фінальних параметрів NIG після MLE.")

    return {
        'a': a_mle, 'B': B_mle, 'S': S_mle,
        'sigma': sigma_eps_mle,
        'NIG_params': nig_params_mle_list_output,
        'mle_details': mle_result,
        'log_likelihood': -mle_result.fun if mle_result.success else np.nan,
        'Sigma_u_est': initial_params_dict.get('Sigma_u_est')
    }


# --- 5. Функція Симуляції Процесу ---

def simulate_ou_nig_paths(X0, a, B, S, nig_params_list, n_steps, n_paths, dt=1 / 12):
    """ Симулює траєкторії VAR(1)-NIG процесу. """
    n_vars = len(X0)
    sim_paths = np.zeros((n_steps + 1, n_vars, n_paths))
    sim_paths[0, :, :] = X0[:, np.newaxis]

    epsilon_sim = np.zeros((n_steps, n_vars, n_paths))
    for i in range(n_vars):
        params_i = nig_params_list[i]
        if params_i is None or params_i.get('error_calculating', False) or pd.isna(params_i.get('a_scipy')):
            raise ValueError(f"Параметри NIG для компонента {i + 1} відсутні або недійсні для симуляції: {params_i}")

        epsilon_sim[:, i, :] = nig_rvs(n=(n_steps, n_paths), params=params_i, dt=dt)

    for t in range(n_steps):
        current_X = sim_paths[t, :, :]
        u_t = S @ epsilon_sim[t, :, :]
        next_X = a[:, np.newaxis] + B @ current_X + u_t
        sim_paths[t + 1, :, :] = next_X

    return sim_paths


def simulate_var_gaussian_paths(X0, a, B, S, sigma_eps_vector, n_steps, n_paths, dt=1 / 12):
    """ Симулює траєкторії VAR(1) процесу з Гаусовими інноваціями. """
    n_vars = len(X0)
    sim_paths = np.zeros((n_steps + 1, n_vars, n_paths))
    sim_paths[0, :, :] = X0[:, np.newaxis]

    epsilon_sim = np.zeros((n_steps, n_vars, n_paths))
    for i in range(n_vars):
        epsilon_sim[:, i, :] = np.random.normal(loc=0, scale=sigma_eps_vector[i] * np.sqrt(dt),
                                                size=(n_steps, n_paths))
    for t in range(n_steps):
        current_X = sim_paths[t, :, :]
        u_t = S @ epsilon_sim[t, :, :]
        next_X = a[:, np.newaxis] + B @ current_X + u_t
        sim_paths[t + 1, :, :] = next_X
    return sim_paths


# --- 6. Функції Аналізу Ризиків (VaR, ES, TSL) ---
def calculate_expected_shortfall(data_for_tail, alpha_confidence, axis=1, is_loss=False):
    """
    Обчислює Expected Shortfall (ES) або Conditional VaR (CVaR).
    """
    if is_loss:
        var_val = np.quantile(data_for_tail, alpha_confidence, axis=axis, keepdims=True)
        condition = data_for_tail > var_val
    else:
        quantile_level = 1.0 - alpha_confidence
        var_val = np.quantile(data_for_tail, quantile_level, axis=axis, keepdims=True)
        condition = data_for_tail < var_val

    if data_for_tail.ndim == 1:
        tail_data = data_for_tail[condition.squeeze()]
        if tail_data.size > 0:
            return np.mean(tail_data)
        else:
            return var_val.item()
    else:
        es_vals = np.zeros(data_for_tail.shape[0])
        for t_step in range(data_for_tail.shape[0]):
            current_var_val = var_val[t_step, 0] if var_val.ndim > 1 and var_val.shape[1] > 0 else var_val[t_step]
            current_condition = (data_for_tail[t_step, :] > current_var_val) if is_loss else (
                        data_for_tail[t_step, :] < current_var_val)
            tail_data_t = data_for_tail[t_step, current_condition]

            if tail_data_t.size > 0:
                es_vals[t_step] = np.mean(tail_data_t)
            else:
                es_vals[t_step] = current_var_val
        return es_vals


def calculate_historical_min_relative_volume(historical_series_actual_volume):
    """ Розраховує історичний мінімальний відносний обсяг V_min(t)/V(0). """
    if not isinstance(historical_series_actual_volume, pd.Series):
        historical_series_actual_volume = pd.Series(historical_series_actual_volume)

    if historical_series_actual_volume.empty:
        return pd.Series(dtype=float)

    initial_vol = historical_series_actual_volume.iloc[0]
    if initial_vol == 0 or pd.isna(initial_vol):
        return pd.Series(np.nan, index=historical_series_actual_volume.index)

    min_so_far = historical_series_actual_volume.expanding(min_periods=1).min()
    min_relative_volume = min_so_far / initial_vol
    return min_relative_volume


def calculate_risk_measures(sim_paths_array, initial_volume, alpha_levels=[0.95, 0.99], volume_var_index=2):
    """ Розраховує VaR, ES та TSL для обсягу депозитів. """
    n_steps_plus_1, n_vars, n_paths = sim_paths_array.shape
    n_steps = n_steps_plus_1 - 1

    log_volume_sim = sim_paths_array[:, volume_var_index, :]
    volume_sim = np.exp(log_volume_sim)

    VaR_abs = {}
    ES_abs = {}

    for alpha_conf in alpha_levels:
        quantile_level = 1 - alpha_conf

        var_abs_t = np.quantile(volume_sim, quantile_level, axis=1)
        VaR_abs[f'VaR{int(alpha_conf * 100)}'] = var_abs_t

        es_abs_t = calculate_expected_shortfall(volume_sim, alpha_confidence=alpha_conf, axis=1, is_loss=False)
        ES_abs[f'ES{int(alpha_conf * 100)}'] = es_abs_t

    mean_volume = np.mean(volume_sim, axis=1)
    min_volume_to_t = np.minimum.accumulate(volume_sim, axis=0)
    TSL = {}
    for alpha_conf in alpha_levels:
        quantile_level = 1 - alpha_conf
        tsl_abs_val = np.quantile(min_volume_to_t, quantile_level, axis=1)
        TSL[f'TSL{int(alpha_conf * 100)}'] = tsl_abs_val / np.maximum(initial_volume, 1e-9)

    results_dict = {
        'TimeStep': np.arange(n_steps + 1),
        'MeanVolume': mean_volume,
        **VaR_abs,
        **ES_abs,
        **TSL
    }
    results_df = pd.DataFrame(results_dict)
    return results_df


# --- 7. Функції Стрес-тестування ---

def calculate_rdo(sim_paths_array, h_steps, alpha_rdo_quantile=0.999, volume_var_index=2):
    """
    Розраховує середній RDO (Relative Drawdown Objective).
    """
    n_steps_plus_1, n_vars, n_paths = sim_paths_array.shape
    if n_steps_plus_1 <= h_steps:
        warnings.warn("Недостатньо кроків симуляції для розрахунку RDO з горизонтом h_steps.")
        return {'mean_rdo': np.nan, 'rdo_per_t': None, 'var_ratio': None}

    log_volume_sim = sim_paths_array[:, volume_var_index, :]
    volume_sim = np.exp(log_volume_sim)

    if volume_sim[:-h_steps, :].shape[0] == 0:
        warnings.warn("Недостатньо даних для розрахунку співвідношення V(t+h)/V(t).")
        return {'mean_rdo': np.nan, 'rdo_per_t': None, 'var_ratio': None}

    denominator = np.maximum(volume_sim[:-h_steps, :], 1e-15)
    numerator = volume_sim[h_steps:, :]
    ratio_v_th_vt = numerator / denominator

    var_ratio_values = np.quantile(ratio_v_th_vt, 1 - alpha_rdo_quantile, axis=1)
    rdo_values = 1 - var_ratio_values

    finite_rdo_values = rdo_values[np.isfinite(rdo_values)]
    if len(finite_rdo_values) > 0:
        mean_rdo = np.mean(finite_rdo_values)
    else:
        mean_rdo = np.nan

    rdo_per_t_df = pd.DataFrame({
        'TimeStep': np.arange(n_steps_plus_1 - h_steps),
        'RDO': rdo_values,
        'VaR_Ratio': var_ratio_values
    })
    return {'mean_rdo': mean_rdo, 'rdo_per_t': rdo_per_t_df, 'var_ratio': var_ratio_values}


def stress_nig3_objective_for_rdo_calibration(params_to_optimize,
                                              target_rdo, h_steps, alpha_rdo_quantile,
                                              X0, a, B, S,
                                              nig_params_other_fixed_tuple,
                                              sigma_sq_stressed_component_fixed,
                                              n_steps_sim_calib, n_paths_sim_calib, dt_sim_calib,
                                              stressed_component_index,
                                              n_total_vars
                                              ):
    """ Цільова функція для оптимізації параметрів NIG для досягнення цільового RDO. """
    beta_stressed = params_to_optimize[0]
    gamma_stressed = np.exp(params_to_optimize[1])

    stressed_nig_component_params_full = calculate_nig_params(
        gamma=gamma_stressed, beta=beta_stressed, sigma_sq=sigma_sq_stressed_component_fixed
    )
    if stressed_nig_component_params_full is None:
        return 1e12

    full_nig_list_for_sim = [None] * n_total_vars
    current_other_idx = 0
    for i in range(n_total_vars):
        if i == stressed_component_index:
            full_nig_list_for_sim[i] = stressed_nig_component_params_full
        else:
            if current_other_idx < len(nig_params_other_fixed_tuple):
                full_nig_list_for_sim[i] = nig_params_other_fixed_tuple[current_other_idx]
                current_other_idx += 1
            else:
                warnings.warn("Помилка у формуванні списку NIG для RDO калібрування.")
                return 1e12

    if any(p is None for p in full_nig_list_for_sim):
        warnings.warn("Один або більше параметрів NIG є None у full_nig_list_for_sim під час RDO калібрування.")
        return 1e12

    try:
        sim_paths_for_rdo = simulate_ou_nig_paths(X0, a, B, S, full_nig_list_for_sim,
                                                  n_steps_sim_calib, n_paths_sim_calib, dt_sim_calib)
    except ValueError as ve:  # Якщо simulate_ou_nig_paths генерує помилку через невалідні NIG
        # warnings.warn(f"ValueError під час симуляції для RDO: {ve}")
        return 1e11
    except Exception as e:
        # warnings.warn(f"Загальна помилка симуляції для RDO: {e}")
        return 1e11

    rdo_result = calculate_rdo(sim_paths_for_rdo, h_steps, alpha_rdo_quantile, stressed_component_index)
    current_mean_rdo = rdo_result['mean_rdo']

    if not np.isfinite(current_mean_rdo):
        return 1e10  # RDO не розраховано

    error = (current_mean_rdo - target_rdo) ** 2

    # Додатковий штраф, якщо RDO не є позитивним (тобто не стрес)
    if current_mean_rdo < 0.01:  # Якщо RDO негативний або дуже малий
        error += (0.01 - current_mean_rdo) ** 2 * 1e6  # Дуже великий штраф

    # М'які штрафи для стабілізації параметрів
    if gamma_stressed < 1e-3:  # Дуже важкі хвости
        error += (1e-3 - gamma_stressed) ** 2 * 1e4
    if np.abs(beta_stressed) > gamma_stressed * 0.98:  # Дуже висока асиметрія
        error += (np.abs(beta_stressed) - gamma_stressed * 0.98) ** 2 * 1e4

    if not np.isfinite(error): error = 1e12  # Захист від NaN/Inf в error
    return error


def create_summary_risk_table(df_full_risk, dt_simulation, key_horizons_years):
    """ Створює зведену таблицю мір ризику для ключових горизонтів. """
    summary_list = []
    key_timesteps = [int(round(h_year / dt_simulation)) for h_year in key_horizons_years]
    max_sim_timestep = df_full_risk['TimeStep'].max()
    valid_timesteps = [ts for ts in key_timesteps if ts <= max_sim_timestep]

    if not valid_timesteps:
        warnings.warn("Немає валідних ключових горизонтів у межах симуляції для зведеної таблиці.")
        return pd.DataFrame()

    df_selected_horizons = df_full_risk[df_full_risk['TimeStep'].isin(valid_timesteps)].copy()

    if df_selected_horizons.empty:
        return pd.DataFrame()

    df_selected_horizons['HorizonYears'] = df_selected_horizons['TimeStep'] * dt_simulation
    df_selected_horizons.set_index('HorizonYears', inplace=True)

    cols_to_summarize = [col for col in df_full_risk.columns if
                         'VaR' in col or 'ES' in col or 'TSL' in col or 'MeanVolume' in col]
    summary_df = df_selected_horizons[cols_to_summarize]

    return summary_df.T


# --- 8. Основний скрипт ---

if __name__ == "__main__":

    start_time_total = time.time()
    N_VARS_EXPECTED = 3
    VOLUME_VAR_INDEX = 2
    MARKET_RATE_VAR_INDEX = 0

    excel_input_filename = "ukraine_nmd_data_v1.xlsx"
    excel_output_filename = "nmd_simulation_results_full_analysis_V2.xlsx"
    # Оновлено назви файлів для графіків
    plot_config = {
        "volume_forecasts_consolidated": "plot_volume_forecasts_consolidated_V2.png",
        "tsl_consolidated": "plot_tsl_consolidated_V2.png"
    }

    print("РОЗДІЛ: ЗАВАНТАЖЕННЯ ТА ОБРОБКА ДАНИХ")
    try:
        raw_data = pd.read_excel(excel_input_filename, engine='openpyxl')
        print(f"Файл '{excel_input_filename}' успішно завантажено.")
    except FileNotFoundError:
        print(f"ПОМИЛКА: Файл не знайдено: {excel_input_filename}");
        exit()
    except Exception as e:
        print(f"ПОМИЛКА при читанні файлу Excel '{excel_input_filename}': {e}");
        exit()

    required_cols = ["Date", "BankName", "MarketRate", "DepositRate", "Volume"]
    if not all(col in raw_data.columns for col in required_cols):
        missing = [col for col in required_cols if col not in raw_data.columns]
        print(f"ПОМИЛКА: Відсутні стовпці: {missing}");
        exit()

    try:
        input_data_full = raw_data.copy()
        input_data_full['Date'] = pd.to_datetime(input_data_full['Date'])
        for col in ['MarketRate', 'DepositRate', 'Volume']:
            if input_data_full[col].dtype == 'object':
                input_data_full[col] = input_data_full[col].astype(str).str.replace(',', '.', regex=False)
            input_data_full[col] = pd.to_numeric(input_data_full[col], errors='coerce')

        input_data_full.dropna(subset=required_cols, inplace=True)
        initial_rows = len(input_data_full)
        input_data_full = input_data_full[(input_data_full['Volume'] > 1e-6) & (input_data_full['DepositRate'] > 1e-10)]
        if len(input_data_full) < initial_rows:
            print(
                f"Видалено {initial_rows - len(input_data_full)} рядків з непозитивними/нульовими Volume/DepositRate або NaN.")
        input_data_full = input_data_full.sort_values(by=['Date', 'BankName'])
    except Exception as e:
        print(f"ПОМИЛКА при обробці типів даних: {e}");
        exit()

    if input_data_full.empty: print("ПОМИЛКА: Немає валідних даних після початкової обробки."); exit()

    print("Агрегування даних на рівень системи...")
    try:
        agg_data = input_data_full.copy()
        agg_data['WeightedRateSum'] = agg_data['DepositRate'] * agg_data['Volume']
        system_data = agg_data.groupby('Date').agg(
            MarketRate=('MarketRate', 'first'),
            WeightedRateSum=('WeightedRateSum', 'sum'),
            Volume=('Volume', 'sum'),
            NumBanks=('BankName', 'nunique')
        ).reset_index()
        system_data['DepositRate'] = np.where(system_data['Volume'] > 1e-9,
                                              system_data['WeightedRateSum'] / system_data['Volume'], 0)
        system_data.drop(columns=['WeightedRateSum'], inplace=True)
        system_data = system_data[(system_data['Volume'] > 1e-6) & \
                                  (system_data['DepositRate'] > 1e-10) & \
                                  np.isfinite(system_data['MarketRate']) & \
                                  np.isfinite(system_data['DepositRate'])]
        system_data = system_data.sort_values(by='Date').reset_index(drop=True)
    except Exception as e:
        print(f"ПОМИЛКА під час агрегації даних: {e}");
        exit()

    MIN_OBS_SYSTEM = 36
    if len(system_data) < MIN_OBS_SYSTEM:
        print(f"ПОМИЛКА: Недостатньо даних після агрегації ({len(system_data)}). Потрібно >= {MIN_OBS_SYSTEM}.");
        exit()
    print(f"Агреговані системні дані отримано для {len(system_data)} дат.")

    model_input_data = system_data.copy()
    try:
        model_input_data['LogDepositRate'] = np.log(model_input_data['DepositRate'])
        model_input_data['LogVolume'] = np.log(model_input_data['Volume'])
        model_input_data = model_input_data[np.isfinite(model_input_data['LogDepositRate']) & \
                                            np.isfinite(model_input_data['LogVolume'])]
    except Exception as e:
        print(f"ПОМИЛКА під час логарифмування агрегованих даних: {e}");
        exit()

    if len(model_input_data) < MIN_OBS_SYSTEM:
        print(f"ПОМИЛКА: Недостатньо системних даних після логарифмування ({len(model_input_data)}).");
        exit()

    X_ts_real = model_input_data[['MarketRate', 'LogDepositRate', 'LogVolume']].values
    n_vars_data = X_ts_real.shape[1]
    if n_vars_data != N_VARS_EXPECTED:
        print(f"ПОМИЛКА: Кількість змінних ({n_vars_data}) не відповідає очікуваній ({N_VARS_EXPECTED}).");
        exit()

    if len(system_data['Date']) > 1:
        time_diff_days = (system_data['Date'].iloc[1] - system_data['Date'].iloc[0]).days
        if 28 <= time_diff_days <= 31:
            dt_model = 1 / 12
            print(f"Визначено часовий крок моделі dt_model = {dt_model:.4f} років (місячні дані).")
        elif 80 <= time_diff_days <= 100:
            dt_model = 1 / 4
            print(f"Визначено часовий крок моделі dt_model = {dt_model:.4f} років (квартальні дані).")
        else:
            dt_model = 1 / 12
            warnings.warn(
                f"Не вдалося автоматично визначити частоту даних. Встановлено dt_model = {dt_model:.4f} (припущення про місячні дані).")
    else:
        dt_model = 1 / 12
        warnings.warn("Лише одне спостереження, dt_model встановлено за замовчуванням.")

    print("\nРОЗДІЛ: ОЦІНКА ПАРАМЕТРІВ МОДЕЛІ")
    start_time_estimation = time.time()

    initial_params_simplified = estimate_var_nig_simplified(X_ts_real)
    estimated_params_mle = None

    if initial_params_simplified:
        print("Спрощена оцінка параметрів (початкові значення для MLE) успішна.")
        try:
            estimated_params_mle = estimate_var_nig_mle(X_ts_real, initial_params_simplified, maxiter=7000)
        except Exception as e:
            print(f"КРИТИЧНА ПОМИЛКА під час виконання MLE: {e}")
            traceback.print_exc()
            print("Спроба продовжити зі спрощеними параметрами.")

    if estimated_params_mle is None and initial_params_simplified:
        print("MLE не вдалося або не було запущено, використовуються результати спрощеної оцінки.")
        estimated_params_mle = initial_params_simplified.copy()
        estimated_params_mle['mle_details'] = None
        estimated_params_mle['log_likelihood'] = np.nan
        nig_params_simplified_full_list = []
        for i, p_simple in enumerate(initial_params_simplified['NIG_params']):
            full_p = calculate_nig_params(p_simple['gamma'], p_simple['beta'], p_simple['sigma_sq'])
            if full_p is None:
                nig_params_simplified_full_list.append({**p_simple, 'error_calculating': True})
            else:
                nig_params_simplified_full_list.append(full_p)
        estimated_params_mle['NIG_params'] = nig_params_simplified_full_list
    elif estimated_params_mle is None and not initial_params_simplified:
        print("ПОМИЛКА: Спрощена оцінка також не вдалася. MLE не може бути запущено.");
        exit()

    end_time_estimation = time.time()
    print(f"Час оцінки параметрів: {end_time_estimation - start_time_estimation:.2f} сек.")

    if estimated_params_mle is None or estimated_params_mle.get('NIG_params') is None:
        print("ПОМИЛКА: Не вдалося оцінити параметри моделі.");
        exit()

    final_nig_params_valid = True
    for i, p_nig in enumerate(estimated_params_mle['NIG_params']):
        if p_nig is None or p_nig.get('error_calculating', False) or pd.isna(p_nig.get('a_scipy')):
            warnings.warn(f"Фінальні параметри NIG для компонента {i + 1} недійсні: {p_nig}")
            final_nig_params_valid = False
    if not final_nig_params_valid:
        print("ПОМИЛКА: Один або більше наборів фінальних параметрів NIG недійсні. Симуляція може не вдатися.");

    print("\nПідсумкові Оцінені Параметри Моделі (VAR-NIG):")
    print(f"  a (константа VAR): {estimated_params_mle['a']}")
    print(f"  B (матриця VAR):\n{estimated_params_mle['B']}")
    print(f"  S (матриця змішування):\n{estimated_params_mle['S']}")
    print(f"  sigma_eps (std dev для NIG/Gaussian ε_i): {estimated_params_mle['sigma']}")
    if estimated_params_mle.get('log_likelihood') is not None:
        print(f"  Логарифмічна правдоподібність (LL): {estimated_params_mle['log_likelihood']:.4f}")

    mu_OU_est, Theta_OU_est = params_var_to_ou(estimated_params_mle['a'], estimated_params_mle['B'], dt=dt_model)
    if mu_OU_est is not None and Theta_OU_est is not None:
        print("\n  Оцінені параметри неперервної моделі OU (з VAR):")
        print(f"  μ_OU (довгострокове середнє):\n{mu_OU_est}")
        print(f"  Θ_OU (матриця швидкості повернення до середнього):\n{Theta_OU_est}")
    else:
        print("\n  Не вдалося конвертувати VAR параметри в OU параметри.")

    print("\n  Оцінені параметри NIG для компонентів ε_i:")
    nig_summary_df = pd.DataFrame([
        {k: p.get(k, np.nan) for k in ['gamma', 'beta', 'alpha', 'delta', 'mu', 'sigma_sq']} if p and not p.get(
            'error_calculating') else {'error_calculating': True}
        for p in estimated_params_mle['NIG_params']
    ], index=[f'NIG_ε{i + 1}' for i in range(N_VARS_EXPECTED)])
    print(nig_summary_df)

    X0_sim_start = X_ts_real[-1, :]
    n_steps_sim = 12 * 10
    n_paths_sim = 10000
    dt_sim = dt_model
    initial_volume_actual = np.exp(X0_sim_start[VOLUME_VAR_INDEX])
    alpha_levels_risk = [0.95, 0.99, 0.999]

    all_scenario_results = {}

    print("\nРОЗДІЛ: БАЗОВИЙ СЦЕНАРІЙ СИМУЛЯЦІЇ (NIG)")
    if not final_nig_params_valid: print("ПОПЕРЕДЖЕННЯ: Симуляція базового сценарію з недійсними NIG параметрами!");

    try:
        paths_base_nig = simulate_ou_nig_paths(
            X0_sim_start, estimated_params_mle['a'], estimated_params_mle['B'], estimated_params_mle['S'],
            estimated_params_mle['NIG_params'], n_steps_sim, n_paths_sim, dt_sim
        )
        all_scenario_results['Base_NIG'] = calculate_risk_measures(
            paths_base_nig, initial_volume_actual, alpha_levels_risk, VOLUME_VAR_INDEX
        )
        print("Розрахунки для базового сценарію (NIG) завершені.")
    except Exception as e:
        print(f"ПОМИЛКА під час симуляції базового сценарію (NIG): {e}");
        traceback.print_exc();
        exit()

    print("\nРОЗДІЛ: БАЗОВИЙ СЦЕНАРІЙ СИМУЛЯЦІЇ (GAUSSIAN BENCHMARK)")
    try:
        sigma_eps_for_gaussian = estimated_params_mle['sigma']
        paths_base_gaussian = simulate_var_gaussian_paths(
            X0_sim_start, estimated_params_mle['a'], estimated_params_mle['B'], estimated_params_mle['S'],
            sigma_eps_for_gaussian,
            n_steps_sim, n_paths_sim, dt_sim
        )
        all_scenario_results['Base_Gaussian'] = calculate_risk_measures(
            paths_base_gaussian, initial_volume_actual, alpha_levels_risk, VOLUME_VAR_INDEX
        )
        print("Розрахунки для базового сценарію (Gaussian) завершені.")
    except Exception as e:
        print(f"ПОМИЛКА під час симуляції базового сценарію (Gaussian): {e}");
        traceback.print_exc()

    print("\nРОЗДІЛ: ЗВОРОТНЄ СТРЕС-ТЕСТУВАННЯ (КАЛІБРУВАННЯ NIG3 по RDO)")
    start_time_rdo_calib = time.time()

    target_rdo_calib = 0.50
    h_rdo_calib = int(12 * 0.5)
    alpha_rdo_q_calib = 0.999
    n_paths_rdo_calib = 2000
    n_steps_rdo_calib = n_steps_sim

    stressed_nig3_params_calibrated_rdo = None
    optim_res_rdo_calib = None
    rdo_calibration_details_dict = {}

    if final_nig_params_valid and \
            estimated_params_mle['NIG_params'][VOLUME_VAR_INDEX] and \
            not estimated_params_mle['NIG_params'][VOLUME_VAR_INDEX].get('error_calculating'):

        a_base_calib = estimated_params_mle['a']
        B_base_calib = estimated_params_mle['B']
        S_base_calib = estimated_params_mle['S']

        nig_params_other_fixed_list = [
            p for i, p in enumerate(estimated_params_mle['NIG_params']) if i != VOLUME_VAR_INDEX
        ]
        if not all(p and not p.get('error_calculating') for p in nig_params_other_fixed_list):
            warnings.warn("Не всі фіксовані параметри NIG для калібрації RDO валідні. Калібрація може бути неточною.")

        base_nig_volume_params = estimated_params_mle['NIG_params'][VOLUME_VAR_INDEX]
        sigma_sq_vol_fixed_calib = base_nig_volume_params['sigma_sq']

        initial_beta3_rdo = -0.5
        initial_gamma3_rdo = 1.0
        initial_guess_rdo_calib = np.array([initial_beta3_rdo, np.log(initial_gamma3_rdo)])

        print(
            f"Цільовий RDO для калібрування NIG компонента {VOLUME_VAR_INDEX + 1}: {target_rdo_calib}, Горизонт h={h_rdo_calib * dt_sim:.2f} років")

        nig_params_other_fixed_tuple_calib = tuple(nig_params_other_fixed_list)

        log_gamma_bounds = (np.log(0.05), np.log(10.0))
        beta_bounds = (-10.0, -0.01)
        rdo_bounds_lbfgsb = Bounds([beta_bounds[0], log_gamma_bounds[0]], [beta_bounds[1], log_gamma_bounds[1]])

        optim_method_rdo = 'L-BFGS-B'
        print(f"Спроба калібрування RDO з {optim_method_rdo}...")
        optim_res_rdo_calib = minimize(
            stress_nig3_objective_for_rdo_calibration,
            initial_guess_rdo_calib,
            args=(target_rdo_calib, h_rdo_calib, alpha_rdo_q_calib,
                  X0_sim_start, a_base_calib, B_base_calib, S_base_calib,
                  nig_params_other_fixed_tuple_calib,
                  sigma_sq_vol_fixed_calib,
                  n_steps_rdo_calib, n_paths_rdo_calib, dt_sim,
                  VOLUME_VAR_INDEX, N_VARS_EXPECTED),
            method=optim_method_rdo,
            bounds=rdo_bounds_lbfgsb,
            options={'maxiter': 300, 'disp': False, 'ftol': 1e-7, 'gtol': 1e-6}
        )

        temp_rdo_check = -999.0  # Ініціалізація на випадок, якщо перевірка не відбудеться
        if optim_res_rdo_calib.success:
            opt_beta_temp = optim_res_rdo_calib.x[0]
            opt_gamma_temp = np.exp(optim_res_rdo_calib.x[1])
            temp_nig_calib = calculate_nig_params(opt_gamma_temp, opt_beta_temp, sigma_sq_vol_fixed_calib)
            if temp_nig_calib:
                temp_nig_list = list(estimated_params_mle['NIG_params'])
                if VOLUME_VAR_INDEX < len(temp_nig_list):
                    temp_nig_list[VOLUME_VAR_INDEX] = temp_nig_calib
                    try:
                        paths_temp_check = simulate_ou_nig_paths(X0_sim_start, a_base_calib, B_base_calib, S_base_calib,
                                                                 temp_nig_list, n_steps_rdo_calib, n_paths_rdo_calib,
                                                                 dt_sim)
                        temp_rdo_check_result = calculate_rdo(paths_temp_check, h_rdo_calib, alpha_rdo_q_calib,
                                                              VOLUME_VAR_INDEX)
                        if temp_rdo_check_result and pd.notna(temp_rdo_check_result['mean_rdo']):
                            temp_rdo_check = temp_rdo_check_result['mean_rdo']
                    except Exception:
                        pass

        if not optim_res_rdo_calib.success or abs(temp_rdo_check - target_rdo_calib) > 0.05 or temp_rdo_check < 0.01:
            warnings.warn(
                f"Калібрування RDO ({optim_method_rdo}) не зійшлося адекватно (RDO: {temp_rdo_check:.4f}, Ціль: {target_rdo_calib:.4f}). Спроба з 'Powell'.")
            optim_method_rdo = 'Powell'
            x0_for_powell = optim_res_rdo_calib.x if optim_res_rdo_calib.success else initial_guess_rdo_calib
            optim_res_rdo_calib = minimize(
                stress_nig3_objective_for_rdo_calibration,
                x0_for_powell,
                args=(target_rdo_calib, h_rdo_calib, alpha_rdo_q_calib,
                      X0_sim_start, a_base_calib, B_base_calib, S_base_calib,
                      nig_params_other_fixed_tuple_calib,
                      sigma_sq_vol_fixed_calib,
                      n_steps_rdo_calib, n_paths_rdo_calib, dt_sim,
                      VOLUME_VAR_INDEX, N_VARS_EXPECTED),
                method=optim_method_rdo,
                options={'maxiter': 1000, 'disp': False, 'ftol': 1e-7}
            )

            if not optim_res_rdo_calib.success:
                warnings.warn(
                    f"Калібрування RDO ({optim_method_rdo}) також не зійшлося: {optim_res_rdo_calib.message}. Спроба з 'Nelder-Mead'.")
                optim_method_rdo = 'Nelder-Mead'
                x0_for_nm = optim_res_rdo_calib.x if optim_res_rdo_calib.success else initial_guess_rdo_calib
                optim_res_rdo_calib = minimize(
                    stress_nig3_objective_for_rdo_calibration,
                    x0_for_nm,
                    args=(target_rdo_calib, h_rdo_calib, alpha_rdo_q_calib,
                          X0_sim_start, a_base_calib, B_base_calib, S_base_calib,
                          nig_params_other_fixed_tuple_calib,
                          sigma_sq_vol_fixed_calib,
                          n_steps_rdo_calib, n_paths_rdo_calib, dt_sim,
                          VOLUME_VAR_INDEX, N_VARS_EXPECTED),
                    method=optim_method_rdo,
                    options={'maxiter': 600, 'disp': False, 'adaptive': True, 'xatol': 1e-5, 'fatol': 1e-5}
                )

        rdo_calibration_details_dict['Optimizer'] = optim_method_rdo
        rdo_calibration_details_dict['Success'] = optim_res_rdo_calib.success if optim_res_rdo_calib else False
        rdo_calibration_details_dict['Message'] = optim_res_rdo_calib.message if optim_res_rdo_calib else "N/A"
        rdo_calibration_details_dict['Iterations'] = optim_res_rdo_calib.nit if optim_res_rdo_calib else "N/A"
        rdo_calibration_details_dict['FunctionValue'] = optim_res_rdo_calib.fun if optim_res_rdo_calib and hasattr(
            optim_res_rdo_calib, 'fun') else np.nan

        if optim_res_rdo_calib and optim_res_rdo_calib.success:
            opt_beta3 = optim_res_rdo_calib.x[0]
            opt_gamma3 = np.exp(optim_res_rdo_calib.x[1])
            stressed_nig3_params_calibrated_rdo = calculate_nig_params(opt_gamma3, opt_beta3, sigma_sq_vol_fixed_calib)
            print(
                f"Калібрування NIG по RDO ({optim_method_rdo}) успішне: beta={opt_beta3:.4f}, gamma={opt_gamma3:.4f}, func_val={optim_res_rdo_calib.fun:.4e}")
            rdo_calibration_details_dict.update({
                'Optimized_Beta_Vol': opt_beta3,
                'Optimized_Gamma_Vol': opt_gamma3,
                'Target_RDO': target_rdo_calib
            })

            nig_list_rdo_stressed = list(estimated_params_mle['NIG_params'])
            if stressed_nig3_params_calibrated_rdo:
                nig_list_rdo_stressed[VOLUME_VAR_INDEX] = stressed_nig3_params_calibrated_rdo
                paths_rdo_stress = simulate_ou_nig_paths(
                    X0_sim_start, a_base_calib, B_base_calib, S_base_calib, nig_list_rdo_stressed,
                    n_steps_sim, n_paths_sim, dt_sim
                )
                all_scenario_results['RDOCalibratedStress'] = calculate_risk_measures(
                    paths_rdo_stress, initial_volume_actual, alpha_levels_risk, VOLUME_VAR_INDEX
                )
                rdo_check = calculate_rdo(paths_rdo_stress, h_rdo_calib, alpha_rdo_q_calib, VOLUME_VAR_INDEX)
                achieved_rdo = rdo_check['mean_rdo']
                print(
                    f"  Перевірка RDO після калібрування (повна симуляція): {achieved_rdo:.4f} (цільовий: {target_rdo_calib:.4f})")
                rdo_calibration_details_dict['Achieved_RDO_FullSim'] = achieved_rdo
                if pd.notna(achieved_rdo) and achieved_rdo < 0:  # Додано перевірку на NaN
                    warnings.warn(
                        "Досягнутий RDO після калібрування є негативним, що може вказувати на проблеми з калібруванням стресу.")

            else:
                warnings.warn("Не вдалося обчислити валідні NIG параметри після RDO калібрування.")
                rdo_calibration_details_dict['Achieved_RDO_FullSim'] = np.nan
        else:
            warnings.warn(
                f"Калібрування NIG по RDO ({optim_method_rdo}) остаточно не зійшлося: {optim_res_rdo_calib.message if optim_res_rdo_calib else 'N/A'}")
            rdo_calibration_details_dict['Achieved_RDO_FullSim'] = np.nan
            rdo_calibration_details_dict.update({
                'Optimized_Beta_Vol': np.nan,
                'Optimized_Gamma_Vol': np.nan,
                'Target_RDO': target_rdo_calib
            })
    else:
        warnings.warn("Базові параметри NIG для обсягу невалідні, калібрування RDO пропущено.")
        rdo_calibration_details_dict.update({
            'Optimizer': "Skipped", 'Success': False, 'Message': "Base NIG params invalid",
            'Iterations': 0, 'FunctionValue': np.nan,
            'Optimized_Beta_Vol': np.nan, 'Optimized_Gamma_Vol': np.nan,
            'Target_RDO': target_rdo_calib, 'Achieved_RDO_FullSim': np.nan
        })

    print(f"Час калібрування RDO: {time.time() - start_time_rdo_calib:.2f} сек.")

    # --- 3. Форвардні Стрес-Сценарії (згідно з дослідженням) ---
    print("\nРОЗДІЛ: ФОРВАРДНІ СТРЕС-СЦЕНАРІЇ (S1, S2, S3-fixed, S4)")
    a_fwd_base = estimated_params_mle['a'].copy()
    B_fwd_base = estimated_params_mle['B'].copy()
    S_fwd_base = estimated_params_mle['S'].copy()
    nig_params_fwd_base = [p.copy() if p and not p.get('error_calculating') else None for p in
                           estimated_params_mle['NIG_params']]
    X0_fwd_base = X0_sim_start.copy()
    mu_OU_fwd_base, Theta_OU_fwd_base = (mu_OU_est.copy() if mu_OU_est is not None else None), \
        (Theta_OU_est.copy() if Theta_OU_est is not None else None)

    # --- S1: Шок ринкової ставки ---
    print("  Сценарій S1: Шок ринкової ставки (+200 bps)")
    X0_S1 = X0_fwd_base.copy()
    X0_S1[MARKET_RATE_VAR_INDEX] += 0.02  # +200 bps
    try:
        if not all(p and not p.get('error_calculating', False) for p in nig_params_fwd_base if
                   p is not None): raise ValueError("Невалідні базові NIG параметри для S1")
        paths_S1 = simulate_ou_nig_paths(X0_S1, a_fwd_base, B_fwd_base, S_fwd_base, nig_params_fwd_base, n_steps_sim,
                                         n_paths_sim, dt_sim)
        all_scenario_results['S1_MarketRateShock'] = calculate_risk_measures(paths_S1, np.exp(X0_S1[VOLUME_VAR_INDEX]),
                                                                             alpha_levels_risk, VOLUME_VAR_INDEX)
    except Exception as e:
        print(f"    ПОМИЛКА S1: {e}")

    # --- S2: Шок довгострокового середнього обсягу ---
    print("  Сценарій S2: Шок довгострокового середнього log-обсягу (-10% від V0)")
    a_S2, B_S2 = None, None  # Ініціалізація
    if mu_OU_fwd_base is not None and Theta_OU_fwd_base is not None:
        mu_OU_S2 = mu_OU_fwd_base.copy()
        log_volume_shock_s2 = np.log(0.90)
        mu_OU_S2[VOLUME_VAR_INDEX] += log_volume_shock_s2
        a_S2, B_S2 = params_ou_to_var(mu_OU_S2, Theta_OU_fwd_base, dt=dt_model)
        if a_S2 is not None and B_S2 is not None:
            try:
                if not all(p and not p.get('error_calculating', False) for p in nig_params_fwd_base if
                           p is not None): raise ValueError("Невалідні базові NIG параметри для S2")
                paths_S2 = simulate_ou_nig_paths(X0_fwd_base, a_S2, B_S2, S_fwd_base, nig_params_fwd_base, n_steps_sim,
                                                 n_paths_sim, dt_sim)
                all_scenario_results['S2_VolumeMeanShock'] = calculate_risk_measures(paths_S2, initial_volume_actual,
                                                                                     alpha_levels_risk,
                                                                                     VOLUME_VAR_INDEX)
            except Exception as e:
                print(f"    ПОМИЛКА S2: {e}")
        else:
            print("    ПОМИЛКА S2: Не вдалося конвертувати OU в VAR.")
    else:
        print("    ПОМИЛКА S2: Базові OU параметри відсутні.")

    # --- S3: Фіксований шок параметрів NIG для обсягу ---
    print("  Сценарій S3 (fixed): Шок параметрів NIG обсягу (gamma/2, beta-0.2)")
    nig_params_S3_fixed = [p.copy() if p else None for p in nig_params_fwd_base]
    nig_vol_S3_stressed = None  # Ініціалізація
    if nig_params_S3_fixed[VOLUME_VAR_INDEX] and not nig_params_S3_fixed[VOLUME_VAR_INDEX].get('error_calculating',
                                                                                               False):
        gamma_base_vol = nig_params_S3_fixed[VOLUME_VAR_INDEX]['gamma']
        beta_base_vol = nig_params_S3_fixed[VOLUME_VAR_INDEX]['beta']
        sigma_sq_base_vol = nig_params_S3_fixed[VOLUME_VAR_INDEX]['sigma_sq']

        gamma_S3 = gamma_base_vol * 0.5
        beta_S3 = beta_base_vol - 0.2

        nig_vol_S3_stressed = calculate_nig_params(gamma_S3, beta_S3, sigma_sq_base_vol)
        if nig_vol_S3_stressed:
            nig_params_S3_fixed[VOLUME_VAR_INDEX] = nig_vol_S3_stressed
            try:
                if not all(p and not p.get('error_calculating', False) for p in nig_params_S3_fixed if
                           p is not None): raise ValueError("Невалідні NIG параметри для S3")
                paths_S3_fixed = simulate_ou_nig_paths(X0_fwd_base, a_fwd_base, B_fwd_base, S_fwd_base,
                                                       nig_params_S3_fixed, n_steps_sim, n_paths_sim, dt_sim)
                all_scenario_results['S3_NIGFixedShock'] = calculate_risk_measures(paths_S3_fixed,
                                                                                   initial_volume_actual,
                                                                                   alpha_levels_risk, VOLUME_VAR_INDEX)
            except Exception as e:
                print(f"    ПОМИЛКА S3 (fixed): {e}")
        else:
            print("    ПОМИЛКА S3 (fixed): Не вдалося обчислити стресові NIG параметри.")
    else:
        print("    ПОМИЛКА S3 (fixed): Базові NIG параметри для обсягу відсутні або невалідні.")

    # --- S4: Комбінований шок (S1 + S2 + S3-fixed) ---
    print("  Сценарій S4: Комбінований шок (S1+S2+S3-fixed)")
    X0_S4 = X0_S1.copy() if 'X0_S1' in locals() else X0_fwd_base.copy()
    a_S4, B_S4 = (a_S2, B_S2) if 'a_S2' in locals() and a_S2 is not None else (a_fwd_base.copy(), B_fwd_base.copy())

    nig_params_S4 = [p.copy() if p else None for p in nig_params_fwd_base]
    if nig_vol_S3_stressed and nig_params_S4[VOLUME_VAR_INDEX]:
        nig_params_S4[VOLUME_VAR_INDEX] = nig_vol_S3_stressed.copy()

    try:
        if not all(
            p and not p.get('error_calculating', False) for p in nig_params_S4 if p is not None): raise ValueError(
            "Невалідні NIG параметри для S4")
        paths_S4 = simulate_ou_nig_paths(X0_S4, a_S4, B_S4, S_fwd_base.copy(), nig_params_S4, n_steps_sim, n_paths_sim,
                                         dt_sim)
        all_scenario_results['S4_CombinedShock'] = calculate_risk_measures(paths_S4, np.exp(X0_S4[VOLUME_VAR_INDEX]),
                                                                           alpha_levels_risk, VOLUME_VAR_INDEX)
    except Exception as e:
        print(f"    ПОМИЛКА S4: {e}")

    # --- Побудова Графіків ---
    print("\nРОЗДІЛ: ПОБУДОВА ГРАФІКІВ")
    if 'Base_NIG' not in all_scenario_results or all_scenario_results['Base_NIG'] is None:
        print("ПОМИЛКА: Результати базового сценарію (NIG) відсутні, графіки не будуть створені.");
        exit()

    sim_time_years = all_scenario_results['Base_NIG']['TimeStep'] * dt_sim
    historical_volumes_actual = np.exp(X_ts_real[:, VOLUME_VAR_INDEX])
    historical_min_rel_vol = calculate_historical_min_relative_volume(pd.Series(historical_volumes_actual))
    historical_time_plot = (model_input_data['Date'] - model_input_data['Date'].iloc[-1]).dt.days / 365.25

    # --- Консолідований графік прогнозів обсягу (NIG vs Gaussian) ---
    fig_vol, ax_vol = plt.subplots(figsize=(12, 7))

    # Історичні дані
    ax_vol.plot(historical_time_plot, historical_volumes_actual, label='Historical', color='tab:blue', linewidth=1.5,
                linestyle='-')

    # NIG Model Results
    if 'Base_NIG' in all_scenario_results and all_scenario_results['Base_NIG'] is not None:
        ax_vol.plot(sim_time_years, all_scenario_results['Base_NIG']['MeanVolume'], label='NIG-Mean',
                    color='darkorange', linestyle='-')  # Змінено на orange
        ax_vol.plot(sim_time_years, all_scenario_results['Base_NIG'][f'VaR{int(alpha_levels_risk[0] * 100)}'],
                    label=f'NIG-VaR{int(alpha_levels_risk[0] * 100)}%', color='turquoise',
                    linestyle='-')  # Змінено на turquoise
        ax_vol.plot(sim_time_years, all_scenario_results['Base_NIG'][f'VaR{int(alpha_levels_risk[1] * 100)}'],
                    label=f'NIG-VaR{int(alpha_levels_risk[1] * 100)}%', color='brown',
                    linestyle=':')  # Змінено на brown :

    # Gaussian Model Results
    if 'Base_Gaussian' in all_scenario_results and all_scenario_results['Base_Gaussian'] is not None:
        ax_vol.plot(sim_time_years, all_scenario_results['Base_Gaussian']['MeanVolume'], label='G-Mean', color='red',
                    linestyle='-.')
        ax_vol.plot(sim_time_years, all_scenario_results['Base_Gaussian'][f'VaR{int(alpha_levels_risk[0] * 100)}'],
                    label=f'G-VaR{int(alpha_levels_risk[0] * 100)}%', color='purple', linestyle='-')
        ax_vol.plot(sim_time_years, all_scenario_results['Base_Gaussian'][f'VaR{int(alpha_levels_risk[1] * 100)}'],
                    label=f'G-VaR{int(alpha_levels_risk[1] * 100)}%', color='lightgreen', linestyle='-.')

    ax_vol.set_title('Deposit volume')
    ax_vol.set_xlabel('Year')
    ax_vol.set_ylabel('Deposit volume (EUR bn)')  # Адаптуйте, якщо у вас інші одиниці
    ax_vol.grid(True)
    # Встановлення лімітів осей, як на прикладі (адаптуйте до ваших даних)
    # ax_vol.set_xlim([-18, 10])
    # ax_vol.set_ylim([0.4, 2.4])

    # --- Консолідований графік TSL ---
    fig_tsl, ax_tsl = plt.subplots(figsize=(12, 7))  # Створюємо окрему фігуру для TSL
    # Якщо потрібно на одному полотні, використовуйте fig, (ax1, ax2) = plt.subplots(1, 2)

    tsl_level_to_plot = int(alpha_levels_risk[1] * 100)  # TSL99%

    # Історичний TSL-like
    if not historical_min_rel_vol.empty:
        ax_tsl.plot(historical_time_plot, historical_min_rel_vol, label='Historical', color='tab:blue',
                    linestyle='-')  # Змінено на суцільну

    # Base NIG TSL
    if 'Base_NIG' in all_scenario_results and all_scenario_results['Base_NIG'] is not None:
        # Для NIG-VaR99% використовувався темно-червоний пунктир, TSL може бути іншим, але для відповідності використаємо його
        ax_tsl.plot(sim_time_years, all_scenario_results['Base_NIG'][f'TSL{tsl_level_to_plot}'],
                    label=f'NIG-VaR{tsl_level_to_plot}% (TSL)', color='brown', linestyle=':')

    # RDO Calibrated Stress TSL
    if 'RDOCalibratedStress' in all_scenario_results and all_scenario_results['RDOCalibratedStress'] is not None:
        # На зображенні немає окремої лінії для RDO TSL, але можна додати, якщо потрібно,
        # або припустити, що це одна з ліній NIG-VaR, якщо стрес впливає на ці параметри.
        # Для прикладу, використаємо колір G-VaR99%
        ax_tsl.plot(sim_time_years, all_scenario_results['RDOCalibratedStress'][f'TSL{tsl_level_to_plot}'],
                    label=f'TSL {tsl_level_to_plot}% (Стрес RDO)', color='lightgreen',
                    linestyle='-.')  # Приклад кольору

    # S4 Combined Shock TSL
    if 'S4_CombinedShock' in all_scenario_results and all_scenario_results['S4_CombinedShock'] is not None:
        # На зображенні немає окремої лінії для S4 TSL. Припустимо, це може бути G-VaR95%
        ax_tsl.plot(sim_time_years, all_scenario_results['S4_CombinedShock'][f'TSL{tsl_level_to_plot}'],
                    label=f'TSL {tsl_level_to_plot}% (Стрес S4)', color='purple', linestyle='-')  # Приклад кольору

    ax_tsl.set_title('TSL')
    ax_tsl.set_xlabel('Year')
    ax_tsl.set_ylabel('TSL')
    ax_tsl.grid(True)
    # Встановлення лімітів осей, як на прикладі
    # ax_tsl.set_xlim([-18, 10])
    # ax_tsl.set_ylim([0.3, 1.0])

    # Створення спільної легенди для обох графіків (приклад, якщо вони на одній фігурі)
    # Якщо графіки окремі, легенда для кожного своя. Для відповідності зображенню, зробимо окремі легенди.
    # Але на зображенні легенда спільна. Це складно зробити ідеально, якщо графіки зовсім різні.
    # Найпростіше - це мати легенду в одному з subplot'ів або спільну легенду під фігурою.

    # Легенда для першого графіка (Обсяг)
    lines_vol, labels_vol = ax_vol.get_legend_handles_labels()

    # Легенда для другого графіка (TSL) - додаємо лише ті лінії, які не дублюються з першого
    lines_tsl, labels_tsl = ax_tsl.get_legend_handles_labels()

    # Спроба створити спільну легенду, якщо графіки на одній фігурі
    # fig, axes = plt.subplots(1, 2, figsize=(18, 6))
    # ... (код для ax_vol -> axes[0], ax_tsl -> axes[1]) ...
    # lines = lines_vol + [l for l in lines_tsl if l not in lines_vol] # Уникаємо дублікатів
    # labels = labels_vol + [lab for i, lab in enumerate(labels_tsl) if lines_tsl[i] not in lines_vol]
    # fig.legend(lines, labels, loc='lower center', ncol=4, bbox_to_anchor=(0.5, -0.05))
    # fig.suptitle('Time evolution of deposit volume and TSL', fontsize=16)
    # fig.tight_layout(rect=[0, 0.05, 1, 0.95]) # Залишити місце для легенди
    # plt.savefig(plot_config["volume_forecasts_consolidated"]) # Зберегти спільну фігуру
    # plt.close(fig)

    # Оскільки запит був на відтворення, а легенда на зображенні одна, хоча графіки окремі,
    # найпростіший спосіб це відтворити - це просто додати легенду до кожного subplot'у
    # або, якщо легенда має бути абсолютно ідентичною, то потрібно вручну створити елементи легенди.
    # На зображенні легенда стосується обох. Давайте спробуємо додати повну легенду до правого графіка.

    # Додаємо легенду до кожного subplot окремо, а потім спробуємо створити одну фігуру
    # Для Обсягу (ax_vol)
    ax_vol.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)  # Легенда праворуч від графіка обсягу
    fig_vol.tight_layout(rect=[0, 0, 0.85, 1])  # Залишити місце для легенди праворуч
    fig_vol.savefig(plot_config["volume_forecasts_consolidated"]);
    plt.close(fig_vol)
    print(f"Графік {plot_config['volume_forecasts_consolidated']} збережено.")

    # Для TSL (ax_tsl)
    ax_tsl.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    fig_tsl.tight_layout(rect=[0, 0, 0.85, 1])
    fig_tsl.savefig(plot_config["tsl_consolidated"]);
    plt.close(fig_tsl)
    print(f"Графік {plot_config['tsl_consolidated']} збережено.")

    # --- Збереження Результатів у Excel ---
    print(f"\nРОЗДІЛ: ЗБЕРЕЖЕННЯ РЕЗУЛЬТАТІВ У {excel_output_filename}")
    try:
        with pd.ExcelWriter(excel_output_filename, engine='openpyxl') as writer:
            if 'system_data' in locals() and isinstance(system_data, pd.DataFrame):
                system_data.to_excel(writer, sheet_name='Input_Data_Aggregated', index=False)
                print("  - Аркуш 'Input_Data_Aggregated' збережено.")

            if estimated_params_mle:
                df_a = pd.DataFrame(estimated_params_mle['a'], index=[f'a{i + 1}' for i in range(N_VARS_EXPECTED)],
                                    columns=['Value'])
                df_B = pd.DataFrame(estimated_params_mle['B'],
                                    index=[f'B_eq{i + 1}' for i in range(N_VARS_EXPECTED)],
                                    columns=[f'B_var{j + 1}' for j in range(N_VARS_EXPECTED)])
                df_a.to_excel(writer, sheet_name='Estimated_VAR_Params', startrow=0, startcol=0)
                writer.sheets['Estimated_VAR_Params'].cell(row=df_a.shape[0] + 3, column=1,
                                                           value="Matrix B:")  # 1-based indexing
                df_B.to_excel(writer, sheet_name='Estimated_VAR_Params', startrow=df_a.shape[0] + 2, startcol=0)
                print("  - Аркуш 'Estimated_VAR_Params' збережено.")

                if mu_OU_est is not None and Theta_OU_est is not None:
                    df_mu_OU = pd.DataFrame(mu_OU_est, index=[f'mu_OU{i + 1}' for i in range(N_VARS_EXPECTED)],
                                            columns=['Value'])
                    df_Theta_OU = pd.DataFrame(Theta_OU_est,
                                               index=[f'Theta_eq{i + 1}' for i in range(N_VARS_EXPECTED)],
                                               columns=[f'Theta_var{j + 1}' for j in range(N_VARS_EXPECTED)])
                    df_mu_OU.to_excel(writer, sheet_name='Estimated_OU_Params', startrow=0, startcol=0)
                    writer.sheets['Estimated_OU_Params'].cell(row=df_mu_OU.shape[0] + 3, column=1,
                                                              value="Matrix Theta_OU:")
                    df_Theta_OU.to_excel(writer, sheet_name='Estimated_OU_Params', startrow=df_mu_OU.shape[0] + 2,
                                         startcol=0)
                    print("  - Аркуш 'Estimated_OU_Params' збережено.")

                nig_params_to_save = []
                for i, p_nig in enumerate(estimated_params_mle['NIG_params']):
                    row_data = {'Component': f'Epsilon_{i + 1}'}
                    if p_nig and not p_nig.get('error_calculating'):
                        row_data.update({
                            'gamma': p_nig.get('gamma'), 'beta': p_nig.get('beta'),
                            'alpha': p_nig.get('alpha'), 'delta': p_nig.get('delta'),
                            'mu': p_nig.get('mu'), 'sigma_sq_target': p_nig.get('sigma_sq'),
                            'sigma_eps_MLE': estimated_params_mle['sigma'][i] if estimated_params_mle[
                                                                                     'sigma'] is not None and i < len(
                                estimated_params_mle['sigma']) else np.nan
                        })
                    else:
                        row_data.update({'Error': 'Could not calculate'})
                    nig_params_to_save.append(row_data)
                df_nig_params = pd.DataFrame(nig_params_to_save)
                df_nig_params.to_excel(writer, sheet_name='Estimated_NIG_Params', index=False)
                print("  - Аркуш 'Estimated_NIG_Params' збережено.")

                sigma_u_to_save = estimated_params_mle.get('Sigma_u_est')
                df_Sigma_u_ref = None
                if sigma_u_to_save is not None:
                    df_Sigma_u_ref = pd.DataFrame(sigma_u_to_save,
                                                  index=[f'u_var{i + 1}' for i in range(N_VARS_EXPECTED)],
                                                  columns=[f'u_var{j + 1}' for j in range(N_VARS_EXPECTED)])
                    df_Sigma_u_ref.to_excel(writer, sheet_name='Covariance_S_Matrices', startrow=0, startcol=0,
                                            header=True, index=True)
                    # Виправлено row=1 для openpyxl
                    writer.sheets['Covariance_S_Matrices'].cell(row=1, column=df_Sigma_u_ref.shape[
                                                                                  1] + 3 if df_Sigma_u_ref is not None else 3,
                                                                value="Matrix S (from MLE):")

                df_S_mle = pd.DataFrame(estimated_params_mle['S'],
                                        index=[f'S_row{i + 1}' for i in range(N_VARS_EXPECTED)],
                                        columns=[f'S_col{j + 1}' for j in range(N_VARS_EXPECTED)])
                start_col_S = df_Sigma_u_ref.shape[1] + 2 if df_Sigma_u_ref is not None else 0
                df_S_mle.to_excel(writer, sheet_name='Covariance_S_Matrices', startrow=0, startcol=start_col_S,
                                  header=True, index=True)
                print("  - Аркуш 'Covariance_S_Matrices' збережено.")

                if rdo_calibration_details_dict:
                    df_rdo_calib = pd.Series(rdo_calibration_details_dict).to_frame('Value')
                    df_rdo_calib.to_excel(writer, sheet_name='RDO_Calibration_Details')
                    print("  - Аркуш 'RDO_Calibration_Details' збережено.")

            key_horizons_for_summary = [1 / 12, 3 / 12, 6 / 12, 1.0, 2.0, 5.0, 10.0]

            for scenario_name, df_res in all_scenario_results.items():
                if df_res is not None and isinstance(df_res, pd.DataFrame):
                    sheet_name_full = f'Risk_{scenario_name[:20]}'
                    sheet_name_summary = f'Summary_{scenario_name[:18]}'

                    df_res_copy = df_res.copy()
                    df_res_copy['TimeYears'] = df_res_copy['TimeStep'] * dt_sim
                    df_res_copy.to_excel(writer, sheet_name=sheet_name_full, index=False)

                    df_summary = create_summary_risk_table(df_res_copy, dt_sim, key_horizons_for_summary)
                    if not df_summary.empty:
                        df_summary.to_excel(writer, sheet_name=sheet_name_summary)

                    print(f"  - Аркуші '{sheet_name_full}' та '{sheet_name_summary}' збережено.")

        print(f"Результати успішно збережено.")
    except Exception as e:
        print(f"ПОМИЛКА при збереженні результатів у Excel: {e}");
        traceback.print_exc()

    plt.close('all')
    end_time_total = time.time()
    print(f"\nЗагальний час виконання скрипту: {end_time_total - start_time_total:.2f} сек.")
    print("Виконання скрипту завершено.")

