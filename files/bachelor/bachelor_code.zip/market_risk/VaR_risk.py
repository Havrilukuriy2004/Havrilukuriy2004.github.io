import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
from arch import arch_model
from statsmodels.tsa.regime_switching.markov_regression import MarkovRegression

# Load data
data = pd.read_csv('stock_prices.csv', sep=';', parse_dates=['Date'], dayfirst=True)
data.set_index('Date', inplace=True)
data.sort_index(inplace=True)

# Calculate returns
data['Returns'] = data['Close'].pct_change()
data.dropna(inplace=True)


# Function to calculate empirical VaR with bootstrapped confidence intervals
def empirical_var(returns, alpha, bootstrap_samples=1000):
    bootstrapped_vars = [np.percentile(np.random.choice(returns, size=len(returns), replace=True), 100 * alpha) for _ in
                         range(bootstrap_samples)]
    return np.percentile(bootstrapped_vars, 100 * alpha), (
    np.percentile(bootstrapped_vars, 2.5), np.percentile(bootstrapped_vars, 97.5))


# Calculate VaR using different models
var_results = {}
var_ci = {}

# (I) Stable Distribution
from scipy.stats import levy_stable

alpha, beta, loc, scale = levy_stable._fitstart(data['Returns'])
var_results['Stable_1%'] = levy_stable.ppf(0.01, alpha, beta, loc, scale)
var_results['Stable_5%'] = levy_stable.ppf(0.05, alpha, beta, loc, scale)

# (II) Pareto Distribution
shape, loc, scale = stats.pareto.fit(-data['Returns'])
var_results['Pareto_1%'] = -stats.pareto.ppf(0.01, shape, loc, scale)
var_results['Pareto_5%'] = -stats.pareto.ppf(0.05, shape, loc, scale)

# (III) GARCH-t Model with Monte Carlo simulation
am = arch_model(data['Returns'] * 10, vol='Garch', p=1, q=1, dist='t')  # Rescale to improve convergence
res = am.fit(disp='off')

omega = res.params['omega']
alpha = res.params['alpha[1]']
beta = res.params['beta[1]']
nu = res.params.get('nu', 8)

simulated_returns = np.zeros((500, 1000))
for i in range(500):
    eps = np.random.standard_t(nu, size=1000)
    sigma2 = np.zeros(1000)
    sigma2[0] = data['Returns'].var()

    for t in range(1, 1000):
        sigma2[t] = omega + alpha * (simulated_returns[i, t - 1] ** 2) + beta * sigma2[t - 1]
        simulated_returns[i, t] = eps[t] * np.sqrt(sigma2[t])

var_results['GARCH_1%'] = np.percentile(simulated_returns, 1)
var_results['GARCH_5%'] = np.percentile(simulated_returns, 5)

# (IV) Hidden Markov Model with regime classification
hmm_model = MarkovRegression(data['Returns'], k_regimes=2, trend='c', switching_variance=True)
hmm_res = hmm_model.fit()
regime_probs = hmm_res.smoothed_marginal_probabilities.idxmax(axis=1)
high_vol_regime = regime_probs.mode()[0]
data_high_vol = data['Returns'][regime_probs == high_vol_regime]
var_results['HMM_1%'], var_ci['HMM_1%'] = empirical_var(data_high_vol, 0.01)
var_results['HMM_5%'], var_ci['HMM_5%'] = empirical_var(data_high_vol, 0.05)

# Convert results to DataFrame
var_df = pd.DataFrame(var_results, index=['VaR']).T

# Plot results with Seaborn
fig, ax = plt.subplots(1, 2, figsize=(12, 5))
sns.barplot(x=var_df.loc[var_df.index.str.endswith('1%')].index, y=var_df.loc[var_df.index.str.endswith('1%')]['VaR'],
            ax=ax[0], palette='coolwarm')
ax[0].set_title('VaR at 1%')
sns.barplot(x=var_df.loc[var_df.index.str.endswith('5%')].index, y=var_df.loc[var_df.index.str.endswith('5%')]['VaR'],
            ax=ax[1], palette='coolwarm')
ax[1].set_title('VaR at 5%')

plt.tight_layout()
plt.show()