import pandas as pd
import numpy as np
import statsmodels.api as sm
from arch import arch_model
import matplotlib.pyplot as plt
from scipy.stats import t

# Load dataset with correct date parsing
df = pd.read_csv("processed_stock_data.csv", sep=";", parse_dates=["Date"], dayfirst=True)
df.set_index("Date", inplace=True)

# Compute log returns
df["StockReturn"] = np.log(df["StockPrice"] / df["StockPrice"].shift(1))
df["MarketReturn"] = np.log(df["MarketIndex"] / df["MarketIndex"].shift(1))

# Drop NaN values from first difference
df.dropna(inplace=True)

# Rescale returns for better GARCH convergence
df["StockReturn"] *= 100
df["MarketReturn"] *= 100

# Fit GARCH(1,1) model for Stock Returns
garch_stock = arch_model(df["StockReturn"], vol="Garch", p=1, q=1, mean="Constant", dist="t")
res_stock = garch_stock.fit(disp="off")

# Fit GARCH(1,1) model for Market Returns
garch_market = arch_model(df["MarketReturn"], vol="Garch", p=1, q=1, mean="Constant", dist="t")
res_market = garch_market.fit(disp="off")

# Set quantile level (5% for CoVaR)
q = 0.05

# Compute VaR for Stock for each date using the fitted Student-t distribution
nu = res_stock.params["nu"]  # Degrees of freedom of the fitted t-distribution
VaR_stock_series = res_stock.conditional_volatility * t.ppf(q, df=nu)

# Compute CoVaR using rolling quantile regression (MarketReturn ~ StockReturn)
CoVaR_series = []
CoVaR_median_series = []

window = 250  # Rolling window size (e.g., 1 year if daily data)
for i in range(window, len(df)):
    # Define rolling window data
    df_rolling = df.iloc[i - window:i]

    # Fit quantile regression for CoVaR
    X = sm.add_constant(df_rolling["StockReturn"])
    model = sm.QuantReg(df_rolling["MarketReturn"], X).fit(q=q)
    CoVaR = model.predict([1, VaR_stock_series.iloc[i]])

    # Fit median quantile regression for ΔCoVaR
    median_model = sm.QuantReg(df_rolling["MarketReturn"], X).fit(q=0.5)
    CoVaR_median = median_model.predict([1, df_rolling["StockReturn"].median()])

    # Store values
    CoVaR_series.append(CoVaR[0])
    CoVaR_median_series.append(CoVaR_median[0])

# Convert lists to Series with correct index
CoVaR_series = pd.Series(CoVaR_series, index=df.index[window:])
CoVaR_median_series = pd.Series(CoVaR_median_series, index=df.index[window:])
Delta_CoVaR_series = CoVaR_series - CoVaR_median_series

# Create DataFrame to store results
results_df = pd.DataFrame({
    "Date": df.index[window:],
    "StockReturn": df["StockReturn"].iloc[window:],
    "MarketReturn": df["MarketReturn"].iloc[window:],
    "VaR_Stock": VaR_stock_series.iloc[window:],
    "CoVaR": CoVaR_series,
    "CoVaR_Median": CoVaR_median_series,
    "Delta_CoVaR": Delta_CoVaR_series
}).set_index("Date")

# Export results to CSV
results_df.to_csv("CoVaR_results.csv", sep=";", index=True)
print("Results exported to CoVaR_results.csv")

# Plot Returns and CoVaR over time
plt.figure(figsize=(12, 6))
plt.plot(results_df.index, results_df["StockReturn"], label="Stock Return", color="black", alpha=0.5)
plt.plot(results_df.index, results_df["MarketReturn"], label="Market Return", color="gray", alpha=0.5)
plt.plot(results_df.index, results_df["CoVaR"], label="CoVaR (5%)", color="red")
plt.plot(results_df.index, results_df["CoVaR_Median"], label="Median CoVaR", color="blue", linestyle="dashed")
plt.fill_between(results_df.index, results_df["CoVaR_Median"], results_df["CoVaR"], color="red", alpha=0.3)
plt.title("Stock & Market Returns with CoVaR Over Time")
plt.xlabel("Date")
plt.ylabel("Returns / CoVaR")
plt.legend()
plt.grid()
plt.show()

# Print latest values
print(f"Latest Stock VaR ({q * 100}%): {results_df['VaR_Stock'].iloc[-1]:.4f}")
print(f"Latest CoVaR ({q * 100}%): {results_df['CoVaR'].iloc[-1]:.4f}")
print(f"Latest ΔCoVaR: {results_df['Delta_CoVaR'].iloc[-1]:.4f}")
