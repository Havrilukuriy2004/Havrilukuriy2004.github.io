# Необхідні бібліотеки
# Install packages if you don't have them
# install.packages("writexl")
# install.packages("ggplot2")
# install.packages("dplyr")
# install.packages("tidyr")

library(writexl) # Для експорту в Excel
library(ggplot2) # Для створення графіків
library(dplyr)   # Для маніпулювання даними
library(tidyr)   # Для маніпулювання даними

# --- Вкажіть цільову директорію для збереження файлів ---
# Використовуйте `path.expand` для коректної роботи з `~`
output_directory <- path.expand("~/university/thesis_undergrad_2025/HHI/MODEL")

# Створення директорії, якщо вона не існує (рекурсивно)
if (!dir.exists(output_directory)) {
  dir.create(output_directory, recursive = TRUE, showWarnings = FALSE)
  print(paste("Створено директорію:", output_directory))
} else {
  print(paste("Директорія для збереження:", output_directory))
}


# Функція для імітації системи стохастичних диференціальних рівнянь
simulate_system <- function(N, h, theta, sigma, T_sim, dt) {
  # N: кількість банків
  # h: параметр внутрішньої стабільності
  # theta: параметр кооперації
  # sigma: амплітуда зовнішнього шоку
  # T_sim: часовий горизонт (перейменовано з T, щоб уникнути конфлікту з функцією T())
  # dt: часовий крок
  
  num_steps <- T_sim / dt
  # Ініціалізація індексів ризику для кожного банку
  x <- matrix(nrow = N, ncol = num_steps + 1)
  x[, 1] <- -1 # Усі банки починають у безпечному стані
  
  # Імітація системи
  for (t in 1:num_steps) {
    # Обчислення емпіричного середнього ризиків
    x_bar <- mean(x[, t])
    
    # Оновлення індексів ризику для кожного банку
    for (j in 1:N) {
      dw <- rnorm(1, mean = 0, sd = sqrt(dt)) # Генеруємо випадковий шок
      # Рівняння Ланжевена для індексу ризику банку j
      dx_dt <- -h * (x[j, t]^3 - x[j, t]) + theta * (x_bar - x[j, t])
      x[j, t + 1] <- x[j, t] + dx_dt * dt + sigma * dw
    }
  }
  return(x)
}

# Функція для оцінки системного ризику
estimate_systemic_risk <- function(x, threshold) {
  # x: матриця індексів ризику з моделювання (Банки x Час)
  # threshold: поріг для визначення банкрутства банку (тут використовується для середнього)
  
  # Підрахунок кількості переходів системи з безпечного стану у стан банкрутства
  transitions <- 0
  N <- nrow(x)
  num_steps_plus_1 <- ncol(x)
  
  # Визначення безпечного та небезпечного станів системи на основі середнього індексу ризику
  system_state <- ifelse(mean(x[, 1]) < threshold, "safe", "failed") # Початковий стан
  
  for (t in 2:num_steps_plus_1) {
    current_mean_risk <- mean(x[, t])
    new_system_state <- ifelse(current_mean_risk < threshold, "safe", "failed")
    # Перевіряємо, чи система перейшла з безпечного стану в стан банкрутства
    if (system_state == "safe" && new_system_state == "failed") {
      transitions <- transitions + 1
    }
    system_state <- new_system_state # Оновлюємо стан системи
  }
  
  # Оцінка системного ризику як частоти переходів
  systemic_risk_prob <- transitions / (num_steps_plus_1 - 1)
  return(systemic_risk_prob)
}

# Функція для запуску моделювання та аналізу
run_simulation_and_analyze <- function(N, h, theta, sigma, T_sim, dt, threshold, scenario_name, save_dir) {
  # Запуск моделювання
  x <- simulate_system(N, h, theta, sigma, T_sim, dt) # Матриця N x (T/dt + 1)
  
  # Оцінка системного ризику
  systemic_risk <- estimate_systemic_risk(x, threshold = threshold) # Використовуємо переданий threshold
  print(paste("Розрахований системний ризик (", scenario_name, "):", format(systemic_risk, scientific = FALSE)))
  
  # Підготовка даних для експорту та графіку
  time_points <- seq(0, T_sim, by = dt) # Вектор довжиною T/dt + 1
  
  # Створення датафрейму у форматі: Стовпець Time, потім стовпці Bank_1, Bank_2, ...
  data_for_export <- data.frame(Time = time_points)
  for (i in 1:N) {
    data_for_export[[paste0("Bank_", i)]] <- x[i, ] # Додаємо стовпець для кожного банку
  }
  
  # --- Оновлена частина для збереження файлів ---
  safe_scenario_name <- gsub(" ", "_", scenario_name) # Замінюємо пробіли на підкреслення для імені файлу
  output_file_excel <- file.path(save_dir, paste0("simulation_results_", safe_scenario_name, ".xlsx"))
  output_file_plot <- file.path(save_dir, paste0("risk_indices_plot_", safe_scenario_name, ".png"))
  
  # Експорт в Excel (результати симуляції)
  tryCatch({
    write_xlsx(data_for_export, path = output_file_excel)
    print(paste("Результати симуляції збережено у:", output_file_excel))
  }, error = function(e) {
    print(paste("Помилка при збереженні Excel файлу симуляції:", e$message))
  })
  
  # --- Створення графіку ---
  df_plot_long <- data_for_export %>%
    tidyr::pivot_longer(cols = -Time, names_to = "Bank", values_to = "Risk_Index")
  
  num_banks_to_plot <- min(5, N)
  selected_bank_names <- sample(paste0("Bank_", 1:N), num_banks_to_plot)
  
  df_plot_selected <- df_plot_long %>%
    dplyr::filter(Bank %in% selected_bank_names)
  
  plot_title <- paste("Індекси ризику для", num_banks_to_plot, "випадкових банків (", scenario_name, ")")
  p <- ggplot(df_plot_selected, aes(x = Time, y = Risk_Index, color = Bank)) +
    geom_line(alpha = 0.8) +
    geom_hline(yintercept = 1, linetype = "dashed", color = "red", alpha = 0.7) +
    geom_hline(yintercept = -1, linetype = "dashed", color = "blue", alpha = 0.7) +
    labs(title = plot_title,
         subtitle = paste("N =", N, ", h =", h, ", θ =", theta, ", σ =", sigma),
         x = "Час (t)",
         y = "Індекс ризику (x)",
         color = "Банк") +
    theme_minimal(base_size = 12) +
    theme(legend.position = "bottom",
          plot.title = element_text(hjust = 0.5),
          plot.subtitle = element_text(hjust = 0.5))
  
  # Збереження графіку
  tryCatch({
    ggsave(output_file_plot, plot = p, width = 10, height = 6, units = "in", dpi = 300)
    print(paste("Графік збережено у:", output_file_plot))
  }, error = function(e) {
    print(paste("Помилка при збереженні графіку:", e$message))
  })
  
  # Повертаємо список з розрахованим ризиком та об'єктом графіку
  return(list(risk = systemic_risk, plot = p))
}

# --- Параметри моделювання ---
N <- 100       # Кількість банків
T_sim <- 100   # Часовий горизонт симуляції
dt <- 0.1      # Часовий крок
threshold <- 0 # Поріг для визначення стану системи (середній ризик > 0 => failed)

# --- Ініціалізація списку для зберігання результатів ---
all_results <- list()

# --- Запуск сценаріїв ---

# 1. Базовий сценарій:
h_base <- 0.1
theta_base <- 0.2
sigma_base <- 0.5
scenario_name_base <- "Базовий сценарій"
print(paste("--- Запуск:", scenario_name_base, "---"))
results_base <- run_simulation_and_analyze(N, h_base, theta_base, sigma_base, T_sim, dt, threshold, scenario_name_base, output_directory)
all_results[[scenario_name_base]] <- list(params = list(N=N, h=h_base, theta=theta_base, sigma=sigma_base, T_sim=T_sim, dt=dt, threshold=threshold), risk = results_base$risk)


# 2. Сценарій з вищою волатильністю (вищий sigma):
sigma_high <- 0.7
scenario_name_high_volatility <- "Вища волатильність"
print(paste("--- Запуск:", scenario_name_high_volatility, "---"))
results_high_volatility <- run_simulation_and_analyze(N, h_base, theta_base, sigma_high, T_sim, dt, threshold, scenario_name_high_volatility, output_directory)
all_results[[scenario_name_high_volatility]] <- list(params = list(N=N, h=h_base, theta=theta_base, sigma=sigma_high, T_sim=T_sim, dt=dt, threshold=threshold), risk = results_high_volatility$risk)


# 3. Сценарій з вищою кооперацією (вищий theta):
theta_high <- 0.4
scenario_name_high_cooperation <- "Вища кооперація"
print(paste("--- Запуск:", scenario_name_high_cooperation, "---"))
results_high_cooperation <- run_simulation_and_analyze(N, h_base, theta_high, sigma_base, T_sim, dt, threshold, scenario_name_high_cooperation, output_directory)
all_results[[scenario_name_high_cooperation]] <- list(params = list(N=N, h=h_base, theta=theta_high, sigma=sigma_base, T_sim=T_sim, dt=dt, threshold=threshold), risk = results_high_cooperation$risk)


# 4. Сценарій з нижчою стабільністю (нижчий h):
h_low <- 0.05
scenario_name_low_stability <- "Нижча стабільність"
print(paste("--- Запуск:", scenario_name_low_stability, "---"))
results_low_stability <- run_simulation_and_analyze(N, h_low, theta_base, sigma_base, T_sim, dt, threshold, scenario_name_low_stability, output_directory)
all_results[[scenario_name_low_stability]] <- list(params = list(N=N, h=h_low, theta=theta_base, sigma=sigma_base, T_sim=T_sim, dt=dt, threshold=threshold), risk = results_low_stability$risk)


# --- Створення та збереження зведеної таблиці ---
print(" ")
print("--- Створення зведеної таблиці результатів ---")

# Перетворення списку результатів у датафрейм
summary_list <- lapply(names(all_results), function(scenario) {
  res <- all_results[[scenario]]
  data.frame(
    Scenario = scenario,
    N = res$params$N,
    h = res$params$h,
    theta = res$params$theta,
    sigma = res$params$sigma,
    T_sim = res$params$T_sim,
    dt = res$params$dt,
    Threshold = res$params$threshold,
    Systemic_Risk = res$risk
  )
})
summary_df <- do.call(rbind, summary_list) # Об'єднання списку датафреймів в один

# Виведення зведеної таблиці в консоль
print("Зведена таблиця:")
print(summary_df)

# Шлях до файлу зведеної статистики
summary_file_excel <- file.path(output_directory, "simulation_summary_statistics.xlsx")

# Збереження зведеної таблиці в Excel
tryCatch({
  write_xlsx(summary_df, path = summary_file_excel)
  print(paste("Зведену статистику збережено у:", summary_file_excel))
}, error = function(e) {
  print(paste("Помилка при збереженні Excel файлу зі зведеною статистикою:", e$message))
})


# --- Порівняльний аналіз (виведення в консоль) ---
print(" ")
print("========== Порівняння системних ризиків ==========")
# Використовуємо дані зі зведеної таблиці для виведення
for(i in 1:nrow(summary_df)) {
  print(paste(summary_df$Scenario[i], ":", format(summary_df$Systemic_Risk[i], digits = 4, scientific = FALSE)))
}
print("==================================================")

# --- Відображення графіків (якщо запускається в інтерактивному середовищі RStudio) ---
if (interactive()) {
  print(results_base$plot)
  print(results_high_volatility$plot)
  print(results_high_cooperation$plot)
  print(results_low_stability$plot)
} else {
  print(paste("Графіки збережено у файли PNG в директорії:", output_directory))
}

