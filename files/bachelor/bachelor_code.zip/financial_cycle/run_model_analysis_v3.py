# -*- coding: utf-8 -*-
"""
Скрипт для оцінки Лінійних та Квантильних Локальних Проекцій
впливу фінансового циклу на показники діяльності банків України,
а також проведення тесту причинності Грейнджера.

Припускає відсутність пропусків або викидів у вхідних даних.
Включає розрахунок BCaR та SVB (тільки для roa_pretax),
використання довідника банків та збереження індивідуальних прогнозів.
Адаптовано для формату дати 'dd/mm/yyyy' у вхідних файлах.
"""

import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, grangercausalitytests
from linearmodels.panel import PanelOLS
import matplotlib.pyplot as plt
import os
import warnings

warnings.filterwarnings("ignore")

# --- 1. Налаштування параметрів ---
H_MAX = 12
H_CUM_START = 4
H_CUM_END = 8
QUANTILES = [0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95]

FIN_CYCLE_VAR = 'financial_cycle_index'
# Список цільових змінних для аналізу
TARGET_VARS_TO_ANALYZE = ['roa_pretax','loans_to_assets', 'net_interest_margin',
                          'cost_to_income']  # Додайте сюди інші показники за потреби

BANK_ID_VAR = 'bank_id'
TIME_ID_VAR = 'time_period'
BANK_NAME_VAR = 'bank_name_ua'
AVG_RISK_WEIGHT_VAR = 'avr_risk_weight'
TOTAL_ASSETS_VAR = 'total_assets'

BANK_CONTROLS_BASE = [
    'log_assets',
    'loans_to_assets',
    'cost_to_income',  # Буде видалено з контролів, якщо є цільовою
    'net_interest_margin',  # Буде видалено з контролів, якщо є цільовою
    'impariments_to_assets',
    AVG_RISK_WEIGHT_VAR,
    'tangible_equity_ratio',
    'tier1_ratio'
]
MACRO_CONTROLS = [
    'hhi',
    'credit_to_gdp',
    'gdp_growth_rate',
    'inflation_rate',
    'short_term_rate',
    'yield_curve_slope',
    'equity_growth',
    'real_estate_growth'
]

BANK_DATA_FILE = 'Bank_Data.csv'
MACRO_DATA_FILE = 'Macro_Data.csv'
BANK_DIRECTORY_FILE = 'Bank_Directory.csv'
EXCEL_OUTPUT_FILE_TEMPLATE = 'model_results_target_{target_var}_v6.xlsx'
PLOTS_DIR_TEMPLATE = 'plots_target_{target_var}_v6'
FULL_RESULTS_DIR_TEMPLATE = 'full_regression_outputs_target_{target_var}_v6'
GRANGER_EXCEL_SHEET = 'Granger_Causality_Tests'
GRANGER_MAX_LAG = 6  # Максимальний лаг для тесту Грейнджера

# Параметри для BCaR/SVB (застосовуються тільки якщо TARGET_VAR = 'roa_pretax')
INDIVIDUAL_PRED_HORIZON = 12
INDIVIDUAL_PRED_QUANTILE = 0.05
BCAR_SVB_HORIZON = INDIVIDUAL_PRED_HORIZON
BCAR_QUANTILE = INDIVIDUAL_PRED_QUANTILE
SVB_QUANTILE = INDIVIDUAL_PRED_QUANTILE
SVB_THRESHOLD = -1.0


def create_directories(target_var):
    """Створює директорії для результатів поточного цільового показника."""
    plots_dir = PLOTS_DIR_TEMPLATE.format(target_var=target_var)
    full_results_dir = FULL_RESULTS_DIR_TEMPLATE.format(target_var=target_var)
    if not os.path.exists(plots_dir):
        os.makedirs(plots_dir)
        print(f"Створено директорію: {plots_dir}")
    if not os.path.exists(full_results_dir):
        os.makedirs(full_results_dir)
        print(f"Створено директорію: {full_results_dir}")
    return plots_dir, full_results_dir


def check_stationarity(series, series_name='Series'):
    """Перевіряє стаціонарність ряду за допомогою тесту ADF."""
    print(f"\nПеревірка стаціонарності для {series_name}:")
    result = adfuller(series.dropna())
    print(f'ADF Statistic: {result[0]}')
    print(f'p-value: {result[1]}')
    for key, value in result[4].items():
        print(f'Critical Value ({key}): {value}')
    if result[1] <= 0.05:
        print(f"Результат: Ряд '{series_name}' стаціонарний (p <= 0.05).")
        return True
    else:
        print(f"Результат: Ряд '{series_name}' нестаціонарний (p > 0.05).")
        return False


def make_stationary(series, series_name='Series'):
    """Робить ряд стаціонарним шляхом диференціювання."""
    d = 0
    series_stat = series.copy()
    # Ensure series is not empty before checking stationarity
    if series_stat.dropna().empty:
        print(f"ПОПЕРЕДЖЕННЯ: Ряд '{series_name}' порожній після dropna() перед перевіркою стаціонарності.")
        return series_stat, d  # Return original empty series and d=0

    while not check_stationarity(series_stat, f"{series_name} (d={d})"):
        d += 1
        series_stat_prev = series_stat  # Keep previous state in case diff results in all NaNs
        series_stat = series_stat.diff().dropna()
        print(f"Застосовано диференціювання порядку {d} до ряду '{series_name}'.")
        if series_stat.empty:
            print(
                f"ПОПЕРЕДЖЕННЯ: Ряд '{series_name}' став порожнім після диференціювання порядку {d}. Повернення попереднього стану.")
            return series_stat_prev, d - 1  # Return previous series and order of diff
        if d > 2:  # Обмеження на кількість диференціювань
            print(f"ПОПЕРЕДЖЕННЯ: Ряд '{series_name}' не вдалося зробити стаціонарним після {d} диференціювань.")
            break
    return series_stat, d


def run_granger_causality_tests(data_df, target_vars_list, fin_cycle_indicator, max_lag, writer, time_id_col):
    """Виконує тест причинності Грейнджера між фінансовим циклом та показниками банку."""
    print("\n--- Тест причинності Грейнджера ---")
    results_list = []
    data_df_granger = data_df.copy()  # Work on a copy

    # Переконуємося, що часовий стовпець є індексом типу DatetimeIndex або PeriodIndex для агрегації
    if not isinstance(data_df_granger.index, (pd.DatetimeIndex, pd.PeriodIndex)):
        if time_id_col in data_df_granger.columns:
            try:
                data_df_granger[time_id_col] = pd.to_datetime(data_df_granger[time_id_col])
                data_df_granger = data_df_granger.set_index(time_id_col)
                print(f"Встановлено індекс {time_id_col} для тесту Грейнджера.")
            except Exception as e:
                print(f"ПОМИЛКА: Не вдалося встановити часовий індекс для тесту Грейнджера: {e}")
                return
        else:
            print(f"ПОМИЛКА: Часовий стовпець {time_id_col} не знайдено для агрегації в тесті Грейнджера.")
            return

    # Ensure data_df_granger.index is sorted if it's a DatetimeIndex
    if isinstance(data_df_granger.index, pd.DatetimeIndex) and not data_df_granger.index.is_monotonic_increasing:
        print("Сортування індексу для даних тесту Грейнджера.")
        data_df_granger = data_df_granger.sort_index()

    # Створюємо часовий ряд для фінансового циклу з унікальним індексом часу
    # Це важливо, оскільки fin_cycle_indicator однаковий для всіх банків у певний момент часу
    if fin_cycle_indicator in data_df_granger.columns:
        ts_fin_cycle = data_df_granger.groupby(data_df_granger.index)[fin_cycle_indicator].first().dropna()
    else:
        print(f"ПОМИЛКА: Стовпець фінансового циклу '{fin_cycle_indicator}' не знайдено в даних для тесту Грейнджера.")
        return

    for target_var in target_vars_list:
        print(f"\nТестування: {fin_cycle_indicator} та {target_var}")
        if target_var not in data_df_granger.columns:
            print(f"ПОПЕРЕДЖЕННЯ: Цільова змінна {target_var} не знайдена в даних для тесту Грейнджера.")
            continue

        # Агрегуємо показник банку (середнє по всіх банках для кожного періоду)
        ts_target = data_df_granger.groupby(data_df_granger.index)[target_var].mean().dropna()

        # Об'єднуємо ряди та видаляємо NaN, що могли з'явитися через різні довжини
        # Індекси ts_target та ts_fin_cycle тепер мають бути унікальними
        df_test = pd.concat([ts_target, ts_fin_cycle], axis=1, keys=[target_var, fin_cycle_indicator]).dropna()

        if df_test.shape[0] < max_lag + 10:  # Збільшено вимогу до кількості спостережень
            print(
                f"ПОПЕРЕДЖЕННЯ: Недостатньо даних для тесту Грейнджера для {target_var} та {fin_cycle_indicator} (спостережень: {df_test.shape[0]}, потрібно щонайменше {max_lag + 10}).")
            continue

        # Перевірка на стаціонарність та диференціювання
        series1_stat, d1 = make_stationary(df_test[target_var], target_var)
        series2_stat, d2 = make_stationary(df_test[fin_cycle_indicator], fin_cycle_indicator)

        # Вирівнюємо довжину рядів після диференціювання
        common_index = series1_stat.index.intersection(series2_stat.index)
        if common_index.empty:
            print(
                f"ПОПЕРЕДЖЕННЯ: Немає спільних індексів після диференціювання для {target_var} та {fin_cycle_indicator}.")
            continue

        # Ensure common_index is sorted
        if not common_index.is_monotonic_increasing:
            common_index = common_index.sort_values()

        df_test_stat = pd.concat([series1_stat.loc[common_index], series2_stat.loc[common_index]], axis=1).dropna()
        df_test_stat.columns = [f"{target_var}_d{d1}", f"{fin_cycle_indicator}_d{d2}"]

        if df_test_stat.shape[0] < max_lag + 10:  # Повторна перевірка після всіх маніпуляцій
            print(
                f"ПОПЕРЕДЖЕННЯ: Недостатньо даних після диференціювання для {target_var} та {fin_cycle_indicator} (спостережень: {df_test_stat.shape[0]}, потрібно щонайменше {max_lag + 10}).")
            continue

        print(f"\nРезультати тесту Грейнджера для '{target_var}_d{d1}' та '{fin_cycle_indicator}_d{d2}':")
        # Тест: fin_cycle_indicator -> target_var
        try:
            # Переконуємося, що дані не містять NaN або Inf
            current_test_data_1 = df_test_stat[[f"{target_var}_d{d1}", f"{fin_cycle_indicator}_d{d2}"]].replace(
                [np.inf, -np.inf], np.nan).dropna()
            if current_test_data_1.shape[0] < max_lag + 10:
                print(
                    f"  Пропуск тесту {fin_cycle_indicator} -> {target_var}: недостатньо даних після очищення NaN/Inf ({current_test_data_1.shape[0]})")
            else:
                gc_res1 = grangercausalitytests(current_test_data_1, maxlag=max_lag, verbose=False)
                for lag in gc_res1:
                    test_stat = gc_res1[lag][0]['ssr_ftest'][0]
                    p_value = gc_res1[lag][0]['ssr_ftest'][1]
                    results_list.append({
                        'Direction': f"{fin_cycle_indicator} (d{d2}) -> {target_var} (d{d1})",
                        'Lag': lag,
                        'F-Statistic': test_stat,
                        'P-Value': p_value
                    })
                    print(
                        f"  {fin_cycle_indicator} (d{d2}) -> {target_var} (d{d1}) | Лаг: {lag}, F-стат: {test_stat:.3f}, P-значення: {p_value:.3f}")
        except Exception as e:
            print(f"ПОМИЛКА тесту Грейнджера ({fin_cycle_indicator} -> {target_var}): {e}")

        # Тест: target_var -> fin_cycle_indicator
        try:
            current_test_data_2 = df_test_stat[[f"{fin_cycle_indicator}_d{d2}", f"{target_var}_d{d1}"]].replace(
                [np.inf, -np.inf], np.nan).dropna()
            if current_test_data_2.shape[0] < max_lag + 10:
                print(
                    f"  Пропуск тесту {target_var} -> {fin_cycle_indicator}: недостатньо даних після очищення NaN/Inf ({current_test_data_2.shape[0]})")
            else:
                gc_res2 = grangercausalitytests(current_test_data_2, maxlag=max_lag, verbose=False)
                for lag in gc_res2:
                    test_stat = gc_res2[lag][0]['ssr_ftest'][0]
                    p_value = gc_res2[lag][0]['ssr_ftest'][1]
                    results_list.append({
                        'Direction': f"{target_var} (d{d1}) -> {fin_cycle_indicator} (d{d2})",
                        'Lag': lag,
                        'F-Statistic': test_stat,
                        'P-Value': p_value
                    })
                    print(
                        f"  {target_var} (d{d1}) -> {fin_cycle_indicator} (d{d2}) | Лаг: {lag}, F-стат: {test_stat:.3f}, P-значення: {p_value:.3f}")
        except Exception as e:
            print(f"ПОМИЛКА тесту Грейнджера ({target_var} -> {fin_cycle_indicator}): {e}")

    if results_list:
        df_granger_results = pd.DataFrame(results_list)
        df_granger_results.to_excel(writer, sheet_name=GRANGER_EXCEL_SHEET, index=False)
        print(f"\nРезультати тесту Грейнджера збережено в аркуш '{GRANGER_EXCEL_SHEET}'.")
    else:
        print("\nНемає результатів тесту Грейнджера для збереження.")


# --- Основний цикл аналізу для кожного цільового показника ---
for current_target_var in TARGET_VARS_TO_ANALYZE:
    print(f"\n\n--- РОЗПОЧАТО АНАЛІЗ ДЛЯ ЦІЛЬОВОГО ПОКАЗНИКА: {current_target_var} ---")

    excel_output_file = EXCEL_OUTPUT_FILE_TEMPLATE.format(target_var=current_target_var)
    plots_dir, full_results_dir = create_directories(current_target_var)

    # --- 2. Завантаження та підготовка даних ---
    print(f"Завантаження даних для {current_target_var}...")
    try:
        df_bank_raw = pd.read_csv(BANK_DATA_FILE)
        df_macro = pd.read_csv(MACRO_DATA_FILE)
        df_directory = pd.read_csv(BANK_DIRECTORY_FILE)
    except FileNotFoundError as e:
        print(f"ПОМИЛКА: Не знайдено файл даних: {e}. Пропуск аналізу для {current_target_var}.")
        continue
    except Exception as e:
        print(f"ПОМИЛКА при завантаженні даних для {current_target_var}: {e}. Пропуск аналізу.")
        continue

    print(f"Підготовка даних для {current_target_var}...")
    # Розрахунок log_assets
    if 'log_assets' not in df_bank_raw.columns and TOTAL_ASSETS_VAR in df_bank_raw.columns:
        df_bank_raw[TOTAL_ASSETS_VAR] = pd.to_numeric(df_bank_raw[TOTAL_ASSETS_VAR], errors='coerce')
        df_bank_raw = df_bank_raw[df_bank_raw[TOTAL_ASSETS_VAR] > 0].copy()
        df_bank_raw['log_assets'] = np.log(df_bank_raw[TOTAL_ASSETS_VAR])
        df_bank_raw.replace([np.inf, -np.inf], np.nan, inplace=True)

    # Адаптація банківських контролів: видаляємо поточний цільовий показник зі списку контролів
    current_bank_controls = [c for c in BANK_CONTROLS_BASE if c != current_target_var]

    required_bank_cols = [BANK_ID_VAR, TIME_ID_VAR, current_target_var, TOTAL_ASSETS_VAR] + current_bank_controls
    if current_target_var == 'roa_pretax':  # AVG_RISK_WEIGHT_VAR потрібен для BCaR/SVB
        if AVG_RISK_WEIGHT_VAR not in required_bank_cols and AVG_RISK_WEIGHT_VAR in df_bank_raw.columns:  # Check if it exists in raw before appending
            required_bank_cols.append(AVG_RISK_WEIGHT_VAR)
    required_macro_cols = [TIME_ID_VAR, FIN_CYCLE_VAR] + MACRO_CONTROLS
    required_dir_cols = [BANK_ID_VAR, BANK_NAME_VAR]

    missing_bank_cols = [col for col in required_bank_cols if col not in df_bank_raw.columns]
    if missing_bank_cols:
        print(
            f"ПОМИЛКА: Відсутні стовпці у '{BANK_DATA_FILE}' для {current_target_var}: {missing_bank_cols}. Пропуск аналізу.")
        continue
    missing_macro_cols = [col for col in required_macro_cols if col not in df_macro.columns]
    if missing_macro_cols:
        print(
            f"ПОМИЛКА: Відсутні стовпці у '{MACRO_DATA_FILE}' для {current_target_var}: {missing_macro_cols}. Пропуск аналізу.")
        continue
    missing_dir_cols = [col for col in required_dir_cols if col not in df_directory.columns]
    if missing_dir_cols:
        print(
            f"ПОМИЛКА: Відсутні стовпці у '{BANK_DIRECTORY_FILE}' для {current_target_var}: {missing_dir_cols}. Пропуск аналізу.")
        continue

    df_bank = pd.merge(df_bank_raw, df_directory[[BANK_ID_VAR, BANK_NAME_VAR]], on=BANK_ID_VAR, how='left')

    is_annual_data = False
    try:
        df_bank[TIME_ID_VAR] = pd.to_datetime(df_bank[TIME_ID_VAR], format='%d/%m/%Y')
        df_bank[TIME_ID_VAR + '_dt'] = df_bank[TIME_ID_VAR]
        df_bank[TIME_ID_VAR] = df_bank[TIME_ID_VAR].dt.to_period('Q')
        df_macro[TIME_ID_VAR] = pd.to_datetime(df_macro[TIME_ID_VAR], format='%d/%m/%Y')
        df_macro[TIME_ID_VAR + '_dt'] = df_macro[TIME_ID_VAR]
        df_macro[TIME_ID_VAR] = df_macro[TIME_ID_VAR].dt.to_period('Q')
    except ValueError:
        try:
            df_bank[TIME_ID_VAR] = pd.to_datetime(df_bank_raw[TIME_ID_VAR],
                                                  format='%d/%m/%Y')  # Use original df_bank_raw
            df_bank[TIME_ID_VAR + '_dt'] = df_bank[TIME_ID_VAR]
            df_bank[TIME_ID_VAR] = df_bank[TIME_ID_VAR].dt.to_period('Y')

            # Ensure df_macro is also processed for yearly if quarterly failed
            df_macro[TIME_ID_VAR] = pd.to_datetime(df_macro[TIME_ID_VAR].astype(str).str.split(' ').str[0],
                                                   format='%Y-%m-%d', errors='coerce')  # Try to make it datetime first
            if df_macro[TIME_ID_VAR].isnull().all():  # if previous failed, try original format
                df_macro[TIME_ID_VAR] = pd.to_datetime(pd.read_csv(MACRO_DATA_FILE)[TIME_ID_VAR], format='%d/%m/%Y')

            df_macro[TIME_ID_VAR + '_dt'] = df_macro[TIME_ID_VAR]
            df_macro[TIME_ID_VAR] = df_macro[TIME_ID_VAR].dt.to_period('Y')

            is_annual_data = True
            print(f"Визначено річну частоту даних для {current_target_var}.")
        except Exception as e_annual:
            print(f"ПОМИЛКА формату '{TIME_ID_VAR}' для {current_target_var}: {e_annual}. Пропуск аналізу.")
            continue
    except Exception as e_gen:
        print(f"ЗАГАЛЬНА ПОМИЛКА конвертації дат для {current_target_var}: {e_gen}. Пропуск аналізу.")
        continue

    # Ensure AVG_RISK_WEIGHT_VAR is present for df_bank_assets_names, use a placeholder if not
    avg_risk_weight_col_for_df_assets = AVG_RISK_WEIGHT_VAR if AVG_RISK_WEIGHT_VAR in df_bank.columns else TOTAL_ASSETS_VAR
    if AVG_RISK_WEIGHT_VAR not in df_bank.columns:
        print(
            f"ПОПЕРЕДЖЕННЯ: Стовпець '{AVG_RISK_WEIGHT_VAR}' відсутній у df_bank. Використовується фіктивне значення 0.")
        df_bank[AVG_RISK_WEIGHT_VAR] = 0  # Add placeholder if missing, for consistent df_bank_assets_names structure

    df_bank_assets_names = df_bank[
        [BANK_ID_VAR, TIME_ID_VAR, TOTAL_ASSETS_VAR, BANK_NAME_VAR, AVG_RISK_WEIGHT_VAR, TIME_ID_VAR + '_dt']].copy()

    df = pd.merge(df_bank, df_macro.drop(columns=[TIME_ID_VAR + '_dt'], errors='ignore'), on=TIME_ID_VAR, how='left')
    df = df.sort_values(by=[BANK_ID_VAR, TIME_ID_VAR])

    print(f"Генерація майбутніх значень для {current_target_var}...")
    for h in range(1, H_MAX + 1):
        df[f'{current_target_var}_h{h}'] = df.groupby(BANK_ID_VAR)[current_target_var].shift(-h)

    df[f'{current_target_var}_lag1'] = df.groupby(BANK_ID_VAR)[current_target_var].shift(1)
    current_bank_controls_with_lag = current_bank_controls + [f'{current_target_var}_lag1']

    try:
        if TIME_ID_VAR + '_dt' not in df.columns:
            if isinstance(df[TIME_ID_VAR].iloc[0], pd.Period):
                df[TIME_ID_VAR + '_dt'] = df[TIME_ID_VAR].dt.to_timestamp()
            else:
                raise ValueError(f"Стовпець {TIME_ID_VAR + '_dt'} відсутній і не може бути відновлений.")
        df = df.set_index([BANK_ID_VAR, TIME_ID_VAR + '_dt'])
    except Exception as e:
        print(f"ПОМИЛКА встановлення індексу для {current_target_var}: {e}. Пропуск аналізу.")
        continue

    # --- 3. Лінійні Локальні Проекції (LLP) ---
    print(f"\n--- Розрахунок LLP для {current_target_var} ---")
    llp_results = {}
    llp_summaries = {}
    exog_vars_llp = [FIN_CYCLE_VAR] + current_bank_controls_with_lag + MACRO_CONTROLS

    # Ensure all exog_vars_llp are numeric and handle potential new NaNs
    df_for_llp = df.copy()
    for col in exog_vars_llp + [current_target_var]:  # Include target var for lag generation
        if col in df_for_llp.columns:
            df_for_llp[col] = pd.to_numeric(df_for_llp[col], errors='coerce')

    missing_exog_llp = [v for v in exog_vars_llp if v not in df_for_llp.columns]
    if missing_exog_llp:
        print(f"ПОМИЛКА: Відсутні екзогенні змінні для LLP ({current_target_var}): {missing_exog_llp}. Пропуск LLP.")
    else:
        for h in range(1, H_MAX + 1):
            target_var_h = f'{current_target_var}_h{h}'
            # Generate future value for LLP within the loop using df_for_llp
            df_for_llp[target_var_h] = df_for_llp.groupby(level=BANK_ID_VAR)[current_target_var].shift(-h)

            if target_var_h not in df_for_llp.columns:
                llp_results[h] = {'coef': np.nan, 'std_err': np.nan, 'p_value': np.nan, 'conf_int_lower': np.nan,
                                  'conf_int_upper': np.nan, 'r_squared': np.nan, 'n_obs': 0}
                llp_summaries[h] = "Стовпець залежної змінної не знайдено."
                continue
            try:
                # Prepare data for this horizon
                data_h_llp = df_for_llp[[target_var_h] + exog_vars_llp].copy()
                # Convert all relevant columns to numeric, coercing errors
                for col in data_h_llp.columns:
                    data_h_llp[col] = pd.to_numeric(data_h_llp[col], errors='coerce')
                data_h_llp.dropna(inplace=True)  # Drop rows with any NaNs in selected columns

                if data_h_llp.empty:
                    llp_results[h] = {'coef': np.nan, 'std_err': np.nan, 'p_value': np.nan, 'conf_int_lower': np.nan,
                                      'conf_int_upper': np.nan, 'r_squared': np.nan, 'n_obs': 0}
                    llp_summaries[h] = "Немає даних після обробки NaN."
                    continue

                mod = PanelOLS(data_h_llp[target_var_h], sm.add_constant(data_h_llp[exog_vars_llp]),
                               entity_effects=True, time_effects=False, drop_absorbed=True)
                fe_res = mod.fit(cov_type='clustered', cluster_entity=True)

                if FIN_CYCLE_VAR not in fe_res.params:
                    llp_results[h] = {'coef': np.nan, 'std_err': np.nan, 'p_value': np.nan, 'conf_int_lower': np.nan,
                                      'conf_int_upper': np.nan, 'r_squared': fe_res.rsquared, 'n_obs': int(fe_res.nobs)}
                    llp_summaries[h] = fe_res.summary.as_text() + f"\nПРИМІТКА: Змінна {FIN_CYCLE_VAR} була видалена."
                else:
                    llp_results[h] = {
                        'coef': fe_res.params[FIN_CYCLE_VAR], 'std_err': fe_res.std_errors[FIN_CYCLE_VAR],
                        'p_value': fe_res.pvalues[FIN_CYCLE_VAR],
                        'conf_int_lower': fe_res.conf_int().loc[FIN_CYCLE_VAR, 'lower'],
                        'conf_int_upper': fe_res.conf_int().loc[FIN_CYCLE_VAR, 'upper'],
                        'r_squared': fe_res.rsquared, 'n_obs': int(fe_res.nobs)
                    }
                llp_summaries[h] = fe_res.summary.as_text()
            except Exception as e:
                print(f"    ПОМИЛКА LLP (PanelOLS) для h={h} ({current_target_var}): {e}")
                llp_results[h] = {'coef': np.nan, 'std_err': np.nan, 'p_value': np.nan, 'conf_int_lower': np.nan,
                                  'conf_int_upper': np.nan, 'r_squared': np.nan, 'n_obs': 0}
                llp_summaries[h] = f"Помилка розрахунку: {e}"

    df_llp = pd.DataFrame.from_dict(llp_results, orient='index')
    df_llp.index.name = 'Horizon (h)'
    for h_val, summary in llp_summaries.items():
        try:
            if "Помилка" not in summary and "Стовпець" not in summary and "Немає даних" not in summary:
                with open(os.path.join(full_results_dir, f'llp_summary_h{h_val}.txt'), 'w', encoding='utf-8') as f:
                    f.write(f"LLP Summary for {current_target_var}, Horizon h={h_val}\n{'-' * 40}\n{summary}")
        except Exception as e:
            print(f"Помилка збереження звіту LLP для {current_target_var}, h={h_val}: {e}")

    # --- 4. Квантильні Локальні Проекції (QLP) ---
    print(f"\n--- Розрахунок QLP для {current_target_var} ---")
    qlp_results = {}
    qlp_summaries = {}
    qlp_fitted_models = {}  # Only for roa_pretax

    df_reset = df.reset_index()  # Start with the main df for QLP data prep
    if TIME_ID_VAR + '_dt' in df_reset.columns:
        df_reset[TIME_ID_VAR] = pd.to_datetime(df_reset[TIME_ID_VAR + '_dt']).dt.to_period(
            'Q' if not is_annual_data else 'Y')
        df_reset.drop(columns=[TIME_ID_VAR + '_dt'], inplace=True, errors='ignore')
    else:  # If _dt is missing, try to convert TIME_ID_VAR if it's not already Period
        if TIME_ID_VAR in df_reset.columns and not isinstance(df_reset[TIME_ID_VAR].iloc[0], pd.Period):
            try:
                df_reset[TIME_ID_VAR] = pd.to_datetime(df_reset[TIME_ID_VAR]).dt.to_period(
                    'Q' if not is_annual_data else 'Y')
            except:
                print(f"ПОПЕРЕДЖЕННЯ: не вдалося конвертувати {TIME_ID_VAR} в PeriodIndex для QLP.")

    # Add necessary columns from df_bank_assets_names to df_reset if they are missing
    # Ensure df_bank_assets_names has TIME_ID_VAR as PeriodIndex for merging
    if TIME_ID_VAR + '_dt' in df_bank_assets_names.columns and TIME_ID_VAR in df_bank_assets_names.columns and not isinstance(
            df_bank_assets_names[TIME_ID_VAR].iloc[0], pd.Period):
        df_bank_assets_names[TIME_ID_VAR] = pd.to_datetime(df_bank_assets_names[TIME_ID_VAR + '_dt']).dt.to_period(
            'Q' if not is_annual_data else 'Y')

    df_bank_assets_names_unique = df_bank_assets_names.drop_duplicates(subset=[BANK_ID_VAR, TIME_ID_VAR])
    merge_cols_for_qlp = [BANK_NAME_VAR, TOTAL_ASSETS_VAR, AVG_RISK_WEIGHT_VAR]
    for col_to_add in merge_cols_for_qlp:
        if col_to_add not in df_reset.columns and col_to_add in df_bank_assets_names_unique.columns:
            # Ensure TIME_ID_VAR types match for merge
            if df_reset[TIME_ID_VAR].dtype == df_bank_assets_names_unique[TIME_ID_VAR].dtype:
                df_reset = pd.merge(df_reset, df_bank_assets_names_unique[[BANK_ID_VAR, TIME_ID_VAR, col_to_add]],
                                    on=[BANK_ID_VAR, TIME_ID_VAR], how='left')
            else:
                print(f"ПОПЕРЕДЖЕННЯ: Типи {TIME_ID_VAR} не співпадають для мержу '{col_to_add}'. Пропуск мержингу.")

    time_dummies_prefix = 'TimeFE'
    time_fe_cols = []
    try:
        if TIME_ID_VAR in df_reset.columns and isinstance(df_reset[TIME_ID_VAR].iloc[0], pd.Period):
            df_reset[TIME_ID_VAR + '_str'] = df_reset[TIME_ID_VAR].astype(str)
            df_reset = pd.get_dummies(df_reset, columns=[TIME_ID_VAR + '_str'], drop_first=True,
                                      prefix=time_dummies_prefix, dtype=int)
            time_fe_cols = [col for col in df_reset.columns if col.startswith(time_dummies_prefix + '_')]
    except Exception as e:
        print(f"ПОМИЛКА створення фіктивних змінних часу для QLP ({current_target_var}): {e}")

    predictors_for_formula_qlp = [FIN_CYCLE_VAR] + current_bank_controls_with_lag + MACRO_CONTROLS + time_fe_cols

    # Ensure all predictors are numeric in df_reset
    for col in predictors_for_formula_qlp + [current_target_var]:  # include target for future value generation
        if col in df_reset.columns:
            df_reset[col] = pd.to_numeric(df_reset[col], errors='coerce')

    missing_predictors_qlp = [p for p in predictors_for_formula_qlp if p not in df_reset.columns]
    if missing_predictors_qlp:
        print(f"ПОМИЛКА: Відсутні предиктори для QLP ({current_target_var}): {missing_predictors_qlp}.")
        predictors_for_formula_qlp = [p for p in predictors_for_formula_qlp if
                                      p in df_reset.columns]  # Use only available

    formula_parts_qlp = []
    for var_name in predictors_for_formula_qlp:
        clean_var = str(var_name).replace('[', '').replace(']', '').replace('<', '').replace(' ', '_').replace('.',
                                                                                                               '_').replace(
            ':', '_')
        if not clean_var.replace('_', '').isalnum() or clean_var[0].isdigit():  # Check cleaned var
            formula_parts_qlp.append(f"Q('{var_name}')")  # Use original name in Q()
        else:
            formula_parts_qlp.append(clean_var)
    formula_base_qlp = " ~ " + " + ".join(formula_parts_qlp) if formula_parts_qlp else ""

    for h_val_qlp in range(1, H_MAX + 1):
        target_var_h = f'{current_target_var}_h{h_val_qlp}'
        # Generate future value for QLP within the loop using df_reset
        df_reset[target_var_h] = df_reset.groupby(BANK_ID_VAR)[current_target_var].shift(-h)

        if target_var_h not in df_reset.columns:
            qlp_results[h_val_qlp] = {};
            qlp_summaries[h_val_qlp] = {}
            if h_val_qlp == INDIVIDUAL_PRED_HORIZON and current_target_var == 'roa_pretax': qlp_fitted_models[
                h_val_qlp] = {}
            continue

        df_h_qlp = df_reset.copy()  # Use a fresh copy of df_reset for each horizon
        cols_for_qlp_h = [target_var_h] + predictors_for_formula_qlp
        for col in cols_for_qlp_h:  # Ensure numeric for this specific horizon's data
            if col in df_h_qlp.columns: df_h_qlp[col] = pd.to_numeric(df_h_qlp[col], errors='coerce')
        df_h_qlp = df_h_qlp.dropna(subset=cols_for_qlp_h).copy()

        if df_h_qlp.empty:
            qlp_results[h_val_qlp] = {};
            qlp_summaries[h_val_qlp] = {}
            if h_val_qlp == INDIVIDUAL_PRED_HORIZON and current_target_var == 'roa_pretax': qlp_fitted_models[
                h_val_qlp] = {}
            continue

        clean_target_var_h = target_var_h.replace('[', '').replace(']', '').replace('<', '').replace(' ', '_').replace(
            '.', '_').replace(':', '_')
        formula_qlp = (f"Q('{target_var_h}')" if not clean_target_var_h.replace('_', '').isalnum() or
                                                 clean_target_var_h[
                                                     0].isdigit() else clean_target_var_h) + formula_base_qlp

        qlp_results[h_val_qlp] = {};
        qlp_summaries[h_val_qlp] = {}
        if h_val_qlp == INDIVIDUAL_PRED_HORIZON and current_target_var == 'roa_pretax': qlp_fitted_models[
            h_val_qlp] = {}

        for q in QUANTILES:
            try:
                qreg_model = smf.quantreg(formula_qlp, data=df_h_qlp)
                qreg_results = qreg_model.fit(q=q, vcov='robust')
                coef_name_to_check = FIN_CYCLE_VAR
                if f"Q('{FIN_CYCLE_VAR}')" in formula_base_qlp: coef_name_to_check = f"Q('{FIN_CYCLE_VAR}')"

                qlp_results[h_val_qlp][q] = {
                    'coef': qreg_results.params.get(coef_name_to_check, np.nan),
                    'std_err': qreg_results.bse.get(coef_name_to_check, np.nan),
                    'p_value': qreg_results.pvalues.get(coef_name_to_check, np.nan),
                    'pseudo_r2': qreg_results.prsquared, 'n_obs': int(qreg_results.nobs)
                }
                qlp_summaries[h_val_qlp][q] = qreg_results.summary().as_text()
                if h_val_qlp == INDIVIDUAL_PRED_HORIZON and q == INDIVIDUAL_PRED_QUANTILE and current_target_var == 'roa_pretax':
                    qlp_fitted_models[h_val_qlp] = {**qlp_fitted_models.get(h_val_qlp, {}), q: qreg_results}
                    qlp_fitted_models[h_val_qlp]['data_for_pred'] = df_h_qlp.copy()
            except Exception as e:
                print(f"    ПОМИЛКА QLP для h={h_val_qlp}, q={q:.2f} ({current_target_var}): {e}")
                qlp_results[h_val_qlp][q] = {'coef': np.nan, 'std_err': np.nan, 'p_value': np.nan, 'pseudo_r2': np.nan,
                                             'n_obs': 0}
                qlp_summaries[h_val_qlp][q] = f"Помилка: {e}"

    df_qlp_list = []
    for h_val_qlp_loop, results_h in qlp_results.items():  # Changed h_val_qlp to avoid conflict
        for q_loop, results_q in results_h.items():  # Changed q to avoid conflict
            results_q['Horizon'] = h_val_qlp_loop
            results_q['Quantile'] = q_loop
            df_qlp_list.append(results_q)
    df_qlp = pd.DataFrame(df_qlp_list)
    df_qlp_pivot_coef = pd.DataFrame(columns=QUANTILES)
    df_qlp_pivot_pvals = pd.DataFrame(columns=QUANTILES)
    df_qlp_pivot_r2 = pd.DataFrame(columns=QUANTILES)
    if not df_qlp.empty:
        try:
            df_qlp_pivot_coef = df_qlp.pivot(index='Horizon', columns='Quantile', values='coef')
            df_qlp_pivot_pvals = df_qlp.pivot(index='Horizon', columns='Quantile', values='p_value')
            df_qlp_pivot_r2 = df_qlp.pivot(index='Horizon', columns='Quantile', values='pseudo_r2')
        except Exception as e_pivot:
            print(f"ПОМИЛКА при створенні зведених таблиць QLP: {e_pivot}")

    for h_val_qlp_sum, summary_h in qlp_summaries.items():  # Changed h_val_qlp to avoid conflict
        for q_sum, summary_q in summary_h.items():  # Changed q to avoid conflict
            try:
                if "Помилка" not in summary_q:
                    with open(os.path.join(full_results_dir, f'qlp_summary_h{h_val_qlp_sum}_q{q_sum:.2f}.txt'), 'w',
                              encoding='utf-8') as f:
                        f.write(
                            f"QLP Summary for {current_target_var}, h={h_val_qlp_sum}, q={q_sum:.2f}\n{'-' * 40}\n{summary_q}")
            except Exception as e:
                print(f"Помилка збереження звіту QLP для {current_target_var}, h={h_val_qlp_sum}, q={q_sum:.2f}: {e}")

    # --- 5. Експорт результатів в Excel ---
    print(f"\n--- Експорт результатів у файл: {excel_output_file} ---")
    try:
        with pd.ExcelWriter(excel_output_file) as writer:
            if not df_llp.empty: df_llp.reset_index().to_excel(writer, sheet_name='LLP_Results', index=False)
            if not df_qlp_pivot_coef.empty: df_qlp_pivot_coef.reset_index().to_excel(writer,
                                                                                     sheet_name='QLP_Coefficients',
                                                                                     index=False)
            if not df_qlp_pivot_pvals.empty: df_qlp_pivot_pvals.reset_index().to_excel(writer, sheet_name='QLP_PValues',
                                                                                       index=False)
            if not df_qlp_pivot_r2.empty: df_qlp_pivot_r2.reset_index().to_excel(writer, sheet_name='QLP_PseudoR2',
                                                                                 index=False)
            if not df_qlp.empty: df_qlp.to_excel(writer, sheet_name='QLP_Full_Table', index=False)

            if current_target_var == 'roa_pretax':
                print("  Підготовка індивідуальних прогнозів для експорту (тільки для roa_pretax)...")
                model_info_for_pred = qlp_fitted_models.get(INDIVIDUAL_PRED_HORIZON)
                if model_info_for_pred and INDIVIDUAL_PRED_QUANTILE in model_info_for_pred:
                    model_for_individual_pred = model_info_for_pred[INDIVIDUAL_PRED_QUANTILE]
                    df_predict_on = model_info_for_pred.get('data_for_pred')
                    if df_predict_on is not None and not df_predict_on.empty:
                        missing_preds_ind = [p for p in model_for_individual_pred.model.exog_names if
                                             p not in df_predict_on.columns and p != 'Intercept']
                        if not missing_preds_ind:
                            try:
                                df_predict_on[
                                    f'predicted_{current_target_var}_q{INDIVIDUAL_PRED_QUANTILE}'] = model_for_individual_pred.predict(
                                    df_predict_on)
                                target_var_h_indiv = f'{current_target_var}_h{INDIVIDUAL_PRED_HORIZON}'

                                # Ensure target_var_h_indiv exists or create it if needed for export consistency
                                if target_var_h_indiv not in df_predict_on.columns:
                                    df_predict_on[
                                        target_var_h_indiv] = np.nan  # Placeholder if actual future value is not there

                                cols_to_export = [BANK_ID_VAR, TIME_ID_VAR, target_var_h_indiv,
                                                  f'predicted_{current_target_var}_q{INDIVIDUAL_PRED_QUANTILE}']
                                if BANK_NAME_VAR in df_predict_on.columns: cols_to_export.insert(1, BANK_NAME_VAR)

                                actual_cols_to_export = [col for col in cols_to_export if col in df_predict_on.columns]
                                df_individual_predictions_export = df_predict_on[actual_cols_to_export].copy()

                                if TIME_ID_VAR in df_individual_predictions_export.columns and isinstance(
                                        df_individual_predictions_export[TIME_ID_VAR].dtype, pd.PeriodDtype):
                                    df_individual_predictions_export[TIME_ID_VAR] = df_individual_predictions_export[
                                        TIME_ID_VAR].astype(str)
                                df_individual_predictions_export.to_excel(writer,
                                                                          sheet_name='Individual_Bank_Predictions',
                                                                          index=False)
                            except Exception as e_pred:
                                print(f"  ПОМИЛКА генерації індивідуальних прогнозів ({current_target_var}): {e_pred}")
                        else:
                            print(
                                f"ПОПЕРЕДЖЕННЯ: Відсутні предиктори для індивідуальних прогнозів ({current_target_var}): {missing_preds_ind}")
                    else:
                        print(f"ПОПЕРЕДЖЕННЯ: Немає даних для індивідуальних прогнозів ({current_target_var}).")
                else:
                    print(f"ПОПЕРЕДЖЕННЯ: Модель QLP для індивідуальних прогнозів ({current_target_var}) не знайдена.")

            if current_target_var == TARGET_VARS_TO_ANALYZE[0]:
                df_granger_input_data = df.reset_index()
                time_col_for_granger_test = TIME_ID_VAR + '_dt'
                if time_col_for_granger_test not in df_granger_input_data.columns:
                    if TIME_ID_VAR in df_granger_input_data.columns and isinstance(
                            df_granger_input_data[TIME_ID_VAR].iloc[0], pd.Period):
                        df_granger_input_data[TIME_ID_VAR + "_dt_temp"] = df_granger_input_data[
                            TIME_ID_VAR].dt.to_timestamp()
                        time_col_for_granger_test = TIME_ID_VAR + "_dt_temp"
                    else:
                        print(
                            "ПОПЕРЕДЖЕННЯ: Не вдалося знайти або створити відповідний часовий стовпець для тесту Грейнджера.")
                        time_col_for_granger_test = None

                if time_col_for_granger_test:
                    run_granger_causality_tests(df_granger_input_data, TARGET_VARS_TO_ANALYZE, FIN_CYCLE_VAR,
                                                GRANGER_MAX_LAG, writer, time_col_for_granger_test)

        print(f"Результати для {current_target_var} успішно експортовано у '{excel_output_file}'.")
    except ImportError:
        print(f"ПОМИЛКА: Модуль 'openpyxl' не знайдено.")
    except Exception as e:
        print(f"ПОМИЛКА експорту в Excel для {current_target_var}: {e}")

    # --- 6. Візуалізація результатів ---
    print(f"\n--- Створення графіків для {current_target_var} у папці '{plots_dir}' ---")
    # ... (код візуалізації залишається в основному тим же, але з використанням current_target_var у назвах файлів та заголовках)
    plot_xlabel = f"Горизонт прогнозу (h, {'роки' if is_annual_data else 'квартали'})"
    try:
        if not df_llp.empty:
            plt.figure(figsize=(10, 6))
            plt.plot(df_llp.index, df_llp['coef'], marker='o', linestyle='-', color='blue',
                     label=f'Коеф. {FIN_CYCLE_VAR}')
            if 'conf_int_lower' in df_llp.columns and 'conf_int_upper' in df_llp.columns and \
                    df_llp['conf_int_lower'].notna().all() and df_llp['conf_int_upper'].notna().all():
                plt.fill_between(df_llp.index, df_llp['conf_int_lower'], df_llp['conf_int_upper'], color='skyblue',
                                 alpha=0.4, label='95% ДІ')
            plt.axhline(0, color='black', ls='--', lw=0.8)
            plt.xlabel(plot_xlabel);
            plt.ylabel(f"Вплив на {current_target_var} (п.п.)")
            plt.title(f"LLP: Середній Вплив Фін. Циклу на {current_target_var}");
            plt.legend();
            plt.grid(True, ls=':', alpha=0.7)
            plt.tight_layout();
            plt.savefig(os.path.join(plots_dir, f'llp_impulse_response_{current_target_var}.png'));
            plt.close()
    except Exception as e:
        print(f"ПОМИЛКА LLP графіка для {current_target_var}: {e}")

    try:
        if not df_qlp_pivot_coef.empty:
            plt.figure(figsize=(12, 7))
            step = max(1, H_MAX // 4 if H_MAX > 0 else 1)
            horizons_to_plot = df_qlp_pivot_coef.index[::step]
            colors = plt.cm.viridis(np.linspace(0, 1, len(horizons_to_plot)))
            for i, h_plot in enumerate(horizons_to_plot):
                if h_plot in df_qlp_pivot_coef.index: plt.plot(df_qlp_pivot_coef.columns, df_qlp_pivot_coef.loc[h_plot],
                                                               marker='o', ls='-', color=colors[i], label=f'h={h_plot}')
            plt.xlabel(f"Квантиль {current_target_var}");
            plt.ylabel(f"Вплив {FIN_CYCLE_VAR} (коеф.)")
            plt.title(f"QLP: Вплив на різні квантилі {current_target_var}")
            plt.legend(title="Горизонт", bbox_to_anchor=(1.05, 1), loc='upper left');
            plt.grid(True, ls=':', alpha=0.7)
            plt.axhline(0, color='black', ls='--', lw=0.8);
            plt.tight_layout(rect=[0, 0, 0.85, 1])
            plt.savefig(os.path.join(plots_dir, f'qlp_coeffs_vs_quantiles_{current_target_var}.png'));
            plt.close()
    except Exception as e:
        print(f"ПОМИЛКА QLP (vs Quantiles) графіка для {current_target_var}: {e}")

    try:
        if not df_qlp_pivot_coef.empty and not df_qlp.empty:  # Ensure df_qlp is also not empty for std_err
            quantiles_to_plot = df_qlp_pivot_coef.columns
            num_quantiles = len(quantiles_to_plot);
            cols_plot = 2;
            rows_plot = (num_quantiles + cols_plot - 1) // cols_plot
            plt.figure(figsize=(7 * cols_plot, 4 * rows_plot))
            for i, q_plot in enumerate(quantiles_to_plot):
                ax = plt.subplot(rows_plot, cols_plot, i + 1)
                subset = df_qlp[df_qlp['Quantile'] == q_plot].set_index('Horizon')  # Use df_qlp for std_err
                if not subset.empty:
                    ax.plot(subset.index, subset['coef'], marker='.', ls='-', color='red',
                            label=f'Коеф. {FIN_CYCLE_VAR}')
                    if 'std_err' in subset.columns and subset['std_err'].notna().all():
                        lower_b = subset['coef'] - 1.96 * subset['std_err'];
                        upper_b = subset['coef'] + 1.96 * subset['std_err']
                        ax.fill_between(subset.index, lower_b, upper_b, color='lightcoral', alpha=0.3, label='95% ДІ');
                        ax.legend()
                    ax.axhline(0, color='black', ls='--', lw=0.8);
                    ax.set_title(f'Квантиль = {q_plot:.2f}')
                    ax.set_xlabel(plot_xlabel);
                    ax.set_ylabel("Коефіцієнт");
                    ax.grid(True, ls=':', alpha=0.7)
                else:
                    ax.text(0.5, 0.5, 'Немає даних', ha='center', va='center', transform=ax.transAxes); ax.set_title(
                        f'Квантиль = {q_plot:.2f}')
            plt.tight_layout(rect=[0, 0.03, 1, 0.95]);
            plt.suptitle(f"QLP: Вплив {FIN_CYCLE_VAR} на {current_target_var} по Горизонтах", fontsize=16, y=0.99)
            plt.savefig(os.path.join(plots_dir, f'qlp_coeffs_vs_horizon_{current_target_var}.png'));
            plt.close()
    except Exception as e:
        print(f"ПОМИЛКА QLP (vs Horizon) графіка для {current_target_var}: {e}")

    # --- 7. Розрахунок похідних показників (BCaR, SVB) - ТІЛЬКИ ДЛЯ ROA_PRETAX ---
    if current_target_var == 'roa_pretax':
        print(f"\n--- Розрахунок BCaR та SVB (тільки для {current_target_var}) ---")
        can_calculate_bcar_svb = True
        # Check df_reset for necessary columns for BCaR/SVB
        if AVG_RISK_WEIGHT_VAR not in df_reset.columns:
            print(f"  ПОПЕРЕДЖЕННЯ: '{AVG_RISK_WEIGHT_VAR}' відсутній у df_reset. Розрахунок BCaR/SVB неможливий.")
            can_calculate_bcar_svb = False
        if TOTAL_ASSETS_VAR not in df_reset.columns:
            print(f"  ПОПЕРЕДЖЕННЯ: '{TOTAL_ASSETS_VAR}' відсутній у df_reset. Розрахунок BCaR/SVB неможливий.")
            can_calculate_bcar_svb = False

        model_info_for_calc = qlp_fitted_models.get(BCAR_SVB_HORIZON)
        model_for_calc = model_info_for_calc.get(INDIVIDUAL_PRED_QUANTILE) if model_info_for_calc else None
        df_analyze = model_info_for_calc.get('data_for_pred') if model_info_for_calc else None

        if not model_for_calc or df_analyze is None or df_analyze.empty:
            print(
                f"  ПОПЕРЕДЖЕННЯ: Модель QLP або дані для h={BCAR_SVB_HORIZON}, q={INDIVIDUAL_PRED_QUANTILE} для BCaR/SVB не знайдена або порожні.")
            can_calculate_bcar_svb = False

        if can_calculate_bcar_svb:
            try:  # BCaR Calculation
                missing_preds_bcar = [p for p in model_for_calc.model.exog_names if
                                      p not in df_analyze.columns and p != 'Intercept']
                if missing_preds_bcar: raise ValueError(f"Відсутні предиктори для BCaR: {missing_preds_bcar}")

                df_analyze.loc[:, f'predicted_roa_q_calc'] = model_for_calc.predict(df_analyze)
                df_analyze[AVG_RISK_WEIGHT_VAR] = pd.to_numeric(df_analyze[AVG_RISK_WEIGHT_VAR], errors='coerce')
                df_analyze[TOTAL_ASSETS_VAR] = pd.to_numeric(df_analyze[TOTAL_ASSETS_VAR], errors='coerce')
                rwa_density = (df_analyze[AVG_RISK_WEIGHT_VAR] / 100.0).replace(0, np.nan)  # Avoid division by zero
                df_analyze.loc[:, 'capital_impact_q_bcar'] = df_analyze[f'predicted_roa_q_calc'] / rwa_density

                # Ensure TIME_ID_VAR is present and is PeriodIndex before groupby
                if TIME_ID_VAR not in df_analyze.columns: raise ValueError(
                    f"Стовпець {TIME_ID_VAR} відсутній в df_analyze для BCaR")
                if not isinstance(df_analyze[TIME_ID_VAR].iloc[0], pd.Period):
                    df_analyze[TIME_ID_VAR] = pd.to_datetime(df_analyze[TIME_ID_VAR]).dt.to_period(
                        'Q' if not is_annual_data else 'Y')

                df_analyze_bcar_valid = df_analyze.dropna(
                    subset=[TOTAL_ASSETS_VAR, 'capital_impact_q_bcar', TIME_ID_VAR])
                if not df_analyze_bcar_valid.empty:
                    bcar_timeseries = df_analyze_bcar_valid.groupby(TIME_ID_VAR).apply(
                        lambda x: np.average(x['capital_impact_q_bcar'], weights=x[TOTAL_ASSETS_VAR]) if x[
                                                                                                             TOTAL_ASSETS_VAR].sum() > 0 else np.nan
                    ).dropna()
                    if not bcar_timeseries.empty:
                        bcar_timeseries.to_excel(os.path.join(plots_dir, f'bcar_timeseries_{current_target_var}.xlsx'))
                        print(
                            f"  Часовий ряд BCaR для {current_target_var} збережено. Середнє значення: {bcar_timeseries.mean():.3f}")
                    else:
                        print(f"  Часовий ряд BCaR для {current_target_var} порожній після видалення NaN.")
                else:
                    print(f"  Неможливо розрахувати BCaR для {current_target_var}: немає валідних даних.")
            except Exception as e:
                print(f"    ПОМИЛКА BCaR ({current_target_var}): {e}")

            try:  # SVB Calculation
                if f'predicted_roa_q_calc' in df_analyze.columns:
                    df_analyze.loc[:, 'is_vulnerable'] = df_analyze[f'predicted_roa_q_calc'] < SVB_THRESHOLD

                    if TIME_ID_VAR not in df_analyze.columns: raise ValueError(
                        f"Стовпець {TIME_ID_VAR} відсутній в df_analyze для SVB")
                    if not isinstance(df_analyze[TIME_ID_VAR].iloc[0], pd.Period):  # Ensure PeriodIndex
                        df_analyze[TIME_ID_VAR] = pd.to_datetime(df_analyze[TIME_ID_VAR]).dt.to_period(
                            'Q' if not is_annual_data else 'Y')

                    df_analyze_svb_valid = df_analyze.dropna(subset=[TOTAL_ASSETS_VAR, 'is_vulnerable', TIME_ID_VAR])
                    if not df_analyze_svb_valid.empty:
                        vulnerable_assets = \
                        df_analyze_svb_valid[df_analyze_svb_valid['is_vulnerable']].groupby(TIME_ID_VAR)[
                            TOTAL_ASSETS_VAR].sum()
                        total_assets_ts = df_analyze_svb_valid.groupby(TIME_ID_VAR)[TOTAL_ASSETS_VAR].sum()
                        svb_timeseries = (vulnerable_assets.reindex(total_assets_ts.index,
                                                                    fill_value=0) / total_assets_ts.replace(0,
                                                                                                            np.nan) * 100).fillna(
                            0).dropna()
                        if not svb_timeseries.empty:
                            svb_timeseries.to_excel(
                                os.path.join(plots_dir, f'svb_timeseries_{current_target_var}.xlsx'))
                            print(
                                f"  Часовий ряд SVB для {current_target_var} збережено. Середнє значення: {svb_timeseries.mean():.2f}%")
                        else:
                            print(f"  Часовий ряд SVB для {current_target_var} порожній після видалення NaN.")
                    else:
                        print(f"  Неможливо розрахувати SVB для {current_target_var}: немає валідних даних.")
                else:
                    print(
                        f"  Неможливо розрахувати SVB для {current_target_var}: відсутній прогноз 'predicted_roa_q_calc'.")
            except Exception as e:
                print(f"    ПОМИЛКА SVB ({current_target_var}): {e}")
        else:
            print(f"  Розрахунок BCaR та SVB пропущено для {current_target_var} через відсутність моделі/даних.")
    else:
        print(f"  Розрахунок BCaR та SVB не застосовується для цільового показника: {current_target_var}.")

    # Кумулятивний ефект LLP
    try:
        if not df_llp.empty:
            df_llp.index = pd.to_numeric(df_llp.index, errors='coerce')  # Ensure index is numeric for isin
            df_llp_valid_coef = df_llp.dropna(subset=['coef'])  # Use only rows with valid coefficients

            valid_horizons_llp = df_llp_valid_coef.index[
                df_llp_valid_coef.index.isin(range(H_CUM_START, H_CUM_END + 1))]
            if not valid_horizons_llp.empty:
                cumulative_coef_llp = df_llp_valid_coef.loc[valid_horizons_llp, 'coef'].sum()
                print(
                    f"\n  Кумулятивний середній вплив LLP на {current_target_var} (h={H_CUM_START}-{H_CUM_END}): {cumulative_coef_llp:.3f} п.п.")
            else:
                print(
                    f"  Немає валідних горизонтів для кумулятивного ефекту LLP для {current_target_var} в діапазоні {H_CUM_START}-{H_CUM_END}.")
    except Exception as e:
        print(f"  Помилка кумулятивного ефекту LLP для {current_target_var}: {e}")

    print(f"\n--- АНАЛІЗ ДЛЯ ЦІЛЬОВОГО ПОКАЗНИКА: {current_target_var} ЗАВЕРШЕНО ---")

print("\n\n--- ВЕСЬ АНАЛІЗ ЗАВЕРШЕНО ---")