clc; clear; close all;

%% Завантаження даних з CSV
filename = 'banks_data.csv'; % Замініть на реальну назву файлу
dataTable = readtable(filename, 'VariableNamingRule', 'preserve'); 
bankNames = dataTable{:, 1}; % Вибір стовпця з іменами банків
data = table2array(dataTable(:, 2:end)); % Перетворення в числовий масив

%% Обробка NaN значень
% Замінити NaN медіаною, щоб зменшити вплив викидів
data = fillmissing(data, 'constant', median(data, 'omitnan'));

%% Нормалізація даних із урахуванням позитивних та негативних факторів
positiveIndicators = [1, 2, 3, 9, 10, 11]; % H1, НРК, НК1, НОК1, LCRвв, LCRів, NSFR
negativeIndicators = [4, 5, 6, 7, 8]; % Н7, Н8, Н9, Н11, Н12, Л13-1, Л13-2

% Інвертуємо негативні показники, щоб вони також стали позитивними
data(:, negativeIndicators) = -data(:, negativeIndicators);

% Робастна нормалізація (на основі медіани та IQR)
med = median(data, 'omitnan');
iqrVal = iqr(data);
data = (data - med) ./ iqrVal;

%% SOM Кластеризація
gridSize = [15 15]; % 15×15 (225 нейронів)
net = selforgmap(gridSize);
net.trainParam.epochs = 10000; % Максимально можливе число ітерацій
net = train(net, data');

%% Візуалізація карти нейронів
figure;
plotsom(net.iw{1,1}, net.layers{1}.distances);
title('Карта нейронів SOM');

%% Призначення банкам кластерів на основі SOM
y = net(data');
[~, clusterIdx] = max(y, [], 1);

%% Визначення 4 фінальних кластерів через K-means
numFinalClusters = 4; % Кількість фінальних кластерів
finalClusters = kmeans(data, numFinalClusters);

%% Виведення результатів
resultTable = table(bankNames, finalClusters, 'VariableNames', {'Bank', 'RiskLevel'});
disp(resultTable);

%% Збереження в CSV
writetable(resultTable, 'bank_risk_clusters_V3.csv');

%% Візуалізація за допомогою PCA
[coeff, score, latent] = pca(data);
figure;
gscatter(score(:,1), score(:,2), finalClusters, ['r' 'm' 'b' 'g'], 'o', 8);
xlabel('Головний компонент 1');
ylabel('Головний компонент 2');
title('Кластеризація банків за ризиком (SOM)');
legend('Кластер 1', 'Кластер 2', 'Кластер 3', 'Кластер 4');
grid on;

%% Boxplot для розподілу значень у кластерах
figure;
for i = 1:size(data, 2)
    subplot(3, ceil(size(data, 2) / 3), i);
    boxplot(data(:, i), finalClusters);
    title(dataTable.Properties.VariableNames{i+1}, 'Interpreter', 'none');
    xlabel('Кластери');
    ylabel('Нормалізоване значення');
    grid on;
end
suptitle('Boxplot розподілу фінансових показників по кластерах');

%% Heatmap для візуалізації відмінностей між кластерами
figure;
clusterMeans = zeros(numFinalClusters, size(data, 2));
for i = 1:numFinalClusters
    clusterMeans(i, :) = mean(data(finalClusters == i, :), 1);
end
heatmap(dataTable.Properties.VariableNames(2:end), 1:numFinalClusters, clusterMeans);
title('Середні значення фінансових показників по кластерах');
xlabel('Фінансові показники');
ylabel('Кластери');

%% Аналіз основних факторів впливу на кластеризацію
explainedVariance = 100 * latent / sum(latent);
figure;
bar(explainedVariance);
title('Відсоток поясненої дисперсії для кожної головної компоненти');
xlabel('Головні компоненти');
ylabel('Відсоток поясненої дисперсії');
grid on;

% Визначення важливості ознак
[~, topFeatures] = max(abs(coeff), [], 1);
importantFactors = dataTable.Properties.VariableNames(2:end);
importantFactors = importantFactors(topFeatures);
disp('Найбільш впливові фактори для кластеризації:');
disp(importantFactors);
