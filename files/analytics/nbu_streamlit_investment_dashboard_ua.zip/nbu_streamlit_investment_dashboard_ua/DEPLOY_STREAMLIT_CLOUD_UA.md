# Деплой на Streamlit Community Cloud

## 1. Створити GitHub repository

Завантажте в репозиторій усі файли:

```text
app.py
src/
.streamlit/
requirements.txt
README_UA.md
```

## 2. Створити Streamlit app

1. Відкрити Streamlit Community Cloud.
2. New app.
3. Обрати GitHub repo.
4. Main file path: `app.py`.
5. Deploy.

## 3. Автоматичність

Дані беруться напряму з NBU API при відкритті app. У `app.py` стоїть кеш:

```python
@st.cache_data(ttl=12 * 60 * 60)
```

Це означає, що app не буде зайвий раз бити API, але оновить дані після закінчення TTL або після кнопки "Очистити кеш і перезавантажити".

Для академічної роботи це достатньо: dashboard завжди може підтягнути актуальну звітність без ручної підготовки CSV.

## 4. Якщо треба повний production

Для production-варіанту можна додати:
- GitHub Actions, який щомісяця зберігає snapshot CSV;
- database layer: Supabase / PostgreSQL;
- authentication;
- окрему сторінку methodology + data quality checks.
