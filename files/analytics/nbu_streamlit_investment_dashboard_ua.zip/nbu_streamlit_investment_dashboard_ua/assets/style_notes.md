Light green academic / World Bank-inspired palette: #F7FBF7, #F1F8E9, #2E7D32, #66A61E, #143D17.
