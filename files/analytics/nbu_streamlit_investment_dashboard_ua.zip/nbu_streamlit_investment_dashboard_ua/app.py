from __future__ import annotations

from datetime import datetime

import pandas as pd
import streamlit as st

from src.charts import (
    bank_scatter,
    investment_result_waterfall,
    investment_structure_bar,
    investments_to_assets_line,
    yield_comparison_line,
)
from src.config import GROUP_LABELS
from src.metrics import (
    TABLE1_SPECS,
    TABLE2_SPECS,
    add_derived_for_bank_level,
    aggregate_entity,
    make_metric_table,
    prepare_wide,
    to_excel_bytes,
)
from src.nbu_api import fetch_banksfinrep_range
from src.style import inject_css


st.set_page_config(
    page_title="NBU Banks Investment Dashboard",
    page_icon="🏦",
    layout="wide",
)

inject_css()


@st.cache_data(ttl=12 * 60 * 60, show_spinner=False)
def load_data(start_year: int, end_year: int, only_uah_r034: bool):
    raw = fetch_banksfinrep_range(start_year, end_year, only_uah_r034=only_uah_r034)
    wide = prepare_wide(raw)
    return raw, wide


def fmt_bn(v: float) -> str:
    if pd.isna(v):
        return "—"
    return f"{v / 1000:,.2f} млрд грн".replace(",", " ")


def fmt_pct(v: float) -> str:
    if pd.isna(v):
        return "—"
    return f"{v:,.2f}%".replace(",", " ")


st.markdown(
    """
    <div class="hero">
      <h1>Інвестиційна діяльність банків України</h1>
      <p>Streamlit-dashboard на основі NBU OpenData: структура інвестицій, фінансові результати, кредитна дохідність і вартість ресурсів.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("### ⚙️ Параметри dashboard")

    start_year, end_year = st.slider(
        "Період аналізу",
        min_value=2018,
        max_value=max(2026, datetime.now().year),
        value=(2021, 2025),
        step=1,
    )

    show_quarters = st.toggle(
        "Показати квартали у таблицях",
        value=False,
        help="Для графіків використовуються тільки річні Q4/12M значення, бо доходи/витрати у звітності накопичуються з початку року.",
    )

    denominator_mode_label = st.radio(
        "Знаменник для дохідностей",
        options=[
            "Середній залишок за період",
            "Залишок на звітну дату",
        ],
        index=0,
        help="Середній залишок краще для академічної інтерпретації дохідності; залишок на дату ближчий до простої табличної логіки.",
    )
    denominator_mode = "average" if denominator_mode_label.startswith("Середній") else "eop"

    only_uah_r034 = st.checkbox(
        "Фільтр r034=1",
        value=True,
        help="Зазвичай для BS1 це гривневе/загальне подання. Якщо дані порожні — вимкніть фільтр.",
    )

    if st.button("🔄 Очистити кеш і перезавантажити", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

with st.spinner("Завантаження даних НБУ та розрахунок показників..."):
    try:
        raw, wide = load_data(start_year, end_year, only_uah_r034)
    except Exception as e:
        st.error("Не вдалося завантажити дані з NBU API.")
        st.exception(e)
        st.stop()

if raw.empty or wide.empty:
    st.warning("Дані не завантажилися. Спробуйте інший період або вимкніть фільтр r034=1.")
    st.stop()

# Selection controls after data load
banks = sorted([x for x in wide["fullname"].dropna().unique().tolist() if str(x).strip()])
group_codes = sorted([x for x in wide["gr_bank"].dropna().astype(str).unique().tolist() if str(x).strip()])

col_a, col_b, col_c = st.columns([1.1, 1.1, 2.0])

with col_a:
    scope_label = st.selectbox(
        "Рівень аналізу",
        ["Окремий банк", "Група банків", "Банківська система"],
        index=0,
    )

with col_b:
    selected_group = None
    if scope_label == "Група банків":
        selected_group = st.selectbox(
            "Група",
            group_codes,
            format_func=lambda x: GROUP_LABELS.get(x, x),
        )
    elif scope_label == "Окремий банк":
        group_filter_label = st.selectbox(
            "Фільтр групи для списку банків",
            ["Усі"] + group_codes,
            format_func=lambda x: "Усі" if x == "Усі" else GROUP_LABELS.get(x, x),
        )
    else:
        st.write("")

with col_c:
    selected_bank = None
    if scope_label == "Окремий банк":
        filtered_bank_df = wide.copy()
        if group_filter_label != "Усі":
            filtered_bank_df = filtered_bank_df[filtered_bank_df["gr_bank"].astype(str) == group_filter_label]
        bank_options = sorted(filtered_bank_df["fullname"].dropna().unique().tolist())
        default_idx = 0
        for i, b in enumerate(bank_options):
            if "ВСТ БАНК" in b or "VST" in b.upper():
                default_idx = i
                break
        selected_bank = st.selectbox("Банк", bank_options, index=default_idx if bank_options else 0)
    else:
        st.write("")

scope = "bank" if scope_label == "Окремий банк" else "group" if scope_label == "Група банків" else "system"

entity_df = aggregate_entity(
    wide,
    scope=scope,
    bank_name=selected_bank,
    group_code=selected_group,
    denominator_mode=denominator_mode,
)

if entity_df.empty:
    st.warning("Немає даних для обраного рівня аналізу.")
    st.stop()

entity_visible = entity_df[
    (entity_df["financial_year"].between(start_year, end_year)) &
    (entity_df["quarter_label"] == "Q4 / 12M")
].copy()

latest_year = int(entity_visible["financial_year"].max()) if not entity_visible.empty else end_year
latest = entity_visible[entity_visible["financial_year"] == latest_year].iloc[0] if not entity_visible.empty else None

st.markdown(
    f"""
    <div class="method-note">
    <b>Методологія:</b> балансові показники — залишки на звітну дату; доходи/витрати — накопичені значення за період.
    Значення API інтерпретуються як млн грн; у табличних формах грошові показники подані у тис. грн.
    Для графіків використано річні спостереження <b>Q4 / 12M</b>. Поточний режим дохідностей: <b>{denominator_mode_label}</b>.
    </div>
    """,
    unsafe_allow_html=True,
)

if latest is not None:
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Чисті активи", fmt_bn(latest["BS1_AssetsNet"]))
    k2.metric("Усього інвестицій", fmt_bn(latest["Investments_total"]))
    k3.metric("Інвестиції / активи", fmt_pct(latest["Investments_to_assets_pct"]))
    k4.metric("Дінв, proxy", fmt_pct(latest["Dinv_pct_proxy"]))

tab_overview, tab_tables, tab_benchmark, tab_data, tab_method = st.tabs(
    ["📈 Огляд", "📋 Академічні таблиці", "🏦 Порівняння банків", "⬇️ Дані", "ℹ️ Методологія"]
)

with tab_overview:
    st.markdown('<div class="section-title">Ключові графіки</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        st.plotly_chart(investment_structure_bar(entity_df, start_year, end_year), use_container_width=True)
    with c2:
        st.plotly_chart(investments_to_assets_line(entity_df, start_year, end_year), use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        st.plotly_chart(yield_comparison_line(entity_df, start_year, end_year), use_container_width=True)
    with c4:
        st.plotly_chart(investment_result_waterfall(entity_df, latest_year), use_container_width=True)

with tab_tables:
    st.markdown('<div class="section-title">2. Склад та структура інвестиційних вкладень банку</div>', unsafe_allow_html=True)
    table1_display, table1_numeric = make_metric_table(entity_df, TABLE1_SPECS, start_year, end_year, show_quarters)
    st.dataframe(table1_display, hide_index=True, use_container_width=True, height=500)

    st.markdown('<div class="section-title">3. Склад та структура доходів від інвестиційної діяльності банку</div>', unsafe_allow_html=True)
    table2_display, table2_numeric = make_metric_table(entity_df, TABLE2_SPECS, start_year, end_year, show_quarters)
    st.dataframe(table2_display, hide_index=True, use_container_width=True, height=500)

    excel_bytes = to_excel_bytes({
        "Table 2 display": table1_display,
        "Table 2 numeric": table1_numeric,
        "Table 3 display": table2_display,
        "Table 3 numeric": table2_numeric,
    })
    st.download_button(
        "⬇️ Завантажити таблиці Excel",
        data=excel_bytes,
        file_name="nbu_investment_tables_ua.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )

with tab_benchmark:
    st.markdown('<div class="section-title">Позиція банку відносно системи</div>', unsafe_allow_html=True)
    bank_level = add_derived_for_bank_level(wide, denominator_mode=denominator_mode)
    selected_year_for_scatter = st.select_slider(
        "Рік для cross-section",
        options=list(range(start_year, end_year + 1)),
        value=latest_year,
    )
    st.plotly_chart(bank_scatter(bank_level, selected_bank, selected_year_for_scatter), use_container_width=True)

    st.markdown("#### Топ банків за часткою інвестицій у чистих активах")
    rank_df = bank_level[
        (bank_level["financial_year"] == selected_year_for_scatter) &
        (bank_level["quarter_label"] == "Q4 / 12M")
    ].copy()
    rank_df["Чисті активи, млрд грн"] = rank_df["BS1_AssetsNet"] / 1000
    rank_df = rank_df.sort_values("Investments_to_assets_pct", ascending=False)
    st.dataframe(
        rank_df[["fullname", "gr_bank", "Чисті активи, млрд грн", "Investments_to_assets_pct", "Dinv_pct_proxy"]]
        .rename(columns={
            "fullname": "Банк",
            "gr_bank": "Група",
            "Investments_to_assets_pct": "Інвестиції / активи, %",
            "Dinv_pct_proxy": "Дінв, proxy, %",
        })
        .head(25),
        hide_index=True,
        use_container_width=True,
    )

with tab_data:
    st.markdown('<div class="section-title">Експорт і діагностика даних</div>', unsafe_allow_html=True)
    st.write(f"Завантажено рядків raw API: **{len(raw):,}**; широких bank-date рядків: **{len(wide):,}**.".replace(",", " "))
    st.write("Перші рядки агрегованого entity dataset:")
    st.dataframe(entity_df.head(20), use_container_width=True)

    st.download_button(
        "⬇️ Entity data CSV",
        entity_df.to_csv(index=False, encoding="utf-8-sig"),
        file_name="entity_metrics.csv",
        mime="text/csv",
        use_container_width=True,
    )
    st.download_button(
        "⬇️ Bank-date wide CSV",
        wide.to_csv(index=False, encoding="utf-8-sig"),
        file_name="wide_bank_quarter.csv",
        mime="text/csv",
        use_container_width=True,
    )

with tab_method:
    st.markdown(
        """
        ### Методологічні зауваження

        1. **Дата річного спостереження.** Для фінансового року `y` використовується `date=(y+1)0101&period=q`, тобто Q4 / 12M.
        2. **Квартали в таблицях.** Q1, Q2, Q3 і Q4 у звітності доходів/витрат є накопиченими значеннями з початку року. Тому квартали в таблицях показуються як reporting view, а не як незалежні квартальні потоки.
        3. **Процентні доходи від цінних паперів.** У базовому BS1 немає чистого окремого поля саме для interest income from securities. У dashboard використано proxy:
           `BS1_InterestIncome - BS1_InterestIncomeLE - BS1_InterestIncomeIndiv`.
        4. **ОВДП.** Поле `BS1_AssetsIGLBRefinNBU` означає ОВДП, що рефінансуються НБУ. Це не весь портфель ОВДП банку. Тому рядок підписано як proxy/обмежений показник.
        5. **Дінв.** Proxy фінрезультату інвест. діяльності = процентний proxy за цінними паперами + торговий результат − приріст резервів під цінні папери.
        6. **Вартість ресурсів.** Знаменник — proxy процентної ресурсної бази: кошти клієнтів + кошти банків + кошти НБУ + боргові цінні папери + інші залучені кошти + субординований борг.
        """
    )

st.markdown(
    """
    <div class="footer">
    Джерело: Національний банк України, OpenData REST API, набір <code>banksfinrep</code>.
    Dashboard підготовлений для академічного аналізу інвестиційної діяльності банків.
    </div>
    """,
    unsafe_allow_html=True,
)
