"""
Configuration for the NBU Streamlit dashboard.
All monetary values returned by the API are treated as mln UAH and converted in tables where needed.
"""

BASE_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/banksfinrep"

GROUP_LABELS = {
    "A": "A — державні банки / state-owned",
    "B": "B — банки іноземних банківських груп",
    "E": "E — банки з приватним капіталом",
    "F": "F — неплатоспроможні / ліквідація",
}

# Core id_api fields used by the two academic tables and dashboard.
ID_API = [
    # Assets / investment portfolio
    "BS1_AssetsNet",
    "BS1_FinAssetsFairVal",
    "BS1_FinAssetsFVPLRefinNBU",
    "BS1_AssetsSecurFVOCI",
    "BS1_AssetsSecurFVOCIRefinNBU",
    "BS1_AssetsSecurAC",
    "BS1_AssetsSecurACRefinNBU",
    "BS1_AssetsInvestSubsid",
    "BS1_AssetsIGLBRefinNBU",

    # Loans
    "BS1_AssetsLoansClients",

    # Income and expenses
    "BS1_InterestIncome",
    "BS1_InterestIncomeLE",
    "BS1_InterestIncomeIndiv",
    "BS1_InterestCosts",
    "BS1_TradeRes",
    "BS1_NetIncome",  # older alias in some extracts
    "BS1_TradeResSecur",
    "BS1_NetIncrProvSecur",
    "BS1_NetIncrProvLoansGranted",

    # Interest-bearing resources proxy
    "BS1_LiabCust",
    "BS1_LiabBanks",
    "BS1_LiabNBU",
    "BS1_LiabDebtSecur",
    "BS1_LiabOtherBorrFunds",
    "BS1_LiabSubDebt",
]

FIELD_UA = {
    "BS1_AssetsNet": "Чисті активи, усього",
    "BS1_FinAssetsFairVal": "Фінансові активи FVPL",
    "BS1_FinAssetsFVPLRefinNBU": "Фінансові активи FVPL, що рефінансуються НБУ",
    "BS1_AssetsSecurFVOCI": "Цінні папери FVOCI",
    "BS1_AssetsSecurFVOCIRefinNBU": "Цінні папери FVOCI, що рефінансуються НБУ",
    "BS1_AssetsSecurAC": "Цінні папери за амортизованою собівартістю",
    "BS1_AssetsSecurACRefinNBU": "Цінні папери AC, що рефінансуються НБУ",
    "BS1_AssetsInvestSubsid": "Інвестиції в асоційовані та дочірні компанії",
    "BS1_AssetsIGLBRefinNBU": "ОВДП, що рефінансуються НБУ",
    "BS1_AssetsLoansClients": "Кредити та заборгованість клієнтів",
    "BS1_InterestIncome": "Процентні доходи",
    "BS1_InterestIncomeLE": "Процентні доходи від операцій з юридичними особами",
    "BS1_InterestIncomeIndiv": "Процентні доходи від операцій з фізичними особами",
    "BS1_InterestCosts": "Процентні витрати",
    "BS1_TradeRes": "Торговий результат",
    "BS1_NetIncome": "Торговий результат, старий alias",
    "BS1_TradeResSecur": "Торговий результат від операцій з цінними паперами",
    "BS1_NetIncrProvSecur": "Чисте збільшення/зменшення резервів під знецінення цінних паперів",
    "BS1_NetIncrProvLoansGranted": "Чисте збільшення/зменшення резервів під кредити клієнтам",
    "BS1_LiabCust": "Кошти клієнтів",
    "BS1_LiabBanks": "Кошти банків",
    "BS1_LiabNBU": "Кошти отримані від НБУ",
    "BS1_LiabDebtSecur": "Боргові цінні папери, емітовані банком",
    "BS1_LiabOtherBorrFunds": "Інші залучені кошти",
    "BS1_LiabSubDebt": "Субординований борг",
}

INVESTMENT_COMPONENTS = {
    "IP1_FVPL": "ІП1: FVPL",
    "IP2_FVOCI": "ІП2: FVOCI",
    "IP3_AC": "ІП3: Amortized cost",
    "IP4_SUBSIDIARIES": "ІП4: дочірні/асоційовані",
}

GREEN_PALETTE = [
    "#2E7D32",
    "#66A61E",
    "#9CCC65",
    "#C5E1A5",
    "#1B5E20",
    "#7CB342",
    "#AED581",
]

PLOTLY_TEMPLATE = "plotly_white"
