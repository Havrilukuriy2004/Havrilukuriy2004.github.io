from __future__ import annotations

from io import BytesIO
from typing import Literal

import numpy as np
import pandas as pd

from .config import ID_API


def safe_div(num, den):
    den = pd.Series(den).replace({0: np.nan})
    return pd.Series(num) / den


def prepare_wide(raw: pd.DataFrame) -> pd.DataFrame:
    """
    Convert NBU long API response to bank-date wide format.
    Values are in mln UAH.
    """
    if raw.empty:
        return pd.DataFrame()

    group_cols = [
        "reporting_date", "request_date", "financial_year", "quarter_label", "is_baseline",
        "nkb", "mfo", "fullname", "gr_bank", "id_api"
    ]
    raw = raw.copy()
    raw["value"] = pd.to_numeric(raw["value"], errors="coerce").fillna(0.0)

    agg = raw.groupby(group_cols, dropna=False)["value"].sum().reset_index()

    wide = (
        agg.pivot_table(
            index=["reporting_date", "request_date", "financial_year", "quarter_label", "is_baseline",
                   "nkb", "mfo", "fullname", "gr_bank"],
            columns="id_api",
            values="value",
            aggfunc="sum",
            fill_value=0.0,
        )
        .reset_index()
    )

    wide.columns.name = None

    for col in ID_API:
        if col not in wide.columns:
            wide[col] = 0.0

    return wide.sort_values(["fullname", "reporting_date"]).reset_index(drop=True)


def add_derived_metrics(df: pd.DataFrame, denominator_mode: str = "average") -> pd.DataFrame:
    """
    Add calculated indicators.
    Values remain in mln UAH for monetary fields; ratios are percentages.
    """
    if df.empty:
        return df

    out = df.copy()
    for col in ID_API:
        if col not in out.columns:
            out[col] = 0.0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0)

    out["IP1_FVPL"] = out["BS1_FinAssetsFairVal"]
    out["IP2_FVOCI"] = out["BS1_AssetsSecurFVOCI"]
    out["IP3_AC"] = out["BS1_AssetsSecurAC"]
    out["IP4_SUBSIDIARIES"] = out["BS1_AssetsInvestSubsid"]

    out["Investments_total"] = (
        out["IP1_FVPL"] + out["IP2_FVOCI"] + out["IP3_AC"] + out["IP4_SUBSIDIARIES"]
    )
    out["Investments_excl_IP4"] = out["IP1_FVPL"] + out["IP2_FVOCI"] + out["IP3_AC"]

    out["Investments_to_assets_pct"] = safe_div(out["Investments_total"], out["BS1_AssetsNet"]) * 100
    out["OVDP_refin_to_investments_pct"] = safe_div(out["BS1_AssetsIGLBRefinNBU"], out["Investments_total"]) * 100
    out["OVDP_refin_to_assets_pct"] = safe_div(out["BS1_AssetsIGLBRefinNBU"], out["BS1_AssetsNet"]) * 100

    # If official total trading result is absent in historical extracts, fallback to old alias.
    out["Trading_result_total"] = out["BS1_TradeRes"]
    fallback_mask = out["Trading_result_total"].isna() | (out["Trading_result_total"].abs() < 1e-12)
    out.loc[fallback_mask, "Trading_result_total"] = out.loc[fallback_mask, "BS1_NetIncome"]

    # Direct securities interest income is not available as a clean separate BS1 field.
    # Proxy = total interest income - client interest income.
    out["Interest_income_clients"] = out["BS1_InterestIncomeLE"] + out["BS1_InterestIncomeIndiv"]
    out["Interest_income_securities_proxy"] = (
        out["BS1_InterestIncome"] - out["BS1_InterestIncomeLE"] - out["BS1_InterestIncomeIndiv"]
    )

    out["Investment_fin_result_proxy"] = (
        out["Interest_income_securities_proxy"]
        + out["Trading_result_total"]
        - out["BS1_NetIncrProvSecur"]
    )

    out["Interest_bearing_resources"] = (
        out["BS1_LiabCust"]
        + out["BS1_LiabBanks"]
        + out["BS1_LiabNBU"]
        + out["BS1_LiabDebtSecur"]
        + out["BS1_LiabOtherBorrFunds"]
        + out["BS1_LiabSubDebt"]
    )

    out = add_average_denominators(out)

    inv_denom = out["Avg_investments_excl_IP4"] if denominator_mode == "average" else out["Investments_excl_IP4"]
    loans_denom = out["Avg_loans_clients"] if denominator_mode == "average" else out["BS1_AssetsLoansClients"]
    resources_denom = out["Avg_interest_bearing_resources"] if denominator_mode == "average" else out["Interest_bearing_resources"]

    out["Dinv_pct_proxy"] = safe_div(out["Investment_fin_result_proxy"], inv_denom) * 100
    out["Loan_yield_gross_pct"] = safe_div(out["Interest_income_clients"], loans_denom) * 100
    out["Loan_yield_net_pct"] = safe_div(
        out["Interest_income_clients"] - out["BS1_NetIncrProvLoansGranted"], loans_denom
    ) * 100
    out["Cost_of_resources_pct"] = safe_div(out["BS1_InterestCosts"], resources_denom) * 100

    return out


def _period_start_date(row: pd.Series) -> pd.Timestamp:
    fy = int(row["financial_year"])
    q = str(row["quarter_label"])
    if q == "Q1":
        return pd.Timestamp(fy, 1, 1)
    if q == "Q2":
        return pd.Timestamp(fy, 4, 1)
    if q == "Q3":
        return pd.Timestamp(fy, 7, 1)
    # Annual 12M: use beginning of financial year.
    return pd.Timestamp(fy, 1, 1)


def add_average_denominators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Average denominators:
    - Q1: average between Jan 1 and Apr 1.
    - Q2: average between Apr 1 and Jul 1.
    - Q3: average between Jul 1 and Oct 1.
    - Q4/12M: average between Jan 1 and next Jan 1.
    """
    out = df.sort_values("reporting_date").copy()
    out["reporting_date"] = pd.to_datetime(out["reporting_date"], errors="coerce")

    cols = {
        "Investments_excl_IP4": "Avg_investments_excl_IP4",
        "BS1_AssetsLoansClients": "Avg_loans_clients",
        "Interest_bearing_resources": "Avg_interest_bearing_resources",
    }

    lookup = out.set_index("reporting_date")
    for source_col, avg_col in cols.items():
        starts = []
        for _, row in out.iterrows():
            start_date = _period_start_date(row)
            if start_date in lookup.index:
                start_value = lookup.loc[start_date, source_col]
                if isinstance(start_value, pd.Series):
                    start_value = float(start_value.iloc[0])
            else:
                start_value = row[source_col]
            starts.append(start_value)

        out[f"{source_col}_period_start"] = starts
        out[avg_col] = (pd.to_numeric(out[source_col], errors="coerce").fillna(0.0)
                        + pd.to_numeric(out[f"{source_col}_period_start"], errors="coerce").fillna(0.0)) / 2

    return out


def aggregate_entity(
    wide: pd.DataFrame,
    scope: Literal["bank", "group", "system"],
    bank_name: str | None = None,
    group_code: str | None = None,
    denominator_mode: str = "average",
) -> pd.DataFrame:
    """
    Aggregate by selected entity and recalculate ratios.
    """
    if wide.empty:
        return pd.DataFrame()

    df = wide.copy()

    if scope == "bank" and bank_name:
        df = df[df["fullname"] == bank_name].copy()
        label = bank_name
    elif scope == "group" and group_code:
        df = df[df["gr_bank"].astype(str) == group_code].copy()
        label = f"Група {group_code}"
    else:
        label = "Банківська система"

    value_cols = [c for c in ID_API if c in df.columns]
    meta_cols = ["reporting_date", "request_date", "financial_year", "quarter_label", "is_baseline"]

    if df.empty:
        return pd.DataFrame()

    out = df.groupby(meta_cols, dropna=False)[value_cols].sum().reset_index()
    out["entity"] = label
    out["scope"] = scope
    return add_derived_metrics(out, denominator_mode=denominator_mode)


def add_derived_for_bank_level(wide: pd.DataFrame, denominator_mode: str = "average") -> pd.DataFrame:
    """
    Add metrics for each bank separately for cross-sectional scatter.
    """
    if wide.empty:
        return pd.DataFrame()
    parts = []
    for _, g in wide.groupby(["nkb", "mfo", "fullname", "gr_bank"], dropna=False):
        parts.append(add_derived_metrics(g.copy(), denominator_mode=denominator_mode))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def format_number(value, unit: str) -> str:
    if value is None or pd.isna(value):
        return "—"
    try:
        v = float(value)
    except Exception:
        return "—"

    if unit == "pct":
        return f"{v:,.2f}%".replace(",", " ")
    if unit == "thsd_uah":
        return f"{v * 1000:,.0f}".replace(",", " ")
    if unit == "mln_uah":
        return f"{v:,.1f}".replace(",", " ")
    if unit == "bn_uah":
        return f"{v / 1000:,.2f}".replace(",", " ")
    return f"{v:,.2f}".replace(",", " ")


TABLE1_SPECS = [
    ("Чисті активи, тис. грн", "BS1_AssetsNet", "thsd_uah"),
    ("Фінансові активи за справедливою вартістю через прибуток або збиток (ІП1), тис. грн", "BS1_FinAssetsFairVal", "thsd_uah"),
    ("У т.ч. ІП1, що рефінансуються НБУ, тис. грн", "BS1_FinAssetsFVPLRefinNBU", "thsd_uah"),
    ("Цінні папери за справедливою вартістю через інший сукупний дохід (ІП2), тис. грн", "BS1_AssetsSecurFVOCI", "thsd_uah"),
    ("У т.ч. ІП2, що рефінансуються НБУ, тис. грн", "BS1_AssetsSecurFVOCIRefinNBU", "thsd_uah"),
    ("Цінні папери за амортизованою собівартістю (ІП3), тис. грн", "BS1_AssetsSecurAC", "thsd_uah"),
    ("У т.ч. ІП3, що рефінансуються НБУ, тис. грн", "BS1_AssetsSecurACRefinNBU", "thsd_uah"),
    ("Інвестиції в асоційовані та дочірні компанії (ІП4), тис. грн", "BS1_AssetsInvestSubsid", "thsd_uah"),
    ("Усього інвестицій (ІП1+ІП2+ІП3+ІП4), тис. грн", "Investments_total", "thsd_uah"),
    ("У % до чистих активів", "Investments_to_assets_pct", "pct"),
    ("ОВДП, що рефінансуються НБУ / proxy для рядка ОВДП, тис. грн", "BS1_AssetsIGLBRefinNBU", "thsd_uah"),
    ("У % до суми інвестицій", "OVDP_refin_to_investments_pct", "pct"),
    ("У % до чистих активів", "OVDP_refin_to_assets_pct", "pct"),
]

TABLE2_SPECS = [
    ("Процентні доходи від операцій з цінними паперами, proxy, тис. грн", "Interest_income_securities_proxy", "thsd_uah"),
    ("Торговий результат, тис. грн", "Trading_result_total", "thsd_uah"),
    ("Чисте збільшення/зменшення резервів під знецінення цінних паперів, тис. грн", "BS1_NetIncrProvSecur", "thsd_uah"),
    ("Усього фінансових результатів від інвестиційної діяльності, proxy, тис. грн", "Investment_fin_result_proxy", "thsd_uah"),
    ("Усього інвестицій, тис. грн", "Investments_total", "thsd_uah"),
    ("Дінв: фінрезультат інвест. діяльності / інвестиції без ІП4, %", "Dinv_pct_proxy", "pct"),
    ("Кредити та заборгованість клієнтів, тис. грн", "BS1_AssetsLoansClients", "thsd_uah"),
    ("Процентні доходи від операцій з юридичними та фізичними особами, тис. грн", "Interest_income_clients", "thsd_uah"),
    ("Дохідність кредитних операцій, %", "Loan_yield_gross_pct", "pct"),
    ("Чисте збільшення/зменшення резервів під кредити клієнтам, тис. грн", "BS1_NetIncrProvLoansGranted", "thsd_uah"),
    ("Чиста дохідність від кредитних операцій, %", "Loan_yield_net_pct", "pct"),
    ("Вартість ресурсів, %", "Cost_of_resources_pct", "pct"),
]


def make_metric_table(
    entity_df: pd.DataFrame,
    specs: list[tuple[str, str, str]],
    start_year: int,
    end_year: int,
    show_quarters: bool,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Return (display_table, numeric_table).
    """
    if entity_df.empty:
        return pd.DataFrame(), pd.DataFrame()

    years = list(range(start_year, end_year + 1))
    data = entity_df[entity_df["financial_year"].isin(years)].copy()
    if not show_quarters:
        data = data[data["quarter_label"] == "Q4 / 12M"].copy()

    data = data.sort_values(["financial_year", "reporting_date"])
    column_keys = []
    for _, row in data.iterrows():
        if show_quarters:
            col = f"{int(row['financial_year'])} {row['quarter_label']}"
        else:
            col = str(int(row["financial_year"]))
        if col not in column_keys:
            column_keys.append(col)

    display_rows = []
    numeric_rows = []

    for metric_name, col_name, unit in specs:
        drow = {"Показник": metric_name}
        nrow = {"Показник": metric_name, "unit": unit}
        for _, row in data.iterrows():
            key = f"{int(row['financial_year'])} {row['quarter_label']}" if show_quarters else str(int(row["financial_year"]))
            val = row[col_name] if col_name in row.index else np.nan
            drow[key] = format_number(val, unit)
            nrow[key] = val
        display_rows.append(drow)
        numeric_rows.append(nrow)

    return pd.DataFrame(display_rows), pd.DataFrame(numeric_rows)


def to_excel_bytes(tables: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        for sheet, table in tables.items():
            clean_sheet = sheet[:31].replace("/", "_").replace("\\", "_")
            table.to_excel(writer, index=False, sheet_name=clean_sheet)
    output.seek(0)
    return output.getvalue()
