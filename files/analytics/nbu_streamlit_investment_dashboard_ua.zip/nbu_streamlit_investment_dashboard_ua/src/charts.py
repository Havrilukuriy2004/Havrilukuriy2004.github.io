from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from .config import GREEN_PALETTE, INVESTMENT_COMPONENTS, PLOTLY_TEMPLATE


def _layout(fig, title: str | None = None):
    fig.update_layout(
        template=PLOTLY_TEMPLATE,
        title=title,
        title_font_size=18,
        font=dict(family="Inter, Arial, sans-serif", size=13, color="#1B2E1B"),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=25, t=60, b=45),
        legend_title_text="",
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="rgba(46,125,50,0.12)")
    return fig


def investment_structure_bar(entity_df: pd.DataFrame, start_year: int, end_year: int):
    data = entity_df[
        (entity_df["financial_year"].between(start_year, end_year)) &
        (entity_df["quarter_label"] == "Q4 / 12M")
    ].copy()

    cols = list(INVESTMENT_COMPONENTS.keys())
    long = data.melt(
        id_vars=["financial_year"],
        value_vars=cols,
        var_name="component",
        value_name="value_mln",
    )
    long["Компонент"] = long["component"].map(INVESTMENT_COMPONENTS)
    long["value_bn"] = long["value_mln"] / 1000

    fig = px.bar(
        long,
        x="financial_year",
        y="value_bn",
        color="Компонент",
        barmode="stack",
        color_discrete_sequence=GREEN_PALETTE,
        labels={"financial_year": "Рік", "value_bn": "млрд грн"},
    )
    return _layout(fig, "Структура інвестиційного портфеля")


def investments_to_assets_line(entity_df: pd.DataFrame, start_year: int, end_year: int):
    data = entity_df[
        (entity_df["financial_year"].between(start_year, end_year)) &
        (entity_df["quarter_label"] == "Q4 / 12M")
    ].copy()

    fig = px.line(
        data,
        x="financial_year",
        y="Investments_to_assets_pct",
        markers=True,
        labels={"financial_year": "Рік", "Investments_to_assets_pct": "% чистих активів"},
    )
    fig.update_traces(line=dict(width=3, color="#2E7D32"), marker=dict(size=9))
    return _layout(fig, "Частка інвестицій у чистих активах")


def yield_comparison_line(entity_df: pd.DataFrame, start_year: int, end_year: int):
    data = entity_df[
        (entity_df["financial_year"].between(start_year, end_year)) &
        (entity_df["quarter_label"] == "Q4 / 12M")
    ].copy()

    long = data.melt(
        id_vars=["financial_year"],
        value_vars=["Dinv_pct_proxy", "Loan_yield_net_pct", "Cost_of_resources_pct"],
        var_name="indicator",
        value_name="pct",
    )
    labels = {
        "Dinv_pct_proxy": "Дінв, proxy",
        "Loan_yield_net_pct": "ЧДкр",
        "Cost_of_resources_pct": "ВР",
    }
    long["Показник"] = long["indicator"].map(labels)

    fig = px.line(
        long,
        x="financial_year",
        y="pct",
        color="Показник",
        markers=True,
        color_discrete_sequence=GREEN_PALETTE,
        labels={"financial_year": "Рік", "pct": "%"},
    )
    fig.update_traces(line=dict(width=3), marker=dict(size=8))
    return _layout(fig, "Дохідність інвестицій, кредитів і вартість ресурсів")


def investment_result_waterfall(entity_df: pd.DataFrame, year: int):
    data = entity_df[
        (entity_df["financial_year"] == year) &
        (entity_df["quarter_label"] == "Q4 / 12M")
    ].copy()

    if data.empty:
        return go.Figure()

    row = data.iloc[0]
    interest = row.get("Interest_income_securities_proxy", 0) / 1000
    trading = row.get("Trading_result_total", 0) / 1000
    reserves_effect = -row.get("BS1_NetIncrProvSecur", 0) / 1000
    total = row.get("Investment_fin_result_proxy", 0) / 1000

    fig = go.Figure(go.Waterfall(
        name="",
        orientation="v",
        measure=["relative", "relative", "relative", "total"],
        x=["Процентний proxy", "Торговий результат", "Ефект резервів", "Разом"],
        y=[interest, trading, reserves_effect, total],
        connector={"line": {"color": "rgba(27,46,27,0.35)"}},
    ))
    fig.update_yaxes(title="млрд грн")
    return _layout(fig, f"Декомпозиція інвестиційного фінрезультату, {year}")


def bank_scatter(bank_level_df: pd.DataFrame, selected_bank: str | None, year: int):
    data = bank_level_df[
        (bank_level_df["financial_year"] == year) &
        (bank_level_df["quarter_label"] == "Q4 / 12M")
    ].copy()

    if data.empty:
        return go.Figure()

    data["assets_bn"] = data["BS1_AssetsNet"] / 1000
    data["selected"] = data["fullname"].eq(selected_bank)
    data["Група"] = data["gr_bank"].fillna("NA").astype(str)

    fig = px.scatter(
        data,
        x="Investments_to_assets_pct",
        y="Dinv_pct_proxy",
        size="assets_bn",
        color="Група",
        hover_name="fullname",
        hover_data={
            "assets_bn": ":.2f",
            "Investments_to_assets_pct": ":.2f",
            "Dinv_pct_proxy": ":.2f",
            "selected": False,
        },
        color_discrete_sequence=GREEN_PALETTE,
        labels={
            "Investments_to_assets_pct": "Інвестиції / чисті активи, %",
            "Dinv_pct_proxy": "Дінв, proxy, %",
            "assets_bn": "Чисті активи, млрд грн",
        },
    )

    # Highlight selected bank with an extra ring.
    if selected_bank and data["selected"].any():
        sel = data[data["selected"]]
        fig.add_trace(go.Scatter(
            x=sel["Investments_to_assets_pct"],
            y=sel["Dinv_pct_proxy"],
            mode="markers",
            marker=dict(size=22, color="rgba(0,0,0,0)", line=dict(width=3, color="#1B5E20")),
            name="Обраний банк",
            hoverinfo="skip",
        ))

    return _layout(fig, f"Позиція банків у системі, {year}")
