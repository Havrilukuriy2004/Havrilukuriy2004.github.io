from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterable

import pandas as pd
import requests

from .config import BASE_URL, ID_API


@dataclass(frozen=True)
class ReportDate:
    date_str: str
    financial_year: int
    quarter_label: str
    is_baseline: bool = False


def report_dates(start_year: int, end_year: int) -> list[ReportDate]:
    """
    Build NBU reporting dates for quarterly reporting.

    For financial year y:
    Q1       = y-04-01
    Q2       = y-07-01
    Q3       = y-10-01
    Q4/12M   = (y+1)-01-01

    Baseline y-01-01 is downloaded to compute average denominators for the year,
    but is not displayed as a target year.
    """
    dates: list[ReportDate] = []
    dates.append(ReportDate(f"{start_year}0101", start_year - 1, "Q4 / 12M", True))

    for y in range(start_year, end_year + 1):
        dates.extend([
            ReportDate(f"{y}0401", y, "Q1"),
            ReportDate(f"{y}0701", y, "Q2"),
            ReportDate(f"{y}1001", y, "Q3"),
            ReportDate(f"{y + 1}0101", y, "Q4 / 12M"),
        ])
    # Keep stable unique order
    seen = set()
    unique = []
    for d in dates:
        if d.date_str not in seen:
            unique.append(d)
            seen.add(d.date_str)
    return unique


def _parse_dt(series: pd.Series) -> pd.Series:
    """Robust parser for NBU dt values: yyyyMMdd or dd.mm.yyyy."""
    s = series.astype(str)
    parsed = pd.to_datetime(s, format="%Y%m%d", errors="coerce")
    mask = parsed.isna()
    if mask.any():
        parsed.loc[mask] = pd.to_datetime(s.loc[mask], dayfirst=True, errors="coerce")
    return parsed


def fetch_banksfinrep_date(date_str: str, period: str = "q", timeout: int = 90) -> pd.DataFrame:
    """
    Download one reporting date from the NBU OpenData REST API.
    """
    url = f"{BASE_URL}?date={date_str}&period={period}&json"
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    data = response.json()

    df = pd.DataFrame(data)
    if df.empty:
        return df

    df["request_date"] = date_str
    df["reporting_date"] = _parse_dt(df["dt"]) if "dt" in df.columns else pd.to_datetime(date_str)
    df["value"] = pd.to_numeric(df.get("value", 0), errors="coerce").fillna(0.0)
    return df


def fetch_banksfinrep_range(
    start_year: int,
    end_year: int,
    id_api: Iterable[str] | None = None,
    only_uah_r034: bool = True,
) -> pd.DataFrame:
    """
    Fetch all required dates and return filtered long data.
    """
    id_set = set(id_api or ID_API)
    frames = []

    for d in report_dates(start_year, end_year):
        df = fetch_banksfinrep_date(d.date_str, period="q")
        if df.empty:
            continue

        df["financial_year"] = d.financial_year
        df["quarter_label"] = d.quarter_label
        df["is_baseline"] = d.is_baseline

        if "id_api" in df.columns:
            df = df[df["id_api"].isin(id_set)].copy()

        if only_uah_r034 and "r034" in df.columns:
            df = df[df["r034"].astype(str).isin(["1", "1.0"])].copy()

        frames.append(df)

    if not frames:
        return pd.DataFrame()

    raw = pd.concat(frames, ignore_index=True)
    # Normalize common metadata columns
    for col in ["nkb", "mfo", "fullname", "gr_bank", "id_api", "txt", "txten"]:
        if col not in raw.columns:
            raw[col] = None

    return raw
