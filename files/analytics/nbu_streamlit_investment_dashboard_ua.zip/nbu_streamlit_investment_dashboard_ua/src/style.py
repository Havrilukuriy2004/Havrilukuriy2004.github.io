import streamlit as st


def inject_css():
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

        html, body, [class*="css"] {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }

        .main {
            background: #F7FBF7;
        }

        .block-container {
            padding-top: 1.4rem;
            padding-bottom: 2.5rem;
            max-width: 1480px;
        }

        .hero {
            border: 1px solid rgba(46,125,50,0.18);
            border-radius: 24px;
            padding: 26px 30px;
            background:
                radial-gradient(circle at 10% 0%, rgba(197,225,165,0.65), transparent 34%),
                linear-gradient(135deg, #FFFFFF 0%, #F1F8E9 48%, #E8F5E9 100%);
            box-shadow: 0 12px 34px rgba(27, 94, 32, 0.08);
            margin-bottom: 18px;
        }

        .hero h1 {
            font-size: 2.15rem;
            line-height: 1.12;
            margin-bottom: 0.35rem;
            color: #143D17;
            font-weight: 800;
            letter-spacing: -0.03em;
        }

        .hero p {
            font-size: 1.02rem;
            color: #4B604B;
            margin: 0;
        }

        .method-note {
            border-left: 5px solid #66A61E;
            background: #FFFFFF;
            border-radius: 14px;
            padding: 14px 18px;
            color: #344E34;
            box-shadow: 0 6px 20px rgba(27, 94, 32, 0.06);
            margin: 12px 0 16px 0;
        }

        .section-title {
            font-weight: 800;
            color: #143D17;
            font-size: 1.22rem;
            margin: 12px 0 8px 0;
        }

        div[data-testid="stMetric"] {
            background: #FFFFFF;
            border: 1px solid rgba(46,125,50,0.14);
            border-radius: 18px;
            padding: 16px 18px;
            box-shadow: 0 7px 20px rgba(27, 94, 32, 0.06);
        }

        div[data-testid="stMetric"] label {
            color: #4B604B !important;
            font-size: 0.86rem !important;
            font-weight: 600 !important;
        }

        div[data-testid="stMetricValue"] {
            color: #143D17 !important;
            font-weight: 800 !important;
        }

        .stDataFrame {
            border: 1px solid rgba(46,125,50,0.13);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 6px 18px rgba(27, 94, 32, 0.05);
        }

        section[data-testid="stSidebar"] {
            background: linear-gradient(180deg, #F1F8E9 0%, #FFFFFF 100%);
            border-right: 1px solid rgba(46,125,50,0.15);
        }

        .small-muted {
            color: #607060;
            font-size: 0.86rem;
        }

        .footer {
            color: #607060;
            font-size: 0.82rem;
            margin-top: 24px;
            padding-top: 12px;
            border-top: 1px solid rgba(46,125,50,0.15);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
