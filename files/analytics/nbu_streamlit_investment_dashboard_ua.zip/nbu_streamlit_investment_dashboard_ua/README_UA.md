# NBU Streamlit Investment Dashboard UA

Академічний Streamlit-dashboard українською мовою для аналізу інвестиційної діяльності банків України за даними NBU OpenData `banksfinrep`.

## Що всередині

- Вибір окремого банку, групи банків або всієї банківської системи.
- Таблиця 2: склад та структура інвестиційних вкладень.
- Таблиця 3: склад та структура доходів від інвестиційної діяльності.
- Можливість розкрити таблиці до кварталів.
- Графіки:
  - структура інвестиційного портфеля;
  - інвестиції / чисті активи;
  - Дінв vs чиста дохідність кредитів vs вартість ресурсів;
  - waterfall фінрезультату інвестиційної діяльності;
  - scatter-positioning банків у системі.
- Експорт таблиць в Excel і CSV.
- Light green academic / World Bank-inspired style.

## Швидкий запуск

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Джерело даних

NBU OpenData REST API:

```text
https://bank.gov.ua/NBUStatService/v1/statdirectory/banksfinrep?date=YYYYMMDD&period=q&json
```

## Логіка років

Для фінансового року `y`:

```text
Q1       → y0401
Q2       → y0701
Q3       → y1001
Q4 / 12M → (y+1)0101
```

Наприклад, 2024 рік у річній таблиці = `date=20250101&period=q`.

## Методологічні caveats

1. `BS1_AssetsIGLBRefinNBU` — це ОВДП, що рефінансуються НБУ, а не весь портфель ОВДП.
2. У BS1 немає чистого окремого поля для процентних доходів саме від цінних паперів. У dashboard використано proxy:
   `BS1_InterestIncome - BS1_InterestIncomeLE - BS1_InterestIncomeIndiv`.
3. Доходи/витрати у квартальних звітах накопичуються з початку року, тому квартальні значення в таблицях не слід читати як незалежні квартальні потоки.
4. Для дохідностей можна обрати:
   - середній залишок за період;
   - залишок на звітну дату.

## Структура проєкту

```text
app.py
src/
  config.py
  nbu_api.py
  metrics.py
  charts.py
  style.py
.streamlit/
  config.toml
requirements.txt
README_UA.md
DEPLOY_STREAMLIT_CLOUD_UA.md
```
