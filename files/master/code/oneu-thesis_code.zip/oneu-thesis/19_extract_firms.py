# -*- coding: utf-8 -*-
"""
19_extract_firms.py: вибір підприємств з finrep_v5_slim.csv.gz у CSV для аркуша 19.1 інструмента Borrower_Class_Credit_Risk_Tool.xlsx.
Selects companies from finrep_v5_slim.csv.gz into a CSV for sheet 19.1 of the borrower class tool.

Запуск / usage:
    python 19_extract_firms.py --codes 00000001,00000002 [--years 2023,2024] [--src ../data_nbu/firms/finrep_v5_slim.csv.gz] [--out finrep_firms.csv]
    python 19_extract_firms.py --codes-file codes.txt          (один код ЄДРПОУ в рядку / one EDRPOU code per line)
Файл читається частинами, тому підходить і для повного набору даних (понад 1 млн рядків).
"""
import argparse, os, sys
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
BAL = ["1000", "1002", "1011", "1012", "1030", "1035", "1040", "1045", "1050", "1090", "1100", "1110", "1125", "1155", "1160", "1165", "1190", "1195", "1300",
       "1495", "1510", "1515", "1595", "1600", "1610", "1615", "1690", "1695"]
PNL = ["2000", "2010", "2050", "2070", "2090", "2095", "2120", "2160", "2165", "2180", "2190", "2195", "2220", "2240", "2250", "2270", "2290", "2295",
       "2350", "2355", "2505", "2515"]
META = ["edrpou", "year", "balance_form", "employees", "firm_kved"]
COLS = META + [f"r{c}_{s}" for c in BAL for s in ("open", "close")] + [f"r{c}" for c in PNL]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.path.join(HERE, "data_nbu", "firms", "finrep_v5_slim.csv.gz"))
    ap.add_argument("--codes", default="")
    ap.add_argument("--codes-file", default="")
    ap.add_argument("--years", default="")
    ap.add_argument("--out", default="finrep_firms.csv")
    a = ap.parse_args()
    codes = [c.strip() for c in a.codes.split(",") if c.strip()]
    if a.codes_file:
        codes += [l.strip() for l in open(a.codes_file, encoding="utf-8") if l.strip()]
    if not codes:
        sys.exit("Вкажіть --codes або --codes-file / give --codes or --codes-file")
    want = {c.lstrip("0") or "0" for c in codes}
    years = {int(y) for y in a.years.split(",") if y.strip()}
    if not os.path.exists(a.src):
        sys.exit(f"Файл не знайдено / file not found: {a.src}")
    parts = []
    for ch in pd.read_csv(a.src, dtype={"edrpou": str, "firm_kved": str}, chunksize=200_000, low_memory=False):
        k = ch["edrpou"].astype(str).str.lstrip("0")
        x = ch[k.isin(want)]
        if years:
            x = x[x["year"].isin(years)]
        if len(x):
            parts.append(x)
    if not parts:
        sys.exit("Жодного рядка не знайдено / no rows found")
    d = pd.concat(parts)
    for c in COLS:
        if c not in d.columns:
            d[c] = 0 if c not in META else None
    d = d[COLS].sort_values(["edrpou", "year"])
    if len(d) > 1000:
        print(f"Увага: {len(d)} рядків; аркуш 19.1 розрахований на 1000 / warning: {len(d)} rows; sheet 19.1 holds 1000")
    d.to_csv(a.out, index=False, encoding="utf-8")
    print(f"OK: {a.out}: {len(d)} рядків, {d['edrpou'].nunique()} підприємств / rows, companies")


if __name__ == "__main__":
    main()
