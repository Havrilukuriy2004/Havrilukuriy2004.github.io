# ============================================================================
# run_section3_v6.R — оновлення розділу 3 без повторного завантаження бази НБУ
# ----------------------------------------------------------------------------
# Запуск у RStudio (робоча тека = тека проєкту):
#   source("run_section3_v6.R", encoding = "UTF-8")
# Кроки: 02 вітрини (опитування банків BLS із виправленим читанням кварталів і чинниками стандартів),
#        06 показники динаміки, 09 очікування і кредитний канал (табл. Ш.5), 16 розділ 3 (зокрема блоки B10a–B10d), 08 таблиці для тексту.
# Блок B10d (панель «банк × КВЕД × місяць»): під час першого запуску скрипт сам завантажує з сайту НБУ два архіви наглядової статистики
#   https://bank.gov.ua/files/stat/Loans_KVED.zip (≈23 МБ) і https://bank.gov.ua/files/stat/Loans_stages.zip (≈2,8 МБ)
#   у data_nbu/local_inputs/loans_nbu/ (якщо завантаження не вдалося – покладіть ці архіви туди вручну; вимкнути: THESIS_LOANS_DOWNLOAD=false).
# Тривалість: близько 15–20 хв (перше читання 98 файлів КВЕД – кілька хвилин, далі кеш). База data_nbu/parquet не змінюється, окрім вітрин mart_* і кешу local_loans_*.
# Результати: output_nbu/section_3/ (tables, figures, Section_3.xlsx) і output_nbu/section_3_results.zip
# ============================================================================
Sys.setenv(THESIS_RESET_DB = "false", THESIS_UPDATE_DB = "false")
if (!nzchar(Sys.getenv("THESIS_STEPS"))) Sys.setenv(THESIS_STEPS = "02,06,09,16,08")
if (!nzchar(Sys.getenv("THESIS_REVIEW"))) Sys.setenv(THESIS_REVIEW = "false")
.s3_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) getwd())
source(file.path(.s3_dir, "run_all_v6.R"), encoding = "UTF-8")
