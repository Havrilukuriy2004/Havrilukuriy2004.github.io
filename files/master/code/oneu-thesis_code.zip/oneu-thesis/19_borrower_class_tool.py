# -*- coding: utf-8 -*-
"""
19_borrower_class_tool.py — Excel-інструмент «Клас позичальника за Положенням НБУ № 351 і кредитний ризик за продуктами і підходами».
 * аркуш 19.1: дані фінансової звітності з CSV (підключення до тексту з запитом файла при оновленні) або вставлені вручну;
 * 19.2: повний розрахунок класу боржника юридичної особи (Додаток 7: таблиці 1 до 5, правила знаменника, критерії розміру),
   обмеження п. 162(4), покриття процентів за Постановою № 23, додаткові показники користувача;
 * 19.3: група пов'язаних контрагентів: сума звітностей учасників з елімінуванням внутрішньогрупових оборотів;
 * 19.4: кредитний ризик за продуктами: Положення № 351 (PD x LGD x EAD), МСФЗ 9 (ECL), стандартизований підхід і IRB;
 * 19.5: пакетний розрахунок класу для всіх рядків імпорту.
Стиль таблиць НБУ (Arial 10), українська і англійська версії. Запуск: python3 19_borrower_class_tool.py OUTPUT_DIR [sample.csv]
"""
import os, sys, re, zipfile, shutil, datetime as dt
from copy import copy
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.chart import BarChart, Reference, Series
from xl_trans import put, header, axis_font, A10, A10B, A10I, A9, A9I, INP, LINKF, FILL_IN, FILL_KEY, FILL_HEAD, BOX, TOPB, CEN, LEFT, LNW, RIGHT, N0, N1, N2, N3
from xl_common import save_both
import class351 as C

OUT_ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "output_nbu")
SAMPLE = sys.argv[2] if len(sys.argv) > 2 else None
DEST = os.path.join(OUT_ROOT, "bank_excel"); os.makedirs(DEST, exist_ok=True)
FILE = os.path.join(DEST, "Borrower_Class_Credit_Risk_Tool.xlsx")
P1 = '0.0%;\\–0.0%;"–"'; P2 = '0.00%;\\–0.00%;"–"'; P3 = '0.000%;\\–0.000%;"–"'
A10L = Font(name="Arial", size=10, underline="single", color="0000FF")
RED = PatternFill("solid", fgColor="F8CBAD"); GREEN = PatternFill("solid", fgColor="C6EFCE"); AMBER = PatternFill("solid", fgColor="FFEB9C")
NIMP = 1000          # rows of the import area
NB = 500             # rows of the batch sheet
IMP_HDR = 6          # header row of the import area (query table starts here)

# ============================================================ statement lines
BAL = [("1000", "Нематеріальні активи"), ("1002", "Нематеріальні активи: накопичена амортизація"), ("1011", "Основні засоби: первісна вартість"),
       ("1012", "Основні засоби: знос"), ("1030", "Довгострокові фінансові інвестиції за методом участі в капіталі"), ("1035", "Інші довгострокові фінансові інвестиції"),
       ("1040", "Довгострокова дебіторська заборгованість"), ("1045", "Відстрочені податкові активи"), ("1050", "Гудвіл"), ("1090", "Інші необоротні активи"),
       ("1100", "Запаси"), ("1110", "Поточні біологічні активи"), ("1125", "Дебіторська заборгованість за продукцію, товари, роботи, послуги"),
       ("1155", "Інша поточна дебіторська заборгованість"), ("1160", "Поточні фінансові інвестиції"), ("1165", "Гроші та їх еквіваленти"), ("1190", "Інші оборотні активи"),
       ("1195", "Усього оборотних активів (розділ II)"), ("1300", "Баланс (активи, усього)"), ("1495", "Власний капітал (розділ I пасиву)"),
       ("1510", "Довгострокові кредити банків"), ("1515", "Інші довгострокові зобов'язання"), ("1595", "Усього довгострокових зобов'язань (розділ II пасиву)"),
       ("1600", "Короткострокові кредити банків"), ("1610", "Поточна кредиторська заборгованість за довгостроковими зобов'язаннями"),
       ("1615", "Поточна кредиторська заборгованість за товари, роботи, послуги"), ("1690", "Інші поточні зобов'язання"), ("1695", "Усього поточних зобов'язань (розділ III пасиву)")]
PNL = [("2000", "Чистий дохід від реалізації продукції (товарів, робіт, послуг)"), ("2010", "Чисті зароблені страхові премії"), ("2050", "Собівартість реалізованої продукції"),
       ("2070", "Чисті понесені збитки за страховими виплатами"), ("2090", "Валовий прибуток"), ("2095", "Валовий збиток"), ("2120", "Інші операційні доходи"),
       ("2160", "Інші доходи (форма 2-мс)"), ("2165", "Інші витрати (форма 2-мс)"), ("2180", "Інші операційні витрати"),
       ("2190", "Фінансовий результат від операційної діяльності: прибуток"), ("2195", "Фінансовий результат від операційної діяльності: збиток"),
       ("2220", "Інші фінансові доходи"), ("2240", "Інші доходи"), ("2250", "Фінансові витрати"), ("2270", "Інші витрати"),
       ("2290", "Фінансовий результат до оподаткування: прибуток"), ("2295", "Фінансовий результат до оподаткування: збиток"),
       ("2350", "Чистий фінансовий результат: прибуток"), ("2355", "Чистий фінансовий результат: збиток"), ("2505", "Витрати на оплату праці"), ("2515", "Амортизація")]
LINES = [(c, n, True) for c, n in BAL] + [(c, n, False) for c, n in PNL]
META = ["edrpou", "year", "balance_form", "employees", "firm_kved"]
CSV_COLS = META + [f"r{c}_{s}" for c, _, b in LINES if b for s in ("open", "close")] + [f"r{c}" for c, _, b in LINES if not b]

# ============================================================ derived amounts and Annex 7 indicators (templates)
NONOP = "+".join("{c:%s}" % c for c in ["1000", "1030", "1035", "1040", "1045", "1050", "1090", "1155", "1160", "1190"])
DER = [("nd_f", "Чистий борг (повна форма): р. 1510 + 1515 + 1600 + 1610 мінус 1165", "{c:1510}+{c:1515}+{c:1600}+{c:1610}-{c:1165}"),
       ("nd_s", "Чистий борг (малі форми): р. 1595 + 1600 + 1610 мінус 1165", "{c:1595}+{c:1600}+{c:1610}-{c:1165}"),
       ("sales", "Чистий дохід: р. 2000 + 2010", "{c:2000}+{c:2010}"),
       ("gross", "Валовий прибуток: р. 2090 мінус 2095 (або 2000 + 2010 мінус 2050 мінус 2070)",
        "IF(OR({c:2090}<>0,{c:2095}<>0),{c:2090}-{c:2095},{c:2000}+{c:2010}-{c:2050}-{c:2070})"),
       ("opr", "Операційний результат: р. 2190 мінус 2195", "{c:2190}-{c:2195}"),
       ("ebt", "Результат до оподаткування (повна форма)", "IF({ebtrep},{c:2290}-{c:2295},{d:opr}+{c:2220}-{c:2250})"),
       ("ebt_s", "Результат до оподаткування (малі форми)", "IF({ebtrep},{c:2290}-{c:2295},{c:2290})"),
       ("ta", "Активи: р. 1300", "{c:1300}"),
       ("wc", "Чистий оборотний капітал: р. 1195 мінус 1160, 1165, 1190, 1695 плюс 1600, 1610, 1690",
        "{c:1195}-{c:1160}-{c:1165}-{c:1190}-{c:1695}+{c:1600}+{c:1610}+{c:1690}"),
       ("finx_s", "Чисті інші витрати (малі форми): р. 2165 + 2270 мінус 2160 мінус 2240", "{c:2165}+{c:2270}-{c:2160}-{c:2240}"),
       ("nonop", "Неопераційні активи: р. 1000, 1030 до 1090, 1155, 1160, 1190", NONOP),
       ("amort", "Амортизація за зміною зносу: р. 1012 і 1002 (кінець мінус початок, не менше 0)", "MAX(0,ABS({c:1012})-ABS({o:1012})+ABS({c:1002})-ABS({o:1002}))"),
       ("nd", "Чистий борг для п. 162(4)", "IF({full},{d:nd_f},{d:nd_s})"),
       ("sales162", "Чистий дохід для п. 162(4)", "IF({full},{d:sales},{c:2000})"),
       ("ebitda", "Операційний прибуток до амортизації для п. 162(4)", "IF({full},{d:opr}+{c:2515},{c:2000}-{c:2050})"),
       ("op23", "Операційний результат до амортизації для Постанови № 23 (п. 2-9(7))",
        "IF({full},{d:opr}+{c:2515},IF({small},{c:2000}-{c:2050}+{c:2120}-{c:2180}+{d:amort},{c:2000}-{c:2050}+{d:amort}))"),
       ("debt", "Борг за кредитами і позиками", "IF({full},{c:1510}+{c:1600}+{c:1610},{c:1595}+{c:1600}+{c:1610})")]
IND = [("K1", "Чистий борг / чистий дохід", "{d:nd_f}", "{d:sales}"), ("K2", "Борг (без вирахування грошей) / активи", "{d:nd_f}+{c:1165}", "{d:ta}"),
       ("K3", "Валовий прибуток / чистий борг", "{d:gross}", "{d:nd_f}"), ("K4", "Результат до оподаткування / чистий борг", "{d:ebt}", "{d:nd_f}"),
       ("K5", "Операційний результат до амортизації / чистий борг", "{d:opr}+{c:2515}", "{d:nd_f}"), ("K6", "Валовий прибуток / фінансові витрати", "{d:gross}", "{c:2250}"),
       ("K7", "Результат до оподаткування / активи", "{d:ebt}", "{d:ta}"), ("K8", "Власний капітал / активи", "{c:1495}", "{d:ta}"),
       ("K10", "Результат до оподаткування / чистий дохід", "{d:ebt}", "{d:sales}"), ("K11", "Операційний результат / активи", "{d:opr}", "{d:ta}"),
       ("K12", "Операційний результат / чистий дохід", "{d:opr}", "{d:sales}"), ("K13", "Результат до оподаткування і амортизації / чистий дохід", "{d:ebt}+{c:2515}", "{d:sales}"),
       ("K16", "Оборотні активи / поточні зобов'язання", "{c:1195}", "{c:1695}"),
       ("K17", "Дебіторська заборгованість, запаси, біоактиви і гроші / поточні зобов'язання", "{c:1125}+{c:1100}+{c:1110}+{c:1165}", "{c:1695}"),
       ("K18", "Оборотність кредиторської заборгованості, днів", "365*{c:1615}", "{c:2050}"), ("K19", "Оборотність дебіторської заборгованості, днів", "365*{c:1125}", "{d:sales}"),
       ("K20", "Оборотність оборотних активів, днів", "365*{c:1195}", "{d:sales}"), ("K21", "Оборотність запасів, днів", "365*({c:1100}+{c:1110})", "{c:2050}"),
       ("K23", "Неопераційні активи / активи", "{d:nonop}", "{d:ta}"),
       ("MK1", "Чистий борг / чистий дохід", "{d:nd_s}", "{c:2000}"), ("MK3", "Валовий прибуток / чистий борг", "{c:2000}-{c:2050}", "{d:nd_s}"),
       ("MK4", "Результат до оподаткування / чистий борг", "{d:ebt_s}", "{d:nd_s}"), ("MK6", "Валовий прибуток / інші витрати", "{c:2000}-{c:2050}", "{c:2165}+{c:2270}"),
       ("MK7", "Результат до оподаткування / активи", "{d:ebt_s}", "{d:ta}"), ("MK8", "Власний капітал / активи", "{c:1495}", "{d:ta}"),
       ("MK9", "Чистий оборотний капітал / активи", "{d:wc}", "{d:ta}"), ("MK10", "Результат до оподаткування / чистий дохід", "{d:ebt_s}", "{c:2000}"),
       ("MK14", "Валовий прибуток / чисті інші витрати", "{c:2000}-{c:2050}", "{d:finx_s}"),
       ("MK15", "Валовий прибуток з іншими операційними доходами і витратами / чисті інші витрати", "{c:2000}+{c:2120}-{c:2050}-{c:2180}", "{d:finx_s}"),
       ("MK18", "Оборотність кредиторської заборгованості, днів", "365*{c:1615}", "{c:2050}"), ("MK19", "Оборотність дебіторської заборгованості, днів", "365*{c:1125}", "{c:2000}"),
       ("MK20", "Оборотність оборотних активів, днів", "365*{c:1195}", "{c:2000}"), ("MK21", "Оборотність запасів, днів", "365*({c:1100}+{c:1110})", "{c:2050}"),
       ("MK22", "Чистий оборотний капітал, днів чистого доходу", "365*{d:wc}", "{c:2000}")]
RULE = {k: "нуль" for k in C.ZERO} | {k: "мінімум" for k in C.LOW} | {k: "максимум" for k in C.HIGH}
GRP_NAME = {"A": "A: сільське господарство", "BCF": "B, C, F: добувна, переробна промисловість, будівництво", "G": "G: торгівля",
            "KLMN": "K, L, M, N: фінанси, нерухомість, професійні і адміністративні послуги", "OTH": "Інші види діяльності"}
FORMS = [("full", "повна (форми 1 і 2)"), ("small", "мала (форми 1-м і 2-м)"), ("micro", "мікро (форми 1-мс і 2-мс)")]
EUR = {2019: 26.42, 2020: 34.74, 2021: 30.92, 2022: 38.95, 2023: 42.21, 2024: 43.93, 2025: 48.0}
RATE = {2020: .12, 2021: .107, 2022: .162, 2023: .198, 2024: .170, 2025: .163}
# Annex 9 Table 1: PD ranges for legal entities by class (1..10) and group (A | BCF | G | KLMN | OTH)
PD9 = {1: [(.005, .007), (.005, .012), (.005, .01), (.005, .016), (.005, .012)], 2: [(.008, .02), (.013, .03), (.011, .021), (.017, .033), (.013, .028)],
       3: [(.021, .033), (.031, .052), (.022, .036), (.034, .042), (.029, .04)], 4: [(.034, .065), (.053, .074), (.037, .058), (.043, .063), (.041, .077)],
       5: [(.066, .10), (.075, .11), (.059, .094), (.064, .088), (.078, .11)], 6: [(.11, .15), (.12, .14), (.095, .13), (.089, .12), (.12, .16)],
       7: [(.16, .25), (.15, .25), (.14, .21), (.13, .19), (.17, .24)], 8: [(.26, .47), (.26, .51), (.22, .42), (.2, .33), (.25, .41)],
       9: [(.48, .99), (.52, .99), (.43, .99), (.34, .99), (.42, .99)], 10: [(1, 1)] * 5}
GKEYS = ["A", "BCF", "G", "KLMN", "OTH"]
# products: name, CCF Reg. 351 by term (<1y, 1..3y, >3y), Basel CCF, balance-sheet product?
PROD = [("Строковий кредит", (.2, .5, 1.0), .40, True), ("Кредитна лінія відновлювальна", (.2, .5, 1.0), .40, True),
        ("Кредитна лінія невідновлювальна", (.2, .5, 1.0), .40, True), ("Овердрафт", (.2, .5, 1.0), .40, True),
        ("Безумовно відкличний ліміт", (0, 0, 0), .10, True), ("Фінансова (платіжна) гарантія", (1.0, 1.0, 1.0), 1.0, False),
        ("Гарантія виконання зобов'язань (тендерна, контрактна)", (.2, .2, .2), .50, False), ("Митна або податкова гарантія", (.5, .5, .5), .50, False),
        ("Документарний акредитив", (.2, .5, .5), .20, False), ("Резервний акредитив (стендбай)", (1.0, 1.0, 1.0), 1.0, False)]
COLL = [("Без забезпечення", 0, 0), ("Грошове покриття", 1.0, 1.0), ("Цінні папери НБУ і ОВДП", 1.0, 1.0), ("Житлова нерухомість (квартири)", .9, .75),
        ("Житлові будинки", .7, .55), ("Нежитлова нерухомість", .85, .6), ("Автомобілі", .9, .75), ("Транспортні засоби, обладнання, майнові комплекси, земля", .65, .5),
        ("Товари в обороті, біологічні активи", .4, .4), ("Цінні папери в біржовому реєстрі", .4, .4), ("Гарантії експортно-кредитного агентства", .85, .85)]
RWS = [("Корпоративний боржник без рейтингу", 1.0), ("МСП: корпоративний портфель", .85), ("МСП: роздрібний портфель", .75),
       ("Корпоративний інвестиційного рівня", .65), ("Спекулятивний рівень або прострочка", 1.5)]

# ============================================================ workbook
wb = Workbook(); wb.remove(wb.active)
NAMES = {}


def sheet(n, tab=None):
    ws = wb.create_sheet(n); ws.sheet_view.showGridLines = False
    if tab: ws.sheet_properties.tabColor = tab
    return ws


TITLE = "19. Інструмент оцінки класу позичальника і кредитного ризику"


def titles(ws, sub, note=None):
    put(ws, 1, 1, TITLE, A10B, al=LNW); put(ws, 2, 1, sub, A10B, al=LNW)
    if note: put(ws, 3, 1, note, A10, al=LNW)
    return 5


def foot(ws, r, lines=()):
    r += 1
    put(ws, r, 1, "«–» — явища не було; «…» — даних немає або показник не визначений.", A9I); r += 1
    for t in lines:
        put(ws, r, 1, t, A9I, al=LNW); r += 1
    put(ws, r, 1, "Джерело: Положення НБУ № 351 (додатки 5, 6, 7, 9), Постанова НБУ № 23; розрахунки автора; скрипт 19_borrower_class_tool.py.", A9I)
    return r + 1


S0 = sheet("19"); S1 = sheet("19.1", "548235"); S2 = sheet("19.2", "1F4E79"); S3 = sheet("19.3", "1F4E79"); S4 = sheet("19.4", "1F4E79"); S5 = sheet("19.5"); S6 = sheet("19.6")
D1 = sheet("Д1", "808080"); D2 = sheet("Д2", "808080"); D3 = sheet("Д3", "808080"); D4 = sheet("Д4", "808080"); D5 = sheet("Д5", "808080")

# ------------------------------------------------------------ Д1 models (Tables 1 and 2), long form
put(D1, 1, 1, "Д1. Моделі інтегрального показника: таблиці 1 і 2 Додатка 7 до Положення № 351 (вхід для формул)", A10B)
put(D1, 2, 1, "(межі діапазонів показників, % або днів x 100; X: бали діапазонів; правило: значення X за нульового або від'ємного знаменника)", A10)
h = ["Ключ", "Таблиця", "Група", "№", "Показник", "Коефіцієнт", "Константа b0", "Правило знаменника", "Кількість діапазонів"] + [f"Межа {i}" for i in range(1, 8)] + [f"X{i}" for i in range(1, 9)]
for j, lab in enumerate(h):
    put(D1, 4, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
D1.row_dimensions[4].height = 30
r = 5
for tab, T in (("T1", C.T1), ("T2", C.T2)):
    for g_, (b0, terms) in T.items():
        for i, (k, coef, cuts, X) in enumerate(terms, 1):
            row = [f"{tab}|{g_}|{i}", tab, g_, i, k, coef, b0, RULE.get(k, ""), len(X)] + cuts + [None] * (7 - len(cuts)) + X + [None] * (8 - len(X))
            for j, v in enumerate(row):
                put(D1, r, j + 1, v, fmt=(N3 if j in (5, 6) or j >= 16 else N1 if 9 <= j < 16 else None), al=CEN if j < 9 else RIGHT)
            r += 1
M0, ML = 5, r - 1
MR = lambda col: f"'Д1'!${CL(col)}${M0}:${CL(col)}${ML}"
for j in range(1, 25): D1.column_dimensions[CL(j)].width = 9
D1.column_dimensions["A"].width = 14; D1.column_dimensions["H"].width = 12
put(D1, r + 1, 1, "Правило знаменника (Додаток 7, пп. 6 до 8): «нуль»: за нульового або від'ємного знаменника X = 0; «мінімум»: за нульового знаменника X найнижчого діапазону; «максимум»: X найвищого діапазону.", A9I)

# ------------------------------------------------------------ Д2 class bounds (Tables 4 and 5) and PD (Annex 9)
put(D2, 1, 1, "Д2. Нижні межі інтегрального показника для класів 1 до 8 (таблиці 4 і 5 Додатка 7) і діапазони PD (таблиця 1 Додатка 9)", A10B)
for j, lab in enumerate(["Ключ", "Таблиця", "Група"] + [f"Клас {i}" for i in range(1, 9)]):
    put(D2, 4, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
r = 5
for tab, T in (("T4", C.T4), ("T5", C.T5)):
    for g_ in GKEYS:
        for j, v in enumerate([f"{tab}|{g_}", tab, g_] + T[g_]):
            put(D2, r, j + 1, v, fmt=N2 if j >= 3 else None, al=CEN if j < 3 else RIGHT)
        r += 1
B0, BL = 5, r - 1
put(D2, r, 1, "Таблиця 4: великі і середні підприємства; таблиця 5: малі підприємства (не менше двох з трьох критеріїв: активи до 4 млн євро, дохід до 8 млн євро, до 50 працівників).", A9I)
r += 2
PD0 = r + 1
for j, lab in enumerate(["Клас"] + sum([[f"{g_}: нижня", f"{g_}: верхня"] for g_ in GKEYS], [])):
    put(D2, r, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
D2.row_dimensions[r].height = 30
for cl in range(1, 11):
    put(D2, PD0 + cl - 1, 1, cl, al=CEN)
    for gi, (lo, hi) in enumerate(PD9[cl]):
        put(D2, PD0 + cl - 1, 2 + 2 * gi, lo, fmt=P1, al=RIGHT); put(D2, PD0 + cl - 1, 3 + 2 * gi, hi, fmt=P1, al=RIGHT)
put(D2, PD0 + 11, 1, "Додаток 9, таблиця 1: діапазони значень PD боржників юридичних осіб за класами і групами видів діяльності; п. 30 і 31: банк з досвідом понад 3 роки застосовує значення не нижче нижньої межі, без власного досвіду: верхню межу.", A9I)
for j in range(1, 12): D2.column_dimensions[CL(j)].width = 10
D2.column_dimensions["A"].width = 12
BR = lambda col: f"'Д2'!${CL(col)}${B0}:${CL(col)}${BL}"

# ------------------------------------------------------------ Д3 products and CCF; Д4 collateral; Д5 lines, EUR, rates
put(D3, 1, 1, "Д3. Продукти, коефіцієнти кредитної конверсії і ваги ризику", A10B)
for j, lab in enumerate(["Продукт", "CCF 351: до 1 року", "CCF 351: 1 до 3 років", "CCF 351: понад 3 роки", "CCF стандартизований", "Балансовий продукт"]):
    put(D3, 3, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
D3.row_dimensions[3].height = 30
for i, (nm, c351, cb, bal) in enumerate(PROD):
    q = 4 + i
    put(D3, q, 1, nm, al=LEFT)
    for j, v in enumerate(c351): put(D3, q, 2 + j, v, INP, '0%;\\–0%;"–"', RIGHT, fill=FILL_IN)
    put(D3, q, 5, cb, INP, '0%;\\–0%;"–"', RIGHT, fill=FILL_IN); put(D3, q, 6, "так" if bal else "ні", al=CEN)
PR0, PRL = 4, 3 + len(PROD)
q = PRL + 2
put(D3, q, 1, "Коефіцієнти Положення № 351 (Додаток 5): група 1 (1,0): фінансові гарантії, резервні акредитиви, зобов'язання з кредитування понад 3 роки; група 2 (0,5): гарантії виконання податкових і митних зобов'язань, акредитиви і зобов'язання 1 до 3 років;", A9I)
put(D3, q + 1, 1, "група 3 (0,2): гарантії виконання зобов'язань, акредитиви і зобов'язання до 1 року; група 4 (0): зобов'язання, повністю покриті грошовим покриттям, і безумовно відкличні зобов'язання. Стандартизований підхід: Базель III (CRE20).", A9I)
q += 3
for j, lab in enumerate(["Клас ваги ризику (стандартизований підхід)", "Вага ризику"]):
    put(D3, q, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
RW0 = q + 1
for i, (nm, w) in enumerate(RWS):
    put(D3, RW0 + i, 1, nm, al=LEFT); put(D3, RW0 + i, 2, w, INP, '0%;\\–0%;"–"', RIGHT, fill=FILL_IN)
RWL = RW0 + len(RWS) - 1
put(D3, RWL + 1, 1, "Ваги ризику: за Положенням НБУ про розрахунок нормативів капіталу (стандартизований підхід); значення можна змінити в жовтих клітинках.", A9I)
D3.column_dimensions["A"].width = 52
for c in "BCDEF": D3.column_dimensions[c].width = 13

put(D4, 1, 1, "Д4. Коефіцієнти ліквідності забезпечення (Додаток 6 до Положення № 351)", A10B)
for j, lab in enumerate(["Вид забезпечення", "Коефіцієнт k: основний", "Коефіцієнт k: знижений"]):
    put(D4, 3, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
for i, (nm, k1, k2) in enumerate(COLL):
    put(D4, 4 + i, 1, nm, al=LEFT); put(D4, 4 + i, 2, k1, INP, N2, RIGHT, fill=FILL_IN); put(D4, 4 + i, 3, k2, INP, N2, RIGHT, fill=FILL_IN)
CO0, COL_ = 4, 3 + len(COLL)
put(D4, COL_ + 2, 1, "Знижений коефіцієнт застосовується у випадках, визначених Додатком 6 (зокрема, якщо не виконано умов щодо оцінки або моніторингу забезпечення); перевірте актуальну редакцію.", A9I)
D4.column_dimensions["A"].width = 56; D4.column_dimensions["B"].width = 14; D4.column_dimensions["C"].width = 14

put(D5, 1, 1, "Д5. Рядки фінансової звітності, курс євро і ставка за кредитами за роками", A10B)
for j, lab in enumerate(["Рядок", "Назва", "Стаття балансу (так) або звіту про фінансові результати (ні)"]):
    put(D5, 3, j + 1, lab, al=CEN, border=BOX, fill=FILL_HEAD)
for i, (c, n, b) in enumerate(LINES):
    put(D5, 4 + i, 1, int(c), al=CEN); put(D5, 4 + i, 2, n, al=LEFT); put(D5, 4 + i, 3, "так" if b else "ні", al=CEN)
LN0, LNL = 4, 3 + len(LINES)
q = 3
for j, lab in enumerate(["Рік", "Курс EUR, грн", "Ставка за новими кредитами НФК, частка"]):
    put(D5, q, 5 + j, lab, al=CEN, border=BOX, fill=FILL_HEAD)
YR0 = q + 1
for i, y in enumerate(sorted(EUR)):
    put(D5, YR0 + i, 5, y, al=CEN); put(D5, YR0 + i, 6, EUR[y], INP, N2, RIGHT, fill=FILL_IN); put(D5, YR0 + i, 7, RATE.get(y), INP, P1, RIGHT, fill=FILL_IN)
YRL = YR0 + len(EUR) - 1
put(D5, YRL + 1, 5, "Курс EUR: офіційний курс НБУ на кінець року (2025: орієнтовно); ставка: середня ставка за новими гривневими кредитами нефінансовим корпораціям.", A9I)
D5.column_dimensions["B"].width = 62; D5.column_dimensions["C"].width = 14
for c in "EFG": D5.column_dimensions[c].width = 14
D5.row_dimensions[3].height = 40
YRS = f"'Д5'!$E${YR0}:$E${YRL}"; EURS = f"'Д5'!$F${YR0}:$F${YRL}"; RATS = f"'Д5'!$G${YR0}:$G${YRL}"

# ------------------------------------------------------------ 19.1 import area
put(S1, 1, 1, TITLE, A10B); put(S1, 2, 1, "19.1. Дані фінансової звітності підприємств (імпорт з CSV або вставлення)", A10B)
put(S1, 3, 1, "Оновлення: Дані, Оновити все (Excel запитає файл CSV); або вставте дані з рядка 6 вниз (рядок 6: назви полів). Формат: як у файлі експорту finrep_v5 (кома: роздільник, крапка: десятковий знак).", A9I)
put(S1, 4, 1, "Обов'язкові поля: edrpou, year, balance_form (full, small, micro); бажано: employees, firm_kved і рядки r1000_open до r2515. Порядок полів довільний; відсутні рядки вважаються нулем.", A9I)
for j, c in enumerate(CSV_COLS):
    put(S1, IMP_HDR, j + 1, c, A10B, al=CEN, fill=FILL_HEAD)
IMPC = CL(max(len(CSV_COLS) + 20, 110))          # import width (extra columns allowed)
IMP_RNG = f"'19.1'!$A${IMP_HDR}:${IMPC}${IMP_HDR + NIMP}"
HROW = f"'19.1'!$A${IMP_HDR}:${IMPC}${IMP_HDR}"
S1.freeze_panes = f"C{IMP_HDR + 1}"
for j in range(1, len(CSV_COLS) + 1): S1.column_dimensions[CL(j)].width = 11


def example_rows():
    if SAMPLE:
        d = pd.read_csv(SAMPLE, dtype={"edrpou": str, "firm_kved": str})
        return d
    # illustrative firms (rounded, synthetic): manufacturer with full forms (2 years), trading company with small forms, second group member
    base = dict.fromkeys(CSV_COLS, 0.0)
    rows = []
    f1 = dict(base, edrpou="00000001", year=2024, balance_form="full", employees=120, firm_kved="25.11",
              r1000_open=150, r1000_close=140, r1002_open=60, r1002_close=75, r1011_open=48000, r1011_close=52000, r1012_open=18000, r1012_close=21500,
              r1100_open=14000, r1100_close=15500, r1125_open=11000, r1125_close=12800, r1155_open=900, r1155_close=1100, r1165_open=2600, r1165_close=3400,
              r1190_open=500, r1190_close=450, r1195_open=29000, r1195_close=33250, r1300_open=59100, r1300_close=63890, r1495_open=27000, r1495_close=29800,
              r1510_open=12000, r1510_close=10500, r1515_open=400, r1515_close=300, r1595_open=12400, r1595_close=10800, r1600_open=6000, r1600_close=7500,
              r1610_open=1500, r1610_close=1500, r1615_open=8400, r1615_close=9100, r1690_open=1200, r1690_close=1300, r1695_open=19700, r1695_close=23290,
              r2000=96000, r2050=74500, r2090=21500, r2120=800, r2180=1100, r2190=6200, r2220=60, r2250=2300, r2240=150, r2270=300, r2290=3810,
              r2350=3120, r2505=14400, r2515=3600)
    f0 = dict(f1, year=2023, r1300_open=55000, r1300_close=59100, r2000=88000, r2050=69300, r2090=18700, r2190=4900, r2250=2600, r2290=2170, r2350=1780, r2515=3300,
              r1495_close=27000, r1495_open=25200, r1510_close=12000, r1600_close=6000, r1165_close=2600, r1195_close=29000, r1695_close=19700, r1125_close=11000,
              r1100_close=14000, r1615_close=8400, r1012_open=15000, r1012_close=18000)
    f2 = dict(base, edrpou="00000002", year=2024, balance_form="full", employees=45, firm_kved="46.69",
              r1011_open=6000, r1011_close=6400, r1012_open=2200, r1012_close=2700, r1100_open=9500, r1100_close=11200, r1125_open=7300, r1125_close=8800,
              r1165_open=900, r1165_close=700, r1195_open=18200, r1195_close=21100, r1300_open=22100, r1300_close=24900, r1495_open=6100, r1495_close=6600,
              r1600_open=5200, r1600_close=6800, r1615_open=9600, r1615_close=10300, r1690_open=1200, r1690_close=1200, r1695_open=16000, r1695_close=18300,
              r2000=64000, r2050=57900, r2090=6100, r2190=1150, r2250=900, r2290=270, r2350=220, r2515=500)
    f3 = dict(base, edrpou="00000003", year=2024, balance_form="small", employees=9, firm_kved="47.11",
              r1011_open=900, r1011_close=950, r1012_open=300, r1012_close=360, r1100_open=1800, r1100_close=2100, r1125_open=400, r1125_close=380,
              r1165_open=250, r1165_close=180, r1195_open=2500, r1195_close=2700, r1300_open=3100, r1300_close=3290, r1495_open=600, r1495_close=480,
              r1595_open=300, r1595_close=300, r1600_open=900, r1600_close=1100, r1615_open=1300, r1615_close=1410, r1695_open=2200, r1695_close=2510,
              r2000=9800, r2050=8700, r2120=40, r2180=60, r2290=0, r2295=120, r2355=120)
    rows = [f1, f0, f2, f3]
    return pd.DataFrame(rows)[CSV_COLS]


EX = example_rows()
cols_ex = list(EX.columns)
for j, c in enumerate(cols_ex):
    put(S1, IMP_HDR, j + 1, c, A10B, al=CEN, fill=FILL_HEAD)
for i, rr in enumerate(EX.itertuples(index=False), 1):
    for j, v in enumerate(rr):
        if isinstance(v, float) and v != v: v = None
        if cols_ex[j] in ("edrpou", "firm_kved", "balance_form"): v = None if v is None else str(v)
        S1.cell(IMP_HDR + i, j + 1, v).font = A10
NEX = len(EX)

# key helper (Д6) for row lookup: VALUE(edrpou)|year
D6 = sheet("Д6", "808080")
put(D6, 1, 1, "Д6. Службові ключі рядків імпорту (не редагувати)", A10B)
put(D6, 2, 1, "Стовпець edrpou", al=LEFT); put(D6, 2, 2, f'=IFERROR(MATCH("edrpou",{HROW},0),1)', fmt=N0, fill=FILL_KEY)
put(D6, 3, 1, "Стовпець year", al=LEFT); put(D6, 3, 2, f'=IFERROR(MATCH("year",{HROW},0),2)', fmt=N0, fill=FILL_KEY)
KE, KY = "'Д6'!$B$2", "'Д6'!$B$3"
put(D6, 5, 1, "Рядок імпорту", A10B, al=CEN, border=BOX, fill=FILL_HEAD); put(D6, 5, 2, "Ключ", A10B, al=CEN, border=BOX, fill=FILL_HEAD)
K0 = 6
for i in range(NIMP):
    ir = IMP_HDR + 1 + i
    put(D6, K0 + i, 1, ir, A9)
    D6.cell(K0 + i, 2, f'=IF(INDEX(\'19.1\'!$A{ir}:${IMPC}{ir},{KE})="","",IFERROR(VALUE(INDEX(\'19.1\'!$A{ir}:${IMPC}{ir},{KE})),INDEX(\'19.1\'!$A{ir}:${IMPC}{ir},{KE}))&"|"&INDEX(\'19.1\'!$A{ir}:${IMPC}{ir},{KY}))').font = A9
KEYS = f"'Д6'!$B${K0}:$B${K0 + NIMP - 1}"
D6.column_dimensions["A"].width = 14; D6.column_dimensions["B"].width = 18


def imp_val(row_expr, field, numeric=True):
    """value of a field in the import row (row_expr: 1-based row within data rows)"""
    col = f'MATCH("{field}",{HROW},0)'
    v = f"INDEX({IMP_RNG},{row_expr}+1,{col})"
    return f"IFERROR(N({v}),0)" if numeric else f'IFERROR({v}&"","")'


# ============================================================ 19.2 single borrower
r = titles(S2, "19.2. Клас боржника юридичної особи за Додатком 7 до Положення № 351: інтегральний показник, обмеження п. 162(4), покриття процентів, PD",
           "(тис. грн; блакитні клітинки на жовтому тлі: перемикачі і ручні значення; сірий фон: службові розрахунки)")
r = header(S2, r, 1, ["Перемикач", "Значення", "Пояснення"], numbers=False)
SW0 = r
SRC = ["Імпорт CSV (аркуш 19.1)", "Ручне введення (графи 5 і 6 нижче)", "Група (аркуш 19.3)"]
SW = [("src", "Джерело звітності", SRC[0], None, "Оберіть: дані з імпорту, ручне введення або сукупна звітність групи."),
      ("edr", "Код ЄДРПОУ", "00000001", None, "Для джерела «Імпорт CSV»: код підприємства як у файлі."),
      ("year", "Звітний рік", 2024, "0", "Рік фінансової звітності."),
      ("form_o", "Форма звітності", "авто", None, "«авто»: з поля balance_form; або оберіть повна, мала, мікро."),
      ("div_o", "Розділ КВЕД (ручна заміна)", None, "0", "Порожньо: з поля firm_kved; два перші знаки коду КВЕД."),
      ("emp_o", "Кількість працівників (ручна заміна)", None, "0", "Порожньо: з поля employees."),
      ("eur_o", "Курс EUR, грн (ручна заміна)", None, N2, "Порожньо: курс на кінець звітного року з Д5."),
      ("ebtrep", "Результат до оподаткування", "звітний (р. 2290 мінус р. 2295)", None, "Друге значення відтворює код розділу 3: повна форма р. 2190 мінус 2195 плюс 2220 мінус 2250, малі форми лише р. 2290."),
      ("p162", "Застосовувати п. 162(4)", "так", None, "Клас не кращий за 9, якщо чистий борг / дохід > порогу і операційний прибуток до амортизації <= 0 або чистий борг / цей прибуток > порогу."),
      ("t_nds", "Поріг: чистий борг / чистий дохід", 2.5, N2, "Положення № 351, п. 162(4)."),
      ("t_nde", "Поріг: чистий борг / операційний прибуток до амортизації", 5.0, N2, "Положення № 351, п. 162(4)."),
      ("icr_src", "Покриття процентів: знаменник", "фінансові витрати (р. 2250)", None, "Або «борг x ставка» (оцінка процентів за ставкою з Д5 або ручною)."),
      ("rate_o", "Ставка для оцінки процентів (ручна заміна)", None, P1, "Порожньо: ставка звітного року з Д5."),
      ("t_icr", "Поріг покриття процентів", 1.0, N2, "Постанова НБУ № 23, п. 2-9(7)."),
      ("res23", "Наслідок покриття нижче порогу", "не застосовувати", None, "«клас не кращий за 9» або «клас 10» за внутрішньою політикою банку."),
      ("pdsel", "Значення PD у межах діапазону", "верхня межа", None, "Додаток 9: досвід понад 3 роки: не нижче нижньої межі; без досвіду: верхня межа.")]
for k, (key, lab, val, fmt, expl) in enumerate(SW):
    q = SW0 + k
    put(S2, q, 1, lab, al=LEFT, border=BOX); c = put(S2, q, 2, val, INP, fmt, RIGHT if fmt else LEFT, BOX, FILL_IN); put(S2, q, 3, expl, A9, al=LNW)
    if key == "edr": c.number_format = "@"
    NAMES[key] = f"'19.2'!$B${q}"
DVL = {"src": SRC, "form_o": ["авто"] + [n for _, n in FORMS], "ebtrep": ["звітний (р. 2290 мінус р. 2295)", "як у коді розділу 3"], "p162": ["так", "ні"],
       "icr_src": ["фінансові витрати (р. 2250)", "борг x ставка"], "res23": ["не застосовувати", "клас не кращий за 9", "клас 10"],
       "pdsel": ["верхня межа", "нижня межа", "середина діапазону"]}
for key, lst in DVL.items():
    dv = DataValidation(type="list", formula1='"' + ",".join(lst) + '"', allow_blank=False); S2.add_data_validation(dv); dv.add(NAMES[key].split("!")[1].replace("$", ""))
q = SW0 + len(SW) + 1
put(S2, q, 1, "Службові величини", A10I); q += 1
HLP = [("irow", "Рядок у даних імпорту", f'=IFERROR(MATCH(IFERROR(VALUE(edr),edr)&"|"&year,{KEYS},0),"не знайдено")', N0),
       ("form_i", "Форма з імпорту", "=" + imp_val("irow", "balance_form", False), None),
       ("form", "Форма для розрахунку (full, small, micro)",
        '=IF(form_o="авто",IF(src=' + f'"{SRC[2]}"' + ",'19.3'!$B$9,IF(OR(form_i=\"full\",form_i=\"small\",form_i=\"micro\"),form_i,\"full\")),"
        + 'INDEX({"full","small","micro"},MATCH(form_o,{' + ",".join(f'"{n}"' for _, n in FORMS) + "},0)))", None),
       ("kved_i", "КВЕД з імпорту", "=" + imp_val("irow", "firm_kved", False), None),
       ("div", "Розділ КВЕД", '=IF(ISNUMBER(div_o),div_o,IF(src=' + f'"{SRC[2]}"' + ",'19.3'!$B$10,IFERROR(VALUE(LEFT(kved_i,MIN(FIND(\".\",kved_i&\".\"),FIND(\",\",kved_i&\",\"))-1)),0)))", "0"),
       ("grp", "Група моделі", '=IF(AND(div>=1,div<=3),"A",IF(OR(AND(div>=5,div<=33),AND(div>=41,div<=43)),"BCF",IF(AND(div>=45,div<=47),"G",IF(AND(div>=64,div<=82),"KLMN","OTH"))))', None),
       ("tab", "Таблиця моделі", '=IF(form="full","T1","T2")', None),
       ("emp", "Кількість працівників", "=IF(ISNUMBER(emp_o),emp_o,IF(src=" + f'"{SRC[2]}"' + ",'19.3'!$B$11," + imp_val("irow", "employees") + "))", N0),
       ("eur", "Курс EUR", f"=IF(ISNUMBER(eur_o),eur_o,IFERROR(INDEX({EURS},MATCH(year,{YRS},0)),INDEX({EURS},COUNT({EURS}))))", N2),
       ("rate", "Ставка для оцінки процентів", f"=IF(ISNUMBER(rate_o),rate_o,IFERROR(INDEX({RATS},MATCH(year,{YRS},0)),INDEX({RATS},COUNT({RATS}))))", P1),
       ("full", "Повна форма", '=form="full"', None), ("small", "Мала форма", '=form="small"', None)]
for k, (key, lab, f, fmt) in enumerate(HLP):
    put(S2, q + k, 1, lab, A9, al=LEFT, border=BOX); put(S2, q + k, 2, f, A9, fmt, RIGHT if fmt else LEFT, BOX, FILL_KEY)
    NAMES[key] = f"'19.2'!$B${q + k}"
q += len(HLP)
put(S2, q, 1, "Результат до оподаткування: звітний", A9, al=LEFT, border=BOX); put(S2, q, 2, '=ebtrep="звітний (р. 2290 мінус р. 2295)"', A9, None, LEFT, BOX, FILL_KEY); NAMES["ebtrep_b"] = f"'19.2'!$B${q}"
q += 1
put(S2, q, 1, "Перевірка даних", A9, al=LEFT, border=BOX)
put(S2, q, 2, f'=IF(src="{SRC[0]}",IF(NOT(ISNUMBER(irow)),"підприємство і рік не знайдено в імпорті","знайдено"),"ручне або групове джерело")', A9, None, LEFT, BOX, FILL_KEY)
S2.conditional_formatting.add(f"B{q}", FormulaRule(formula=[f'B{q}="підприємство і рік не знайдено в імпорті"'], fill=RED))
r = q + 2

# --- 19.2.1 statement lines
put(S2, r, 1, "19.2.1. Фінансова звітність, тис. грн", A10B); r += 1
r = header(S2, r, 1, ["Рядок", "Назва", "Імпорт: на початок", "Імпорт: на кінець або за період", "Ручне: на початок", "Ручне: на кінець або за період",
                      "Група: на початок", "Група: на кінець або за період", "Для розрахунку: на початок", "Для розрахунку: на кінець або за період"], height=54)
LR = {}
GRP_LINE_ROW0 = 17   # rows of lines on 19.3 start here (see below)
for i, (code, nm, isbal) in enumerate(LINES):
    q = r + i; LR[code] = q
    put(S2, q, 1, int(code), al=CEN); put(S2, q, 2, nm, A9, al=LNW)
    if isbal:
        put(S2, q, 3, "=" + imp_val("irow", f"r{code}_open"), LINKF, N1, RIGHT)
        put(S2, q, 4, "=" + imp_val("irow", f"r{code}_close"), LINKF, N1, RIGHT)
        put(S2, q, 5, None, INP, N1, RIGHT, fill=FILL_IN)
        put(S2, q, 7, f"='19.3'!$O${GRP_LINE_ROW0 + i}", LINKF, N1, RIGHT)
    else:
        put(S2, q, 3, None); put(S2, q, 5, None); put(S2, q, 7, None)
        put(S2, q, 4, "=" + imp_val("irow", f"r{code}"), LINKF, N1, RIGHT)
    put(S2, q, 6, None, INP, N1, RIGHT, fill=FILL_IN)
    put(S2, q, 8, f"='19.3'!$P${GRP_LINE_ROW0 + i}", LINKF, N1, RIGHT)
    for c_, (ci, cm, cg) in ((9, ("C", "E", "G")), (10, ("D", "F", "H"))):
        if c_ == 9 and not isbal:
            put(S2, q, 9, None); continue
        put(S2, q, c_, f'=IF(src="{SRC[1]}",N({cm}{q}),IF(src="{SRC[2]}",N({cg}{q}),N({ci}{q})))', A10B, N1, RIGHT, fill=FILL_KEY)
LR_END = r + len(LINES) - 1
r = LR_END + 2


def res_single(code, kind):
    return f"$J${LR[code]}" if kind == "c" else f"$I${LR[code]}"


# --- 19.2.2 derived amounts
put(S2, r, 1, "19.2.2. Розрахункові величини, тис. грн", A10B); r += 1
r = header(S2, r, 1, ["Величина", "Значення", "Визначення"], numbers=False)
DR = {}


def expand(tpl, L, D, flags):
    def sub(m):
        t, v = m.group(1), m.group(2)
        if t in ("c", "o"): return L(v, t)
        if t == "d": return D[v]
        return flags[v]
    return re.sub(r"\{(?:(c|o|d):([^}]+)|([a-z]+))\}", lambda m: sub(m) if m.group(1) else flags[m.group(3)], tpl)


FL1 = {"full": "full", "small": "small", "ebtrep": "ebtrep_b"}
for i, (key, lab, tpl) in enumerate(DER):
    q = r + i; DR[key] = f"$B${q}"
    put(S2, q, 1, lab, al=LNW); put(S2, q, 2, "=" + expand(tpl, res_single, DR, FL1), fmt=N1, al=RIGHT); put(S2, q, 3, key, A9, al=LNW)
r += len(DER) + 1

# --- 19.2.7 (placed after) all indicators: compute first so the model slots can refer to them
IR0_single = None  # filled below


def ind_formula(num, den, k, L, D, flags):
    n_ = expand(num, L, D, flags); d_ = expand(den, L, D, flags)
    neg = f'IF(({d_})<0,"від\'ємний",' if k in C.ZERO else "IF(FALSE,0,"
    return f'=IF(({d_})=0,"нуль",{neg}100*({n_})/({d_})))'


# --- 19.2.3 model slots
put(S2, r, 1, '="19.2.3. Показники моделі: "&IF(tab="T1","таблиця 1 (повні форми)","таблиця 2 (форми малих і мікропідприємств)")&", група "&grp', A10B); r += 1
r = header(S2, r, 1, ["№", "Показник", "Зміст", "Значення, % або днів x 100", "Правило знаменника", "Номер діапазону", "Бал X", "Коефіцієнт", "Внесок у Z"], height=40)
SL0 = r
IND_CELL = {}     # filled after the all-indicators block is placed; use INDEX/MATCH by name instead
IALL0 = SL0 + 6 + 30      # top row of the all-indicators table (set below, must be consistent)
IALL_RNG_K = None
slots = []
for i in range(1, 7):
    q = SL0 + i - 1
    m = f'MATCH(tab&"|"&grp&"|"&{i},{MR(1)},0)'
    put(S2, q, 1, i, al=CEN, border=BOX)
    put(S2, q, 2, f'=IFERROR(INDEX({MR(5)},{m}),"")', A10B, al=CEN, border=BOX)
    put(S2, q, 3, None, A9, al=LNW, border=BOX)       # set below (lookup in all-indicators table)
    put(S2, q, 4, None, fmt=N1, al=RIGHT, border=BOX)
    put(S2, q, 5, f'=IFERROR(INDEX({MR(8)},{m}),"")', A9, al=CEN, border=BOX)
    put(S2, q, 6, None, fmt=N0, al=CEN, border=BOX)
    put(S2, q, 7, None, fmt=N3, al=RIGHT, border=BOX)
    put(S2, q, 8, f'=IFERROR(INDEX({MR(6)},{m}),"")', fmt=N3, al=RIGHT, border=BOX)
    put(S2, q, 9, f'=IF(ISNUMBER(G{q}),G{q}*H{q},"")', fmt=N3, al=RIGHT, border=BOX)
    slots.append((q, m))
q = SL0 + 6
put(S2, q, 1, "Константа b0", al=LEFT, border=TOPB); put(S2, q, 9, f'=IFERROR(INDEX({MR(7)},MATCH(tab&"|"&grp&"|1",{MR(1)},0)),"")', fmt=N3, al=RIGHT, border=TOPB)
for c_ in range(2, 9): put(S2, q, c_, None, border=TOPB)
ZROW = q + 1
put(S2, ZROW, 1, "Інтегральний показник Z", A10B, al=LEFT, border=TOPB); put(S2, ZROW, 9, f"=I{q}+SUM(I{SL0}:I{SL0 + 5})", A10B, N3, RIGHT, TOPB, FILL_KEY)
for c_ in range(2, 9): put(S2, ZROW, c_, None, border=TOPB)
NAMES["zint"] = f"'19.2'!$I${ZROW}"
r = ZROW + 2

# --- 19.2.4 class
put(S2, r, 1, "19.2.4. Розмір підприємства, клас боржника і PD", A10B); r += 1
r = header(S2, r, 1, ["Показник", "Значення", "Пояснення"], numbers=False)
CR0 = r
CLS = [("Активи на кінець року, тис. грн", f"={res_single('1300', 'c')}", N1, ""),
       ("Критерій 1: активи до 4 млн євро", "=" + res_single("1300", "c") + "<=4000*eur", None, "Сума в тис. грн порівнюється з 4 млн євро за курсом"),
       ("Критерій 2: чистий дохід до 8 млн євро", "=" + res_single("2000", "c") + "<=8000*eur", None, ""),
       ("Критерій 3: до 50 працівників", "=emp<=50", None, ""),
       ("Мале підприємство (таблиця 5)", f"=OR(NOT(full),(B{r + 1}+0)+(B{r + 2}+0)+(B{r + 3}+0)>=2)", None, "Не менше двох з трьох критеріїв; малі і мікроформи: завжди таблиця 5"),
       ("Таблиця меж класів", f'=IF(B{r + 4},"T5","T4")', None, ""),
       ("Клас за інтегральним показником", f'=IF(ISNUMBER(zint),1+COUNTIF(INDEX(\'Д2\'!$D${B0}:$K${BL},MATCH(B{r + 5}&"|"&grp,{BR(1)},0),0),">"&zint),"…")', N0, "Додаток 7, таблиці 4 і 5"),
       ("Чистий борг / чистий дохід (п. 162(4))", f'=IF({DR["sales162"]}>0,{DR["nd"]}/{DR["sales162"]},"…")', N2, ""),
       ("Чистий борг / операційний прибуток до амортизації", f'=IF({DR["ebitda"]}>0,{DR["nd"]}/{DR["ebitda"]},"…")', N2, "Якщо прибуток <= 0: умова виконана"),
       ("Умова п. 162(4) виконана", f'=AND(p162="так",ISNUMBER(B{r + 7}),B{r + 7}>t_nds,OR({DR["ebitda"]}<=0,AND(ISNUMBER(B{r + 8}),B{r + 8}>t_nde)))', None, ""),
       ("Покриття процентів (Постанова № 23)", f'=IF(icr_src="фінансові витрати (р. 2250)",IF(AND(full,{res_single("2250", "c")}>0),{DR["op23"]}/{res_single("2250", "c")},"…"),IF({DR["debt"]}*rate>0,{DR["op23"]}/({DR["debt"]}*rate),"…"))', N2, "Операційний результат до амортизації / проценти"),
       ("Покриття нижче порогу", f"=AND(ISNUMBER(B{r + 10}),B{r + 10}<t_icr)", None, ""),
       ("Клас з урахуванням п. 162(4) і Постанови № 23", f'=IF(ISNUMBER(B{r + 6}),MAX(B{r + 6},IF(B{r + 9},9,0),IF(AND(B{r + 11},res23="клас не кращий за 9"),9,0),IF(AND(B{r + 11},res23="клас 10"),10,0)),"…")', N0, ""),
       ("Погіршення за додатковими показниками, класів", None, N0, "Сума з таблиці 19.2.5"),
       ("Клас боржника: підсумок", f'=IF(ISNUMBER(B{r + 12}),MIN(10,B{r + 12}+N(B{r + 13})),"…")', N0, ""),
       ("PD: нижня межа діапазону", None, P2, "Додаток 9, таблиця 1"), ("PD: верхня межа діапазону", None, P2, ""),
       ("PD для розрахунку кредитного ризику", f'=IFERROR(IF(pdsel="нижня межа",B{r + 15},IF(pdsel="верхня межа",B{r + 16},(B{r + 15}+B{r + 16})/2)),"…")', P2, "")]
for k, (lab, f, fmt, expl) in enumerate(CLS):
    q = CR0 + k
    bold = lab.startswith("Клас боржника") or lab.startswith("PD для")
    put(S2, q, 1, lab, A10B if bold else A10, al=LNW, border=BOX); put(S2, q, 2, f, A10B if bold else A10, fmt, RIGHT if fmt else CEN, BOX, FILL_KEY if bold else None)
    put(S2, q, 3, expl, A9, al=LNW, border=BOX)
CLASS_CELL = f"'19.2'!$B${CR0 + 14}"; PD_CELL = f"'19.2'!$B${CR0 + 17}"; NAMES["clsfin"] = CLASS_CELL
gi = f'MATCH(grp,{{"A","BCF","G","KLMN","OTH"}},0)'
S2.cell(CR0 + 15, 2).value = f"=IFERROR(INDEX('Д2'!$B${PD0}:$K${PD0 + 9},B{CR0 + 14},2*{gi}-1),\"…\")"
S2.cell(CR0 + 16, 2).value = f"=IFERROR(INDEX('Д2'!$B${PD0}:$K${PD0 + 9},B{CR0 + 14},2*{gi}),\"…\")"
S2.conditional_formatting.add(f"B{CR0 + 14}", CellIsRule(operator="greaterThanOrEqual", formula=["9"], fill=RED))
S2.conditional_formatting.add(f"B{CR0 + 14}", CellIsRule(operator="between", formula=["6", "8"], fill=AMBER))
S2.conditional_formatting.add(f"B{CR0 + 14}", CellIsRule(operator="lessThanOrEqual", formula=["5"], fill=GREEN))
for rr_ in (CR0 + 9, CR0 + 11):
    S2.conditional_formatting.add(f"B{rr_}", CellIsRule(operator="equal", formula=["TRUE"], fill=RED))
PEN_CELL = (CR0 + 13, 2)
r = CR0 + len(CLS) + 1
# class bounds display
put(S2, r, 1, "Нижні межі Z для класів 1 до 8 обраної таблиці і групи", A9I)
for j in range(8):
    put(S2, r, 3 + j, f'=INDEX(\'Д2\'!$D${B0}:$K${BL},MATCH(B{CR0 + 5}&"|"&grp,{BR(1)},0),{j + 1})', A9, N2, RIGHT)
r += 2

# --- 19.2.5 additional indicators
put(S2, r, 1, "19.2.5. Додаткові показники: стандартні і власні показники банку", A10B); r += 1
r = header(S2, r, 1, ["Показник", "Значення", "Поріг", "Умова порушення", "Порушено", "Погіршення класу при порушенні", "Погіршення", "Пояснення"], height=40)
AD0 = r
AD = [("Чистий борг / операційний прибуток до амортизації", f'=IF({DR["ebitda"]}>0,{DR["nd"]}/{DR["ebitda"]},"…")', 3.5, ">", 0, "Внутрішній поріг банку (приклад)"),
      ("Покриття процентів", f"=B{CR0 + 10}", 1.5, "<", 0, "Внутрішній поріг банку (приклад)"),
      ("Коефіцієнт поточної ліквідності", f'=IF({res_single("1695", "c")}>0,{res_single("1195", "c")}/{res_single("1695", "c")},"…")', 1.0, "<", 0, "Оборотні активи / поточні зобов'язання"),
      ("Частка власного капіталу в активах", f'=IF({res_single("1300", "c")}>0,{res_single("1495", "c")}/{res_single("1300", "c")},"…")', 0.2, "<", 0, ""),
      ("Рентабельність активів", f'=IF({res_single("1300", "o")}+{res_single("1300", "c")}>0,({res_single("2350", "c")}-{res_single("2355", "c")})/AVERAGE({res_single("1300", "o")},{res_single("1300", "c")}),"…")', 0.0, "<", 0, "Чистий результат / середні активи"),
      ("Рентабельність продажів за операційним результатом", f'=IF({DR["sales"]}>0,{DR["opr"]}/{DR["sales"]},"…")', 0.0, "<", 0, "")]
for k, (lab, f, thr, op, pen, expl) in enumerate(AD):
    q = AD0 + k
    put(S2, q, 1, lab, al=LNW, border=BOX); put(S2, q, 2, f, fmt=N2, al=RIGHT, border=BOX)
    put(S2, q, 3, thr, INP, N2, RIGHT, BOX, FILL_IN); put(S2, q, 4, op, INP, al=CEN, border=BOX, fill=FILL_IN); put(S2, q, 6, pen, INP, N0, CEN, BOX, FILL_IN)
    put(S2, q, 8, expl, A9, al=LNW, border=BOX)
# user-defined: numerator and denominator as sums of up to 3 lines with multipliers
put(S2, AD0 + len(AD), 1, "Власні показники: чисельник і знаменник як суми рядків звітності з множниками (рядок: код з графи 1 таблиці 19.2.1)", A9I)
UD0 = AD0 + len(AD) + 1
r = header(S2, UD0, 1, ["Назва показника", "Чисельник: рядок 1", "Множник 1", "Рядок 2", "Множник 2", "Рядок 3", "Множник 3", "Знаменник: рядок 1", "Множник", "Рядок 2", "Множник"], height=40, numbers=False)
UDR = r
lk = lambda cell: f'IFERROR(INDEX($J${LR[LINES[0][0]]}:$J${LR_END},MATCH({cell},$A${LR[LINES[0][0]]}:$A${LR_END},0)),0)'
UDX = [("Борг перед банками / активи", 1510, 1, 1600, 1, None, None, 1300, 1, None, None), ("Запаси / собівартість, частка року", 1100, 1, None, None, None, None, 2050, 1, None, None),
       (None,) * 11]
for k in range(3):
    q = UDR + k; ex = UDX[k]
    for j in range(11):
        put(S2, q, 1 + j, ex[j], INP, None if j == 0 else ("0" if j in (1, 3, 5, 7, 9) else N2), LEFT if j == 0 else CEN, BOX, FILL_IN)
UDV0 = UDR + 3
r = header(S2, UDV0 + 1, 1, ["Власний показник", "Значення", "Поріг", "Умова порушення", "Порушено", "Погіршення класу при порушенні", "Погіршення", ""], numbers=False)
UDV = r
for k in range(3):
    q = UDV + k; s_ = UDR + k
    numf = f"N(C{s_})*{lk(f'B{s_}')}+N(E{s_})*{lk(f'D{s_}')}+N(G{s_})*{lk(f'F{s_}')}"
    denf = f"N(I{s_})*{lk(f'H{s_}')}+N(K{s_})*{lk(f'J{s_}')}"
    put(S2, q, 1, f'=IF(A{s_}="","",A{s_})', al=LNW, border=BOX)
    put(S2, q, 2, f'=IF(OR(A{s_}="",({denf})=0),"…",({numf})/({denf}))', fmt=N3, al=RIGHT, border=BOX)
    put(S2, q, 3, None, INP, N3, RIGHT, BOX, FILL_IN); put(S2, q, 4, ">", INP, al=CEN, border=BOX, fill=FILL_IN); put(S2, q, 6, 0, INP, N0, CEN, BOX, FILL_IN)
    put(S2, q, 8, None, border=BOX)
ALLAD = list(range(AD0, AD0 + len(AD))) + list(range(UDV, UDV + 3))
for q in ALLAD:
    put(S2, q, 5, f'=IF(AND(ISNUMBER(B{q}),ISNUMBER(C{q})),IF(D{q}=">",B{q}>C{q},IF(D{q}="<",B{q}<C{q},IF(D{q}=">=",B{q}>=C{q},B{q}<=C{q}))),FALSE)', al=CEN, border=BOX)
    put(S2, q, 7, f"=IF(E{q},N(F{q}),0)", fmt=N0, al=CEN, border=BOX)
    S2.conditional_formatting.add(f"E{q}", CellIsRule(operator="equal", formula=["TRUE"], fill=RED))
dvop = DataValidation(type="list", formula1='">,<,>=,<="'); S2.add_data_validation(dvop)
for q in ALLAD: dvop.add(f"D{q}")
dvln = DataValidation(type="list", formula1=f"'Д5'!$A${LN0}:$A${LNL}", allow_blank=True); S2.add_data_validation(dvln)
for k in range(3):
    for c_ in "BDFHJ": dvln.add(f"{c_}{UDR + k}")
S2.cell(*PEN_CELL).value = "=" + "+".join(f"G{q}" for q in ALLAD)
r = UDV + 4
put(S2, r, 1, "Погіршення класу за додатковими показниками: за внутрішньою політикою банку; за замовчуванням 0 (не впливає на клас за Положенням № 351).", A9I)
r += 2

# --- 19.2.6 all Annex 7 indicators
put(S2, r, 1, "19.2.6. Усі показники Додатка 7 для обраного підприємства", A10B); r += 1
r = header(S2, r, 1, ["Показник", "Зміст", "Чисельник", "Знаменник", "Значення, % або днів x 100", "Правило знаменника"], height=30)
IA0 = r
for i, (k, lab, num, den) in enumerate(IND):
    q = IA0 + i
    put(S2, q, 1, k, A10B, al=CEN); put(S2, q, 2, lab, A9, al=LNW)
    put(S2, q, 3, "=" + expand(num, res_single, DR, FL1), fmt=N1, al=RIGHT); put(S2, q, 4, "=" + expand(den, res_single, DR, FL1), fmt=N1, al=RIGHT)
    put(S2, q, 5, f'=IF(D{q}=0,"нуль",' + (f'IF(D{q}<0,"від\'ємний",' if k in C.ZERO else "IF(FALSE,0,") + f"100*C{q}/D{q}))", A10B, N1, RIGHT)
    put(S2, q, 6, RULE[k], A9, al=CEN)
IAL = IA0 + len(IND) - 1
IAK = f"$A${IA0}:$A${IAL}"
for q, m in slots:
    S2.cell(q, 3).value = f'=IFERROR(INDEX($B${IA0}:$B${IAL},MATCH(B{q},{IAK},0)),"")'
    S2.cell(q, 4).value = f'=IFERROR(INDEX($E${IA0}:$E${IAL},MATCH(B{q},{IAK},0)),"")'
    xrow = f"INDEX('Д1'!$Q${M0}:$X${ML},{m},0)"; crow = f"INDEX('Д1'!$J${M0}:$P${ML},{m},0)"
    S2.cell(q, 6).value = f'=IF(B{q}="","",IF(ISNUMBER(D{q}),COUNTIF({crow},"<="&D{q})+1,IF(E{q}="нуль","…",IF(E{q}="мінімум",1,INDEX(\'Д1\'!$I${M0}:$I${ML},{m})))))'
    S2.cell(q, 7).value = f'=IF(B{q}="","",IF(ISNUMBER(F{q}),INDEX({xrow},F{q}),0))'
r = IAL + 2
r = foot(S2, r, ["Значення показників: у відсотках (x 100); показники оборотності: 365 x залишок / потік (дні) x 100, як у Додатку 7. Межі діапазонів: «не менше» нижньої межі.",
                 "Перевірка: пакетний розрахунок 19.5 для тих самих даних відтворює клас з коду розділу 3 (class351.py), якщо обрано «як у коді розділу 3» для результату до оподаткування."])
S2.column_dimensions["A"].width = 50; S2.column_dimensions["B"].width = 30; S2.column_dimensions["C"].width = 40
for c_ in "DEFGHIJK": S2.column_dimensions[c_].width = 15
S2.freeze_panes = "A5"

# ============================================================ 19.3 group
r = titles(S3, "19.3. Група пов'язаних контрагентів: сукупна звітність як сума звітностей учасників з елімінуванням внутрішньогрупових залишків і оборотів",
           "(тис. грн; учасники: коди ЄДРПОУ з імпорту 19.1 за звітний рік з 19.2; частка: частка консолідації, 100 % для повного включення)")
put(S3, 5, 1, "Назва групи", al=LEFT, border=BOX); put(S3, 5, 2, "Група 1", INP, al=LEFT, border=BOX, fill=FILL_IN)
put(S3, 6, 1, "Звітний рік (з 19.2)", al=LEFT, border=BOX); put(S3, 6, 2, "=year", LINKF, "0", RIGHT, BOX)
put(S3, 7, 1, "Форма звітності групи для моделі", al=LEFT, border=BOX); put(S3, 7, 2, FORMS[0][1], INP, al=LEFT, border=BOX, fill=FILL_IN)
put(S3, 8, 1, "Розділ КВЕД основного виду діяльності групи", al=LEFT, border=BOX); put(S3, 8, 2, 25, INP, "0", RIGHT, BOX, FILL_IN)
put(S3, 9, 1, "Форма (код)", A9, al=LEFT, border=BOX); put(S3, 9, 2, '=INDEX({"full","small","micro"},MATCH(B7,{' + ",".join(f'"{n}"' for _, n in FORMS) + "},0))", A9, al=LEFT, border=BOX, fill=FILL_KEY)
put(S3, 10, 1, "Розділ КВЕД (для 19.2)", A9, al=LEFT, border=BOX); put(S3, 10, 2, "=B8", A9, "0", RIGHT, BOX, FILL_KEY)
put(S3, 11, 1, "Працівників, усього", A9, al=LEFT, border=BOX); put(S3, 11, 2, None, A9, N0, RIGHT, BOX, FILL_KEY)
dvf = DataValidation(type="list", formula1='"' + ",".join(n for _, n in FORMS) + '"'); S3.add_data_validation(dvf); dvf.add("B7")
NM = 6   # members
# member header block rows 12..14: code, included, share
put(S3, 12, 1, "Учасник: код ЄДРПОУ", A10B, al=LEFT, border=BOX); put(S3, 13, 1, "Включити (так, ні)", al=LEFT, border=BOX); put(S3, 14, 1, "Частка консолідації", al=LEFT, border=BOX)
MEM = ["00000001", "00000002"] + [None] * (NM - 2)
for j in range(NM):
    c_ = 3 + 2 * j
    S3.merge_cells(start_row=12, start_column=c_, end_row=12, end_column=c_ + 1); S3.merge_cells(start_row=13, start_column=c_, end_row=13, end_column=c_ + 1)
    S3.merge_cells(start_row=14, start_column=c_, end_row=14, end_column=c_ + 1)
    cc = put(S3, 12, c_, MEM[j], INP, "@", CEN, BOX, FILL_IN); put(S3, 13, c_, "так" if MEM[j] else "ні", INP, al=CEN, border=BOX, fill=FILL_IN)
    put(S3, 14, c_, 1.0, INP, '0%', CEN, BOX, FILL_IN)
dvy = DataValidation(type="list", formula1='"так,ні"'); S3.add_data_validation(dvy)
for j in range(NM): dvy.add(f"{CL(3 + 2 * j)}13")
# columns: A code, B name, members C..N (open, close pairs), O sum open, P sum close... layout: O = group open, P = group close
# sum before elimination Q,R; eliminations S,T (inputs); keep O,P as final for 19.2 links
hdr_row = GRP_LINE_ROW0 - 1
put(S3, hdr_row, 1, "Рядок", A9, al=CEN, border=BOX, fill=FILL_HEAD); put(S3, hdr_row, 2, "Назва", A9, al=CEN, border=BOX, fill=FILL_HEAD)
for j in range(NM):
    put(S3, hdr_row, 3 + 2 * j, f"Учасник {j + 1}: початок", A9, al=CEN, border=BOX, fill=FILL_HEAD); put(S3, hdr_row, 4 + 2 * j, f"Учасник {j + 1}: кінець або період", A9, al=CEN, border=BOX, fill=FILL_HEAD)
for c_, lab in ((15, "Група: початок"), (16, "Група: кінець або період"), (17, "Сума учасників: початок"), (18, "Сума учасників: кінець або період"),
                (19, "Елімінування: початок"), (20, "Елімінування: кінець або період")):
    put(S3, hdr_row, c_, lab, A9, al=CEN, border=BOX, fill=FILL_HEAD)
S3.row_dimensions[hdr_row].height = 54
assert NM * 2 + 2 == 14
mrow = lambda j: f'MATCH(IFERROR(VALUE({CL(3 + 2 * j)}$12),{CL(3 + 2 * j)}$12)&"|"&$B$6,{KEYS},0)'
for i, (code, nm, isbal) in enumerate(LINES):
    q = GRP_LINE_ROW0 + i
    put(S3, q, 1, int(code), al=CEN); put(S3, q, 2, nm, A9, al=LNW)
    for j in range(NM):
        for s_, fld in ((0, f"r{code}_open"), (1, f"r{code}_close" if isbal else f"r{code}")):
            if s_ == 0 and not isbal:
                continue
            c_ = 3 + 2 * j + s_
            put(S3, q, c_, f'=IF({CL(3 + 2 * j)}$13="так",IFERROR({imp_val(mrow(j), fld)}*{CL(3 + 2 * j)}$14,0),0)', fmt=N1, al=RIGHT)
    for s_ in (0, 1):
        if s_ == 0 and not isbal: continue
        cols = ",".join(f"{CL(3 + 2 * j + s_)}{q}" for j in range(NM))
        put(S3, q, 17 + s_, f"=SUM({cols})", fmt=N1, al=RIGHT)
        put(S3, q, 19 + s_, None, INP, N1, RIGHT, fill=FILL_IN)
        put(S3, q, 15 + s_, f"={CL(17 + s_)}{q}+N({CL(19 + s_)}{q})", A10B, N1, RIGHT, fill=FILL_KEY)
GL = GRP_LINE_ROW0 + len(LINES) - 1
S3.cell(11, 2).value = "=" + "+".join(f'IF({CL(3 + 2 * j)}$13="так",IFERROR({imp_val(mrow(j), "employees")},0),0)' for j in range(NM))
q = GL + 2
put(S3, q, 1, "Перевірка: учасник знайдено в імпорті", A9, al=LEFT)
for j in range(NM):
    put(S3, q, 3 + 2 * j, f'=IF({CL(3 + 2 * j)}$12="","",IF(ISNA({mrow(j)}),"не знайдено","так"))', A9, al=CEN)
foot(S3, q + 1, ["Елімінування (графи 19, 20): введіть зі знаком мінус внутрішньогрупову дебіторську і кредиторську заборгованість, внутрішньогрупові продажі і собівартість, фінансові інвестиції в учасників групи.",
                 "Для розрахунку класу групи оберіть на аркуші 19.2 джерело «Група (аркуш 19.3)». Сума показників підсумкових рядків (1195, 1300, 1495, 1695) також потребує елімінування."])
S3.column_dimensions["A"].width = 46; S3.column_dimensions["B"].width = 42
for j in range(3, 21): S3.column_dimensions[CL(j)].width = 12
S3.freeze_panes = f"C{GRP_LINE_ROW0}"
# fix name column label for row 12..14 (A holds labels, B column empty there)

# ============================================================ 19.4 credit risk by products and approaches
r = titles(S4, "19.4. Кредитний ризик за продуктами і підходами: Положення № 351, МСФЗ 9, стандартизований підхід і IRB",
           "(тис. грн; клас боржника і PD: з аркуша 19.2; блакитні клітинки на жовтому тлі: параметри продуктів і підходів)")
r = header(S4, r, 1, ["Параметр", "Значення", "Пояснення"], numbers=False)
PS0 = r
PS = [("Клас боржника (з 19.2)", f"={CLASS_CELL}", N0, "Можна замінити в рядку нижче"), ("Клас боржника (ручна заміна)", None, N0, "Порожньо: клас з 19.2"),
      ("PD за Положенням № 351", None, P2, "За класом, групою і вибором межі на 19.2"),
      ("Застосовувати знижений коефіцієнт ліквідності", "ні", None, "Додаток 6"),
      ("Очікувані надходження без забезпечення (RC), частка непокритої заборгованості", 0.0, P1, "Не більше 5 %"),
      ("Вимога до капіталу для RWA", 0.10, P1, "Мінімальний норматив достатності капіталу"),
      ("LGD для IRB", "LGD за Положенням № 351", None, "Або «базове 40 % (F-IRB)»"),
      ("Річний обсяг продажу боржника, млн євро (коригування МСП в IRB)", None, N1, "Порожньо: з 19.2 (р. 2000 / курс EUR / 1000)"),
      ("Стадія МСФЗ 9 для режиму «авто»", None, N0, "Клас 10: стадія 3; клас 9 або умова п. 162(4): стадія 2; інакше 1")]
for k, (lab, f, fmt, expl) in enumerate(PS):
    q = PS0 + k
    inp = f is None or not str(f).startswith("=")
    put(S4, q, 1, lab, al=LNW, border=BOX); put(S4, q, 2, f, INP if inp else LINKF, fmt, RIGHT if fmt else LEFT, BOX, FILL_IN if inp else None)
    put(S4, q, 3, expl, A9, al=LNW, border=BOX)
CLS4 = f"$B${PS0 + 7}"
_t = f"'Д2'!$B${PD0}:$K${PD0 + 9}"; _g = gi.replace('grp', NAMES['grp'])
S4.cell(PS0 + 2, 2).value = (f'=IF(ISNUMBER(B{PS0 + 1}),IFERROR(IF(pdsel="нижня межа",INDEX({_t},B{PS0 + 1},2*{_g}-1),IF(pdsel="верхня межа",INDEX({_t},B{PS0 + 1},2*{_g}),'
                             f'(INDEX({_t},B{PS0 + 1},2*{_g}-1)+INDEX({_t},B{PS0 + 1},2*{_g}))/2)),"…"),{PD_CELL})')
S4.cell(PS0 + 2, 2).font = A10B; S4.cell(PS0 + 2, 2).fill = FILL_KEY
S4.cell(PS0 + 7, 2).value = f'=IFERROR({res_single("2000", "c").replace("$", "")}*0+\'19.2\'!{res_single("2000", "c")}/eur/1000,"…")'
S4.cell(PS0 + 7, 2).value = f"=IFERROR('19.2'!{res_single('2000', 'c')}/eur/1000,\"…\")"
S4.cell(PS0 + 7, 2).font = LINKF; S4.cell(PS0 + 7, 2).fill = PatternFill(None)
S4.cell(PS0 + 8, 2).value = f'=IF(N(B{PS0 + 1})>0,IF(B{PS0 + 1}=10,3,IF(B{PS0 + 1}=9,2,1)),IF({CLASS_CELL}=10,3,IF(OR({CLASS_CELL}=9,\'19.2\'!$B${CR0 + 9}),2,1)))'
S4.cell(PS0 + 8, 2).font = A10; S4.cell(PS0 + 8, 2).fill = FILL_KEY
CLASS4 = f"IF(ISNUMBER($B${PS0 + 1}),$B${PS0 + 1},$B${PS0})"
PD4, LOWK, RCF, KREQ, LGDIRB, SME, STG = (f"$B${PS0 + 2}", f"$B${PS0 + 3}", f"$B${PS0 + 4}", f"$B${PS0 + 5}", f"$B${PS0 + 6}", f"$B${PS0 + 7}", f"$B${PS0 + 8}")
for key, lst in ((PS0 + 3, ["так", "ні"]), (PS0 + 6, ["LGD за Положенням № 351", "базове 40 % (F-IRB)"])):
    dv = DataValidation(type="list", formula1='"' + ",".join(lst) + '"'); S4.add_data_validation(dv); dv.add(f"B{key}")
r = PS0 + len(PS) + 1
put(S4, r, 1, "19.4.1. Продукти і забезпечення", A10B); r += 1
PH = ["Продукт", "Заборгованість (балансова)", "Невикористаний ліміт або позабалансова сума", "Строк до погашення, років", "Отримана комісія (зменшує EAD позабалансових)",
      "Вид забезпечення", "Вартість забезпечення", "Грошове покриття", "Стадія МСФЗ 9 (авто, 1, 2, 3)", "Ефективна ставка", "Клас ваги ризику", "CCF 351 (ручна заміна)", "Вага ризику (ручна заміна)"]
PT0 = header(S4, r, 1, PH, height=66)
NP = 8
EXP = [("Строковий кредит", 9000, 0, 3, 0, "Нежитлова нерухомість", 12000, 0, "авто", 0.18, RWS[0][0]),
       ("Кредитна лінія відновлювальна", 4000, 3000, 1.5, 15, "Товари в обороті, біологічні активи", 5000, 0, "авто", 0.20, RWS[0][0]),
       ("Овердрафт", 500, 1500, 0.5, 0, "Без забезпечення", 0, 0, "авто", 0.24, RWS[0][0]),
       ("Гарантія виконання зобов'язань (тендерна, контрактна)", 0, 2500, 1, 25, "Без забезпечення", 0, 500, "авто", 0.0, RWS[0][0])]
for k in range(NP):
    q = PT0 + k; ex = EXP[k] if k < len(EXP) else (None,) * 11
    for j in range(13):
        v = ex[j] if j < 11 else None
        fmt = None if j in (0, 5, 8, 10) else (P1 if j in (9, 11, 12) else N1)
        put(S4, q, 1 + j, v, INP, fmt, LEFT if j in (0, 5, 10) else RIGHT, BOX, FILL_IN)
PTL = PT0 + NP - 1
for col, src_ in (("A", f"'Д3'!$A${PR0}:$A${PRL}"), ("F", f"'Д4'!$A${CO0}:$A${COL_}"), ("K", f"'Д3'!$A${RW0}:$A${RWL}")):
    dv = DataValidation(type="list", formula1=src_, allow_blank=True); S4.add_data_validation(dv); dv.add(f"{col}{PT0}:{col}{PTL}")
dvs = DataValidation(type="list", formula1='"авто,1,2,3"', allow_blank=True); S4.add_data_validation(dvs); dvs.add(f"I{PT0}:I{PTL}")
r = PTL + 2
put(S4, r, 1, "19.4.2. Розрахунок за підходами", A10B); r += 1
CH = ["Продукт", "CCF 351", "EAD 351", "Коефіцієнт k", "Забезпечення x k + грошове покриття", "Очікувані надходження без забезпечення", "LGD 351", "PD 351", "Кредитний ризик 351 (PD x LGD x EAD)",
      "Стадія МСФЗ 9", "PD на горизонті", "EAD МСФЗ 9", "ECL МСФЗ 9", "CCF стандартизований", "EAD стандартизований", "Вага ризику", "RWA стандартизований",
      "PD IRB", "LGD IRB", "Строк M", "Кореляція R", "Вимога K (IRB)", "RWA IRB", "Очікуваний збиток IRB"]
RC0 = header(S4, r, 1, CH, height=66)
for k in range(NP):
    q = RC0 + k; p = PT0 + k
    on = f'$A{p}<>""'
    pr = f"MATCH($A{p},'Д3'!$A${PR0}:$A${PRL},0)"
    term_col = f'IF(N($D{p})<1,2,IF(N($D{p})<=3,3,4))'
    put(S4, q, 1, f'=IF({on},$A{p},"")', al=LNW)
    f = {}
    tcf = f"INDEX('Д3'!$A${PR0}:$D${PRL},{pr},{term_col})"
    f[2] = f'=IF({on},IF(ISNUMBER($L{p}),$L{p},IF(AND(N($C{p})>0,N($H{p})>=N($C{p})),0,{tcf})),"")'
    f[3] = f'=IF({on},N($B{p})+MAX(0,N($C{p})-N($E{p}))*B{q},"")'
    f[4] = f"=IF({on},IFERROR(INDEX('Д4'!$B${CO0}:$C${COL_},MATCH($F{p},'Д4'!$A${CO0}:$A${COL_},0),IF({LOWK}=\"так\",2,1)),0),\"\")"
    f[5] = f'=IF({on},MIN(C{q},N($G{p})*D{q}+N($H{p})),"")'
    f[6] = f'=IF({on},MIN(0.05,N({RCF}))*MAX(0,C{q}-E{q}),"")'
    f[7] = f'=IF({on},IF(C{q}>0,MAX(0,1-(E{q}+F{q})/C{q}),0),"")'
    f[8] = f'=IF({on},N({PD4}),"")'
    f[9] = f'=IF({on},H{q}*G{q}*C{q},"")'
    f[10] = f'=IF({on},IF(OR($I{p}="авто",$I{p}=""),{STG},VALUE($I{p}&"")),"")'
    f[11] = f'=IF({on},IF(J{q}=3,1,IF(J{q}=2,1-(1-H{q})^MAX(1,N($D{p})),H{q})),"")'
    f[12] = f'=IF({on},N($B{p})+N($C{p})*B{q},"")'
    qd = f"((1-H{q})/(1+N($J{p})))"
    tt = f"IF(J{q}=1,1,MAX(1,N($D{p})))"
    f[13] = f'=IF({on},IF(J{q}=3,G{q}*L{q},G{q}*L{q}*H{q}/(1+N($J{p}))*IF(ABS(1-{qd})<1E-9,{tt},(1-{qd}^{tt})/(1-{qd}))),"")'
    f[14] = f"=IF({on},INDEX('Д3'!$E${PR0}:$E${PRL},{pr}),\"\")"
    f[15] = f'=IF({on},N($B{p})+N($C{p})*N(N{q}),"")'
    f[16] = f"=IF({on},IF(ISNUMBER($M{p}),$M{p},IFERROR(INDEX('Д3'!$B${RW0}:$B${RWL},MATCH($K{p},'Д3'!$A${RW0}:$A${RWL},0)),1)),\"\")"
    f[17] = f'=IF({on},O{q}*P{q},"")'
    f[18] = f'=IF({on},MIN(0.9999,MAX(0.0005,H{q})),"")'
    f[19] = f'=IF({on},IF({LGDIRB}="базове 40 % (F-IRB)",0.4,G{q}),"")'
    f[20] = f'=IF({on},MIN(5,MAX(1,N($D{p}))),"")'
    sme = f"IF(ISNUMBER({SME}),0.04*(1-(MIN(50,MAX(5,{SME}))-5)/45)*IF({SME}<50,1,0),0)"
    f[21] = f'=IF({on},0.12*(1-EXP(-50*R{q}))/(1-EXP(-50))+0.24*(1-(1-EXP(-50*R{q}))/(1-EXP(-50)))-{sme},"")'
    bb = f"(0.11852-0.05478*LN(R{q}))^2"
    f[22] = f'=IF({on},IF(H{q}>=1,0,S{q}*(NORMSDIST((NORMSINV(R{q})+SQRT(U{q})*NORMSINV(0.999))/SQRT(1-U{q}))-R{q})*(1+(T{q}-2.5)*{bb})/(1-1.5*{bb})),"")'
    f[23] = f'=IF({on},V{q}*12.5*C{q},"")'
    f[24] = f'=IF({on},R{q}*S{q}*C{q},"")'
    for c_ in range(2, 25):
        fmt = P1 if c_ in (2, 7, 14, 16, 19, 21) else P2 if c_ in (8, 11, 18, 22) else N2 if c_ in (4, 20) else N0 if c_ == 10 else N1
        put(S4, q, c_, f[c_], A10B if c_ in (9, 13, 17, 23) else A10, fmt, RIGHT)
RCL = RC0 + NP - 1
q = RCL + 1
put(S4, q, 1, "Разом", A10B, al=LEFT, border=TOPB)
for c_ in range(2, 25):
    v = f"=SUM({CL(c_)}{RC0}:{CL(c_)}{RCL})" if c_ in (3, 5, 6, 9, 12, 13, 15, 17, 23, 24) else None
    put(S4, q, c_, v, A10B, N1, RIGHT, TOPB)
TOT = q
r = q + 2
put(S4, r, 1, "19.4.3. Підсумок за підходами", A10B); r += 1
r = header(S4, r, 1, ["Підхід", "Експозиція (EAD)", "Очікувані втрати або резерв", "Частка EAD", "Активи, зважені за ризиком", "Вимога до капіталу"], height=40)
SU0 = r
SUM_ = [("Положення № 351: кредитний ризик", f"=C{TOT}", f"=I{TOT}", None),
        ("МСФЗ 9: очікувані кредитні збитки", f"=L{TOT}", f"=M{TOT}", None),
        ("Стандартизований підхід", f"=O{TOT}", None, f"=Q{TOT}"),
        ("IRB (базовий)", f"=C{TOT}", f"=X{TOT}", f"=W{TOT}")]
for k, (lab, e, l, rwa) in enumerate(SUM_):
    q = SU0 + k
    put(S4, q, 1, lab, al=LNW, border=BOX); put(S4, q, 2, e, A10B, N1, RIGHT, BOX); put(S4, q, 3, l, A10B, N1, RIGHT, BOX)
    put(S4, q, 4, f'=IFERROR(C{q}/B{q},"…")' if l else "…", fmt=P2, al=RIGHT, border=BOX)
    put(S4, q, 5, rwa, A10B, N1, RIGHT, BOX); put(S4, q, 6, f"=E{q}*{KREQ}" if rwa else "…", fmt=N1, al=RIGHT, border=BOX)
SUL = SU0 + 3
bc = BarChart(); bc.type = "col"; bc.grouping = "clustered"; bc.title = "Очікувані втрати за підходами, тис. грн"
bc.add_data(Reference(S4, min_col=3, min_row=SU0, max_row=SUL), titles_from_data=False); bc.set_categories(Reference(S4, min_col=1, min_row=SU0, max_row=SUL))
bc.series[0].graphicalProperties.solidFill = "1F4E79"; bc.legend = None; bc.height = 7; bc.width = 14; axis_font(bc)
S4.add_chart(bc, f"H{SU0 - 3}")
r = SUL + 2
foot(S4, r, ["Положення № 351: EAD позабалансових = (сума мінус комісія) x CCF (Додаток 5); LGD = 1 мінус (вартість забезпечення x k (Додаток 6) + грошове покриття + RC) / EAD; кредитний ризик = PD x LGD x EAD.",
             "МСФЗ 9: стадія 1: PD на 12 міс.; стадія 2: PD на весь строк 1 - (1 - PD)^T; стадія 3: PD = 1; ECL дисконтовано за ефективною ставкою (спрощено: постійна річна PD).",
             "IRB: формула Базеля для корпоративних експозицій (кореляція R з коригуванням для МСП, коригування на строк M), PD не нижче 0,05 %; RWA = K x 12,5 x EAD.",
             "Ілюстративний розрахунок: параметри МСФЗ 9 і IRB не є регуляторними для українських банків без внутрішніх моделей; результати для порівняння підходів."])
S4.column_dimensions["A"].width = 46; S4.column_dimensions["B"].width = 18; S4.column_dimensions["C"].width = 16
for j in range(4, 25): S4.column_dimensions[CL(j)].width = 13
S4.column_dimensions["F"].width = 30; S4.column_dimensions["K"].width = 28
S4.freeze_panes = "B5"

# ============================================================ 19.5 batch
r = titles(S5, "19.5. Пакетний розрахунок класу боржника для всіх рядків імпорту (Додаток 7, п. 162(4), покриття процентів)",
           f"(рядки 1 до {NB} імпорту 19.1; параметри: пороги, визначення результату до оподаткування і ставка з аркуша 19.2; для більшої кількості скопіюйте останній рядок вниз)")
BH = ["Рядок імпорту", "ЄДРПОУ", "Рік", "Форма", "Розділ КВЕД", "Група моделі", "Таблиця"]
lines_cols = {}
c_ = len(BH) + 1
LCOL0 = c_
for code, nm, isbal in LINES:
    if isbal:
        lines_cols[(code, "o")] = c_; lines_cols[(code, "c")] = c_ + 1; c_ += 2
    else:
        lines_cols[(code, "c")] = c_; c_ += 1
LCOLL = c_ - 1
DCOL = {}
for key, _, _ in DER:
    DCOL[key] = c_; c_ += 1
ICOL = {}
for k, *_ in IND:
    ICOL[k] = c_; c_ += 1
SCOL = c_          # slots: m, X for 6 slots
c_ += 12
ZC = c_; c_ += 1
SMC = c_; c_ += 1     # small enterprise
CLC = c_; c_ += 1     # class by score
NDS = c_; NDE = c_ + 1; HCR = c_ + 2; ICR = c_ + 3; ICRF = c_ + 4; CLF = c_ + 5; c_ += 6
LASTC = c_ - 1
hdrs = {i + 1: h for i, h in enumerate(BH)}
for (code, kind), col in lines_cols.items():
    hdrs[col] = f"r{code}_{'open' if kind == 'o' else 'close'}" if any(cc == code and b for cc, _, b in LINES) else f"r{code}"
for key, col in DCOL.items(): hdrs[col] = key
for k, col in ICOL.items(): hdrs[col] = k
for i in range(6): hdrs[SCOL + 2 * i] = f"Слот {i + 1}: рядок моделі"; hdrs[SCOL + 2 * i + 1] = f"Слот {i + 1}: X"
hdrs.update({ZC: "Інтегральний показник Z", SMC: "Мале підприємство", CLC: "Клас за Z", NDS: "Чистий борг / дохід", NDE: "Чистий борг / операційний прибуток до амортизації",
             HCR: "Умова п. 162(4)", ICR: "Покриття процентів", ICRF: "Покриття нижче порогу", CLF: "Клас підсумковий"})
HR5 = r
for col, h_ in hdrs.items():
    put(S5, HR5, col, h_, A9, al=CEN, border=BOX, fill=FILL_HEAD)
S5.row_dimensions[HR5].height = 54
# column-index row for import fields
IXR = HR5 + 1
put(S5, IXR, 1, "Стовпець у 19.1", A9I)
for (code, kind), col in lines_cols.items():
    put(S5, IXR, col, f'=IFERROR(MATCH("{hdrs[col]}",{HROW},0),0)', A9, N0, CEN, fill=FILL_KEY)
for col, fld in ((2, "edrpou"), (3, "year"), (4, "balance_form"), (5, "firm_kved")):
    put(S5, IXR, col, f'=IFERROR(MATCH("{fld}",{HROW},0),0)', A9, N0, CEN, fill=FILL_KEY)
put(S5, IXR, SMC, f'=IFERROR(MATCH("employees",{HROW},0),0)', A9, N0, CEN, fill=FILL_KEY)
BR0 = IXR + 1


def L5(q):
    return lambda code, kind: f"${CL(lines_cols[(code, kind)])}{q}"


for i in range(NB):
    q = BR0 + i; ir = IMP_HDR + 1 + i
    row_ = f"'19.1'!$A${ir}:${IMPC}${ir}"
    on = f'$B{q}<>""'
    put(S5, q, 1, ir, A9, al=CEN)
    put(S5, q, 2, f'=IF(B${IXR}=0,"",IF(INDEX({row_},B${IXR})="","",INDEX({row_},B${IXR})&""))', A9, al=CEN)
    put(S5, q, 3, f'=IF({on},IFERROR(VALUE(INDEX({row_},C${IXR})&""),0),"")', A9, "0", CEN)
    put(S5, q, 4, f'=IF({on},IF(D${IXR}=0,"full",INDEX({row_},D${IXR})&""),"")', A9, al=CEN)
    put(S5, q, 5, f'=IF({on},IFERROR(VALUE(LEFT(INDEX({row_},E${IXR})&"",MIN(FIND(".",INDEX({row_},E${IXR})&"."),FIND(",",INDEX({row_},E${IXR})&","))-1)),0),"")', A9, "0", CEN)
    put(S5, q, 6, f'=IF({on},IF(AND(E{q}>=1,E{q}<=3),"A",IF(OR(AND(E{q}>=5,E{q}<=33),AND(E{q}>=41,E{q}<=43)),"BCF",IF(AND(E{q}>=45,E{q}<=47),"G",IF(AND(E{q}>=64,E{q}<=82),"KLMN","OTH")))),"")', A9, al=CEN)
    put(S5, q, 7, f'=IF({on},IF(D{q}="full","T1","T2"),"")', A9, al=CEN)
    for (code, kind), col in lines_cols.items():
        cl_ = CL(col)
        S5.cell(q, col, f"=IF(AND({on},{cl_}${IXR}>0),N(INDEX({row_},{cl_}${IXR})),0)").font = A9
    fl = {"full": f'($D{q}="full")', "small": f'($D{q}="small")', "ebtrep": "'19.2'!" + NAMES["ebtrep_b"].split("!")[1]}
    DD = {}
    for key, _, tpl in DER:
        col = DCOL[key]; DD[key] = f"${CL(col)}{q}"
    for key, _, tpl in DER:
        S5.cell(q, DCOL[key], "=" + expand(tpl, L5(q), DD, fl)).font = A9
    for k, lab, num, den in IND:
        S5.cell(q, ICOL[k], ind_formula(num, den, k, L5(q), DD, fl)).font = A9
    irng = f"${CL(ICOL[IND[0][0]])}{q}:${CL(ICOL[IND[-1][0]])}{q}"
    ihdr = f"${CL(ICOL[IND[0][0]])}${HR5}:${CL(ICOL[IND[-1][0]])}${HR5}"
    zterms = []
    for s in range(6):
        cm, cx = SCOL + 2 * s, SCOL + 2 * s + 1
        S5.cell(q, cm, f'=IF({on},IFERROR(MATCH($G{q}&"|"&$F{q}&"|{s + 1}",{MR(1)},0),0),0)').font = A9
        m = f"${CL(cm)}{q}"
        v = f"INDEX({irng},MATCH(INDEX({MR(5)},{m}),{ihdr},0))"
        rule = f"INDEX({MR(8)},{m})"
        xrow = f"INDEX('Д1'!$Q${M0}:$X${ML},{m},0)"; crow = f"INDEX('Д1'!$J${M0}:$P${ML},{m},0)"
        S5.cell(q, cx, f'=IF({m}=0,0,IF(ISNUMBER({v}),INDEX({xrow},COUNTIF({crow},"<="&{v})+1),IF({rule}="нуль",0,IF({rule}="мінімум",INDEX({xrow},1),INDEX({xrow},INDEX(\'Д1\'!$I${M0}:$I${ML},{m}))))))').font = A9
        zterms.append(f"IF({m}>0,INDEX({MR(6)},{m})*${CL(cx)}{q},0)")
    b0 = f"INDEX({MR(7)},${CL(SCOL)}{q})"
    S5.cell(q, ZC, f'=IF(AND({on},${CL(SCOL)}{q}>0),{b0}+' + "+".join(zterms) + ',"")').font = A9
    emp = f"IF(${CL(SMC)}${IXR}>0,N(INDEX({row_},${CL(SMC)}${IXR})),0)"
    eur = f"IFERROR(INDEX({EURS},MATCH($C{q},{YRS},0)),INDEX({EURS},COUNT({EURS})))"
    S5.cell(q, SMC, f'=IF({on},OR($D{q}<>"full",((${CL(lines_cols[("1300", "c")])}{q}<=4000*{eur})+(${CL(lines_cols[("2000", "c")])}{q}<=8000*{eur})+({emp}<=50))>=2),"")').font = A9
    S5.cell(q, CLC, f'=IF(ISNUMBER(${CL(ZC)}{q}),1+COUNTIF(INDEX(\'Д2\'!$D${B0}:$K${BL},MATCH(IF(${CL(SMC)}{q},"T5","T4")&"|"&$F{q},{BR(1)},0),0),">"&${CL(ZC)}{q}),"")').font = A9
    S5.cell(q, NDS, f'=IF(AND({on},{DD["sales162"]}>0),{DD["nd"]}/{DD["sales162"]},"")').font = A9
    S5.cell(q, NDE, f'=IF(AND({on},{DD["ebitda"]}>0),{DD["nd"]}/{DD["ebitda"]},"")').font = A9
    S5.cell(q, HCR, f'=IF({on},AND(ISNUMBER(${CL(NDS)}{q}),${CL(NDS)}{q}>t_nds,OR({DD["ebitda"]}<=0,AND(ISNUMBER(${CL(NDE)}{q}),${CL(NDE)}{q}>t_nde))),"")').font = A9
    rate = f"IF(ISNUMBER(rate_o),rate_o,IFERROR(INDEX({RATS},MATCH($C{q},{YRS},0)),INDEX({RATS},COUNT({RATS}))))"
    f2250 = f"${CL(lines_cols[('2250', 'c')])}{q}"
    S5.cell(q, ICR, f'=IF({on},IF(icr_src="фінансові витрати (р. 2250)",IF(AND($D{q}="full",{f2250}>0),{DD["op23"]}/{f2250},""),IF({DD["debt"]}*{rate}>0,{DD["op23"]}/({DD["debt"]}*{rate}),"")),"")').font = A9
    S5.cell(q, ICRF, f'=IF({on},AND(ISNUMBER(${CL(ICR)}{q}),${CL(ICR)}{q}<t_icr),"")').font = A9
    cz = f"${CL(CLC)}{q}"
    S5.cell(q, CLF, f'=IF(ISNUMBER({cz}),MAX({cz},IF(AND(p162="так",${CL(HCR)}{q}),9,0),IF(AND(${CL(ICRF)}{q},res23="клас не кращий за 9"),9,0),IF(AND(${CL(ICRF)}{q},res23="клас 10"),10,0)),"")').font = A10B
    for col in (ZC,): S5.cell(q, col).number_format = N3
    for col in (NDS, NDE, ICR): S5.cell(q, col).number_format = N2
BRL = BR0 + NB - 1
S5.freeze_panes = S5.cell(BR0, 4)
S5.column_dimensions["A"].width = 8; S5.column_dimensions["B"].width = 11
for col in range(3, LASTC + 1): S5.column_dimensions[CL(col)].width = 10
for col in (ZC, CLC, HCR, CLF): S5.column_dimensions[CL(col)].width = 12
# group the technical columns
S5.column_dimensions.group(CL(LCOL0), CL(SCOL + 11), outline_level=1, hidden=True)
S5.conditional_formatting.add(f"{CL(CLF)}{BR0}:{CL(CLF)}{BRL}", CellIsRule(operator="greaterThanOrEqual", formula=["9"], fill=RED))
put(S5, BRL + 2, 1, "Технічні графи (рядки звітності, розрахункові величини, показники Додатка 7, слоти моделі) згруповано і приховано: кнопка «+» над заголовками.", A9I)
put(S5, BRL + 3, 1, "Джерело: розрахунки автора за Положенням НБУ № 351 (Додаток 7, п. 162(4)) і Постановою НБУ № 23; скрипт 19_borrower_class_tool.py.", A9I)
# batch summary (top-right): distribution of classes
put(S5, 3, LASTC + 2, "Розподіл за класом", A10B)
for cl in range(1, 11):
    put(S5, 3 + cl, LASTC + 2, cl, al=CEN); put(S5, 3 + cl, LASTC + 3, f"=COUNTIF(${CL(CLF)}${BR0}:${CL(CLF)}${BRL},{cl})", fmt=N0, al=RIGHT)

# ============================================================ 19.6 methodology
r = titles(S6, "19.6. Методологія і порядок роботи")
TXT = [("Призначення", "Розрахунок класу боржника юридичної особи за Положенням НБУ № 351 за даними річної фінансової звітності, оцінка кредитного ризику продуктів банку різними підходами; для практиків банків, студентів і дослідників."),
       ("1. Дані", "Аркуш 19.1: Дані, Оновити все: Excel запитає файл CSV (кодування UTF-8, роздільник кома, десятковий знак крапка). Без підключення: Дані, З тексту або CSV, мова English (United States), і вставте результат з клітинки A6."),
       ("", "Файл CSV для кількох підприємств: скрипт 19_extract_firms.py (вибирає коди ЄДРПОУ з finrep_v5_slim.csv.gz) або власний експорт з тими самими назвами полів."),
       ("2. Клас", "Аркуш 19.2: оберіть джерело, код ЄДРПОУ і рік. Модель (таблиця 1 або 2) і група визначаються формою звітності і розділом КВЕД; показники рахуються з рядків звітності з правилами знаменника Додатка 7."),
       ("", "Межі класів: таблиця 4 (великі і середні) або 5 (малі) за критеріями розміру. Після класу за інтегральним показником застосовуються п. 162(4) і, за вибором, покриття процентів за Постановою № 23."),
       ("3. Група", "Аркуш 19.3: введіть коди учасників і частки консолідації, внесіть елімінування; на аркуші 19.2 оберіть джерело «Група». Клас групи визначається за сукупною звітністю."),
       ("4. Кредитний ризик", "Аркуш 19.4: продукти, забезпечення, строки; результати за Положенням № 351, МСФЗ 9, стандартизованим підходом і IRB з підсумком і графіком."),
       ("5. Пакет", "Аркуш 19.5: клас для всіх рядків імпорту; розподіл за класами. Використовується і для перевірки відповідності коду розділу 3 магістерської роботи."),
       ("Обмеження", "Інструмент не враховує якісних чинників, подій дефолту, реструктуризації і даних кредитного реєстру; для регуляторних цілей перевірте актуальну редакцію нормативних актів НБУ."),
       ("Позначення", "Блакитний шрифт на жовтому тлі: вхідні дані; зелений: посилання; чорний: формули; сірий фон: службові розрахунки; червоне тло: порушення порогу або клас 9 і 10.")]
for t1, t2 in TXT:
    put(S6, r, 1, t1, A10B, al=LEFT); put(S6, r, 2, t2, al=LEFT); S6.row_dimensions[r].height = 42; r += 1
S6.column_dimensions["A"].width = 18; S6.column_dimensions["B"].width = 130
foot(S6, r)

# ============================================================ contents
S0.column_dimensions["A"].width = 120
r = 2
put(S0, r, 1, "19. Інструмент оцінки класу позичальника за Положенням НБУ № 351 і кредитного ризику за продуктами і підходами", A10B); r += 2
for sh, txt in [("19.1", "19.1. Дані фінансової звітності (підключення до CSV або вставлення)"),
                ("19.2", "19.2. Клас боржника: модель Додатка 7, п. 162(4), Постанова № 23, додаткові показники, PD"),
                ("19.3", "19.3. Група пов'язаних контрагентів: сума звітностей учасників з елімінуванням"),
                ("19.4", "19.4. Кредитний ризик за продуктами: Положення № 351, МСФЗ 9, стандартизований підхід, IRB"),
                ("19.5", "19.5. Пакетний розрахунок класу для всіх рядків імпорту"), ("19.6", "19.6. Методологія і порядок роботи"),
                ("Д1", "Д1. Моделі: таблиці 1 і 2 Додатка 7"), ("Д2", "Д2. Межі класів (таблиці 4 і 5) і PD (Додаток 9)"), ("Д3", "Д3. Продукти, CCF і ваги ризику"),
                ("Д4", "Д4. Коефіцієнти ліквідності забезпечення (Додаток 6)"), ("Д5", "Д5. Рядки звітності, курс євро і ставки"), ("Д6", "Д6. Службові ключі")]:
    c = put(S0, r, 1, txt, A10L, al=LNW); c.hyperlink = f"#'{sh}'!A1"; r += 1
r += 1
put(S0, r, 1, "Приклад: у 19.1 наведено умовні підприємства 00000001 (два роки), 00000002 (учасник групи) і 00000003 (мала форма); замініть їх власними даними.", A10I)
put(S0, r + 2, 1, f"Згенеровано {dt.date.today().strftime('%d.%m.%Y')} скриптом 19_borrower_class_tool.py.", A9I)

# ------------------------------------------------------------ names, order, setup
pat = re.compile(r"(?<![A-Za-z_'!$.])(" + "|".join(sorted(map(re.escape, NAMES), key=len, reverse=True)) + r")(?![A-Za-z0-9_(!$:])")
LIT = re.compile(r'"(?:[^"]|"")*"')


def subst(f):
    out, pos = [], 0
    for m in LIT.finditer(f):
        out.append(pat.sub(lambda mm: NAMES[mm.group(1)], f[pos:m.start()])); out.append(m.group(0)); pos = m.end()
    out.append(pat.sub(lambda mm: NAMES[mm.group(1)], f[pos:]))
    return "".join(out)


for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.startswith("="):
                c.value = subst(c.value)
    for cf in ws.conditional_formatting:
        for rule in cf.rules:
            rule.formula = [subst(f) for f in (rule.formula or [])]
order = ["19", "19.1", "19.2", "19.3", "19.4", "19.5", "19.6", "Д1", "Д2", "Д3", "Д4", "Д5", "Д6"]
wb._sheets = [wb[n] for n in order]
for ws in wb.worksheets:
    ws.page_setup.orientation = "landscape"; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0; ws.sheet_properties.pageSetUpPr.fitToPage = True
wb.active = 2
wb.calculation.fullCalcOnLoad = True
SM = {"Д1": "D1", "Д2": "D2", "Д3": "D3", "Д4": "D4", "Д5": "D5", "Д6": "D6"}
path_en, _ = save_both(wb, FILE, SM, os.path.join(DEST, "i18n_missing_borrower.txt"))


# ------------------------------------------------------------ text connection to CSV (query table on 19.1)
def add_csv_connection(path):
    sidx = order.index("19.1")
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        names = zin.namelist()
        sheet_file = f"xl/worksheets/sheet{sidx + 1}.xml"
        rels_file = f"xl/worksheets/_rels/sheet{sidx + 1}.xml.rels"
        for n in names:
            data = zin.read(n)
            if n == "[Content_Types].xml":
                s = data.decode("utf-8")
                s = s.replace("</Types>", '<Override PartName="/xl/connections.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml"/>'
                                          '<Override PartName="/xl/queryTables/queryTable1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.queryTable+xml"/></Types>')
                data = s.encode("utf-8")
            elif n == "xl/_rels/workbook.xml.rels":
                s = data.decode("utf-8")
                s = s.replace("</Relationships>", '<Relationship Id="rIdCsv1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/connections" Target="connections.xml"/></Relationships>')
                data = s.encode("utf-8")
            elif n == "xl/workbook.xml":
                s = data.decode("utf-8")
                dn = f'<definedName name="ExternalData_1" localSheetId="{sidx}" hidden="1">\'19.1\'!$A${IMP_HDR}:${IMPC}${IMP_HDR + NIMP}</definedName>'
                if "<definedNames>" in s:
                    s = s.replace("<definedNames>", "<definedNames>" + dn, 1)
                elif "<definedNames/>" in s:
                    s = s.replace("<definedNames/>", "<definedNames>" + dn + "</definedNames>", 1)
                else:
                    s = s.replace("</sheets>", "</sheets><definedNames>" + dn + "</definedNames>", 1)
                data = s.encode("utf-8")
            elif n == rels_file:
                s = data.decode("utf-8")
                s = s.replace("</Relationships>", '<Relationship Id="rIdQt1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/queryTable" Target="../queryTables/queryTable1.xml"/></Relationships>')
                data = s.encode("utf-8")
            zout.writestr(n, data)
        if rels_file not in names:
            zout.writestr(rels_file, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                                     '<Relationship Id="rIdQt1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/queryTable" Target="../queryTables/queryTable1.xml"/></Relationships>')
        tf = '<textField type="text"/>'
        zout.writestr("xl/connections.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                      '<connections xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                      '<connection id="1" name="finrep_csv" type="6" refreshedVersion="6" background="1" saveData="1">'
                      '<textPr prompt="1" codePage="65001" sourceFile="finrep_firms.csv" delimited="1" decimal="." thousands=" " tab="0" comma="1">'
                      f'<textFields count="5">{tf}<textField/>{tf}<textField/>{tf}</textFields></textPr></connection></connections>')
        zout.writestr("xl/queryTables/queryTable1.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                      '<queryTable xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" name="ExternalData_1" connectionId="1" autoFormatId="16" '
                      'applyNumberFormats="0" applyBorderFormats="0" applyFontFormats="0" applyPatternFormats="0" applyAlignmentFormats="0" applyWidthHeightFormats="0" '
                      'growShrinkType="overwriteClear" adjustColumnWidth="0"/>')
    shutil.move(tmp, path)


for p_ in (FILE, path_en):
    add_csv_connection(p_)
print("OK:", FILE, f"рядків імпорту: {NIMP}, пакет: {NB}, прикладів: {NEX}")
