# -*- coding: utf-8 -*-
"""Firm-year panel from the v5 export (all lines): Reg. 351 p.162(4) ratios, Res. 23 coverage, Annex 7 class.
python firms_reg351_build_v5.py data_nbu/firms/finrep_v5_slim.csv.gz data_nbu/firms/reg351_panel_v5.parquet [extra_2021.csv]"""
import pandas as pd, numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import class351 as C
SRC, OUT = sys.argv[1:3]
d = pd.read_csv(SRC, dtype={'edrpou': str, 'firm_kved': str, 'firm_katottg': str}, low_memory=False)
if len(sys.argv) > 3:   # optional separate file for a missing year (e.g. 2021 in v4 layout)
    e = pd.read_csv(sys.argv[3], dtype={'﻿edrpou': str, 'edrpou': str, 'firm_kved': str}, low_memory=False)
    e.columns = [c.lstrip('﻿') for c in e.columns]
    e = e[~e.year.isin(d.year.unique())][[c for c in e.columns if c in d.columns]]
    d = pd.concat([e, d], ignore_index=True)
d = d.drop_duplicates(['edrpou', 'year'], keep='last')
print('rows by year', d.groupby('year').size().to_dict())
d['div'] = pd.to_numeric(d.firm_kved.str.split('.').str[0], errors='coerce')
d = d[~d['div'].isin([64, 65, 66, 84]) & (d.r1300_close >= 50)].copy()
g = lambda c: d[c].astype(float).fillna(0) if c in d else pd.Series(0.0, index=d.index)
full = d.balance_form.eq('full'); small = d.balance_form.eq('small'); micro = d.balance_form.eq('micro')
d['full'] = full
if 'operating_result' not in d or d.operating_result.isna().all():
    d['operating_result'] = np.where(full, g('r2190') - g('r2195'), np.nan)
d['nd'] = np.where(full, g('r1510_close') + g('r1515_close') + g('r1600_close') + g('r1610_close') - g('r1165_close'),
                   g('r1595_close') + g('r1600_close') + g('r1610_close') - g('r1165_close'))
d['sales'] = np.where(full, g('r2000') + g('r2010'), g('r2000'))
d['ebitda'] = np.where(full, g('r2190') - g('r2195') + g('r2515'), g('r2000') - g('r2050'))          # p.162(4) definitions
d['amort'] = ((g('r1012_close').abs() - g('r1012_open').abs()) + (g('r1002_close').abs() - g('r1002_open').abs())).clip(lower=0)
d['amort_used'] = np.where(full & (g('r2515') > 0), g('r2515'), d.amort)
d['op_res23'] = np.select([full, small, micro], [g('r2190') - g('r2195') + g('r2515'),                    # Res.23 p.2-9(7)
                                                 g('r2000') - g('r2050') + g('r2120') - g('r2180') + d.amort,
                                                 g('r2000') - g('r2050') + d.amort], np.nan)
d['finexp'] = np.where(full, d.r2250, np.nan)
d['bank_close'] = g('r1510_close') + g('r1600_close')
d['bank_open'] = g('r1510_open') + g('r1600_open')
d['borrower'] = (d.bank_close > 0) | (d.bank_open > 0)
d['nd_sales'] = np.where(d.sales > 0, d.nd / d.sales, np.nan)
d['nd_ebitda'] = np.where(d.ebitda > 0, d.nd / d.ebitda, np.nan)
d['icr'] = np.where(d.finexp > 0, d.op_res23 / d.finexp, np.nan)
RATE = {2020: .12, 2021: .107, 2022: .162, 2023: .198, 2024: .170, 2025: .163}   # NBU avg rate, new UAH loans to NFCs (<1y, 1-5y)
debt = np.where(full, g('r1510_close') + g('r1600_close') + g('r1610_close'), g('r1595_close') + g('r1600_close') + g('r1610_close'))
d['int_proxy'] = debt * d.year.map(RATE)
d['icr_rate'] = np.where(d.int_proxy > 0, d.op_res23 / d.int_proxy, np.nan)
d['s1'] = d.nd_sales > 2.5
d['s2'] = (d.ebitda <= 0) | (d.nd_ebitda > 5)
d['hcr'] = d.s1 & d.s2 & (d.sales > 0)
d['dflt23'] = full & (d.finexp > 0) & (d.icr < 1)
d['roa'] = d.net_result / d.r1300_open.where(d.r1300_open > 0)
d = C.score(d)
d.to_parquet(OUT, index=False)
print(d.groupby(['year', 'borrower']).class351.mean().round(2).unstack())
