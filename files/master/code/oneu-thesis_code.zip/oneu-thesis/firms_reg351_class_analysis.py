# -*- coding: utf-8 -*-
"""Borrower class (Reg. 351 Annex 7) during the war: distribution, migration, and next-year bank credit.
python firms_reg351_class_analysis.py data_nbu/firms/reg351_panel_v5.parquet output_nbu/section_3/tables"""
import pandas as pd, numpy as np, sys, os
from scipy.stats import norm
P, OUT = sys.argv[1:3]; os.makedirs(OUT, exist_ok=True)
d = pd.read_parquet(P)
d = d[d.class351.notna()].copy()
d['cls'] = d.class351.astype(int)
# 1. distribution
D = (d.groupby(['year', 'borrower']).cls.value_counts(normalize=True).rename('share').reset_index()
     .pivot_table(index=['year', 'borrower'], columns='cls', values='share').round(4))
D['mean_class'] = d.groupby(['year', 'borrower']).cls.mean().round(3)
D['n'] = d.groupby(['year', 'borrower']).size()
D.to_csv(f'{OUT}/S3_B18_class_distribution.csv')
print(D.to_string())
# 2. migration (same firm, consecutive years), borrowers at t
nx = d[['edrpou', 'year', 'cls', 'bank_close', 'r1300_close']].copy(); nx['year'] -= 1
m = d.merge(nx.rename(columns={'cls': 'cls_next', 'bank_close': 'bank_next', 'r1300_close': 'ta_next'}), on=['edrpou', 'year'], how='left')
M = []
for y in sorted(m.year.unique())[:-1]:
    s = m[(m.year == y) & m.borrower & m.cls_next.notna()]
    M.append(dict(from_year=y, to_year=y + 1, n=len(s), downgraded=(s.cls_next > s.cls).mean(), upgraded=(s.cls_next < s.cls).mean(),
                  down_2plus=(s.cls_next - s.cls >= 2).mean(), mean_change=(s.cls_next - s.cls).mean(),
                  to_class_7_9=((s.cls_next >= 7) & (s.cls <= 6)).mean()))
M = pd.DataFrame(M); M.to_csv(f'{OUT}/S3_B18_class_migration.csv', index=False); print(M.round(3).to_string())
TM = pd.crosstab(m[(m.year == 2021) & m.borrower].cls, m[(m.year == 2021) & m.borrower].cls_next, normalize='index').round(3)
TM.to_csv(f'{OUT}/S3_B18_transition_2021_2022.csv'); print(TM.to_string())
# 3. class and next-year bank credit (borrowers with bank debt at t, firm present at t+1)
s = m[(m.bank_close > 0) & m.ta_next.notna()].copy()
s['dlbank'] = np.log1p(s.bank_next.clip(lower=0)) - np.log1p(s.bank_close)
s['lost'] = (s.bank_next <= 0).astype(float)
s['lta'] = np.log(s.r1300_close); s['lbank'] = np.log1p(s.bank_close)
prev = d[['edrpou', 'year', 'cls']].copy(); prev['year'] += 1
s = s.merge(prev.rename(columns={'cls': 'cls_prev'}), on=['edrpou', 'year'], how='left')
s['downgrade'] = (s.cls > s.cls_prev).astype(float).where(s.cls_prev.notna())
s['dy'] = s['div'].fillna(-1).astype(int).astype(str) + '_' + s.year.astype(str)
for k in range(2, 10): s[f'c{k}'] = (s.cls == k).astype(float)
s['lev'] = (s.bank_close / s.r1300_close).clip(0, 3); s['roa_c'] = s.roa.clip(-1, 1).fillna(0); s['roa_miss'] = s.roa.isna().astype(float)
s['lsales'] = np.log1p(s.r2000.clip(lower=0).fillna(0))
s['war'] = (s.year == 2021).astype(float)     # class at end-2021 (pre-war statements) -> bank credit Dec 2021 -> Dec 2022
s['war_dn'] = (s.year == 2022).astype(float)  # downgrade in FY2022 statements -> bank credit during 2023


def demean(M, g, it=1):
    n = np.bincount(g)
    mu = np.vstack([np.bincount(g, M[:, j], minlength=len(n)) for j in range(M.shape[1])]).T / n[:, None]
    return M - mu[g]


def ols_fe(s, y, xs, fe='dy', cl='edrpou'):
    s = s.dropna(subset=[y] + xs)
    M = demean(np.column_stack([s[y].values] + [s[x].values for x in xs]).astype(float), pd.factorize(s[fe])[0])
    Y, X = M[:, 0], M[:, 1:]
    b = np.linalg.lstsq(X, Y, rcond=None)[0]; e = Y - X @ b
    c = pd.factorize(s[cl])[0]; XtXi = np.linalg.pinv(X.T @ X)
    S = np.vstack([np.bincount(c, X[:, j] * e) for j in range(X.shape[1])]).T
    V = XtXi @ (S.T @ S) @ XtXi * (c.max() + 1) / c.max()
    se = np.sqrt(np.diag(V))
    return pd.DataFrame(dict(term=xs, coef=b, se=se, p=2 * norm.sf(np.abs(b / se)), n=len(s), mean_y=s[y].mean()))


R = []
CL = [f'c{k}' for k in range(2, 10)]
for y in ['dlbank', 'lost']:
    r = ols_fe(s, y, CL + ['lta', 'lbank']); r['spec'] = f'{y}: class dummies (base class 1), division x year FE'; R.append(r)
    s2 = s.copy()
    for k in range(2, 10):
        s2[f'c{k}_y22'] = s2[f'c{k}'] * s2.war       # class at end-2021 -> credit during 2022
        s2[f'c{k}_y23'] = s2[f'c{k}'] * s2.war_dn    # class at end-2022 (war-year statements) -> credit during 2023
    r = ols_fe(s2, y, CL + [f'c{k}_y22' for k in range(2, 10)] + [f'c{k}_y23' for k in range(2, 10)] + ['lta', 'lbank'])
    r['spec'] = f'{y}: class x credit year (base: credit in 2024-2025)'; R.append(r)
    r = ols_fe(s2, y, CL + [f'c{k}_y22' for k in range(2, 10)] + [f'c{k}_y23' for k in range(2, 10)] + ['lta', 'lbank', 'lev', 'roa_c', 'roa_miss', 'lsales'])
    r['spec'] = f'{y}: class x credit year + leverage, ROA, sales'; R.append(r)
    s4 = s.copy(); s4['oth'] = 1.0 - s4.war - s4.war_dn
    PX = []
    for k in range(2, 10):
        for nm, ind in (('p22', 'war'), ('p23', 'war_dn'), ('p2425', 'oth')):
            s4[f'c{k}_{nm}'] = s4[f'c{k}'] * s4[ind]; PX.append(f'c{k}_{nm}')
    for ctr, lab in ((['lta', 'lbank'], ''), (['lta', 'lbank', 'lev', 'roa_c', 'roa_miss', 'lsales'], ' + leverage, ROA, sales')):
        r = ols_fe(s4, y, PX + ctr); r['spec'] = f'{y}: class by credit period (totals){lab}'; R.append(r)
    r = ols_fe(s, y, ['downgrade', 'lta', 'lbank']); r['spec'] = f'{y}: downgraded this year'; R.append(r)
    s3 = s.assign(down_war=s.downgrade * s.war_dn)
    r = ols_fe(s3, y, ['downgrade', 'down_war', 'lta', 'lbank']); r['spec'] = f'{y}: downgrade in FY2022 statements (credit in 2023)'; R.append(r)
    r = ols_fe(s, y, ['hcr', 'lta', 'lbank']); r['spec'] = f'{y}: p.162(4) sign'; R.append(r)
R = pd.concat(R, ignore_index=True); R.to_csv(f'{OUT}/S3_B18_class_credit.csv', index=False)
print(R[~R.term.isin(['lta', 'lbank'])].round(4).to_string())
