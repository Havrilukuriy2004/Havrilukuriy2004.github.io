# ============================================================================
# 19_borrower_class_tool_v6.R: Excel класу позичальника (Положення НБУ № 351) і кредитного ризику: викликає 19_borrower_class_tool.py
# ----------------------------------------------------------------------------
# Даних розділів не потребує (CSV підприємств підключається в самому файлі; вибірка: 19_extract_firms.py). Python 3 з openpyxl, pandas.
# Результат: output_nbu/bank_excel/Borrower_Class_Credit_Risk_Tool.xlsx і Borrower_Class_Credit_Risk_Tool_EN.xlsx (формули перераховуються при відкритті).
# ============================================================================
`%||%` <- function(a, b) if (is.null(a)) b else a
.this_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL) %||%
  Sys.getenv("THESIS_CODE_DIR", unset = getwd())
source(file.path(.this_dir, "00_config_v6.R"), encoding = "UTF-8")
run_thesis_python(file.path(PROJECT_DIR, "19_borrower_class_tool.py"), OUTPUT_DIR)
