# ============================================================================
# run_all_v6.R — ONE entry point: update the database, then rebuild, then models
# ----------------------------------------------------------------------------
# Layers (models never download anything):
#   1) DATABASE   01_nbu_download_v6.R   NBU API -> data_nbu/parquet/raw_*   (incremental, needs internet)
#                 01b_check_db_v6.R       health check of raw_* + local_inputs (offline)
#   2) MARTS      02_build_marts_v6.R    raw_* + local_inputs -> mart_* , macro_monthly_v6 (offline)
#   3) MODELS     03–07                  read ONLY mart_* / macro_monthly_v6 (offline); 06 = показники динаміки; 07 = підрозділ 2.2; 09 = очікування агентів, повна статистика ставок, грошова статистика; 10 = 2.3 виявлений розрив переоцінки; 11 = 2.4 тіньова вартість фондування; 08 = таблиці для тексту (Word); 12 = динамічний Excel по банках
#   4) ORIGIN     every figure also goes to output_nbu/origin/ -> origin_build_figures.py (inside Origin)
#
# Fresh start (default now): the NBU database is downloaded again from scratch, local_inputs are kept,
#   all sections are recomputed, every figure/table is produced in Ukrainian (figures/, tables/, *.xlsx)
#   and English (figures_en/, tables_en/, *_EN.xlsx, *_EN.docx); bundles: output_nbu/Results_UA.zip, Results_EN.zip.
#   Later monthly runs: Sys.setenv(THESIS_RESET_DB = "false") before sourcing.
# Monthly routine: replace UIRD.xls and 5-7-9.xlsx in data_nbu/local_inputs, then
#   source("run_all_v6.R", encoding = "UTF-8")
# After a code fix in 02 (like the MIR k140 fix) no download is needed:
#   set UPDATE_DB <- FALSE and run.
# ============================================================================
RESET_DB   <- !identical(Sys.getenv("THESIS_RESET_DB", "true"), "false")  # TRUE: the NBU database is downloaded again FROM SCRATCH (data_nbu/parquet + data_nbu/raw are moved to data_nbu/_archive/db_<time>; data_nbu/local_inputs stay as they are). After one successful run set Sys.setenv(THESIS_RESET_DB = "false") or change to FALSE.
UPDATE_DB  <- RESET_DB || identical(Sys.getenv("THESIS_UPDATE_DB", "false"), "true")    # 01: pull new data from NBU (last 3 months + new months) AND fill holes inside series (e.g. MIR 2023-03…2024-05)
FILL_GAPS  <- FALSE   # 01c: ONLY fill holes inside series (quick; use when UPDATE_DB = FALSE)
CHECK_DB   <- TRUE    # 01b: database health check -> output_nbu/logs/db_check_v6.csv
BUILD      <- TRUE    # 02: rebuild marts (always after UPDATE_DB or any change in local_inputs)
MODELS     <- c("03", "04", "05", "06", "07", "09", "10", "14", "11", "16", "08", "12", "13", "18", "19")   # character(0) = none; 09 = очікування і гроші; 10 = 2.3; 11 = 2.4; 08 = таблиці Word; 12 = динамічний Excel
STEPS_ONLY <- trimws(strsplit(Sys.getenv("THESIS_STEPS", ""), ",")[[1]])   # e.g. THESIS_STEPS=10,14,11 reruns only these steps on the existing database
if (length(STEPS_ONLY) && !"01" %in% STEPS_ONLY) { RESET_DB <- FALSE; UPDATE_DB <- FALSE }

`%||%` <- function(a, b) if (is.null(a)) b else a
.root <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL) %||%
  Sys.getenv("THESIS_CODE_DIR", unset = getwd())
if (!length(.root) || !nzchar(.root[1])) .root <- Sys.getenv("THESIS_CODE_DIR", unset = getwd())
Sys.setenv(THESIS_CODE_DIR = .root)
source(file.path(.root, "00_config_v6.R"), encoding = "UTF-8")
source(file.path(.root, "utils_i18n_v7.R"), encoding = "UTF-8")      # Ukrainian + English figures/tables

# ------------------------------ fresh database ---------------------------------
# Moves the whole downloaded store (raw_*, stg_*, mart_*, macro_*, API cache, capital parse) to an archive folder.
# local_inputs are never touched. If download or rebuild fails, the archive is moved back automatically.
DB_ARCHIVE <- NULL
reset_database <- function() {
  arch <- file.path(DATA_DIR, "_archive", format(Sys.time(), "db_%Y%m%d_%H%M%S"))
  moved <- 0L
  for (d in c(PARQUET_DIR, RAW_DIR)) {
    fs <- list.files(d, all.files = TRUE, no.. = TRUE, full.names = TRUE); if (!length(fs)) next
    dest <- file.path(arch, basename(d)); dir.create(dest, recursive = TRUE, showWarnings = FALSE)
    for (f in fs) { ok <- suppressWarnings(file.rename(f, file.path(dest, basename(f))))
      if (!ok) { ok <- file.copy(f, dest, recursive = TRUE, overwrite = TRUE) && unlink(f, recursive = TRUE) == 0 }
      if (!ok) stop("Cannot move ", f, " — close programs that use the database (Excel, Python, Power BI) and rerun.")
      moved <- moved + 1L }
  }
  cap_manifest <- file.path(OUTPUT_DIR, "capital", "tables", "capital_manifest.json"); if (file.exists(cap_manifest)) unlink(cap_manifest)
  log_msg("RESET_DB: ", moved, " files moved to ", arch, "; local_inputs kept (", length(list.files(LOCAL_DIR)), " files)")
  arch
}
restore_database <- function(arch) {
  if (is.null(arch) || !dir.exists(arch)) return(invisible(FALSE))
  for (d in c(PARQUET_DIR, RAW_DIR)) {
    src <- file.path(arch, basename(d)); if (!dir.exists(src)) next
    unlink(list.files(d, all.files = TRUE, no.. = TRUE, full.names = TRUE), recursive = TRUE)
    for (f in list.files(src, all.files = TRUE, no.. = TRUE, full.names = TRUE)) file.rename(f, file.path(d, basename(f)))
  }
  unlink(arch, recursive = TRUE)
  log_msg("RESET_DB: previous database restored from ", arch)
  invisible(TRUE)
}
if (RESET_DB) DB_ARCHIVE <- reset_database()
ensure_capital_inputs()
SCRIPTS <- c("01" = "01_nbu_download_v6.R", "01c" = "01c_fill_gaps_v6.R", "01b" = "01b_check_db_v6.R", "02" = "02_build_marts_v6.R",
             "03" = "03_section_2_1_analysis_v2.R", "04" = "04_section_2_1_deposit_dynamics.R", "05" = "05_section_2_1_assets_joint.R",
             "06" = "06_dynamics_v6.R", "07" = "07_section_2_2_transmission.R", "09" = "09_expectations_money_v6.R",
             "10" = "10_section_2_3_repricing_gap_v6.R", "11" = "11_section_2_4_shadow_cost_v6.R", "08" = "08_thesis_tables_v6.R", "12" = "12_bank_excel_v6.R", "13" = "13_irrbb_stress_test_v6.R", "14" = "14_ou_deposit_dynamics_v6.R", "16" = "16_section_3_allocation_v6.R", "18" = "18_bank_assets_tool_v6.R", "19" = "19_borrower_class_tool_v6.R")
run_step <- function(id) {
  f <- file.path(.root, SCRIPTS[[id]]); t0 <- Sys.time()
  message(sprintf("\n========== %s  %s ==========", id, SCRIPTS[[id]]))
  ok <- tryCatch({ source(f, encoding = "UTF-8", local = new.env());
    if (exists("STATUS", envir = .GlobalEnv) && any(get("STATUS", envir = .GlobalEnv)$status == "error")) stop("Model block failed; see status tables")
    TRUE },
                 error = function(e) { message("ПОМИЛКА у ", SCRIPTS[[id]], ": ", conditionMessage(e)); FALSE })
  message(sprintf("---------- %s: %s за %.1f хв", id, if (ok) "готово" else "ЗУПИНЕНО", as.numeric(difftime(Sys.time(), t0, units = "mins"))))
  ok
}
plan <- c(if (UPDATE_DB) "01", if (!UPDATE_DB && FILL_GAPS) "01c", if (CHECK_DB) "01b", if (BUILD) "02", MODELS)
if (length(STEPS_ONLY)) plan <- STEPS_ONLY
done <- character()
for (id in plan) {
  ok <- run_step(id); done <- c(done, setNames(if (ok) "ok" else "error", id))
  if (!ok) {
    message("Наступні кроки пропущено: вони залежать від ", id)
    if (RESET_DB && id %in% c("01", "01b", "02")) { message("Нову базу не сформовано — повертаю попередню базу з архіву."); restore_database(DB_ARCHIVE) }
    break }
}
print(done)

# English copies of every table, workbook and Word table + bundles Results_UA.zip / Results_EN.zip
if ("en" %in% I18N_LANGS) tryCatch(i18n_export_all(), error = function(e) message("Англійські таблиці не сформовано: ", conditionMessage(e)))
if (any(done == "error")) stop("Pipeline failed; inspect the step log. Existing outputs may be stale.")
if (identical(Sys.getenv("THESIS_REVIEW", "true"), "true")) {
  run_thesis_python(file.path(.root, "15_robustness_review.py"), .root)
}
