# ============================================================================
# 18_bank_assets_tool_v6.R: динамічний Excel розподілу активів банку (розділ 3): викликає 18_bank_assets_tool.py
# ----------------------------------------------------------------------------
# Потрібні результати 16_ (output_nbu/section_3) і 07_ (section_2_2), вітрина data_nbu/parquet/mart_bank_assets_v6.parquet; Python 3 з openpyxl, pandas, pyarrow.
# Результат: output_nbu/bank_excel/Bank_Assets_Tool.xlsx і Bank_Assets_Tool_EN.xlsx (формули перераховуються при відкритті).
# ============================================================================
`%||%` <- function(a, b) if (is.null(a)) b else a
.this_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL) %||%
  Sys.getenv("THESIS_CODE_DIR", unset = getwd())
source(file.path(.this_dir, "00_config_v6.R"), encoding = "UTF-8")
run_thesis_python(file.path(PROJECT_DIR, "18_bank_assets_tool.py"), OUTPUT_DIR)
