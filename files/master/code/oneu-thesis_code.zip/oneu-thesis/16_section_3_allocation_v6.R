# ============================================================================
# 16_section_3_allocation_v6.R — РОЗДІЛ 3. Відносна дохідність активів та розподіл банківських ресурсів
# ----------------------------------------------------------------------------
# Reads ONLY marts (02) and, if present, tables of 2.4 (11). Offline. Output: output_nbu/section_3/
#   tables/S3_*.csv, Section_3.xlsx, S3_facts.csv, S3_status.csv, S3_run_log.json
# Run:  source("16_section_3_allocation_v6.R", encoding = "UTF-8")      (≈ 5–15 хв; S3_NBOOT задає бутстреп, типово 300)
#
# 3.1  Ризик-скоригована дохідність кредитування та альтернативна вартість ліквідності
#   A1 структура розподільного портфеля: система, групи, концентрація, гривня/валюта
#   A2 книжкова дохідність, вартість ризику, RAR, маржа ДС, відносна дохідність RR: система, фази, групи, розподіл, чутливість
#   A3 ринкова премія нових кредитів до ДС, кривої ОВДП (NSS), UIRD; нахил кривої
#   A4 розклад зміни RR між фазами; ефект ставки та ефект структури в дохідності активів
#   A5 сегменти: бізнес / населення, гривня / валюта
#   A6 економічна вартість ресурсу (2.4): чи покривають кредити бар'єрну ставку SFC
#   A7 передача облікової ставки за банками (ECM, асиметрія) і модельна траєкторія RR після шоку ставки
#   A8 стійкість позицій банків: матриця переходів між квартилями RR
# 3.2  Детермінанти розподілу активів
#   B1 дробова мультиноміальна логіт-модель (QMLE, Мундлак), кластерний бутстреп   B2 неоднорідність
#   B3 фіксовані ефекти: зміна часток за 12 міс.; поріг капіталу                    B4 часткове коригування
#   B5 локальні проєкції з взаємодіями; асиметрія підвищень і знижень               B6 подієве дослідження ДС 3М (04.2023)
#   B7 граничне використання приросту депозитів                                     B8 позавибіркова перевірка
#   B9 типологія бізнес-моделей (k-середніх)
#   B10 попит і пропозиція кредиту (опитування банків BLS): чинники стандартів; модель (3.6) з попитом, специфічним для банку; панель «банк × сегмент» з ефектами «сегмент × місяць»
#   B11–B15 надійність, галузі, МСФЗ 9;  B16 шоки пропозиції кредиту банків (Аміті–Вайнштейн) і реальні наслідки для фірм (фінзвітність Держстату)
# 3.3  Контрфактичний аналіз ALM рішень
#   C1 сценарії + проєкція на обмеження капіталу та LCR (quadprog) + інтервали      C2 динамічні траєкторії; сітка коридору ставок
#   C3 кредитна спроможність: капітал, LCR, втрати, буфери 2027                     C4 ROE, внутрішнє нагромадження капіталу, дивіденди
#   C5 розклад Шеплі змін частки кредитів 2022–2026                                 C6 ефективна межа «маржа – ризик», відстань банків до межі
# D1–D9 поглиблений аналіз: сортування за фондуванням, джерела відмінностей, стійкість оцінок, горизонти використання депозитів, проєкція спроможності
# F    24 рисунки у figures/ (стиль проєкту через save_fig)
# ============================================================================
`%||%` <- function(a, b) if (is.null(a)) b else a
.this_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL) %||%
  Sys.getenv("THESIS_CODE_DIR", unset = getwd())
source(file.path(.this_dir, "00_config_v6.R"), encoding = "UTF-8")
source(file.path(PROJECT_DIR, "utils_models_v6.R"), encoding = "UTF-8")
# clean-up after an earlier interrupted run of a previous version of this script (it left `sub`/`pt` in the global environment)
for (.nm in c("sub", "pt", "path", "run", "seg", "ols", "eff", "es", "pick", "shap", "perms", "mk1", "mk2")) if (exists(.nm, envir = globalenv(), inherits = FALSE) && is.function(get(.nm, envir = globalenv()))) rm(list = .nm, envir = globalenv())
.need(c("quadprog"))
init_output("S3", folder = "section_3")
CAP <- "Джерело: розрахунки автора за даними НБУ."
set.seed(20261110)
NBOOT <- as.integer(Sys.getenv("S3_NBOOT", "300"))
# blocks run in their own environment, so helper names inside a block (sub, pt, path ...) can never mask base functions in the session
blk <- function(name, expr) { t0 <- Sys.time(); message("  [", name, "] ..."); ex <- substitute(expr); pf <- parent.frame()
  ok <- tryCatch({ eval(ex, new.env(parent = pf)); TRUE }, error = function(e) { status(name, "error", conditionMessage(e)); message("  [", name, "] ПОМИЛКА: ", conditionMessage(e)); FALSE })
  if (ok) status(name, "ok", sprintf("%.1f с", as.numeric(difftime(Sys.time(), t0, units = "secs")))) }
t0_all <- Sys.time()

PAR <- list(equity_premium = 0.10,   # премія власного капіталу над вартістю депозитів
            rw_loan = 1.00, rw_other = 0.20, h_other = 0.50,   # ризикові ваги; частка інших ліквідних активів у HQLA
            pass12 = 0.42,           # 12-місячна передача облікової ставки у книжкову дохідність і вартість депозитів (2.2)
            buf_cons = 0.025, buf_sys = 0.015, k_base_2027 = 0.08)
PHASES <- data.table(from = as.Date(c("2018-01-01", "2019-04-01", "2021-03-01", "2022-03-01", "2023-07-01", "2024-12-01")),
                     to   = as.Date(c("2019-03-31", "2021-02-28", "2022-02-28", "2023-06-30", "2024-11-30", "2099-12-31")),
                     phase = c("1. Жорстка політика 2018–2019", "2. Пом'якшення 2019–2021", "3. Посилення 2021–2022",
                               "4. Воєнний шок, ставка 25%", "5. Пом'якшення 2023–2024", "6. Посилення 2025–2026"))
phase_of <- function(m) { out <- rep(NA_character_, length(m)); for (i in seq_len(nrow(PHASES))) out[m >= PHASES$from[i] & m <= PHASES$to[i]] <- PHASES$phase[i]; out }

# ------------------------------ helpers ----------------------------------------
f0 <- function(x) fifelse(is.finite(x), x, 0)
col0 <- function(dt, v) if (v %in% names(dt)) f0(as.numeric(dt[[v]])) else rep(0, nrow(dt))
coln <- function(dt, v) if (v %in% names(dt)) as.numeric(dt[[v]]) else rep(NA_real_, nrow(dt))
pct1 <- function(x) { x <- as.numeric(x); if (all(is.na(x))) return(x); if (max(abs(x), na.rm = TRUE) > 1.5) x / 100 else x }
wmean <- function(x, w) { ok <- is.finite(x) & is.finite(w) & w > 0; if (!any(ok)) NA_real_ else sum(x[ok] * w[ok]) / sum(w[ok]) }
winsor <- function(x, lo = .01, hi = .99) { q <- quantile(x, c(lo, hi), na.rm = TRUE); pmin(pmax(x, q[1]), q[2]) }
roll_sum <- function(x, n = 12L, minp = 6L, mean = FALSE, annualise = FALSE) {   # trailing window, NA-tolerant
  ok <- is.finite(x); cs <- cumsum(ifelse(ok, x, 0)); cn <- cumsum(ok); L <- length(x)
  lag <- function(v) c(rep(0, min(n, L)), v[seq_len(max(L - n, 0))])
  s <- cs - lag(cs); k <- cn - lag(cn); s[k < minp] <- NA_real_
  if (mean) return(s / k); if (annualise) return(s * 12 / k); s }
stars <- function(p) fifelse(!is.finite(p), "", fifelse(p < .01, "***", fifelse(p < .05, "**", fifelse(p < .10, "*", ""))))

add_lead <- function(dt, v, h, name) {   # value h months ahead with exact month matching (unbalanced panels)
  key <- dt[, .(nkb, mkey = as.integer(format(month, "%Y")) * 12L + as.integer(format(month, "%m")), val = get(v))]
  cur <- dt[, .(nkb, mkey = as.integer(format(month, "%Y")) * 12L + as.integer(format(month, "%m")) + h)]
  set(dt, j = name, value = key[cur, on = .(nkb, mkey), val]); invisible(dt) }
pinv <- function(A) { e <- eigen((A + t(A)) / 2, symmetric = TRUE); ok <- e$values > max(e$values) * 1e-10; e$vectors[, ok, drop = FALSE] %*% (t(e$vectors[, ok, drop = FALSE]) / e$values[ok]) }
# two-way within transformation (alternating projections) and cluster-robust OLS
twoway_demean <- function(M, gi, gt, iters = 100L, tol = 1e-9) {
  for (it in seq_len(iters)) { M0 <- M
    for (k in seq_len(ncol(M))) { M[, k] <- M[, k] - ave(M[, k], gi); M[, k] <- M[, k] - ave(M[, k], gt) }
    if (max(abs(M - M0)) < tol) break }
  M }
ols_cluster <- function(y, X, g) {
  XtXi <- pinv(crossprod(X))
  b <- drop(XtXi %*% crossprod(X, y)); u <- drop(y - X %*% b)
  S <- matrix(0, ncol(X), ncol(X)); for (s in split(seq_along(y), g)) { v <- crossprod(X[s, , drop = FALSE], u[s]); S <- S + tcrossprod(v) }
  G <- length(unique(g)); n <- nrow(X); k <- ncol(X)
  V <- G / (G - 1) * (n - 1) / max(n - k, 1) * XtXi %*% S %*% XtXi
  se <- sqrt(pmax(diag(V), 0)); list(b = b, se = se, p = 2 * pt(-abs(b / se), G - 1), n = n, G = G, r2 = 1 - sum(u^2) / sum((y - mean(y))^2)) }
fe_reg <- function(dt, y, xs, i = "nkb", t = "month") {
  d <- dt[, c(i, t, y, xs), with = FALSE]; d <- d[stats::complete.cases(d) & Reduce(`&`, lapply(d[, c(y, xs), with = FALSE], is.finite))]
  M <- twoway_demean(as.matrix(d[, c(y, xs), with = FALSE]), d[[i]], as.character(d[[t]]))
  r <- ols_cluster(M[, 1], M[, -1, drop = FALSE], d[[i]])
  data.table(var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G, r2_within = r$r2) }

# =============================== P0. panel =====================================
a  <- store_read("mart_bank_assets_v6"); m <- store_read("mart_bank_month_v6"); pr <- store_read("mart_bank_prudential_v7"); mac <- store_read("macro_monthly_v6")
for (x in list(a, m, pr, mac)) x[, month := as.Date(month)]
for (x in list(a, m, pr)) x[, nkb := as.character(nkb)]
keep_m <- intersect(c("month", "nkb", "fullname", "fx_share", "dep_hh_term_uah", "dep_core4_uah", "dep_core4_total", "ovdp_uah", "ovdp_fx", "cd_nbu_uah",
                      "loans_corp_all_uah", "loans_corp_all_fx", "loans_hh_all_uah", "loans_hh_all_fx", "avg_loans_corp_all_uah", "avg_loans_corp_all_fx",
                      "avg_loans_hh_all_uah", "avg_loans_hh_all_fx", "y_loans_corp_uah", "y_loans_corp_fx", "y_loans_hh_uah", "y_loans_hh_fx",
                      "r_hh_term_uah", "r_hh_demand_uah", "r_corp_term_uah", "r_corp_demand_uah", "avg_dep_hh_term_uah", "avg_dep_hh_demand_uah",
                      "avg_dep_corp_term_uah", "avg_dep_corp_demand_uah", "fin_profit_m", "fin_equity"), names(m))
keep_m <- c("month", "nkb", setdiff(keep_m, c("month", "nkb", setdiff(names(a), c("month", "nkb")))))
d <- merge(a, m[, ..keep_m], by = c("month", "nkb"), all.x = TRUE)
keep_p <- intersect(c("month", "nkb", "total_ratio_pct", "tier1_ratio_pct", "lcr_all_pct", "nsfr_pct", "leverage_pct", "headroom_total_min_pp", "headroom_tier1_min_pp", "headroom_cet1_min_pp", "credit_rwa_mn",
                      "reg_capital_mn", "minimum_total_pct", "systemic_flag", "risk_exposure_implied_mn"), names(pr))
d <- merge(d, pr[, ..keep_p], by = c("month", "nkb"), all.x = TRUE)
mk <- mac[, .(month, pol = pct1(policy_avg), cd_on = pct1(cd_on_rate_avg))]
d <- merge(d, mk, by = "month", all.x = TRUE); setorder(d, nkb, month)
# loans_le / loans_hh у вітрині вже чисті (за вирахуванням резервів): резерви prov_* наведені довідково і вдруге не віднімаються
d[, `:=`(A_L = pmax(col0(d, "loans_le") + col0(d, "loans_hh"), 0), A_B = col0(d, "ovdp_osb"), A_S = col0(d, "cd_osb"),
         A_O = pmax(col0(d, "other_banks") + col0(d, "due_nbu") + col0(d, "sec_other"), 0))]
d[, P := A_L + A_B + A_S + A_O]; d <- d[P > 0]
for (k in c("L", "B", "S", "O")) set(d, j = paste0("s_", k), value = d[[paste0("A_", k)]] / d$P)
# До 2021 р. дохід за цінними паперами у фінансовій звітності входив до рядка процентних доходів від юридичних осіб, тому до січня 2021 р. дохід за кредитами
# обчислюється як загальний процентний дохід за вирахуванням доходу за ОВДП і сертифікатами НБУ; із 2021 р. – прямо, як сума доходів від юридичних і фізичних осіб.
FINREP_BREAK <- as.Date("2021-01-01")
d[, ii_loans_m := fifelse(month < FINREP_BREAK, pmax(col0(.SD, "ii_m") - col0(.SD, "inc_refin") - col0(.SD, "inc_cd"), 0), col0(.SD, "ii_le_m") + col0(.SD, "ii_hh_m"))]
d[, `:=`(y_L = roll_sum(ii_loans_m, annualise = TRUE) / roll_sum(avg_loans_all, mean = TRUE),
         y_B = roll_sum(inc_refin, annualise = TRUE) / roll_sum(avg_ovdp_osb, mean = TRUE),
         y_S = roll_sum(inc_cd, annualise = TRUE) / roll_sum(avg_cd_osb, mean = TRUE),
         cc  = roll_sum(alloc_prov_m, annualise = TRUE) / roll_sum(avg_loans_all, mean = TRUE),
         cod = roll_sum(cod4_total, mean = TRUE), y_S_sys12 = roll_sum(cd_on, mean = TRUE)), by = nkb]
d[!is.finite(y_L) | f0(avg_loans_all) < 50 | s_L < .01 | y_L < 0 | y_L > .8, y_L := NA_real_]; d[is.na(y_L) | !is.finite(cc) | cc < -.25 | cc > .6, cc := NA_real_]
d[!is.finite(y_B) | f0(avg_ovdp_osb) < 20 | y_B < 0 | y_B > .5, y_B := NA_real_]; d[!is.finite(y_S) | f0(avg_cd_osb) < 20 | y_S < 0 | y_S > .5, y_S := NA_real_]
d[, kreq := fifelse(is.finite(minimum_total_pct), minimum_total_pct, 10) / 100]
d[, cap_charge := kreq * PAR$rw_loan * PAR$equity_premium]
d[, y_S_alt := fifelse(is.finite(y_S), y_S, y_S_sys12)]
d[, `:=`(rar_L = y_L - cc - cod - cap_charge, m_S = y_S - cod, m_B = y_B - cod, rr_LS = y_L - cc - cap_charge - y_S_alt, rr_BS = y_B - y_S_alt)]
d[, `:=`(head = pmin(pmax(headroom_total_min_pp, -5), 50) / 100, ln_lcr = log(pmin(pmax(lcr_all_pct, 50), 2000) / 100), ln_assets = log(fifelse(assets > 0, assets, NA_real_)),
         phase = phase_of(month), owner_ua = c(State = "Державні", Foreign = "Іноземні", Private = "Приватні")[owner])]
LAST <- max(d[is.finite(rr_LS), .N, by = month][N >= 20, month])
fact("panel_rows", nrow(d)); fact("panel_banks", uniqueN(d$nkb)); fact("last_month", as.character(LAST)); fact("first_month", as.character(min(d$month)))
D0 <- d[month >= as.Date("2018-12-01")]

# =============================== 3.1 ===========================================
sys_row <- function(g) { x <- g[is.finite(rr_LS)]
  list(y_L = wmean(g$y_L, g$A_L), cc = wmean(g$cc, g$A_L), cap_charge = wmean(g$cap_charge, g$A_L), cod = wmean(g$cod, g$P), y_S = wmean(g$y_S, g$A_S), y_B = wmean(g$y_B, g$A_B),
       rar_L = wmean(g$rar_L, g$A_L), m_S = wmean(g$y_S, g$A_S) - wmean(g$cod, g$P), m_B = wmean(g$y_B, g$A_B) - wmean(g$cod, g$P),
       rr_LS = wmean(g$rr_LS, g$A_L), rr_BS = wmean(g$rr_BS, g$A_B), share_neg = if (nrow(x)) mean(x$rr_LS < 0) else NA_real_,
       share_neg_w = if (nrow(x)) sum(x$A_L[x$rr_LS < 0]) / sum(x$A_L) else NA_real_,
       s_L = sum(g$A_L) / sum(g$P), s_B = sum(g$A_B) / sum(g$P), s_S = sum(g$A_S) / sum(g$P), s_O = sum(g$A_O) / sum(g$P),
       q25 = if (nrow(x)) quantile(x$rr_LS, .25) else NA_real_, q50 = if (nrow(x)) median(x$rr_LS) else NA_real_, q75 = if (nrow(x)) quantile(x$rr_LS, .75) else NA_real_,
       n = nrow(x), P_bn = sum(g$P) / 1e3) }

blk("A1 структура портфеля", {
  st <- D0[, .(s_L = sum(A_L) / sum(P), s_B = sum(A_B) / sum(P), s_S = sum(A_S) / sum(P), s_O = sum(A_O) / sum(P), P_bn = sum(P) / 1e3, banks = .N,
               hhi_L = sum((A_L / sum(A_L))^2), hhi_B = sum((A_B / sum(A_B))^2), hhi_S = sum((A_S / sum(A_S))^2),
               top5_L = sum(sort(A_L, decreasing = TRUE)[1:5]) / sum(A_L), top5_B = sum(sort(A_B, decreasing = TRUE)[1:5]) / sum(A_B), top5_S = sum(sort(A_S, decreasing = TRUE)[1:5]) / sum(A_S),
               loans_fx_share = sum(col0(.SD, "loans_corp_all_fx") + col0(.SD, "loans_hh_all_fx")) / sum(col0(.SD, "loans_corp_all_fx") + col0(.SD, "loans_hh_all_fx") + col0(.SD, "loans_corp_all_uah") + col0(.SD, "loans_hh_all_uah")),
               ovdp_fx_share = sum(col0(.SD, "ovdp_fx")) / sum(col0(.SD, "ovdp_fx") + col0(.SD, "ovdp_uah")),
               loans_hh_share = sum(col0(.SD, "loans_hh")) / sum(col0(.SD, "loans_hh") + col0(.SD, "loans_le"))), by = month]
  save_tab(st, "S3_A1_structure_monthly.csv", "A1_structure_m")
  save_tab(D0[, .(s_L = sum(A_L) / sum(P), s_B = sum(A_B) / sum(P), s_S = sum(A_S) / sum(P), s_O = sum(A_O) / sum(P), P_bn = sum(P) / 1e3), by = .(month, owner_ua)][order(owner_ua, month)],
           "S3_A1_structure_owner_monthly.csv", "A1_structure_owner")
  stp <- D0[, .(s_L = sum(A_L) / sum(P), s_B = sum(A_B) / sum(P), s_S = sum(A_S) / sum(P), s_O = sum(A_O) / sum(P)), by = .(phase, month)][, lapply(.SD, mean), by = phase, .SDcols = c("s_L", "s_B", "s_S", "s_O")]
  save_tab(stp[order(phase)], "S3_A1_structure_phases.csv", "A1_structure_ph")
  x <- d[month == LAST]
  save_tab(x[, .(banks = .N, zero_loans = sum(s_L < .05), zero_cd = sum(s_S < .01), zero_ovdp = sum(s_B < .01), cd_above_30 = sum(s_S > .3), ovdp_above_30 = sum(s_B > .3), loans_above_50 = sum(s_L > .5),
                 med_s_L = median(s_L), med_s_B = median(s_B), med_s_S = median(s_S)), by = owner_ua], "S3_A1_structure_cross_latest.csv", "A1_cross")
})

blk("A2 дохідність і відносна дохідність", {
  sm <<- D0[, sys_row(.SD), by = month][order(month)]; sm[, phase := phase_of(month)]
  save_tab(sm, "S3_A2_system_monthly.csv", "A2_system_m")
  cols <- c("y_L", "cc", "cap_charge", "cod", "rar_L", "y_S", "m_S", "y_B", "m_B", "rr_LS", "rr_BS", "share_neg", "s_L", "s_B", "s_S", "s_O")
  save_tab(sm[, lapply(.SD, mean, na.rm = TRUE), by = phase, .SDcols = cols][order(phase)], "S3_A2_phases.csv", "A2_phases")
  lat <<- d[month == LAST]
  own <- rbind(lat[, c(sys_row(.SD), list(n_banks = .N)), by = owner_ua], cbind(owner_ua = "Система", as.data.table(c(sys_row(lat), list(n_banks = nrow(lat))))), fill = TRUE)
  save_tab(own, "S3_A2_owner_latest.csv", "A2_owner")
  lat[, cc_breakeven := y_L - cap_charge - y_S_alt]
  qs <- c(.1, .25, .5, .75, .9)
  save_tab(data.table(quantile = qs, sapply(c("y_L", "cc", "rr_LS", "cc_breakeven", "rr_BS", "m_S", "rar_L"), function(v) quantile(lat[[v]], qs, na.rm = TRUE))), "S3_A2_distribution_latest.csv", "A2_dist")
  save_tab(lat[, .(nkb, fullname, owner_ua, P, s_L, s_B, s_S, s_O, y_L, cc, cap_charge, cod, y_S, y_B, rar_L, m_S, rr_LS, rr_BS, cc_breakeven, total_ratio_pct, headroom_total_min_pp, lcr_all_pct, nsfr_pct)][order(-P)],
           "S3_A2_banks_latest.csv", "A2_banks")
  save_tab(rbindlist(lapply(c(.05, .10, .15, .20), function(pm) { rr <- lat$y_L - lat$cc - lat$kreq * PAR$rw_loan * pm - lat$y_S_alt; ok <- is.finite(rr)
    data.table(equity_premium = pm, rr_LS_system = wmean(rr, lat$A_L), rr_LS_median = median(rr[ok]), share_neg = mean(rr[ok] < 0), share_neg_w = sum(lat$A_L[ok & rr < 0]) / sum(lat$A_L[ok])) })),
    "S3_A2_equity_premium_sensitivity.csv", "A2_sens")
  fact("rr_LS_system_latest", round(100 * wmean(lat$rr_LS, lat$A_L), 2), "в. п."); fact("share_neg_latest", round(100 * mean(lat$rr_LS < 0, na.rm = TRUE), 1), "%")
})

blk("A3 ринкова премія нових кредитів", {
  v <- function(n) if (n %in% names(mac)) pct1(mac[[n]]) else rep(NA_real_, nrow(mac))
  mp <- data.table(month = mac$month, loan_nfc = v("fm_loan_nfc_uah"), loan_nfc_1y = v("fm_loan_nfc_uah_1y"), loan_hh = v("fm_loan_hh_uah"), dep_hh = v("fm_dep_hh_uah"), dep_nfc = v("fm_dep_nfc_uah"),
                   ovdp_prim = v("fm_ovdp_prim"), cd = v("cd_on_rate_avg"), pol = v("policy_avg"), zc1 = v("zc_uah_1y_avg"), zc3 = v("zc_uah_3y_avg"), zc10 = v("zc_uah_10y_avg"),
                   uird3 = v("uird_uah_3m_avg"), uonia = v("uonia_avg"), pie = v("pie_banks"), cpi = v("cpi_yoy"))[month >= as.Date("2018-01-01") & month <= LAST]
  mp[, `:=`(prem_nfc_cd = loan_nfc - cd, prem_nfc_zc1 = fcoalesce(loan_nfc_1y, loan_nfc) - zc1, prem_nfc_uird = loan_nfc - uird3, prem_nfc_pol = loan_nfc - pol, prem_hh_cd = loan_hh - cd,
            ovdp_cd = ovdp_prim - cd, slope_10_1 = zc10 - zc1, dep_hh_cd = dep_hh - cd, new_margin_nfc = loan_nfc - dep_nfc, real_cd = cd - pie, real_loan_nfc = loan_nfc - pie, phase = phase_of(month))]
  save_tab(mp, "S3_A3_market_premium_monthly.csv", "A3_market_m")
  cs <- c("loan_nfc", "loan_hh", "ovdp_prim", "cd", "prem_nfc_cd", "prem_nfc_zc1", "prem_nfc_uird", "prem_hh_cd", "ovdp_cd", "slope_10_1", "new_margin_nfc", "real_cd", "real_loan_nfc")
  x <- rbind(mp[, lapply(.SD, mean, na.rm = TRUE), by = phase, .SDcols = cs][order(phase)], cbind(phase = "Останні 12 місяців", mp[month > seq(LAST, by = "-12 months", length.out = 2)[2], lapply(.SD, mean, na.rm = TRUE), .SDcols = cs]))
  save_tab(x, "S3_A3_market_premium_phases.csv", "A3_market_ph")
})

blk("A4 розклади", {
  cm <- D0[is.finite(rr_LS) & is.finite(y_L) & is.finite(cc), .(y_L = wmean(y_L, A_L), cc = wmean(cc, A_L), cap = wmean(cap_charge, A_L), y_S = wmean(y_S_alt, A_L), rr = wmean(rr_LS, A_L)), by = month]
  cp <- cm[, lapply(.SD, mean), by = .(phase = phase_of(month)), .SDcols = c("y_L", "cc", "cap", "y_S", "rr")][order(phase)]
  save_tab(rbindlist(lapply(2:nrow(cp), function(i) data.table(from = cp$phase[i - 1], to = cp$phase[i], d_rr = cp$rr[i] - cp$rr[i - 1], c_yield = cp$y_L[i] - cp$y_L[i - 1], c_risk = -(cp$cc[i] - cp$cc[i - 1]),
                                                                c_capital = -(cp$cap[i] - cp$cap[i - 1]), c_cd = -(cp$y_S[i] - cp$y_S[i - 1])))), "S3_A4_rr_decomposition.csv", "A4_rr_decomp")
  # rate effect vs structure effect in the yield of the allocatable portfolio (midpoint decomposition between phases)
  ys <- sm[, .(phase, month, s_L, s_B, s_S, s_O, r_L = y_L - cc, r_B = y_B, r_S = y_S)][, r_O := 0.03]
  yp <- ys[, lapply(.SD, mean, na.rm = TRUE), by = phase, .SDcols = c("s_L", "s_B", "s_S", "s_O", "r_L", "r_B", "r_S", "r_O")][order(phase)]
  save_tab(rbindlist(lapply(2:nrow(yp), function(i) { a <- yp[i - 1]; b <- yp[i]; S0 <- unlist(a[, .(s_L, s_B, s_S, s_O)]); S1 <- unlist(b[, .(s_L, s_B, s_S, s_O)]); R0 <- unlist(a[, .(r_L, r_B, r_S, r_O)]); R1 <- unlist(b[, .(r_L, r_B, r_S, r_O)])
    data.table(from = a$phase, to = b$phase, yield0 = sum(S0 * R0), yield1 = sum(S1 * R1), rate_effect = sum((S0 + S1) / 2 * (R1 - R0)), structure_effect = sum((R0 + R1) / 2 * (S1 - S0)),
               rate_L = (S0[1] + S1[1]) / 2 * (R1[1] - R0[1]), rate_B = (S0[2] + S1[2]) / 2 * (R1[2] - R0[2]), rate_S = (S0[3] + S1[3]) / 2 * (R1[3] - R0[3]),
               str_L = (R0[1] + R1[1]) / 2 * (S1[1] - S0[1]), str_B = (R0[2] + R1[2]) / 2 * (S1[2] - S0[2]), str_S = (R0[3] + R1[3]) / 2 * (S1[3] - S0[3])) })),
    "S3_A4_yield_rate_structure.csv", "A4_rate_structure")
})

blk("A5 сегменти", {
  # дохідність сегментів на тій самій основі, що й y_L (процентний дохід до чистого залишку); окремі рядки доходу від юридичних і фізичних осіб зіставні з 2021 р.
  seg <- function(g, y, w, minw = 50) { ok <- is.finite(g[[y]]) & f0(g[[w]]) > minw & g[[y]] >= 0 & g[[y]] <= .9; if (!any(ok)) NA_real_ else sum(g[[y]][ok] * g[[w]][ok]) / sum(g[[w]][ok]) }
  sg <- D0[, .(ii_le = sum(col0(.SD, "ii_le_m")), ii_hh = sum(col0(.SD, "ii_hh_m")), le = sum(col0(.SD, "avg_loans_le")), hh = sum(col0(.SD, "avg_loans_hh")),
               y_corp_uah = if ("y_loans_corp_uah" %in% names(.SD)) seg(.SD, "y_loans_corp_uah", "avg_loans_corp_all_uah") else NA_real_,
               y_hh_uah = if ("y_loans_hh_uah" %in% names(.SD)) seg(.SD, "y_loans_hh_uah", "avg_loans_hh_all_uah") else NA_real_,
               cc = sum(col0(.SD, "alloc_prov_m")) , la = sum(col0(.SD, "avg_loans_all")),
               cd = mean(cd_on, na.rm = TRUE), share_hh = sum(col0(.SD, "loans_hh")) / sum(col0(.SD, "loans_hh") + col0(.SD, "loans_le"))), by = month][order(month)]
  r12 <- function(x) as.numeric(stats::filter(x, rep(1, 12), sides = 1)); ok12 <- sg$month >= seq(FINREP_BREAK, by = "11 months", length.out = 2)[2]
  sg[, `:=`(y_corp_12 = fifelse(ok12, r12(ii_le) / (r12(le) / 12), NA_real_), y_hh_12 = fifelse(ok12, r12(ii_hh) / (r12(hh) / 12), NA_real_), cd_12 = r12(cd) / 12,
            y_corp_uah_12 = r12(y_corp_uah) / 12, y_hh_uah_12 = r12(y_hh_uah) / 12)]
  sg[, `:=`(prem_corp = y_corp_12 - cd_12, prem_hh = y_hh_12 - cd_12, prem_corp_uah = y_corp_uah_12 - cd_12, prem_hh_uah = y_hh_uah_12 - cd_12, phase = phase_of(month))]
  save_tab(sg, "S3_A5_segments_monthly.csv", "A5_segments_m")
  save_tab(sg[, c(lapply(.SD, mean, na.rm = TRUE), list(months = sum(is.finite(y_corp_12)))), by = phase, .SDcols = c("y_corp_12", "y_hh_12", "y_corp_uah_12", "y_hh_uah_12", "prem_corp", "prem_hh", "prem_corp_uah", "prem_hh_uah", "share_hh")][order(phase)],
           "S3_A5_segments_phases.csv", "A5_segments_ph")
  x <- d[month > seq(LAST, by = "-12 months", length.out = 2)[2] & month <= LAST & !is.na(owner_ua)]
  own <- x[, .(y_corp = sum(col0(.SD, "ii_le_m")) / (sum(col0(.SD, "avg_loans_le")) / 12), y_hh = sum(col0(.SD, "ii_hh_m")) / (sum(col0(.SD, "avg_loans_hh")) / 12)), by = owner_ua]
  own <- merge(own, d[month == LAST & !is.na(owner_ua), .(share_hh = sum(col0(.SD, "loans_hh")) / sum(col0(.SD, "loans_hh") + col0(.SD, "loans_le")), loans_bn = sum(A_L) / 1e3, corp_bn = sum(col0(.SD, "loans_le")) / 1e3, hh_bn = sum(col0(.SD, "loans_hh")) / 1e3), by = owner_ua], by = "owner_ua")
  tot <- data.table(owner_ua = "Система", y_corp = sum(col0(x, "ii_le_m")) / (sum(col0(x, "avg_loans_le")) / 12), y_hh = sum(col0(x, "ii_hh_m")) / (sum(col0(x, "avg_loans_hh")) / 12),
                    share_hh = sum(own$hh_bn) / sum(own$hh_bn + own$corp_bn), loans_bn = sum(own$loans_bn), corp_bn = sum(own$corp_bn), hh_bn = sum(own$hh_bn))
  save_tab(rbind(own, tot), "S3_A5_segments_owner.csv", "A5_segments_own")
})

blk("A6 економічна вартість ресурсу", {
  f <- file.path(OUTPUT_DIR, "section_2_4", "tables", "S24_bank_history_60m.csv")
  if (!file.exists(f)) stop("немає S24_bank_history_60m.csv — спершу запустіть 11_section_2_4_shadow_cost_v6.R")
  h <- fread(f); h[, `:=`(month = as.Date(month), nkb = as.character(nkb))]
  e <- merge(d[, .(month, nkb, owner_ua, A_L, P, y_L, cc, cap_charge, cod, y_S_alt, rr_LS)], h[, .(month, nkb, ec = ec / 100, sfc = sfc / 100, wedge = wedge / 100, cod_nom = cod_nom / 100)], by = c("month", "nkb"))
  e[, `:=`(ec12 = roll_sum(ec, mean = TRUE), sfc12 = roll_sum(sfc, mean = TRUE), wedge12 = roll_sum(wedge, mean = TRUE)), by = nkb]
  e[, `:=`(rar_L_econ = y_L - cc - cap_charge - ec12, clears_hurdle = (y_L - cc - cap_charge) > sfc12, cd_clears_hurdle = y_S_alt > sfc12)]
  save_tab(e[is.finite(rar_L_econ), .(wedge = wmean(wedge12, P), ec = wmean(ec12, P), sfc = wmean(sfc12, P), rar_L_nominal = wmean(y_L - cc - cap_charge - cod, A_L), rar_L_econ = wmean(rar_L_econ, A_L),
               share_clear = mean(clears_hurdle), share_clear_w = sum(A_L[clears_hurdle]) / sum(A_L), share_cd_clear = mean(cd_clears_hurdle), n = .N), by = month][order(month)], "S3_A6_economic_cost_monthly.csv", "A6_econ_m")
  save_tab(e[month == LAST & is.finite(rar_L_econ), .(wedge = wmean(wedge12, P), sfc = wmean(sfc12, P), rar_L_econ = wmean(rar_L_econ, A_L), share_clear = mean(clears_hurdle), n = .N), by = owner_ua], "S3_A6_economic_cost_owner.csv", "A6_econ_own")
})

blk("A7 передача за банками", {
  pol <- mk[, .(month, i = pol)]
  PROD <- list(c("r_hh_term_uah", "avg_dep_hh_term_uah", "Строкові депозити ФО, грн"), c("r_hh_demand_uah", "avg_dep_hh_demand_uah", "Кошти ФО на вимогу, грн"),
               c("r_corp_term_uah", "avg_dep_corp_term_uah", "Строкові депозити СГ, грн"), c("r_corp_demand_uah", "avg_dep_corp_demand_uah", "Кошти СГ на вимогу, грн"),
               c("y_loans_hh_uah", "avg_loans_hh_all_uah", "Кредити ФО, грн"), c("y_loans_corp_uah", "avg_loans_corp_all_uah", "Кредити СГ, грн"))
  ols <- function(y, X) { b <- drop(solve(crossprod(X), crossprod(X, y))); u <- y - X %*% b; s2 <- sum(u^2) / max(nrow(X) - ncol(X), 1); list(b = b, se = sqrt(diag(s2 * solve(crossprod(X)))), r2 = 1 - sum(u^2) / sum((y - mean(y))^2)) }
  mm <- m[order(nkb, month)]
  res <- rbindlist(lapply(split(mm, by = "nkb"), function(g) rbindlist(lapply(PROD, function(p) {
    if (!all(p[1:2] %in% names(g))) return(NULL)
    r <- as.numeric(g[[p[1]]]); r[!(f0(g[[p[2]]]) >= 10) | !is.finite(r) | r < 0 | r > .8] <- NA_real_; r <- roll_sum(r, 3L, 2L, mean = TRUE)
    x <- merge(data.table(month = g$month, r = r), pol, by = "month")[is.finite(r) & is.finite(i)][order(month)]
    if (nrow(x) < 36) return(NULL)
    e <- x[, .(dr = r - shift(r), r1 = shift(r), i1 = shift(i), di = i - shift(i))][is.finite(dr)]
    f <- tryCatch(ols(e$dr, cbind(1, e$r1, e$i1, e$di)), error = function(e) NULL); if (is.null(f)) return(NULL)
    phi <- f$b[2]; theta <- if (phi < -1e-4) -f$b[3] / phi else NA_real_; half <- if (phi > -1 && phi < 0) log(.5) / log(1 + phi) else NA_real_
    l <- x[, .(y = r - shift(r, 12), x = i - shift(i, 12))][is.finite(y) & is.finite(x)]
    b12 <- bu <- bd <- NA_real_
    if (nrow(l) >= 24) b12 <- ols(l$y, cbind(1, l$x))$b[2]
    if (nrow(l) >= 36 && sum(l$x > 0) >= 10 && sum(l$x < 0) >= 10) { ba <- ols(l$y, cbind(1, pmax(l$x, 0), pmin(l$x, 0)))$b; bu <- ba[2]; bd <- ba[3] }
    lastr <- tail(x, 1)
    data.table(nkb = g$nkb[1], product = p[3], n = nrow(e), beta0 = f$b[4], beta12 = b12, theta = theta, phi = phi, half_life_m = half, beta12_up = bu, beta12_down = bd, r2 = f$r2,
               rate_last = if (lastr$month >= seq(LAST, by = "-2 months", length.out = 2)[2]) lastr$r else NA_real_, stock_last = f0(g[[p[2]]][g$month == LAST])[1], active = LAST %in% g$month) }))))
  for (v in c("beta0", "beta12", "theta", "beta12_up", "beta12_down")) res[!is.finite(get(v)) | get(v) < -1.5 | get(v) > 3, (v) := NA_real_]
  res <- merge(res, unique(d[month == LAST, .(nkb, fullname, owner_ua)]), by = "nkb", all.x = TRUE)
  save_tab(res, "S3_A7_bank_transmission.csv", "A7_bank_transmission")
  ac <- res[active == TRUE]
  save_tab(ac[, .(banks = .N, beta12_median = median(beta12, na.rm = TRUE), beta12_q25 = quantile(beta12, .25, na.rm = TRUE), beta12_q75 = quantile(beta12, .75, na.rm = TRUE), theta_median = median(theta, na.rm = TRUE),
                  theta_q25 = quantile(theta, .25, na.rm = TRUE), theta_q75 = quantile(theta, .75, na.rm = TRUE), half_life_median = median(half_life_m, na.rm = TRUE), phi_median = median(phi, na.rm = TRUE),
                  beta0_median = median(beta0, na.rm = TRUE), beta12_up_median = median(beta12_up, na.rm = TRUE), beta12_down_median = median(beta12_down, na.rm = TRUE), rate_last_median = median(rate_last, na.rm = TRUE)), by = product],
           "S3_A7_transmission_summary.csv", "A7_summary")
  save_tab(ac[, .(banks = .N, beta12 = median(beta12, na.rm = TRUE), theta = median(theta, na.rm = TRUE), half = median(half_life_m, na.rm = TRUE), rate = median(rate_last, na.rm = TRUE)), by = .(product, owner_ua)],
           "S3_A7_transmission_owner.csv", "A7_owner")
  # model path of the relative return after a permanent +1 pp policy shock: CDs reprice at once, loan yield follows the median ECM
  sm7 <- ac[product %in% c("Кредити СГ, грн", "Кредити ФО, грн"), .(theta = median(theta, na.rm = TRUE), phi = median(phi, na.rm = TRUE), b0 = median(beta0, na.rm = TRUE)), by = product]
  sh <- wmean(d[month == LAST, col0(.SD, "loans_hh") / (col0(.SD, "loans_hh") + col0(.SD, "loans_le"))], d[month == LAST, A_L])
  path <- function(theta, phi, b0, H = 36) { r <- numeric(H + 1); r[1] <- b0; for (t in 2:(H + 1)) r[t] <- r[t - 1] + phi * (r[t - 1] - theta); r }
  pc <- with(sm7[product == "Кредити СГ, грн"], path(theta, phi, b0)); ph <- with(sm7[product == "Кредити ФО, грн"], path(theta, phi, b0))
  save_tab(data.table(t = 0:36, d_loan_corp = pc, d_loan_hh = ph, d_loan = (1 - sh) * pc + sh * ph, d_cd = 1, d_rr = (1 - sh) * pc + sh * ph - 1), "S3_A7_rr_path_after_shock.csv", "A7_rr_path")
})

blk("A8 стійкість позицій банків", {
  x <- d[is.finite(rr_LS), .(nkb, month, rr_LS)]; x[, q := cut(rank(rr_LS, ties.method = "first") / .N, c(0, .25, .5, .75, 1), labels = paste0("Q", 1:4)), by = month]
  add_lead(x, "q", 12L, "q12"); add_lead(x, "rr_LS", 12L, "rr12"); y <- x[!is.na(q12)]
  tm <- y[, .N, by = .(from = q, to = q12)][, share := N / sum(N), by = from][order(from, to)]
  save_tab(dcast(tm, from ~ to, value.var = "share", fill = 0), "S3_A8_rr_transition_12m.csv", "A8_transition")
  ac <- y[, .(rho12 = if (.N > 12) cor(rr_LS, rr12) else NA_real_), by = nkb]; fact("rr_pooled_autocorr12", round(cor(y$rr_LS, y$rr12), 3))
  fact("rr_bank_autocorr12_median", round(median(ac$rho12, na.rm = TRUE), 3))
})

# =============================== 3.2 ===========================================
ALT <- c("s_L", "s_B", "s_S", "s_O")
d[, `:=`(rr_LS_w = winsor(rr_LS), rr_BS_w = winsor(rr_BS), war = as.numeric(month >= as.Date("2022-03-01")), state = as.numeric(owner == "State"), foreign = as.numeric(owner == "Foreign"))]
XV <- c("rr_LS_w", "rr_BS_w", "cod", "demand_share", "fx_share", "head", "ln_lcr", "ln_assets")
for (v in XV) { x <- as.numeric(d[[v]]); x[!is.finite(x)] <- NA_real_; set(d, j = v, value = x) }
d[, pol := as.numeric(pol)]
for (v in XV) d[, paste0("L1_", v) := shift(get(v)), by = nkb]
# coverage check: a regressor that is missing for most bank-months (differences between data vintages) is dropped, not allowed to empty the sample
.base <- is.finite(d$L1_rr_LS_w) & is.finite(d$L1_rr_BS_w) & is.finite(d$s_L)
COVER <- data.table(var = XV, finite_share = sapply(XV, function(v) mean(is.finite(d[[paste0("L1_", v)]]))), finite_share_in_core = sapply(XV, function(v) mean(is.finite(d[[paste0("L1_", v)]][.base]))))
COVER[, used := finite_share_in_core >= 0.5 | var %in% c("rr_LS_w", "rr_BS_w")]
save_tab(COVER, "S3_B0_model_coverage.csv", "B0_coverage")
if (any(!COVER$used)) { message("  УВАГА: регресори з покриттям < 50% вилучено з моделі: ", paste(COVER[used == FALSE, var], collapse = ", ")); fact("fmnl_dropped_regressors", paste(COVER[used == FALSE, var], collapse = ", ")) }
XV <- COVER[used == TRUE, var]
LX <- paste0("L1_", XV); MUND <- intersect(c("L1_rr_LS_w", "L1_rr_BS_w", "L1_cod", "L1_demand_share", "L1_head"), LX)
.need_cols <- c(LX, ALT, "pol", "war", "state", "foreign")
.bad <- sapply(.need_cols, function(v) sum(!is.finite(as.numeric(d[[v]])) & !is.na(d[[v]])))        # Inf / NaN that complete.cases() would let through
if (any(.bad > 0)) { message("  нескінченні значення вилучено з вибірки моделі: ", paste(names(.bad)[.bad > 0], .bad[.bad > 0], collapse = "; ")); fact("fmnl_nonfinite_dropped", paste(names(.bad)[.bad > 0], .bad[.bad > 0], collapse = "; ")) }
est <- d[Reduce(`&`, lapply(.need_cols, function(v) is.finite(as.numeric(d[[v]]))))]
est <- est[abs(rowSums(as.matrix(est[, ..ALT])) - 1) < 1e-6 & s_L >= 0 & s_B >= 0 & s_S >= 0 & s_O >= 0]
for (v in MUND) est[, paste0("M_", v) := mean(get(v)), by = nkb]
XCOLS <- c(LX, "pol", "war", "state", "foreign", paste0("M_", MUND))
MU <- colMeans(as.matrix(est[, ..XCOLS])); SD <- apply(as.matrix(est[, ..XCOLS]), 2, sd); SD[!is.finite(SD) | SD == 0] <- 1
if (nrow(est) < 500) stop("замало спостережень для моделі розподілу: ", nrow(est))
design <- function(dt) cbind(1, sweep(sweep(as.matrix(dt[, ..XCOLS]), 2, MU), 2, SD, "/"))
probs <- function(th, Z) { U <- cbind(Z %*% t(matrix(th, 3, ncol(Z), byrow = TRUE)), 0); U <- U - pmax(U[, 1], U[, 2], U[, 3], U[, 4]); E <- exp(U); E / rowSums(E) }
fit_fmnl <- function(Z, Y, th0 = NULL) { n <- nrow(Z)
  fn <- function(th) -sum(Y * log(pmax(probs(th, Z), 1e-12))) / n
  gr <- function(th) -as.vector(crossprod(Z, (Y - probs(th, Z))[, 1:3])) / n
  optim(th0 %||% rep(0, 3 * ncol(Z)), fn, gr, method = "BFGS", control = list(maxit = 1000, reltol = if (is.null(th0)) 1e-11 else 1e-9))$par }
ape <- function(th, dt, var, delta) { d2 <- copy(dt); set(d2, j = var, value = d2[[var]] + delta); colMeans(probs(th, design(d2)) - probs(th, design(dt))) }
APE_SPEC <- list(c("L1_rr_LS_w", .01, "Відносна дохідність кредитів до ДС, +1 в. п."), c("L1_rr_BS_w", .01, "Відносна дохідність ОВДП до ДС, +1 в. п."), c("L1_cod", .01, "Вартість депозитів, +1 в. п."),
                 c("L1_demand_share", .10, "Частка коштів на вимогу, +10 в. п."), c("L1_fx_share", .10, "Валютна частка депозитів, +10 в. п."), c("L1_head", .05, "Запас капіталу до мінімуму, +5 в. п."),
                 c("L1_ln_lcr", log(1.5), "LCR, +50%"), c("L1_ln_assets", log(2), "Розмір банку, ×2"), c("pol", .01, "Облікова ставка, +1 в. п."), c("war", 1, "Період воєнного стану"),
                 c("state", 1, "Державний банк"), c("foreign", 1, "Іноземний банк"))
APE_SPEC <- Filter(function(z) z[1] %in% XCOLS, APE_SPEC)
theta <- NULL; BOOT <- NULL
blk("B1 дробова мультиноміальна логіт-модель", {
  Z <- design(est); Y <- as.matrix(est[, ..ALT]); theta <<- fit_fmnl(Z, Y); P0 <- probs(theta, Z)
  fact("fmnl_n", nrow(est)); fact("fmnl_banks", uniqueN(est$nkb)); fact("fmnl_from", as.character(min(est$month))); fact("fmnl_to", as.character(max(est$month)))
  for (j in 1:4) fact(paste0("fmnl_corr_", ALT[j]), round(cor(P0[, j], Y[, j]), 3)); fact("fmnl_mae_pp", round(100 * mean(abs(P0 - Y)), 2))
  a0 <- t(sapply(APE_SPEC, function(s) ape(theta, est, s[1], as.numeric(s[2]))))
  idx <- split(seq_len(nrow(est)), est$nkb); banks <- names(idx)
  bt <- matrix(NA_real_, NBOOT, length(theta)); ba <- array(NA_real_, c(NBOOT, length(APE_SPEC), 4))
  for (b in seq_len(NBOOT)) { ii <- unlist(idx[sample(banks, length(banks), TRUE)], use.names = FALSE)
    th <- tryCatch(fit_fmnl(Z[ii, ], Y[ii, ], theta), error = function(e) NULL); if (is.null(th)) next
    bt[b, ] <- th; eb <- est[ii]; ba[b, , ] <- t(sapply(APE_SPEC, function(s) ape(th, eb, s[1], as.numeric(s[2])))) }
  BOOT <<- bt[stats::complete.cases(bt), , drop = FALSE]; se <- apply(ba, c(2, 3), sd, na.rm = TRUE)
  out <- data.table(var = sapply(APE_SPEC, `[`, 1), label = sapply(APE_SPEC, `[`, 3))
  for (j in 1:4) { out[, paste0("ape_", ALT[j]) := 100 * a0[, j]]; out[, paste0("se_", ALT[j]) := 100 * se[, j]]; out[, paste0("p_", ALT[j]) := 2 * pnorm(-abs(a0[, j] / se[, j]))] }
  save_tab(out, "S3_B1_fmnl_ape.csv", "B1_ape"); fact("nboot_effective", nrow(BOOT))
  cf <- matrix(theta, 3, ncol(Z), byrow = TRUE); colnames(cf) <- c("const", XCOLS)
  save_tab(data.table(equation = c("Кредити", "ОВДП", "Сертифікати НБУ"), cf), "S3_B1_fmnl_coefficients_std.csv", "B1_coef")
})

blk("B2 неоднорідність", {
  sub <- function(mask, lab, nb = min(100L, NBOOT)) { e <- est[mask]; if (uniqueN(e$nkb) < 5) return(NULL); Z <- design(e); Y <- as.matrix(e[, ..ALT]); th <- fit_fmnl(Z, Y, theta)
    idx <- split(seq_len(nrow(e)), e$nkb); bk <- names(idx); vs <- c("L1_rr_LS_w", "L1_rr_BS_w"); a0 <- t(sapply(vs, function(v) ape(th, e, v, .01)))
    bb <- array(NA_real_, c(nb, 2, 4)); for (b in seq_len(nb)) { ii <- unlist(idx[sample(bk, length(bk), TRUE)], use.names = FALSE); tb <- tryCatch(fit_fmnl(Z[ii, ], Y[ii, ], th), error = function(x) NULL)
      if (!is.null(tb)) bb[b, , ] <- t(sapply(vs, function(v) ape(tb, e[ii], v, .01))) }
    se <- apply(bb, c(2, 3), sd, na.rm = TRUE); o <- data.table(sample = lab, var = vs, n = nrow(e), banks = length(bk))
    for (j in 1:4) { o[, paste0("ape_", ALT[j]) := 100 * a0[, j]]; o[, paste0("se_", ALT[j]) := 100 * se[, j]] }; o }
  big <- est[, mean(P), by = nkb]; bigset <- big[V1 >= quantile(V1, .75), nkb]
  save_tab(rbindlist(list(sub(est$month < as.Date("2022-03-01"), "До березня 2022 р."), sub(est$month >= as.Date("2022-03-01"), "Із березня 2022 р."), sub(est$owner == "State", "Державні банки"),
                          sub(est$owner == "Foreign", "Іноземні банки"), sub(est$owner == "Private", "Приватні банки"), sub(est$nkb %in% bigset, "Верхній квартиль за розміром"),
                          sub(!(est$nkb %in% bigset), "Інші банки за розміром"), if ("L1_head" %in% names(est)) sub(est$L1_head < .05, "Запас капіталу до 5 в. п."), if ("L1_head" %in% names(est)) sub(est$L1_head >= .05, "Запас капіталу від 5 в. п."))), "S3_B2_heterogeneity.csv", "B2_heterogeneity")
})

for (k in c("L", "B", "S")) { add_lead(d, paste0("s_", k), 12L, "tmp"); set(d, j = paste0("ds_", k, "12f"), value = d$tmp - d[[paste0("s_", k)]]) }
add_lead(d, "A_L", 12L, "tmp"); d[, dln_L12f := winsor(log(fifelse(tmp > 0, tmp, NA_real_)) - log(fifelse(A_L > 0, A_L, NA_real_)))]; d[, tmp := NULL]

blk("B3 фіксовані ефекти та поріг капіталу", {
  out <- rbindlist(lapply(c("dln_L12f", "ds_L12f", "ds_B12f", "ds_S12f"), function(y) rbindlist(list(
    cbind(dep = y, spec = "base", fe_reg(d, y, c("rr_LS_w", "rr_BS_w"))),
    cbind(dep = y, spec = "controls", fe_reg(d, y, c("rr_LS_w", "rr_BS_w", "head", "ln_lcr", "demand_share", "cod", "ln_assets")))))))
  save_tab(out, "S3_B3_fe_forward_changes.csv", "B3_fe")
  d[, `:=`(low_head = as.numeric(headroom_total_min_pp < 5), mid_head = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15))]
  d[, `:=`(rr_x_low = rr_LS_w * low_head, rr_x_high = rr_LS_w * (1 - low_head))]
  dd <- d[is.finite(headroom_total_min_pp)]
  out2 <- rbindlist(lapply(c("ds_L12f", "dln_L12f", "ds_S12f", "ds_B12f"), function(y) rbindlist(list(
    cbind(dep = y, spec = "dummies", fe_reg(dd, y, c("low_head", "mid_head", "rr_LS_w", "ln_lcr", "demand_share", "cod", "ln_assets"))),
    cbind(dep = y, spec = "interaction", fe_reg(dd, y, c("rr_x_low", "rr_x_high", "low_head", "ln_lcr", "demand_share", "cod", "ln_assets")))))))
  save_tab(out2, "S3_B3_capital_threshold.csv", "B3_threshold"); fact("share_low_head_obs", round(mean(dd$low_head), 3))
  # threshold search: which headroom cut-off fits the loan-share dynamics best
  gr <- rbindlist(lapply(seq(2, 20, 1), function(c0) { dd[, lowc := as.numeric(headroom_total_min_pp < c0)]; r <- fe_reg(dd, "ds_L12f", c("lowc", "rr_LS_w", "ln_lcr", "demand_share", "cod", "ln_assets")); data.table(cutoff_pp = c0, coef = r$coef[1], se = r$se[1], r2_within = r$r2_within[1], share_low = mean(dd$lowc)) }))
  save_tab(gr, "S3_B3_threshold_grid.csv", "B3_threshold_grid")
})

LAM <- NULL
blk("B4 часткове коригування", {
  P0 <- probs(theta, design(est)); e <- copy(est); for (j in 1:4) set(e, j = paste0("tgt_", ALT[j]), value = P0[, j])
  out <- rbindlist(lapply(c(1L, 3L, 6L, 12L), function(h) rbindlist(lapply(ALT[1:3], function(a) { add_lead(e, a, h, "lead"); e[, `:=`(dy = lead - get(a), gap = get(paste0("tgt_", a)) - get(a))]
    r <- fe_reg(e, "dy", "gap"); lam <- r$coef; lm <- if (lam > 0 && lam < 1) 1 - (1 - lam)^(1 / h) else NA_real_
    data.table(asset = a, h = h, lambda_h = lam, se = r$se, p = r$p, n = r$n, lambda_monthly = lm, half_life_m = if (is.finite(lm)) log(.5) / log(1 - lm) else NA_real_) }))))
  save_tab(out, "S3_B4_partial_adjustment.csv", "B4_adjustment"); LAM <<- out
})

blk("B5 локальні проєкції", {
  d[, dpol := pol - shift(pol), by = nkb]
  for (v in c("head", "s_S", "demand_share")) { d[, tmpv := shift(get(v)), by = nkb]; z <- (d$tmpv - mean(d$tmpv, na.rm = TRUE)) / sd(d$tmpv, na.rm = TRUE)
    set(d, j = paste0("z_", v), value = z); set(d, j = paste0("dpx_", v), value = d$dpol * 100 * z)
    set(d, j = paste0("dpx_up_", v), value = pmax(d$dpol, 0) * 100 * z); set(d, j = paste0("dpx_dn_", v), value = pmin(d$dpol, 0) * 100 * z) }
  d[, tmpv := NULL]
  out <- rbindlist(lapply(c("L", "B", "S"), function(k) rbindlist(lapply(c(0L, 1L, 3L, 6L, 9L, 12L), function(h) { add_lead(d, paste0("s_", k), h, "ld"); d[, lhs := (ld - shift(get(paste0("s_", k)))) * 100, by = nkb]
    r1 <- fe_reg(d, "lhs", c("dpx_head", "dpx_s_S", "dpx_demand_share", "z_head", "z_s_S", "z_demand_share"))[1:3]
    r2 <- fe_reg(d, "lhs", c("dpx_up_head", "dpx_dn_head", "dpx_up_s_S", "dpx_dn_s_S", "dpx_up_demand_share", "dpx_dn_demand_share", "z_head", "z_s_S", "z_demand_share"))[1:6]
    rbind(cbind(asset = k, h = h, spec = "symmetric", r1), cbind(asset = k, h = h, spec = "asymmetric", r2)) }))))
  save_tab(out, "S3_B5_local_projections.csv", "B5_lp")
  # system-level response of shares to the policy rate (time series LP, Newey–West)
  s <- copy(sm)[, .(month, s_L, s_B, s_S)]; s <- merge(s, mk[, .(month, pol)], by = "month")[order(month)]; s[, dpol := (pol - shift(pol)) * 100]
  ts <- rbindlist(lapply(c("s_L", "s_B", "s_S"), function(v) rbindlist(lapply(c(1, 3, 6, 12), function(h) { y <- (shift(s[[v]], h, type = "lead") - shift(s[[v]])) * 100; X <- cbind(dpol = s$dpol, dpol_l1 = shift(s$dpol), dy_l1 = shift(s[[v]] - shift(s[[v]])) * 100); ok <- stats::complete.cases(cbind(y, X))
    f <- nw_ols(y[ok], X[ok, , drop = FALSE], h + 1L); data.table(asset = v, h = h, coef = f$b[2], se = sqrt(diag(f$V))[2], n = f$n) }))))
  save_tab(ts, "S3_B5_system_lp.csv", "B5_system_lp")
})

blk("B6 подієве дослідження ДС 3М", {
  EV <- as.Date("2023-04-01"); pre <- d[month >= as.Date("2022-10-01") & month <= as.Date("2023-03-01"), .(expo = mean(f0(dep_hh_term_uah) / P)), by = nkb]
  ev <- merge(d, pre, by = "nkb")[month >= as.Date("2022-04-01") & month <= as.Date("2024-10-01")]
  ev[, expo_z := (expo - mean(pre$expo)) / sd(pre$expo)]; ev[, k := (as.integer(format(month, "%Y")) - 2023L) * 12L + as.integer(format(month, "%m")) - 4L]; ev[, kb := pmin(pmax(k, -9L), 15L)]
  ks <- setdiff(sort(unique(ev$kb)), -1L); for (k in ks) set(ev, j = paste0("e_", k + 100), value = (ev$kb == k) * ev$expo_z); ev[, post_x := (k >= 0) * expo_z]
  ev[, trend_x := k * expo_z]
  out <- rbindlist(lapply(ALT, function(a) { ev[, lhs := get(a) * 100]
    rbind(cbind(asset = a, k = ks, fe_reg(ev, "lhs", paste0("e_", ks + 100))), cbind(asset = a, k = 99L, fe_reg(ev, "lhs", "post_x")), cbind(asset = a, k = 98L, fe_reg(ev, "lhs", c("post_x", "trend_x"))[1]), fill = TRUE) }))
  save_tab(out, "S3_B6_event_cd3m.csv", "B6_event")   # k = 99: pooled post; k = 98: pooled post with exposure-specific linear trend
})

blk("B7 граничне використання приросту депозитів", {
  d[, dep := f0(liab_cust)]
  for (v in c("A_L", "A_B", "A_S", "A_O", "dep", "P")) { add_lead(d, v, -12L, "lg"); set(d, j = paste0("d12_", v), value = (d[[v]] - d$lg)); if (v == "P") set(d, j = "P_lag12", value = d$lg) }
  d[, lg := NULL]
  for (v in c("A_L", "A_B", "A_S", "A_O", "dep")) set(d, j = paste0("g_", v), value = winsor(d[[paste0("d12_", v)]] / d$P_lag12))
  run <- function(mask, lab) rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(sample = lab, asset = v, fe_reg(d[mask & is.finite(P_lag12) & P_lag12 > 0], paste0("g_", v), "g_dep"))))
  d[, dep_up := pmax(g_dep, 0)]; d[, dep_dn := pmin(g_dep, 0)]
  asym <- rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(sample = "Асиметрія: приплив / відплив", asset = v, fe_reg(d[is.finite(P_lag12) & P_lag12 > 0], paste0("g_", v), c("dep_up", "dep_dn")))))
  save_tab(rbind(run(rep(TRUE, nrow(d)), "Уся вибірка"), run(d$month < as.Date("2022-03-01"), "До березня 2022 р."), run(d$month >= as.Date("2022-03-01"), "Із березня 2022 р."),
                 run(d$owner == "State", "Державні"), run(d$owner == "Foreign", "Іноземні"), run(d$owner == "Private", "Приватні"),
                 run(f0(d$headroom_total_min_pp) < 5 & is.finite(d$headroom_total_min_pp), "Запас капіталу до 5 в. п."), run(d$headroom_total_min_pp >= 5, "Запас капіталу від 5 в. п."), asym, fill = TRUE),
           "S3_B7_marginal_use_of_deposits.csv", "B7_marginal_use")
  # system accounting: where the increase of customer funds went, by phase (bn UAH)
  s <- d[, .(dep = sum(dep), A_L = sum(A_L), A_B = sum(A_B), A_S = sum(A_S), A_O = sum(A_O)), by = month][order(month)]; s[, phase := phase_of(month)]
  save_tab(s[, .(d_dep = (last(dep) - first(dep)) / 1e3, d_L = (last(A_L) - first(A_L)) / 1e3, d_B = (last(A_B) - first(A_B)) / 1e3, d_S = (last(A_S) - first(A_S)) / 1e3, d_O = (last(A_O) - first(A_O)) / 1e3), by = phase][order(phase)],
           "S3_B7_system_flow_of_funds.csv", "B7_flow_of_funds")
})

blk("B8 позавибіркова перевірка", {
  CUT <- seq(LAST, by = "-24 months", length.out = 2)[2]; tr <- est$month <= CUT; Z <- design(est); Y <- as.matrix(est[, ..ALT]); th <- fit_fmnl(Z[tr, ], Y[tr, ], theta)
  ete <- est[!tr]; Pte <- probs(th, Z[!tr, ]); Yte <- Y[!tr, ]
  lastsh <- est[tr][order(month), lapply(.SD, last), by = nkb, .SDcols = ALT]; meansh <- est[tr][, lapply(.SD, mean), by = nkb, .SDcols = ALT]
  ok <- ete$nkb %in% lastsh$nkb; nv <- as.matrix(lastsh[ete$nkb[ok], on = "nkb"][, ..ALT]); bm <- as.matrix(meansh[ete$nkb[ok], on = "nkb"][, ..ALT]); sy <- matrix(colMeans(Y[tr, ]), sum(ok), 4, byrow = TRUE)
  mk1 <- function(nm, pr) { e <- abs(pr - Yte[ok, ]) * 100; data.table(predictor = nm, mae_s_L = mean(e[, 1]), mae_s_B = mean(e[, 2]), mae_s_S = mean(e[, 3]), mae_s_O = mean(e[, 4]), mae_all = mean(e), n = sum(ok)) }
  o1 <- rbind(mk1("Модель (оцінена до дати відсікання)", Pte[ok, ]), mk1("Остання частка банку", nv), mk1("Середня частка банку", bm), mk1("Середня частка системи", sy))
  e9 <- copy(est); Pa <- probs(th, Z); for (j in 1:4) { set(e9, j = paste0("t_", ALT[j]), value = Pa[, j]); add_lead(e9, ALT[j], 12L, paste0("f_", ALT[j])) }
  lam <- sapply(ALT, function(a) { q <- e9[tr]; q[, `:=`(dy = get(paste0("f_", a)) - get(a), gap = get(paste0("t_", a)) - get(a))]; min(max(fe_reg(q, "dy", "gap")$coef, 0), 1) })
  te <- e9[month >= CUT & is.finite(f_s_L)]; act <- as.matrix(te[, paste0("f_", ALT), with = FALSE]); per <- as.matrix(te[, ..ALT])
  pa <- sapply(ALT, function(a) te[[a]] + lam[a] * (te[[paste0("t_", a)]] - te[[a]])); pa <- pmax(pa, 0); pa <- pa / rowSums(pa)
  mk2 <- function(nm, pr) { e <- abs(pr - act) * 100; data.table(predictor = nm, mae_s_L = mean(e[, 1]), mae_s_B = mean(e[, 2]), mae_s_S = mean(e[, 3]), mae_s_O = mean(e[, 4]), mae_all = mean(e), n = nrow(te)) }
  save_tab(rbind(cbind(test = "Рівень часток, 24 місяці", o1), cbind(test = "Прогноз на 12 місяців", rbind(mk2("Незмінна частка", per), mk2("Часткове коригування до модельної цілі", pa), mk2("Модельна ціль без коригування", as.matrix(te[, paste0("t_", ALT), with = FALSE]))))),
           "S3_B8_out_of_sample.csv", "B8_oos"); fact("oos_cut", as.character(CUT))
})

blk("B9 типологія бізнес-моделей", {
  w <- d[month > seq(LAST, by = "-12 months", length.out = 2)[2] & month <= LAST, .(s_L = mean(s_L), s_B = mean(s_B), s_S = mean(s_S), s_O = mean(s_O), demand_share = mean(demand_share, na.rm = TRUE), fx_share = mean(fx_share, na.rm = TRUE),
          cod = mean(cod, na.rm = TRUE), hh_loans = mean(col0(.SD, "loans_hh") / pmax(col0(.SD, "loans_hh") + col0(.SD, "loans_le"), 1)), P = mean(P), rr_LS = mean(rr_LS, na.rm = TRUE), y_L = mean(y_L, na.rm = TRUE), cc = mean(cc, na.rm = TRUE),
          head = mean(headroom_total_min_pp, na.rm = TRUE), owner_ua = owner_ua[1], fullname = fullname[.N]), by = nkb]
  feat <- c("s_L", "s_B", "s_S", "s_O", "demand_share", "fx_share", "hh_loans"); X <- as.matrix(w[, ..feat]); X[!is.finite(X)] <- NA; for (j in seq_len(ncol(X))) X[is.na(X[, j]), j] <- median(X[, j], na.rm = TRUE)
  X[!is.finite(X)] <- 0; X <- X[, apply(X, 2, sd) > 0, drop = FALSE]; feat <- colnames(X)
  Xs <- scale(X); wss <- sapply(2:6, function(k) { set.seed(1); kmeans(Xs, k, nstart = 50)$tot.withinss }); set.seed(1); km <- kmeans(Xs, 4, nstart = 100)
  ord <- order(-tapply(w$s_L, km$cluster, mean)); w[, cluster := match(km$cluster, ord)]
  save_tab(w[, c(list(banks = .N, share_P = sum(P) / sum(w$P)), lapply(.SD, function(x) weighted.mean(x, P, na.rm = TRUE)), list(state = sum(owner_ua == "Державні"), foreign = sum(owner_ua == "Іноземні"), private = sum(owner_ua == "Приватні"))),
             by = cluster, .SDcols = c(feat, "cod", "rr_LS", "y_L", "cc", "head")][order(cluster)], "S3_B9_clusters_profile.csv", "B9_clusters")
  save_tab(w[order(cluster, -P), .(cluster, nkb, fullname, owner_ua, P, s_L, s_B, s_S, s_O, demand_share, fx_share, hh_loans, rr_LS)], "S3_B9_clusters_banks.csv", "B9_cluster_banks")
  save_tab(data.table(k = 2:6, total_within_ss = wss), "S3_B9_clusters_elbow.csv", "B9_elbow")
  cen <- km$centers[ord, , drop = FALSE]; mu <- attr(Xs, "scaled:center"); sdv <- attr(Xs, "scaled:scale")   # cluster of each bank through time (nearest centre)
  allm <- d[is.finite(demand_share), .(nkb, month, P, s_L, s_B, s_S, s_O, demand_share, fx_share = fifelse(is.finite(fx_share), fx_share, 0), hh_loans = col0(.SD, "loans_hh") / pmax(col0(.SD, "loans_hh") + col0(.SD, "loans_le"), 1))]
  Zm <- as.matrix(allm[, ..feat]); Zm[!is.finite(Zm)] <- 0; Zm <- sweep(sweep(Zm, 2, mu), 2, sdv, "/"); allm[, cluster := apply(Zm, 1, function(r) which.min(colSums((t(cen) - r)^2)))]
  save_tab(dcast(allm[, .(share_P = sum(P)), by = .(month, cluster)][, share_P := share_P / sum(share_P), by = month], month ~ cluster, value.var = "share_P", fill = 0), "S3_B9_clusters_over_time.csv", "B9_cluster_time")
})

# ---------- B10: попит і пропозиція кредиту — опитування банків про умови кредитування (BLS) ----------
#   B10a  чинники зміни стандартів кредитування за оцінками самих банків (система, за фазами) і зіставлення з часткою банків із малим запасом капіталу
#   B10b  модель (3.6) з контролем попиту, специфічного для банку: зважений структурою кредитного портфеля банку попит із BLS (shift-share)
#   B10c  складена панель «банк × сегмент» (бізнес / населення) з фіксованими ефектами «сегмент × місяць», які повністю поглинають попит сегмента
#   Опитування квартальне; значення кварталу віднесено до трьох його місяців (02, bls_wide). Баланс відповідей, %: + = жорсткіші стандарти / вищий попит.
BLS_FACTORS <- c(bls_std_nfc_cap = "Капіталізація банку", bls_std_nfc_liq = "Ліквідна позиція банку", bls_std_nfc_comp = "Конкуренція з іншими банками",
                 bls_std_nfc_econ = "Очікування економічної активності", bls_std_nfc_ind = "Ризики галузі або підприємства", bls_std_nfc_coll = "Ризик застави",
                 bls_std_nfc_inflexp = "Інфляційні очікування", bls_std_nfc_fxexp = "Курсові очікування")
BLS_HH <- c(bls_std_hh_cost = "Вартість ресурсів і балансові обмеження", bls_std_hh_solv = "Платоспроможність позичальників", bls_std_hh_econ = "Очікування економічної активності")
load_bls <- function() {
  sb <- store_read("mart_system_month_v6"); sb[, month := as.Date(month)]
  need <- c("bls_dem_nfc", "bls_dem_hh", "bls_std_nfc", "bls_std_hh", names(BLS_FACTORS), names(BLS_HH))
  miss <- setdiff(need, names(sb))
  if (length(miss)) {   # вітрини побудовано попередньою версією 02: чинники стандартів читаються прямо з локального файлу BLS
    message("  BLS: у вітрині немає ", paste(miss, collapse = ", "), " – читаю data_nbu/local_inputs/BLS*.xlsx")
    if (!exists("read_bls_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
    bw <- tryCatch(bls_wide(read_bls_local()), error = function(e) NULL)
    if (!is.null(bw)) { bw[, month := as.Date(month)]; sb <- merge(sb[, setdiff(names(sb), intersect(miss, names(bw))), with = FALSE], bw[, c("month", intersect(miss, names(bw))), with = FALSE], by = "month", all.x = TRUE) }
  }
  for (v in setdiff(need, names(sb))) set(sb, j = v, value = NA_real_)
  sb[, c("month", need), with = FALSE][order(month)] }
BL <- NULL
blk("B10a опитування банків: чинники стандартів кредитування", {
  BL <<- load_bls(); if (!any(is.finite(BL$bls_std_nfc))) stop("немає даних BLS")
  q <- BL[month >= as.Date("2018-01-01") & as.integer(format(month, "%m")) %in% c(1L, 4L, 7L, 10L) & is.finite(bls_std_nfc)]
  # частка портфеля банків із запасом капіталу до 5 в. п. (балансові дані, середнє за місяці кварталу) для зіставлення з оцінкою банків «капіталізація як чинник посилення»
  lh <- d[is.finite(headroom_total_min_pp), .(lhs = 100 * sum(P[headroom_total_min_pp < 5]) / sum(P)), by = month]
  lh[, qstart := as.Date(sprintf("%s-%02d-01", format(month, "%Y"), 3L * ((as.integer(format(month, "%m")) - 1L) %/% 3L) + 1L))]
  q <- merge(q, lh[, .(low_head_share = mean(lhs)), by = .(month = qstart)], by = "month", all.x = TRUE)
  # квартал віднесено до фази за його останнім місяцем: опитування описує квартал загалом, тому I квартал 2022 р. належить до фази воєнного шоку
  q[, phase := phase_of(seq(month, by = "2 months", length.out = 2)[2]), by = month]
  cols <- c("bls_std_nfc", names(BLS_FACTORS), "bls_dem_nfc", "bls_std_hh", names(BLS_HH), "bls_dem_hh", "low_head_share")
  ph <- q[, c(list(quarters = .N), lapply(.SD, function(x) mean(x, na.rm = TRUE))), by = phase, .SDcols = cols][order(phase)]
  al <- q[, c(list(phase = "Увесь період", quarters = .N), lapply(.SD, function(x) mean(x, na.rm = TRUE))), .SDcols = cols]
  save_tab(rbind(ph, al), "S3_B10_bls_factors_by_phase.csv", "B10_bls_phases")
  save_tab(q[, c("month", "phase", cols), with = FALSE], "S3_B10_bls_quarterly.csv", "B10_bls_quarterly")
  cr <- rbindlist(lapply(c(names(BLS_FACTORS)), function(v) { ok <- is.finite(q[[v]]) & is.finite(q$bls_std_nfc)
    data.table(factor = v, label = BLS_FACTORS[[v]], corr_with_standards = cor(q[[v]][ok], q$bls_std_nfc[ok]),
               corr_with_low_head_share = { k <- ok & is.finite(q$low_head_share); if (sum(k) > 5) cor(q[[v]][k], q$low_head_share[k]) else NA_real_ }, n = sum(ok)) }))
  save_tab(cr, "S3_B10_bls_factor_correlations.csv", "B10_bls_corr")
  # які чинники пояснюють зміну стандартів між фазами: внесок = зміна середнього чинника (у в. п. балансу відповідей)
  fact("bls_quarters", nrow(q)); fact("bls_first", as.character(min(q$month))); fact("bls_last", as.character(max(q$month)))
})

# FE regression with a cluster variable that may differ from the unit of the fixed effect (bank × segment units, clustered by bank)
fe_reg_cl <- function(dt, y, xs, i, t, cl) {
  d0 <- dt[, c(i, t, cl, y, xs), with = FALSE]; d0 <- d0[stats::complete.cases(d0) & Reduce(`&`, lapply(d0[, c(y, xs), with = FALSE], is.finite))]
  M <- twoway_demean(as.matrix(d0[, c(y, xs), with = FALSE]), d0[[i]], as.character(d0[[t]]))
  r <- ols_cluster(M[, 1], M[, -1, drop = FALSE], d0[[cl]])
  data.table(var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G, r2_within = r$r2) }

blk("B10b модель (3.6) з контролем попиту банку (BLS, shift-share)", {
  if (is.null(BL)) BL <<- load_bls()
  b <- BL[, .(month, dn = bls_dem_nfc, dh = bls_dem_hh, sn = bls_std_nfc, sh = bls_std_hh)][order(month)]
  fwd12 <- function(x) { n <- length(x); vapply(seq_len(n), function(i) { j <- seq.int(i + 1L, min(i + 12L, n)); if (i >= n || sum(is.finite(x[j])) < 6) NA_real_ else mean(x[j], na.rm = TRUE) }, 0) }
  b[, `:=`(dn_f = fwd12(dn), dh_f = fwd12(dh), sn_f = fwd12(sn), sh_f = fwd12(sh))]
  e <- merge(d, b, by = "month", all.x = TRUE); setorder(e, nkb, month)
  e[, w_nfc := { L <- col0(.SD, "loans_le") + col0(.SD, "loans_hh"); shift(fifelse(L > 0, col0(.SD, "loans_le") / L, NA_real_)) }, by = nkb]
  # попит, з яким стикається банк упродовж вікна залежної змінної: середній за наступні 12 міс. баланс відповідей, зважений структурою кредитного портфеля банку
  e[, `:=`(dem_bank = (w_nfc * dn_f + (1 - w_nfc) * dh_f) / 10, std_bank = (w_nfc * sn_f + (1 - w_nfc) * sh_f) / 10, dem_now = (w_nfc * dn + (1 - w_nfc) * dh) / 10)]
  e[, `:=`(low_head = as.numeric(headroom_total_min_pp < 5), mid_head = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15))]
  CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
  core <- e[is.finite(dem_bank) & is.finite(std_bank) & is.finite(w_nfc)]
  run <- function(y, cap) rbindlist(list(
    cbind(dep = y, spec = "1. Базова (вибірка з даними BLS)", fe_reg(core, y, c(cap, CTRL))),
    cbind(dep = y, spec = "2. + попит банку (BLS) і структура портфеля", fe_reg(core, y, c(cap, CTRL, "dem_bank", "w_nfc"))),
    cbind(dep = y, spec = "3. + попит і стандарти банку (BLS)", fe_reg(core, y, c(cap, CTRL, "dem_bank", "std_bank", "w_nfc")))))
  out <- rbindlist(list(cbind(capital = "Лінійний запас", rbindlist(lapply(c("ds_L12f", "dln_L12f", "ds_S12f"), run, cap = "head"))),
                        cbind(capital = "Пороги запасу", rbindlist(lapply(c("ds_L12f", "dln_L12f", "ds_S12f"), run, cap = c("low_head", "mid_head"))))))
  save_tab(out, "S3_B10_demand_controls.csv", "B10_demand_controls")
  used <- core[stats::complete.cases(core[, c("ds_L12f", "head", CTRL, "dem_bank", "w_nfc"), with = FALSE])]   # вибірка оцінювання основної специфікації
  fact("b10_n", nrow(used)); fact("b10_banks", uniqueN(used$nkb)); fact("b10_from", as.character(min(used$month))); fact("b10_to", as.character(max(used$month)))
  fact("b10_w_nfc_mean", round(mean(used$w_nfc, na.rm = TRUE), 3))
  # чи пов'язаний попит банку з його запасом капіталу (якщо ні, пропуск попиту не зміщує оцінку капіталу)
  r <- fe_reg(core, "dem_bank", c("head", CTRL, "w_nfc")); save_tab(cbind(dep = "dem_bank", r), "S3_B10_demand_balance.csv", "B10_balance")
})

blk("B10c панель «банк × сегмент» з ефектами «сегмент × місяць»", {
  segs <- list(c("Бізнес", "loans_le"), c("Населення", "loans_hh"))
  long <- rbindlist(lapply(segs, function(s) { z <- d[, .(nkb, month, head, headroom_total_min_pp, rr_LS_w, rr_BS_w, ln_lcr, demand_share, cod, ln_assets, P, A_L, L = col0(.SD, s[2]))]
    add_lead(z, "L", 12L, "Lf"); z[, `:=`(seg = s[1], g12 = log(fifelse(Lf > 0, Lf, NA_real_)) - log(fifelse(L > 0, L, NA_real_)))]
    z[L >= 20 & L / pmax(A_L, 1) >= .05] }))
  long[, g12 := winsor(g12)]
  long[, `:=`(unit = paste(nkb, seg), segm = paste(seg, month), low_head = as.numeric(headroom_total_min_pp < 5), mid_head = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15))]
  CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
  out <- rbindlist(list(
    cbind(spec = "Ефекти банку×сегмента і місяця", capital = "Лінійний запас", fe_reg_cl(long, "g12", c("head", CTRL), "unit", "month", "nkb")),
    cbind(spec = "Ефекти банку×сегмента і сегмента×місяця", capital = "Лінійний запас", fe_reg_cl(long, "g12", c("head", CTRL), "unit", "segm", "nkb")),
    cbind(spec = "Ефекти банку×сегмента і місяця", capital = "Пороги запасу", fe_reg_cl(long, "g12", c("low_head", "mid_head", CTRL), "unit", "month", "nkb")),
    cbind(spec = "Ефекти банку×сегмента і сегмента×місяця", capital = "Пороги запасу", fe_reg_cl(long, "g12", c("low_head", "mid_head", CTRL), "unit", "segm", "nkb"))))
  # окремо за сегментами (ефекти банку і місяця в межах сегмента)
  bys <- rbindlist(lapply(c("Бізнес", "Населення"), function(s) cbind(spec = paste("Лише сегмент:", s), capital = "Лінійний запас", fe_reg_cl(long[seg == s], "g12", c("head", CTRL), "unit", "month", "nkb"))))
  save_tab(rbind(out, bys), "S3_B10_bank_segment_panel.csv", "B10_segment_panel")
  usedc <- long[stats::complete.cases(long[, c("g12", "head", CTRL), with = FALSE])]   # вибірка оцінювання
  fact("b10c_n", nrow(usedc)); fact("b10c_units", uniqueN(usedc$unit)); fact("b10c_banks", uniqueN(usedc$nkb))
})

blk("B10d панель «банк × КВЕД × місяць» з ефектами «КВЕД × місяць»", {
  # Наглядова статистика НБУ «Розподіл кредитів, наданих суб'єктам господарювання, за видами економічної діяльності» (файли Loans_KVED_*.xlsx):
  # залишки кредитів банку за розділами КВЕД (2 знаки). Фіксовані ефекти «КВЕД × місяць» поглинають попит на кредит, спільний для галузі в певному місяці;
  # ефекти «банк × КВЕД» – сталу галузеву спеціалізацію банку. Неконтрольованим лишається попит клієнтів окремого банку в межах галузі.
  if (!exists("read_loans_kved_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  kv <- tryCatch(read_loans_kved_local(), error = function(e) { message("  Loans_KVED: ", conditionMessage(e)); NULL })
  if (is.null(kv) || uniqueN(kv$month) < 24L) {
    message("  B10d пропущено: потрібна помісячна історія Loans_KVED (архів Loans_KVED.zip із сайту НБУ у data_nbu/local_inputs/loans_nbu/)")
    fact("b10d_n", 0, "немає помісячних файлів Loans_KVED")
  } else {
    KV_MIN <- 20; KV_SHARE <- .01                                   # клітинка: щонайменше 20 млн грн і 1% кредитів бізнесу банку
    CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
    mk <- function(m) as.integer(format(m, "%Y")) * 12L + as.integer(format(m, "%m"))
    x <- kv[kved != "00", .(nkb, kved, month, L = loans, Lu = loans_uah, npl)]
    x[, mkey := mk(month)]; x[, Lb := sum(L), by = .(nkb, month)]
    x <- merge(x, x[, .(nkb, kved, mkey = mkey - 12L, Lf = L, Luf = Lu)], by = c("nkb", "kved", "mkey"), all.x = TRUE)
    x[, `:=`(g12 = fifelse(L > 0 & is.finite(Lf) & Lf > 0, log(Lf) - log(L), NA_real_), g12u = fifelse(Lu >= KV_MIN & is.finite(Luf) & Luf > 0, log(Luf) - log(Lu), NA_real_),
             npl_sh = fifelse(L > 0 & is.finite(npl), pmin(pmax(npl / L, 0), 1), NA_real_), w_cell = L / pmax(Lb, 1e-9))]
    bk <- d[, c("nkb", "month", "head", "headroom_total_min_pp", CTRL), with = FALSE]
    tot_panel <- merge(x[, .(nkb, month, L)], bk[, .(nkb, month)], by = c("nkb", "month"))[, sum(L)]
    x <- merge(x[L >= KV_MIN & w_cell >= KV_SHARE], bk, by = c("nkb", "month"))
    x[, `:=`(g12 = winsor(g12), g12u = winsor(g12u), unit = paste(nkb, kved), km = paste(kved, month), mon = as.character(month),
             low_head = as.numeric(headroom_total_min_pp < 5), mid_head = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15))]
    st <- tryCatch(read_loans_stages_local(), error = function(e) NULL)
    if (!is.null(st) && "s2_share_corp" %in% names(st)) x <- merge(x, st[, .(nkb, month, s2_corp = s2_share_corp)], by = c("nkb", "month"), all.x = TRUE) else x[, s2_corp := NA_real_]
    tw_fast <- function(M, gi, gt, iters = 1000L, tol = 1e-8) { gi <- as.integer(factor(gi)); gt <- as.integer(factor(gt)); ni <- tabulate(gi); nt <- tabulate(gt)
      for (it in seq_len(iters)) { M0 <- M; M <- M - (rowsum(M, gi) / ni)[gi, , drop = FALSE]; M <- M - (rowsum(M, gt) / nt)[gt, , drop = FALSE]; if (max(abs(M - M0)) < tol) break }
      M }
    reg <- function(dt, y, xs, t) { d0 <- dt[, c("unit", t, "nkb", y, xs), with = FALSE]; setnames(d0, t, "tt"); d0 <- d0[stats::complete.cases(d0)]
      repeat { n0 <- nrow(d0); d0 <- d0[, if (.N > 1L) .SD, by = unit]; d0 <- d0[, if (.N > 1L) .SD, by = tt]; if (nrow(d0) == n0) break }   # клітинки та «КВЕД × місяць» з одним спостереженням не несуть інформації
      if (nrow(d0) < 200L) return(NULL)
      M <- tw_fast(as.matrix(d0[, c(y, xs), with = FALSE]), d0$unit, d0$tt); r <- ols_cluster(M[, 1], M[, -1, drop = FALSE], d0$nkb)
      data.table(var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G, cells = uniqueN(d0$unit), fe_time = uniqueN(d0$tt), r2_within = r$r2) }
    SP <- list(c("1. Ефекти банку×КВЕД і місяця", "g12", "mon", ""), c("2. Ефекти банку×КВЕД і КВЕД×місяця", "g12", "km", ""),
               c("3. + частка непрацюючих кредитів банку в галузі", "g12", "km", "npl_sh"), c("4. Лише гривневі кредити", "g12u", "km", ""),
               c("5. + частка стадії 2 у кредитах бізнесу банку (з 2022 р.)", "g12", "km", "s2_corp"))
    CP <- list(c("Лінійний запас", "head"), c("Пороги запасу", "low_head", "mid_head"))
    out <- rbindlist(lapply(SP, function(s) rbindlist(lapply(CP, function(cp) { if (nzchar(s[4]) && sum(is.finite(x[[s[4]]])) < 200L) return(NULL)
      r <- reg(x, s[2], c(cp[-1], CTRL, if (nzchar(s[4])) s[4]), s[3]); if (is.null(r)) NULL else cbind(spec = s[1], capital = cp[1], dep = s[2], r) }))))
    save_tab(out, "S3_B10_bank_kved_panel.csv", "B10_kved_panel")
    # вибірка основної специфікації (2)
    u <- x[stats::complete.cases(x[, c("g12", "head", CTRL), with = FALSE])]
    smp <- u[, .(obs = .N, cells = uniqueN(unit), banks = uniqueN(nkb), kved = uniqueN(kved), median_cell_mn = median(L), mean_g12 = mean(g12), sd_g12 = sd(g12), npl_share = wmean(npl_sh, L)), by = .(year = as.integer(format(month, "%Y")))][order(year)]
    save_tab(rbind(smp, u[, .(year = NA_integer_, obs = .N, cells = uniqueN(unit), banks = uniqueN(nkb), kved = uniqueN(kved), median_cell_mn = median(L), mean_g12 = mean(g12), sd_g12 = sd(g12), npl_share = wmean(npl_sh, L))]),
             "S3_B10_kved_sample.csv", "B10_kved_sample")
    m2 <- out[spec == SP[[2]][1] & capital == "Лінійний запас"][1]
    fact("b10d_n", m2$n); fact("b10d_cells", m2$cells); fact("b10d_banks", m2$banks); fact("b10d_kved", uniqueN(u$kved)); fact("b10d_fe_kved_month", m2$fe_time)
    fact("b10d_from", as.character(min(u$month))); fact("b10d_to", as.character(max(u$month))); fact("b10d_cover", round(sum(u$L) / tot_panel, 3), "частка кредитів бізнесу банків панелі, що входить до вибірки")
    # чи відрізняється галузева структура портфеля банків із малим і великим запасом капіталу
    hg <- d[is.finite(headroom_total_min_pp), .(nkb, month, grp = fifelse(headroom_total_min_pp < 5, "low", fifelse(headroom_total_min_pp < 15, "mid", "high")))]
    z <- merge(kv[kved != "00", .(nkb, month, sec = kved_section(kved), L = loans)], hg, by = c("nkb", "month"))
    sh <- z[, .(L = sum(L)), by = .(month, grp, sec)]; sh[, s := L / sum(L), by = .(month, grp)]
    okm <- sh[, uniqueN(grp), by = month][V1 == 3L, month]
    if (length(okm)) { w <- dcast(sh[month %in% okm], month + sec ~ grp, value.var = "s", fill = 0)
      dis <- w[, .(low_high = .5 * sum(abs(low - high)), low_mid = .5 * sum(abs(low - mid))), by = month]
      tb <- w[, .(low = 100 * mean(low), mid = 100 * mean(mid), high = 100 * mean(high)), by = sec][order(-(low + mid + high))]
      tb[, name := KVED_SECTIONS[sec]]; setcolorder(tb, c("sec", "name"))
      tb <- rbind(tb, data.table(sec = "", name = "Індекс відмінності структури від банків із запасом понад 15 в. п., %", low = 100 * mean(dis$low_high), mid = 100 * mean(dis$low_mid) , high = 0))
      save_tab(tb, "S3_B10_kved_structure.csv", "B10_kved_structure"); fact("b10d_dissim_low_high", round(100 * mean(dis$low_high), 1)) }
  }
})

blk("B11 надійність оцінок і механізм: секторальна панель «банк × КВЕД × місяць»", {
  # Розширення блоку B10d. Модель: ln L(i,s,t+h) − ln L(i,s,t) = α(i,s) + δ(s,t) + β·H(i,t−1) + γ·RRLS(i,t−1) + θ'X(i,t−1) + ε, h = 1, 3, 6, 12.
  # B11a горизонти й валюта (очищення від валютної переоцінки); B11b альтернативні визначення запасу капіталу й пороги 5/10/15 в. п.;
  # B11c ендогенність і специфікація; B11d довоєнна вибірка і воєнні режими; B11e стандартні похибки за перекривних горизонтів
  # (банк, банк×КВЕД, двостороння, Дрісколла–Края, неперекривна вибірка, wild cluster bootstrap, рандомізаційний тест);
  # B11f подієві дослідження: повномасштабна війна (запас перед війною) і перехід на нову структуру капіталу 05.08.2024 (експозиція банку);
  # B11g механізм: монетарний шок × запас капіталу × відносна дохідність кредитів; B11h заміщення в портфелі; B11i сценарії для 3.3.
  if (!exists("read_loans_kved_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  kv <- tryCatch(read_loans_kved_local(), error = function(e) NULL)
  if (is.null(kv) || uniqueN(kv$month) < 24L) { message("  B11 пропущено: немає помісячної історії Loans_KVED"); return(invisible()) }
  NB_WCB <- as.integer(Sys.getenv("S3_NBOOT_WCB", "999")); NB_RI <- as.integer(Sys.getenv("S3_NPERM", "99"))
  KV_MIN <- 20; KV_SHARE <- .01; H <- c(1L, 3L, 6L, 12L)
  CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
  mk <- function(m) as.integer(format(m, "%Y")) * 12L + as.integer(format(m, "%m"))
  # ---------- макродані: валютний кошик і монетарний шок
  M <- as.data.table(mac); M[, month := as.Date(month)]; setorder(M, month)
  M[, bsk := if ("fx_basket_dlog" %in% names(M)) exp(cumsum(fifelse(is.finite(fx_basket_dlog), fx_basket_dlog, 0))) else usd_eom]
  M[, `:=`(mkey = mk(month), pol = pct1(policy_eom), xp3 = pct1(exp_path_3m), xp1 = pct1(exp_path_1y), cpi = pct1(cpi_yoy))]
  M[, `:=`(dpol = pol - shift(pol), xp3_l = shift(xp3), xp1_l = shift(xp1), dpol_l = shift(pol - shift(pol)), cpi_l = shift(cpi), dcpi_l = shift(cpi - shift(cpi)), dfx_l = shift(log(bsk) - shift(log(bsk))))]
  # Шок – частина зміни облікової ставки за місяць, яку не можна передбачити за кривою дохідності ОВДП і макроданими попереднього місяця
  sh <- M[complete.cases(M[, .(dpol, xp3_l, xp1_l, dpol_l, cpi_l, dcpi_l, dfx_l)])]
  rule <- lm(dpol ~ xp3_l + xp1_l + dpol_l + cpi_l + dcpi_l + dfx_l, data = sh); sh[, mp := 100 * resid(rule)]
  M <- merge(M, sh[, .(month, mp)], by = "month", all.x = TRUE)
  save_tab(data.table(term = names(coef(rule)), coef = coef(rule), se = sqrt(diag(sandwich::vcovHC(rule, type = "HC1"))), n = nobs(rule), r2 = summary(rule)$r.squared),
           "S3_B11_mp_rule.csv", "B11_mp_rule")
  save_tab(M[is.finite(mp), .(month, dpol_pp = 100 * dpol, mp_shock_pp = mp)], "S3_B11_mp_shock.csv", "B11_mp_shock")
  fact("b11_mp_r2", round(summary(rule)$r.squared, 3)); fact("b11_mp_n", nobs(rule)); fact("b11_mp_sd", round(sd(sh$mp), 3))
  # ---------- клітинки «банк – КВЕД»
  x <- kv[kved != "00" & is.finite(loans) & loans > 0, .(nkb, kved, month, L = loans, Lu = pmax(f0(loans_uah), 0), Lfx = pmax(f0(loans_fx), 0), npl)]
  x[, mkey := mk(month)]; x[, Lb := sum(L), by = .(nkb, month)]; x <- merge(x, M[, .(mkey, bsk)], by = "mkey", all.x = TRUE)
  x[, Pf := fifelse(is.finite(npl), pmax(L - npl, 0), NA_real_)]                                 # працюючі кредити (без непрацюючих)
  bnpl <- x[, .(npl_bank = fifelse(sum(L) > 0 & any(is.finite(npl)), sum(npl, na.rm = TRUE) / sum(L), NA_real_)), by = .(nkb, mkey)]
  for (h in H) {
    f <- x[, .(nkb, kved, mkey = mkey - h, Lh = L, Luh = Lu, Lfxh = Lfx, bh = bsk, Pfh = Pf)]; x <- merge(x, f, by = c("nkb", "kved", "mkey"), all.x = TRUE)
    x[, (paste0("gp", h)) := fifelse(is.finite(Pf) & Pf >= KV_MIN & is.finite(Pfh) & Pfh > 0, log(Pfh) - log(Pf), NA_real_)]          # працюючі кредити
    x[, (paste0("gr", h)) := fifelse(is.finite(Lh), log(Lh) - log(L), NA_real_)]                                                         # без очищення
    x[, (paste0("g", h)) := fifelse(is.finite(Lh), log(Luh + Lfxh * bsk / bh) - log(L), NA_real_)]                                         # очищено від переоцінки
    x[, (paste0("gu", h)) := fifelse(Lu >= KV_MIN & is.finite(Luh) & Luh > 0, log(Luh) - log(Lu), NA_real_)]
    x[, (paste0("gf", h)) := fifelse(Lfx >= KV_MIN & is.finite(Lfxh) & Lfxh > 0, log(Lfxh / bh) - log(Lfx / bsk), NA_real_)]
    x[, c("Lh", "Luh", "Lfxh", "bh", "Pfh") := NULL] }
  pst <- x[, .(nkb, kved, mkey = mkey + 12L, Lp = L, Lup = Lu, Lfxp = Lfx, bp = bsk)]; x <- merge(x, pst, by = c("nkb", "kved", "mkey"), all.x = TRUE)
  x[, g_past := fifelse(is.finite(Lp) & Lp > 0, log(L) - log(Lup + Lfxp * bsk / bp), NA_real_)]; x[, c("Lp", "Lup", "Lfxp", "bp") := NULL]
  x[, npl_sh := fifelse(is.finite(npl), pmin(pmax(npl / L, 0), 1), NA_real_)]
  x <- x[L >= KV_MIN & L / Lb >= KV_SHARE]
  for (v in grep("^g[a-z]*[0-9]+$|^g_past$", names(x), value = TRUE)) set(x, j = v, value = winsor(x[[v]]))
  # ---------- банк: стан на кінець попереднього місяця (t−1), а також на t і t−12
  B <- d[, c("nkb", "month", "headroom_total_min_pp", "headroom_cet1_min_pp", "total_ratio_pct", "reg_capital_mn", "risk_exposure_implied_mn", "minimum_total_pct", "owner", "fin_profit_m", "assets", CTRL), with = FALSE]
  B[, `:=`(mkey = mk(month), roa = roll_sum(fin_profit_m, annualise = TRUE) / fifelse(assets > 0, assets, NA_real_)), by = nkb]
  B[, gap_own := total_ratio_pct - median(total_ratio_pct[month < as.Date("2022-03-01")], na.rm = TRUE), by = nkb]
  B[!is.finite(gap_own), gap_own := total_ratio_pct - median(total_ratio_pct, na.rm = TRUE), by = nkb]
  B <- merge(B, bnpl, by = c("nkb", "mkey"), all.x = TRUE)
  LB <- x[, .(Lbiz = Lb[1]), by = .(nkb, mkey)]; B <- merge(B, LB, by = c("nkb", "mkey"), all.x = TRUE)
  B[, exc_cap := winsor(fifelse(Lbiz > 0 & is.finite(risk_exposure_implied_mn), risk_exposure_implied_mn * headroom_total_min_pp / 100 / Lbiz, NA_real_))]
  BV <- c("headroom_total_min_pp", "headroom_cet1_min_pp", "gap_own", "exc_cap", "roa", "npl_bank", CTRL)
  lagB <- function(k, sfx) { z <- B[, c("nkb", "mkey", BV), with = FALSE]; z[, mkey := mkey + k]; setnames(z, BV, paste0(BV, sfx)); z }
  x <- merge(x, lagB(1L, ""), by = c("nkb", "mkey"))                         # основна специфікація: стан банку в t−1
  x <- merge(x, lagB(0L, "_c"), by = c("nkb", "mkey"), all.x = TRUE)          # поточний стан (t)
  x <- merge(x, lagB(12L, "_l12"), by = c("nkb", "mkey"), all.x = TRUE)       # t−12
  x <- merge(x, unique(B[, .(nkb, owner)], by = "nkb"), by = "nkb", all.x = TRUE)
  hp <- function(v) pmin(pmax(v, -5), 50)
  mkcap <- function(dt, sfx = "") { hr <- dt[[paste0("headroom_total_min_pp", sfx)]]
    dt[, (paste0("head", sfx)) := hp(hr) / 10]; dt[, (paste0("low", sfx)) := as.numeric(hr < 5)]; dt[, (paste0("mid", sfx)) := as.numeric(hr >= 5 & hr < 15)] }
  mkcap(x); mkcap(x, "_c"); mkcap(x, "_l12")
  x[, `:=`(below10 = as.numeric(headroom_total_min_pp < 10), below15 = as.numeric(headroom_total_min_pp < 15), gap10 = pmin(pmax(gap_own, -30), 30) / 10,
           lowcet1 = as.numeric(headroom_cet1_min_pp < 5), exc = exc_cap, unit = paste(nkb, kved), km = paste(kved, mkey), tt = mkey)]
  x[, `:=`(rrs = rr_LS_w * 10, mp = M$mp[match(mkey + 1L, M$mkey)])]     # шок у першому місяці вікна; стан банку – на кінець попереднього місяця
  fact("b11_n_cells", uniqueN(x$unit)); fact("b11_banks", uniqueN(x$nkb))
  # ---------- оцінювач: двосторонні фіксовані ефекти, кілька варіантів стандартних похибок
  has_collapse <- FALSE   # collapse::fhdwithin потребує fixest для двох вимірів ефектів
  dm <- function(Mx, f1, f2, w = NULL) {
    if (has_collapse && is.null(w)) return(as.matrix(collapse::fhdwithin(Mx, list(f1 = factor(f1), f2 = factor(f2)))))
    g1 <- as.integer(factor(f1)); g2 <- as.integer(factor(f2)); ww <- if (is.null(w)) rep(1, nrow(Mx)) else w
    n1 <- as.vector(rowsum(ww, g1)); n2 <- as.vector(rowsum(ww, g2))
    for (it in 1:2000) { M0 <- Mx; Mx <- Mx - (rowsum(Mx * ww, g1) / n1)[g1, , drop = FALSE]; Mx <- Mx - (rowsum(Mx * ww, g2) / n2)[g2, , drop = FALSE]
      if (max(abs(Mx - M0)) < 1e-8) break }
    Mx }
  prep <- function(dt, y, xs, fe2 = "km", w = NULL) {
    z <- dt[, unique(c("unit", fe2, "nkb", "kved", "tt", y, xs, w)), with = FALSE]; setnames(z, fe2, "FE2")
    z <- z[stats::complete.cases(z) & Reduce(`&`, lapply(z[, c(y, xs), with = FALSE], is.finite))]
    repeat { n0 <- nrow(z); z <- z[, if (.N > 1L) .SD, by = unit]; z <- z[, if (.N > 1L) .SD, by = FE2]; if (nrow(z) == n0) break }
    if (nrow(z) < 300L) return(NULL)
    if (any(apply(as.matrix(z[, ..xs]), 2, function(v) length(unique(v)) < 2L))) return(NULL)
    ww <- if (is.null(w)) NULL else z[[w]] / mean(z[[w]])
    Mx <- dm(as.matrix(z[, c(y, xs), with = FALSE]), z$unit, z$FE2, ww)
    if (!is.null(ww)) Mx <- Mx * sqrt(ww)
    list(y = Mx[, 1], X = Mx[, -1, drop = FALSE], z = z, xs = xs) }
  meat <- function(X, u, g) { S <- matrix(0, ncol(X), ncol(X)); for (s in split(seq_along(u), g)) { v <- crossprod(X[s, , drop = FALSE], u[s]); S <- S + tcrossprod(v) }; S }
  vc <- function(P, b, type = "bank", L = 12L) {
    X <- P$X; u <- drop(P$y - X %*% b); XtXi <- solve(crossprod(X)); n <- nrow(X); k <- ncol(X)
    cl <- function(g) { G <- length(unique(g)); list(V = G / (G - 1) * (n - 1) / (n - k) * XtXi %*% meat(X, u, g) %*% XtXi, G = G) }
    if (type == "bank") return(cl(P$z$nkb)); if (type == "cell") return(cl(P$z$unit))
    if (type == "twoway") { a <- cl(P$z$nkb); b2 <- cl(P$z$tt); c2 <- cl(paste(P$z$nkb, P$z$tt)); V <- a$V + b2$V - c2$V
      e <- eigen(V, symmetric = TRUE); V <- e$vectors %*% diag(pmax(e$values, 0), length(e$values)) %*% t(e$vectors); return(list(V = V, G = min(a$G, b2$G))) }
    if (type == "dk") { tt <- P$z$tt; ts <- sort(unique(tt)); Sx <- rowsum(X * u, tt)[as.character(ts), , drop = FALSE]
      S <- crossprod(Sx); for (l in seq_len(L)) { w <- 1 - l / (L + 1); idx <- which((ts - l) %in% ts); if (!length(idx)) next
        A <- Sx[idx, , drop = FALSE]; Bm <- Sx[match(ts[idx] - l, ts), , drop = FALSE]; G0 <- crossprod(A, Bm); S <- S + w * (G0 + t(G0)) }
      return(list(V = XtXi %*% S %*% XtXi, G = length(ts))) } }
  est <- function(dt, y, xs, fe2 = "km", se = "bank", w = NULL, L = 12L) {
    P <- prep(dt, y, xs, fe2, w); if (is.null(P)) return(NULL); b <- drop(solve(crossprod(P$X), crossprod(P$X, P$y))); v <- vc(P, b, se, L)
    s <- sqrt(pmax(diag(v$V), 0)); data.table(var = xs, coef = b, se = s, p = 2 * pt(-abs(b / s), max(v$G - 1, 1)), n = nrow(P$X), banks = uniqueN(P$z$nkb),
                                           cells = uniqueN(P$z$unit), r2_within = 1 - sum((P$y - P$X %*% b)^2) / sum(P$y^2)) }
  CT <- CTRL; THR <- c("low", "mid"); LIN <- "head"
  run <- function(lab, dt, y, cap, extra = NULL, ...) { r <- est(dt, y, c(cap, CT, extra), ...); if (is.null(r)) NULL else cbind(spec = lab, dep = y, r) }
  # ---------- B11a: горизонти, валюта, очищення від переоцінки
  DEP <- c(g = "Усі кредити, очищено від валютної переоцінки", gr = "Усі кредити, без очищення", gu = "Гривневі кредити", gf = "Валютні кредити в постійній валюті", gp = "Працюючі кредити (без непрацюючих)")
  a <- rbindlist(lapply(H, function(h) rbindlist(lapply(names(DEP), function(k) rbindlist(list(
    cbind(h = h, depl = DEP[[k]], capital = "Пороги запасу", run("B11a", x, paste0(k, h), THR)),
    cbind(h = h, depl = DEP[[k]], capital = "Лінійний запас", run("B11a", x, paste0(k, h), LIN))), fill = TRUE)))), fill = TRUE)
  save_tab(a, "S3_B11_horizons_currency.csv", "B11_horizons")
  base <- a[h == 12 & depl == DEP[["g"]] & capital == "Пороги запасу" & var == "low"]
  fact("b11_low12", round(base$coef, 4)); fact("b11_low12_se", round(base$se, 4)); fact("b11_low12_n", base$n); fact("b11_low12_banks", base$banks); fact("b11_low12_cells", base$cells)
  # ---------- B11b: альтернативні визначення запасу капіталу
  b <- rbindlist(list(
    run("1. Пороги 5 і 15 в. п. (основна)", x, "g12", THR), run("2. Запас до 5 в. п.", x, "g12", "low"), run("3. Запас до 10 в. п.", x, "g12", "below10"),
    run("4. Запас до 15 в. п.", x, "g12", "below15"), run("5. Лінійний запас (на 10 в. п.)", x, "g12", LIN),
    run("6. Відхилення від власного довоєнного рівня (на 10 в. п.)", x, "g12", "gap10"),
    run("7. Надлишковий капітал до кредитів бізнесу", x, "g12", "exc"),
    run("8. Запас CET1 до 5 в. п. (з серпня 2024 р.)", x[mkey >= mk(as.Date("2024-08-01"))], "g12", "lowcet1")), fill = TRUE)
  save_tab(b, "S3_B11_capital_definitions.csv", "B11_capital_defs")
  # ---------- B11c: ендогенність і специфікація
  x[, wcell := L]
  c3 <- rbindlist(list(
    run("1. Стан банку в t−1 (основна)", x, "g12", THR), run("2. Стан банку в t", x, "g12", c("low_c", "mid_c")),
    run("3. Стан банку в t−12", x, "g12", c("low_l12", "mid_l12")),
    run("4. + минуле зростання клітинки", x, "g12", THR, "g_past"), run("5. + ROA і частка NPL банку", x, "g12", THR, c("roa", "npl_bank")),
    run("6. + частка NPL банку в галузі", x, "g12", THR, "npl_sh"), run("7. Без державних банків", x[owner != "State"], "g12", THR),
    run("8. Зважено на обсяг кредитів клітинки", x, "g12", THR, w = "wcell"),
    run("9. Ефекти банку×КВЕД і місяця", x, "g12", THR, fe2 = "tt")), fill = TRUE)
  save_tab(c3, "S3_B11_endogeneity.csv", "B11_endogeneity")
  # плацебо: минуле зростання (t−12 → t) на запас капіталу в t
  pl <- rbindlist(list(run("Плацебо: зростання за попередні 12 місяців", x, "g_past", c("low_c", "mid_c")),
                       run("Плацебо: зростання за попередні 12 місяців (лінійний запас)", x, "g_past", "head_c")), fill = TRUE)
  save_tab(pl, "S3_B11_placebo_past.csv", "B11_placebo")
  # ---------- B11d: періоди
  PER <- list(c("Довоєнний період (вікна до лютого 2022 р.)", "2019-01-01", "2021-01-31"), c("Повномасштабна війна, усе (з березня 2022 р.)", "2022-03-01", "2099-01-01"),
              c("Воєнний шок (03.2022–06.2023)", "2022-03-01", "2023-06-30"), c("Пом'якшення 2023–2024", "2023-07-01", "2024-11-30"), c("Посилення 2025", "2024-12-01", "2099-01-01"),
              c("Без вікон, що перетинають лютий 2022 р.", "2019-01-01", "2099-01-01"))
  dper <- rbindlist(lapply(PER, function(p) { z <- x[month >= as.Date(p[2]) & month <= as.Date(p[3])]
    if (grepl("^Без вікон", p[1])) z <- z[!(month >= as.Date("2021-02-01") & month <= as.Date("2022-02-28"))]
    rbindlist(list(cbind(capital = "Пороги запасу", run(p[1], z, "g12", THR)), cbind(capital = "Лінійний запас", run(p[1], z, "g12", LIN))), fill = TRUE) }), fill = TRUE)
  save_tab(dper, "S3_B11_periods.csv", "B11_periods")
  # ---------- B11e: стандартні похибки за перекривних 12-місячних горизонтів
  se_tab <- rbindlist(lapply(c(12L, 1L), function(h) { y <- paste0("g", h)
    rbindlist(list(cbind(h = h, method = "Кластери за банками", est(x, y, c(THR, CT), se = "bank")), cbind(h = h, method = "Кластери за парами «банк – КВЕД»", est(x, y, c(THR, CT), se = "cell")),
                   cbind(h = h, method = "Двостороння кластеризація: банк і місяць", est(x, y, c(THR, CT), se = "twoway")),
                   cbind(h = h, method = sprintf("Дрісколл–Края, %d лагів", max(h, 3L)), est(x, y, c(THR, CT), se = "dk", L = max(h, 3L))))) }))
  nov <- x[as.integer(format(month, "%m")) == 12L]                                                     # неперекривна вибірка: лише грудневі стани
  se_tab <- rbind(se_tab, cbind(h = 12L, method = "Неперекривні вікна (стан на грудень), кластери за банками", est(nov, "g12", c(THR, CT), fe2 = "km")), fill = TRUE)
  # wild cluster bootstrap-t з обмеженням нульової гіпотези (Rademacher), кластери за банками
  P <- prep(x, "g12", c(THR, CT)); j <- 1L; Xr <- P$X[, -j, drop = FALSE]
  br <- drop(solve(crossprod(Xr), crossprod(Xr, P$y))); ur <- drop(P$y - Xr %*% br); fr <- drop(Xr %*% br)
  b0 <- drop(solve(crossprod(P$X), crossprod(P$X, P$y))); t0 <- b0[j] / sqrt(vc(P, b0, "bank")$V[j, j])
  gidx <- as.integer(factor(P$z$nkb)); G <- max(gidx); XtXi <- solve(crossprod(P$X))
  tstar <- vapply(seq_len(NB_WCB), function(r) { w <- sample(c(-1, 1), G, TRUE)[gidx]; ys <- fr + ur * w; bs <- drop(XtXi %*% crossprod(P$X, ys)); us <- ys - drop(P$X %*% bs)
    S <- meat(P$X, us, gidx); V <- G / (G - 1) * (nrow(P$X) - 1) / (nrow(P$X) - ncol(P$X)) * XtXi %*% S %*% XtXi; bs[j] / sqrt(V[j, j]) }, numeric(1))
  p_wcb <- mean(abs(tstar) >= abs(t0))
  # рандомізаційний тест: траєкторії запасу капіталу переставлено між банками
  bk <- unique(x$nkb); hb <- B[, .(nkb, mkey = mkey + 1L, hr = headroom_total_min_pp)]
  ri <- vapply(seq_len(NB_RI), function(r) { pm <- setNames(sample(bk), bk); z <- copy(x[, c("nkb", "mkey", "unit", "km", "kved", "tt", "g12", CT), with = FALSE])
    z[, nkb_p := pm[nkb]]; z <- merge(z, hb, by.x = c("nkb_p", "mkey"), by.y = c("nkb", "mkey"))
    z[, `:=`(low = as.numeric(hr < 5), mid = as.numeric(hr >= 5 & hr < 15))]; r0 <- est(z, "g12", c(THR, CT)); if (is.null(r0)) NA_real_ else r0[var == "low", coef] }, numeric(1))
  p_ri <- mean(abs(ri[is.finite(ri)]) >= abs(b0[j]))
  se_tab <- rbind(se_tab, data.table(h = 12L, method = c(sprintf("Wild cluster bootstrap-t, %d повторень (p-значення)", NB_WCB), sprintf("Рандомізаційний тест, %d перестановок (p-значення)", sum(is.finite(ri)))),
                                     var = "low", coef = b0[j], p = c(p_wcb, p_ri)), fill = TRUE)
  save_tab(se_tab, "S3_B11_standard_errors.csv", "B11_se"); fact("b11_p_wcb", round(p_wcb, 3)); fact("b11_p_ri", round(p_ri, 3))
  # ---------- B11f: подієві дослідження
  bins <- function(k, lo, hi, width = 3L) { b <- floor(k / width); b[k < lo] <- floor(lo / width); b[k > hi] <- floor(hi / width); b }
  ev <- function(z, treat, ev_month, lo, hi, ref = -1L, lab, extra = NULL) {
    z <- copy(z); k <- z$mkey - mk(as.Date(ev_month)); z[, eb := bins(k, lo, hi)]; z <- z[k >= lo & k <= hi & is.finite(get(treat))]
    for (v in extra) z <- z[is.finite(get(v))]
    lv <- setdiff(sort(unique(z$eb)), ref); for (l in lv) z[, (paste0("e", ifelse(l < 0, "m", "p"), abs(l))) := as.numeric(eb == l) * get(treat)]
    xs <- paste0("e", ifelse(lv < 0, "m", "p"), abs(lv)); xe <- NULL
    for (v in extra) for (l in lv) { nm <- paste0("x_", v, "_", ifelse(l < 0, "m", "p"), abs(l)); z[, (nm) := as.numeric(eb == l) * get(v)]; xe <- c(xe, nm) }
    r <- est(z, "lnL", c(xs, xe)); if (!is.null(r)) r <- r[var %in% xs]
    if (is.null(r)) return(NULL); r[, `:=`(design = lab, bin = lv, k_from = lv * 3L, k_to = lv * 3L + 2L)]; rbind(r, data.table(design = lab, var = "ref", bin = ref, coef = 0, se = 0, p = NA_real_), fill = TRUE) }
  # (1) війна: запас капіталу перед війною (середнє за 07–12.2021, на 10 в. п.), рівень кредитів у постійній валюті грудня 2021 р.
  w0 <- B[month >= as.Date("2021-07-01") & month <= as.Date("2021-12-01"), .(H0 = hp(mean(headroom_total_min_pp, na.rm = TRUE)) / 10), by = nkb]
  bref <- M[month == as.Date("2021-12-01"), bsk]
  e1 <- merge(x[, .(nkb, kved, mkey, month, unit, km, tt, lnL = log(Lu + Lfx * bref / bsk))], w0, by = "nkb")
  e1 <- e1[unit %in% e1[month >= as.Date("2021-10-01") & month <= as.Date("2021-12-01"), unique(unit)]]
  ev1 <- ev(e1, "H0", "2022-02-01", -36L, 41L, -1L, "Війна: запас капіталу перед війною (на 10 в. п.)")
  # з поправкою на диференційований довоєнний тренд: нахил H0 × час оцінено лише до війни і віднято від усієї траєкторії
  e1[, kk := mkey - mk(as.Date("2022-02-01"))]; e1[, hk := H0 * kk]
  tr <- est(e1[kk < 0 & kk >= -36L], "lnL", "hk"); slope <- if (is.null(tr)) 0 else tr$coef
  e1d <- copy(e1)[, lnL := lnL - slope * hk]
  ev1d <- ev(e1d, "H0", "2022-02-01", -36L, 41L, -1L, "Війна: з поправкою на довоєнний тренд")
  # пруденційні пояснення довоєнного тренду: (а) запас до врахування операційного ризику (07–11.2021); (б) запас на початку довоєнного періоду (12.2018–03.2019);
  # (в) контроль експозиції до операційного ризику, врахованого в нормативі з грудня 2021 р. (частка в активах, зважених за ризиком), взаємодіяної з часовими інтервалами
  w0b <- B[month >= as.Date("2021-07-01") & month <= as.Date("2021-11-01"), .(H0b = hp(mean(headroom_total_min_pp, na.rm = TRUE)) / 10), by = nkb]
  w0c <- B[month >= as.Date("2018-12-01") & month <= as.Date("2019-03-01"), .(H0c = hp(mean(headroom_total_min_pp, na.rm = TRUE)) / 10), by = nkb]
  opx <- as.data.table(pr)[as.Date(month) == as.Date("2021-12-01") & is.finite(operational_risk_equivalent_mn) & risk_exposure_implied_mn > 0,
                           .(opx = operational_risk_equivalent_mn / risk_exposure_implied_mn), by = .(nkb = as.character(nkb))]
  opx[, opx := (opx - mean(opx)) / sd(opx)]
  e1x <- Reduce(function(a_, b_) merge(a_, b_, by = "nkb", all.x = TRUE), list(e1, w0b, w0c, opx))
  ev1b <- ev(e1x, "H0b", "2022-02-01", -36L, 41L, -1L, "Війна: запас до врахування операційного ризику (07–11.2021)")
  ev1c <- ev(e1x, "H0c", "2022-02-01", -36L, 41L, -1L, "Війна: запас на початку періоду (12.2018–03.2019)")
  ev1e <- ev(e1x, "H0", "2022-02-01", -36L, 41L, -1L, "Війна: з контролем експозиції до операційного ризику", extra = "opx")
  fact("b11_opx_banks", nrow(opx)); fact("b11_war_corr_H0_H0c", round(cor(e1x[!duplicated(nkb)]$H0, e1x[!duplicated(nkb)]$H0c, use = "complete.obs"), 2))
  # хронологія пруденційних змін за звітністю банків
  pt <- as.data.table(pr)[, .(min_total = paste(sort(unique(minimum_total_pct)), collapse = "/"), regime = paste(sort(unique(capital_regime)), collapse = "/"),
                              op_banks = sum(f0(operational_risk_equivalent_mn) > 0), mr_banks = sum(f0(market_risk_equivalent_mn) > 0), lev_banks = sum(is.finite(leverage_pct)), banks = .N), by = .(month = as.Date(month))]
  setorder(pt, month); ch <- pt[, chg := min_total != shift(min_total) | regime != shift(regime) | (op_banks > 0) != (shift(op_banks) > 0) | (mr_banks > 0) != (shift(mr_banks) > 0) | (lev_banks > 0) != (shift(lev_banks) > 0)][chg == TRUE]
  save_tab(ch[, !"chg"], "S3_B11_prudential_timeline.csv", "B11_prudential")
  fact("b11_war_pretrend_slope", round(slope, 5)); fact("b11_war_pretrend_se", if (is.null(tr)) NA else round(tr$se, 5))
  # (2) перехід на нову структуру капіталу 05.08.2024: зміна запасу капіталу банку в серпні 2024 р. (втрата, на 10 в. п.)
  ex <- B[month %in% as.Date(c("2024-07-01", "2024-08-01")), .(dH = headroom_total_min_pp[month == as.Date("2024-08-01")][1] - headroom_total_min_pp[month == as.Date("2024-07-01")][1],
                                                                  H7 = headroom_total_min_pp[month == as.Date("2024-07-01")][1]), by = nkb][is.finite(dH)]
  ex[, loss := pmin(pmax(-dH, -30), 30) / 10]
  bref2 <- M[month == as.Date("2024-07-01"), bsk]
  e2 <- merge(x[, .(nkb, kved, mkey, month, unit, km, tt, lnL = log(Lu + Lfx * bref2 / bsk))], ex[, .(nkb, loss)], by = "nkb")
  e2 <- e2[unit %in% e2[month >= as.Date("2024-05-01") & month <= as.Date("2024-07-01"), unique(unit)]]
  ev2 <- ev(e2, "loss", "2024-08-01", -12L, 25L, -1L, "Нова структура капіталу 08.2024: втрата запасу (на 10 в. п.)")
  near <- ex[H7 < 20, nkb]
  ev2n <- ev(e2[nkb %in% near], "loss", "2024-08-01", -12L, 25L, -1L, "Нова структура капіталу: банки із запасом до 20 в. п. у липні 2024 р.")
  fact("b11_reform_near_banks", length(near))
  save_tab(rbind(ev1, ev1d, ev1b, ev1c, ev1e, ev2, ev2n, fill = TRUE), "S3_B11_event_studies.csv", "B11_events")
  save_tab(ex[, .(nkb, dH_pp = dH, H_jul2024 = H7)], "S3_B11_reform_exposure.csv", "B11_exposure")
  fact("b11_reform_banks", nrow(ex)); fact("b11_reform_dH_mean", round(mean(ex$dH), 2)); fact("b11_reform_dH_sd", round(sd(ex$dH), 2))
  # перший етап і 2МНК: запас капіталу (на 10 в. п.) інструментовано експозицією × після реформи
  e2[, post := as.numeric(mkey >= mk(as.Date("2024-08-01")))]; e2[, zinst := loss * post]
  e2 <- merge(e2, B[, .(nkb, mkey, headH = hp(headroom_total_min_pp) / 10)], by = c("nkb", "mkey"))
  e2 <- e2[mkey >= mk(as.Date("2023-08-01"))]
  ivrun <- function(z, lab) { rf <- est(z, "lnL", "zinst"); fs <- est(z, "headH", "zinst"); P2 <- prep(z, "lnL", c("headH", "zinst")); iv <- NULL
    if (!is.null(P2)) { y2 <- P2$y; xh <- P2$X[, 1]; zz <- P2$X[, 2]; biv <- sum(zz * y2) / sum(zz * xh); u <- y2 - biv * xh
      g2 <- P2$z$nkb; G2 <- uniqueN(g2); mt <- sum(vapply(split(seq_along(u), g2), function(s) sum(zz[s] * u[s])^2, numeric(1)))
      se_iv <- sqrt(G2 / (G2 - 1) * mt) / abs(sum(zz * xh)); iv <- data.table(var = "headH", coef = biv, se = se_iv, p = 2 * pt(-abs(biv / se_iv), G2 - 1), n = length(y2), banks = G2) }
    F1 <- if (!is.null(fs)) (fs[var == "zinst", coef / se])^2 else NA_real_
    rbind(cbind(sample = lab, stage = "Скорочена форма: ln кредитів", rf), cbind(sample = lab, stage = "Перший етап: запас капіталу", fs, F = F1),
          cbind(sample = lab, stage = "2МНК", iv), fill = TRUE) }
  ivt <- rbind(ivrun(e2, "Усі банки"), ivrun(e2[nkb %in% near], "Банки із запасом до 20 в. п. у липні 2024 р."), fill = TRUE)
  save_tab(ivt, "S3_B11_reform_iv.csv", "B11_iv"); fact("b11_iv_F", round(ivt[sample == "Усі банки" & stage == "Перший етап: запас капіталу", F][1], 1))
  # ---------- B11g: механізм – монетарний шок × запас капіталу × відносна дохідність
  x[, `:=`(hc = head - mean(head, na.rm = TRUE), rc = rrs - mean(rrs, na.rm = TRUE))]
  x[, `:=`(mp_h = mp * hc, mp_r = mp * rc, h_r = hc * rc, mp_low = mp * low)]
  MX <- c("mp_h", "mp_r", "h_r", "hc", "rc", setdiff(CT, "rr_LS_w"))
  g <- rbindlist(lapply(c(3L, 6L, 12L), function(h) { y <- paste0("g", h); z <- x[is.finite(mp)]
    rbindlist(list(cbind(h = h, spec = "1. Безперервний запас", est(z, y, MX)),
                   cbind(h = h, spec = "2. Шок × запас до 5 в. п.", est(z, y, c("mp_low", "mp_r", "low", "mid", "rc", setdiff(CT, "rr_LS_w")))),
                   cbind(h = h, spec = "3. Без 2022 р.", est(z[!(month >= as.Date("2022-01-01") & month <= as.Date("2022-12-01"))], y, MX)),
                   cbind(h = h, spec = "4. Двостороння кластеризація", est(z, y, MX, se = "twoway")))) }))
  save_tab(g, "S3_B11_mechanism.csv", "B11_mechanism")
  # ---------- B11h: заміщення в портфелі банку (частки активів, зміна за 12 місяців)
  q <- copy(d[, .(nkb, month, s_L, s_B, s_S, s_O, headroom_total_min_pp, rr_LS_w, rr_BS_w, ln_lcr, demand_share, cod, ln_assets)])
  q[, mkey := mk(month)]; f12 <- q[, .(nkb, mkey = mkey - 12L, fL = s_L, fB = s_B, fS = s_S, fO = s_O)]; q <- merge(q, f12, by = c("nkb", "mkey"))
  q[, `:=`(dL = 100 * (fL - s_L), dB = 100 * (fB - s_B), dS = 100 * (fS - s_S), dO = 100 * (fO - s_O), low = as.numeric(headroom_total_min_pp < 5), mid = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15))]
  q <- q[month >= as.Date("2019-01-01")]
  sub_tab <- rbindlist(lapply(names(c(dL = 1, dB = 1, dS = 1, dO = 1)), function(v) { r <- fe_reg(q, v, c("low", "mid", CT)); cbind(asset = c(dL = "Кредити", dB = "ОВДП", dS = "Депозитні сертифікати НБУ", dO = "Інші ліквідні активи")[[v]], r) }))
  sub_war <- rbindlist(lapply(names(c(dL = 1, dB = 1, dS = 1, dO = 1)), function(v) { r <- fe_reg(q[month >= as.Date("2022-03-01")], v, c("low", "mid", CT)); cbind(asset = c(dL = "Кредити", dB = "ОВДП", dS = "Депозитні сертифікати НБУ", dO = "Інші ліквідні активи")[[v]], r) }))
  save_tab(rbind(cbind(period = "Увесь період", sub_tab), cbind(period = "З березня 2022 р.", sub_war)), "S3_B11_substitution.csv", "B11_substitution")
  # ---------- B11i: сценарії для 3.3 за оцінками секторальної панелі (сценарна реакція моделі, а не причинний ефект політики)
  last <- max(x[is.finite(low), mkey]); cur <- x[mkey == last]
  r_diff <- est(x, "g12", c("low", "below15", CT))[var == "low"]          # різниця між групами «до 5 в. п.» і «5–15 в. п.»
  r_mid <- a[h == 12 & depl == DEP[["g"]] & capital == "Пороги запасу" & var == "mid"]
  cap_need <- function(target) { z <- B[mkey == last - 1L & nkb %in% cur[low == 1, unique(nkb)]]; sum(pmax(target - z$headroom_total_min_pp, 0) / 100 * z$risk_exposure_implied_mn, na.rm = TRUE) / 1e3 }
  r_low <- base; r_npl <- c3[spec == "6. + частка NPL банку в галузі" & var == "npl_sh"]; r_rr <- a[h == 12 & depl == DEP[["g"]] & capital == "Пороги запасу" & var == "rr_LS_w"]
  Lall <- sum(cur$L); Llow <- sum(cur[low == 1, L]); nlow <- uniqueN(cur[low == 1, nkb])
  sc <- function(lab, Lbase, dlog, se) data.table(scenario = lab, base_bn = Lbase / 1e3, effect_bn = Lbase * (exp(dlog) - 1) / 1e3,
                                                 lo_bn = Lbase * (exp(dlog - 1.96 * abs(se)) - 1) / 1e3, hi_bn = Lbase * (exp(dlog + 1.96 * abs(se)) - 1) / 1e3, pct = 100 * (exp(dlog) - 1))
  scen <- rbindlist(fill = TRUE, list(
    cbind(sc(sprintf("Капітальна підтримка: запас банків нижче 5 в. п. (%d банків) піднято до 5 в. п.", nlow), Llow, -r_diff$coef, r_diff$se), capital_bn = cap_need(5)),
    cbind(sc(sprintf("Капітальна підтримка: запас банків нижче 5 в. п. (%d банків) піднято до 15 в. п.", nlow), Llow, -r_low$coef, r_low$se), capital_bn = cap_need(15)),
    sc("Зниження частки непрацюючих кредитів у кожній галузі на 10 в. п.", Lall, -0.10 * r_npl$coef, 0.10 * r_npl$se),
    sc("Зниження дохідності сертифікатів НБУ на 200 б. п. (відносна дохідність кредитів +2 в. п.)", Lall, 0.02 * r_rr$coef, 0.02 * r_rr$se)))
  scen[, month := as.character(as.Date(sprintf("%d-%02d-01", (last - 1L) %/% 12L, (last - 1L) %% 12L + 1L)))]
  save_tab(scen, "S3_B11_scenarios.csv", "B11_scenarios")
  fact("b11_scen_month", scen$month[1]); fact("b11_scen_low_banks", nlow)
  # ---------- рисунок подієвих досліджень
  es <- rbind(ev1, ev1d, ev2, fill = TRUE)[is.finite(coef)]; es[, mid_k := fifelse(var == "ref", -2, k_from + 1)]
  pfig <- ggplot(es, aes(mid_k, 100 * coef)) + geom_hline(yintercept = 0, linewidth = .3) + geom_vline(xintercept = -.5, linetype = "22", linewidth = .3) +
    geom_errorbar(aes(ymin = 100 * (coef - 1.96 * se), ymax = 100 * (coef + 1.96 * se)), width = 0, colour = "grey45") + geom_point(size = 1.4) +
    facet_wrap(~ design, ncol = 1, scales = "free") + labs(x = "Місяців від події", y = "Логарифмічні пункти × 100", caption = CAP) + theme_thesis()
  save_fig(pfig, "S3_F25_event_studies.png", 8.5, 7.2)
})

blk("B12 чутливість відносної дохідності кредитів до припущень про кредитні втрати й альтернативну дохідність", {
  # RR_LS = y_L − c − плата за капітал − альтернативна дохідність. Варіанти: вартість ризику за цикл (середня банку за весь період), очікувані втрати за МСФЗ 9
  # (покриття резервами кредитів стадій 1–2, з 03.2022), вартість ризику ×0,5 і ×1,5, альтернатива – дохідність ОВДП або облікова ставка, плата за капітал ×2.
  if (!exists("read_loans_stages_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  st <- tryCatch(read_loans_stages_local(), error = function(e) NULL)
  z <- copy(D0[is.finite(rr_LS), .(nkb, month, A_L, y_L, cc, cap_charge, y_S_alt, y_B, pol, rr_LS, phase)])
  z[, cc_ttc := mean(cc, na.rm = TRUE), by = nkb]
  if (!is.null(st)) { s2 <- st[, .(nkb, month, cc_el = fifelse(f0(gross_corp) + f0(gross_hh) > 0,
                                                            (abs(f0(cov_s12_corp)) * f0(gross_corp) + abs(f0(cov_s12_hh)) * f0(gross_hh)) / (f0(gross_corp) + f0(gross_hh)), NA_real_))]
    z <- merge(z, s2, by = c("nkb", "month"), all.x = TRUE) } else z[, cc_el := NA_real_]
  yB_sys <- z[is.finite(y_B), .(yB_sys = wmean(y_B, A_L)), by = month]; z <- merge(z, yB_sys, by = "month", all.x = TRUE)
  V <- list("1. Базовий розрахунок" = z$rr_LS,
            "2. Вартість ризику за цикл (середня банку)" = z$y_L - z$cc_ttc - z$cap_charge - z$y_S_alt,
            "3. Очікувані втрати за МСФЗ 9 (з 03.2022)" = z$y_L - z$cc_el - z$cap_charge - z$y_S_alt,
            "4. Вартість ризику × 0,5" = z$y_L - .5 * z$cc - z$cap_charge - z$y_S_alt,
            "5. Вартість ризику × 1,5" = z$y_L - 1.5 * z$cc - z$cap_charge - z$y_S_alt,
            "6. Альтернатива – дохідність ОВДП" = z$y_L - z$cc - z$cap_charge - fifelse(is.finite(z$y_B), z$y_B, z$yB_sys),
            "7. Альтернатива – облікова ставка" = z$y_L - z$cc - z$cap_charge - z$pol,
            "8. Плата за капітал × 2" = z$y_L - z$cc - 2 * z$cap_charge - z$y_S_alt)
  out <- rbindlist(lapply(names(V), function(v) { zz <- copy(z)[, r := V[[v]]][is.finite(r)]
    m <- zz[, .(rr = wmean(r, A_L), neg = mean(r < 0)), by = .(month, phase)]
    m[, .(variant = v, rr_pp = 100 * mean(rr), share_neg_banks = 100 * mean(neg), months = .N), by = phase] }))
  setorder(out, variant, phase)
  save_tab(out, "S3_B12_rr_sensitivity.csv", "B12_rr_sens")
})

blk("B13 галузевий аналіз кредитів бізнесу (КВЕД)", {
  # Структура, динаміка та якість кредитів бізнесу за секціями КВЕД; спеціалізація банків; неоднорідність ефекту капіталу за галузями; галузевий внесок
  # капітального обмеження. Списання непрацюючих кредитів у грудні 2025 р. (≈150 млрд грн) враховано: динаміку подано також для працюючих кредитів.
  if (!exists("read_loans_kved_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  kv <- tryCatch(read_loans_kved_local(), error = function(e) NULL)
  if (is.null(kv) || uniqueN(kv$month) < 24L) { message("  B13 пропущено: немає історії Loans_KVED"); return(invisible()) }
  mk <- function(m) as.integer(format(m, "%Y")) * 12L + as.integer(format(m, "%m"))
  M <- as.data.table(mac); M[, month := as.Date(month)]; setorder(M, month)
  M[, bsk := if ("fx_basket_dlog" %in% names(M)) exp(cumsum(fifelse(is.finite(fx_basket_dlog), fx_basket_dlog, 0))) else usd_eom]
  z <- kv[kved != "00" & is.finite(loans) & loans > 0, .(nkb, kved, month, L = loans, Lu = pmax(f0(loans_uah), 0), Lfx = pmax(f0(loans_fx), 0), npl = f0(npl))]
  z[, sec := kved_section(kved)]; z <- merge(z, M[, .(month, bsk)], by = "month", all.x = TRUE)
  # великі секції – окремо, решта – «Інші галузі»
  LAST <- max(z$month); PRE <- as.Date("2021-12-01")
  big <- z[month == LAST, .(L = sum(L)), by = sec][order(-L)][L / sum(L) >= .025, sec]
  z[, grp := fifelse(sec %in% big, sec, "Z")]
  GN <- c(KVED_SECTIONS, Z = "Інші галузі")
  # ---- (a) структура, динаміка й якість за секціями
  bref <- M[month == PRE, bsk]; blast <- M[month == LAST, bsk]
  agg <- z[month %in% c(PRE, LAST), .(L = sum(L), Lc = sum(Lu + Lfx * bref / bsk), npl = sum(npl), P = sum(pmax(L - npl, 0)), banks = uniqueN(nkb)), by = .(grp, month)]
  w <- dcast(agg, grp ~ month, value.var = c("L", "Lc", "npl", "P", "banks"))
  setnames(w, names(w), sub(paste0("_", PRE), "_pre", sub(paste0("_", LAST), "_last", names(w))))
  w[, `:=`(name = GN[grp], share_pre = 100 * L_pre / sum(L_pre), share_last = 100 * L_last / sum(L_last), growth_c = 100 * (Lc_last / Lc_pre - 1),
           growth_perf = 100 * (P_last / P_pre - 1), npl_pre = 100 * npl_pre / L_pre, npl_last = 100 * npl_last / L_last, L_last_bn = L_last / 1e3)]
  # концентрація: частка п’яти найбільших банків у секції
  t5 <- z[month == LAST, .(L = sum(L)), by = .(grp, nkb)][, .(top5 = 100 * sum(sort(L, decreasing = TRUE)[1:min(5, .N)]) / sum(L)), by = grp]
  w <- merge(w, t5, by = "grp")
  tot <- w[, .(grp = "", name = "Усього", L_last_bn = sum(L_last_bn), share_pre = 100, share_last = 100, growth_c = 100 * (sum(Lc_last) / sum(Lc_pre) - 1),
               growth_perf = 100 * (sum(P_last) / sum(P_pre) - 1), npl_pre = 100 * sum(npl_pre * L_pre / 100) / sum(L_pre), npl_last = 100 * sum(npl_last * L_last / 100) / sum(L_last))]
  out <- rbind(w[order(-share_last), .(grp, name, L_last_bn, share_pre, share_last, growth_c, growth_perf, npl_pre, npl_last, top5)], tot, fill = TRUE)
  save_tab(out, "S3_B13_sector_structure.csv", "B13_structure")
  fact("b13_last", as.character(LAST)); fact("b13_big_n", length(big))
  # щорічна динаміка часток (грудень кожного року та остання дата)
  yrs <- sort(unique(c(z[format(month, "%m") == "12", month], LAST)))
  sy <- z[month %in% yrs, .(L = sum(L), npl = sum(npl)), by = .(grp, month)][, `:=`(share = 100 * L / sum(L), npl_sh = 100 * npl / L), by = month]
  sy[, name := GN[grp]]; save_tab(sy, "S3_B13_sector_shares_annual.csv", "B13_shares")
  # списання непрацюючих кредитів у грудні 2025 р.
  wo <- z[month %in% as.Date(c("2025-11-01", "2025-12-01")), .(L = sum(L), npl = sum(npl)), by = month]
  if (nrow(wo) == 2L) { fact("b13_writeoff_npl_drop_bn", round((wo$npl[1] - wo$npl[2]) / 1e3, 1)); fact("b13_writeoff_L_drop_bn", round((wo$L[1] - wo$L[2]) / 1e3, 1)) }
  # спеціалізація банків: індекс Герфіндаля портфеля банку за секціями
  hb <- z[month == LAST, .(L = sum(L)), by = .(nkb, sec)][, .(hhi = sum((L / sum(L))^2), Lb = sum(L)), by = nkb]
  fact("b13_hhi_median", round(median(hb$hhi), 3)); fact("b13_hhi_wmean", round(weighted.mean(hb$hhi, hb$Lb), 3))
  # ---- (b) неоднорідність ефекту капіталу за галузями: основна модель B11 з взаємодіями «запас до 5 в. п. × секція»
  x <- z[, .(nkb, kved, grp, month, L, Lu, Lfx, bsk)]; x[, mkey := mk(month)]; x[, Lb := sum(L), by = .(nkb, month)]
  f <- x[, .(nkb, kved, mkey = mkey - 12L, Lh = L, Luh = Lu, Lfxh = Lfx, bh = bsk)]; x <- merge(x, f, by = c("nkb", "kved", "mkey"))
  x[, g12 := winsor(log(Luh + Lfxh * bsk / bh) - log(L))]; x <- x[L >= 20 & L / Lb >= .01]
  CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
  bk <- d[, c("nkb", "month", "headroom_total_min_pp", CTRL), with = FALSE][, mkey := mk(month) + 1L][, month := NULL]
  x <- merge(x, bk, by = c("nkb", "mkey"))
  x[, `:=`(low = as.numeric(headroom_total_min_pp < 5), mid = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15), unit = paste(nkb, kved), km = paste(kved, mkey))]
  G <- sort(unique(x$grp)); for (g in G) x[, (paste0("lowx_", g)) := low * (grp == g)]
  # галузевий ризик: частка непрацюючих кредитів секції на дату t (вище медіани – «ризикова»)
  sr <- z[, .(sec_npl = sum(npl) / sum(L)), by = .(grp, month)]; sr[, risky := as.numeric(sec_npl > median(sec_npl)), by = month]
  x <- merge(x, sr[, .(grp, month, risky)], by = c("grp", "month"), all.x = TRUE)
  x[, `:=`(low_risky = low * risky, low_safe = low * (1 - risky))]
  tw <- function(Mx, g1, g2) { g1 <- as.integer(factor(g1)); g2 <- as.integer(factor(g2)); n1 <- tabulate(g1); n2 <- tabulate(g2)
    for (it in 1:2000) { M0 <- Mx; Mx <- Mx - (rowsum(Mx, g1) / n1)[g1, , drop = FALSE]; Mx <- Mx - (rowsum(Mx, g2) / n2)[g2, , drop = FALSE]; if (max(abs(Mx - M0)) < 1e-8) break }; Mx }
  reg <- function(dt, xs) { d0 <- dt[, c("unit", "km", "nkb", "g12", xs), with = FALSE]; d0 <- d0[stats::complete.cases(d0)]
    repeat { n0 <- nrow(d0); d0 <- d0[, if (.N > 1L) .SD, by = unit]; d0 <- d0[, if (.N > 1L) .SD, by = km]; if (nrow(d0) == n0) break }
    keep <- xs[vapply(xs, function(v) sd(d0[[v]]) > 0, logical(1))]
    Mx <- tw(as.matrix(d0[, c("g12", keep), with = FALSE]), d0$unit, d0$km); r <- ols_cluster(Mx[, 1], Mx[, -1, drop = FALSE], d0$nkb)
    data.table(var = keep, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G) }
  het <- reg(x, c(paste0("lowx_", G), "mid", CTRL)); het <- het[grepl("^lowx_", var)]; het[, `:=`(grp = sub("^lowx_", "", var), name = GN[sub("^lowx_", "", var)])]
  nlow <- x[low == 1, .(cells_low = uniqueN(unit), banks_low = uniqueN(nkb)), by = grp]; het <- merge(het, nlow, by = "grp", all.x = TRUE)
  rk <- reg(x, c("low_risky", "low_safe", "mid", CTRL)); rk <- rk[var %in% c("low_risky", "low_safe")]
  save_tab(het, "S3_B13_sector_heterogeneity.csv", "B13_het"); save_tab(rk, "S3_B13_sector_risk.csv", "B13_risk")
  # ---- (c) галузевий внесок капітального обмеження: на скільки більшими були б кредити секції за рік, якби банки із запасом до 5 в. п. кредитували, як інші
  cur <- x[mkey == max(mkey)]; cur0 <- z[month == LAST]
  mlast <- max(d$month[d$month <= LAST & is.finite(d$headroom_total_min_pp)])
  lowb <- unique(merge(cur0[, .(nkb)], d[month == mlast, .(nkb, headroom_total_min_pp)], by = "nkb")[headroom_total_min_pp < 5, nkb])
  base <- reg(x, c("low", "mid", CTRL))[var == "low"]
  ctr <- cur0[, .(L_low = sum(L[nkb %in% lowb]), L = sum(L)), by = grp]
  ctr <- merge(ctr, het[, .(grp, b_sec = coef, se_sec = se)], by = "grp", all.x = TRUE)
  ctr[, `:=`(name = GN[grp], gap_bn = L_low * (exp(-base$coef) - 1) / 1e3, gap_sec_bn = L_low * (exp(-fifelse(is.finite(b_sec), b_sec, base$coef)) - 1) / 1e3,
             low_share = 100 * L_low / L)]
  ctr[, gap_pct := 100 * gap_bn * 1e3 / L]
  save_tab(ctr[order(-gap_bn)], "S3_B13_sector_gap.csv", "B13_gap"); fact("b13_low_banks_last", length(lowb)); fact("b13_base_low", round(base$coef, 4))
  # ---- рисунок: коефіцієнти за секціями
  hp_ <- het[is.finite(coef)][order(coef)]; hp_[, name := factor(name, levels = name)]
  save_fig(ggplot(hp_, aes(x = 100 * coef, y = name)) + geom_vline(xintercept = 0, linewidth = .3) + geom_vline(xintercept = 100 * base$coef, linetype = "22", linewidth = .3) +
             geom_errorbarh(aes(xmin = 100 * (coef - 1.96 * se), xmax = 100 * (coef + 1.96 * se)), height = 0, colour = "grey45") + geom_point(size = 1.6) +
             labs(x = "Різниця річного приросту кредитів, логарифмічні пункти × 100", y = NULL, caption = CAP) + theme_thesis(), "S3_F26_sector_heterogeneity.png", 8.5, 4.6)
})

blk("B14 кредитний ризик за МСФЗ 9: стадії знецінення та кредитна пропозиція", {
  if (!exists("read_loans_stages_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  st <- tryCatch(read_loans_stages_local(), error = function(e) NULL)
  if (is.null(st) || !"s1_share_corp" %in% names(st)) { message("  B14 пропущено: немає даних про стадії (потрібен кеш local_loans_stages_v3)"); return(invisible()) }
  mk <- function(m) as.integer(format(m, "%Y")) * 12L + as.integer(format(m, "%m"))
  # ---- (a) системна структура за стадіями і покриття резервами
  seg <- function(s) { g <- st[[paste0("gross_", s)]]; data.table(month = st$month, nkb = st$nkb, g = f0(g),
    s1 = f0(st[[paste0("s1_share_", s)]]) * f0(g), s2 = f0(st[[paste0("s2_share_", s)]]) * f0(g), s3 = f0(st[[paste0("s3_share_", s)]]) * f0(g), so = f0(st[[paste0("oth_share_", s)]]) * f0(g),
    p1 = f0(st[[paste0("cov1_", s)]]) * f0(st[[paste0("s1_share_", s)]]) * f0(g), p2 = f0(st[[paste0("cov2_", s)]]) * f0(st[[paste0("s2_share_", s)]]) * f0(g),
    p3 = f0(st[[paste0("cov3_", s)]]) * f0(st[[paste0("s3_share_", s)]]) * f0(g)) }
  sysm <- rbindlist(lapply(c(corp = "corp", hh = "hh"), function(s) seg(s)[, .(gross_bn = sum(g) / 1e3, s1 = 100 * sum(s1) / sum(g), s2 = 100 * sum(s2) / sum(g), s3 = 100 * sum(s3) / sum(g),
    oth = 100 * sum(so) / sum(g), cov1 = 100 * sum(p1) / sum(s1), cov2 = 100 * sum(p2) / sum(s2), cov3 = 100 * sum(p3) / sum(s3)), by = month][, segment := s]), idcol = FALSE)
  save_tab(sysm, "S3_B14_stages_system_monthly.csv", "B14_sys")
  pick <- sort(unique(c(min(sysm$month), sysm[format(month, "%m") == "12", month], max(sysm$month))))
  save_tab(sysm[month %in% pick], "S3_B14_stages_system_dates.csv", "B14_dates")
  # ---- (b) чи передбачає частка стадії 2 подальше знецінення: зміна частки стадії 3 за 12 місяців на частку стадії 2 (банк, місяць – фіксовані ефекти)
  q <- st[, .(nkb, month, s2 = s2_share_corp, s3 = s3_share_corp, g = gross_corp)][is.finite(s2) & g > 100]
  q[, mkey := mk(month)]; q <- merge(q, q[, .(nkb, mkey = mkey - 12L, s3f = s3)], by = c("nkb", "mkey"))
  q[, ds3 := 100 * (s3f - s3)]; q[, s2p := 100 * s2]; q[, s3p := 100 * s3]
  mig <- fe_reg(q, "ds3", c("s2p", "s3p")); save_tab(mig, "S3_B14_migration.csv", "B14_mig")
  # ---- (c) запас капіталу і стадії: середні за групами запасу (зважені на кредити бізнесу)
  hb <- merge(st[, .(nkb, month, s2 = s2_share_corp, s3 = s3_share_corp, c2 = cov2_corp, g = gross_corp)], d[, .(nkb, month, headroom_total_min_pp)], by = c("nkb", "month"))
  hb <- hb[is.finite(headroom_total_min_pp)]; hb[, grp := fifelse(headroom_total_min_pp < 5, "до 5 в. п.", fifelse(headroom_total_min_pp < 15, "5–15 в. п.", "понад 15 в. п."))]
  gtab <- hb[is.finite(s2) & g > 0, .(s2 = 100 * weighted.mean(s2, g), s3 = 100 * weighted.mean(s3, g, na.rm = TRUE), cov2 = 100 * weighted.mean(c2, s2 * g, na.rm = TRUE),
                                      banks = uniqueN(nkb), obs = .N), by = grp]
  save_tab(gtab, "S3_B14_stages_by_headroom.csv", "B14_head")
  # ---- (d) капітал × кредитний ризик у секторальній панелі (з березня 2022 р.): чи сильніше скорочують кредити банки з малим запасом і високою часткою стадії 2
  kv <- tryCatch(read_loans_kved_local(), error = function(e) NULL)
  if (!is.null(kv)) {
    M <- as.data.table(mac); M[, month := as.Date(month)]; setorder(M, month)
    M[, bsk := if ("fx_basket_dlog" %in% names(M)) exp(cumsum(fifelse(is.finite(fx_basket_dlog), fx_basket_dlog, 0))) else usd_eom]
    x <- kv[kved != "00" & loans > 0, .(nkb, kved, month, L = loans, Lu = pmax(f0(loans_uah), 0), Lfx = pmax(f0(loans_fx), 0))]
    x <- merge(x, M[, .(month, bsk)], by = "month"); x[, mkey := mk(month)]; x[, Lb := sum(L), by = .(nkb, month)]
    x <- merge(x, x[, .(nkb, kved, mkey = mkey - 12L, Lh = L, Luh = Lu, Lfxh = Lfx, bh = bsk)], by = c("nkb", "kved", "mkey"))
    x[, g12 := winsor(log(Luh + Lfxh * bsk / bh) - log(L))]; x <- x[L >= 20 & L / Lb >= .01]
    CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
    bk <- d[, c("nkb", "month", "headroom_total_min_pp", CTRL), with = FALSE][, mkey := mk(month) + 1L][, month := NULL]
    sk <- st[, .(nkb, mkey = mk(month) + 1L, s2c = 10 * s2_share_corp, cov2c = 10 * cov2_corp)]
    x <- merge(merge(x, bk, by = c("nkb", "mkey")), sk, by = c("nkb", "mkey"))
    x[, `:=`(low = as.numeric(headroom_total_min_pp < 5), mid = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15), unit = paste(nkb, kved), km = paste(kved, mkey))]
    x[, s2cc := s2c - mean(s2c, na.rm = TRUE)]; x[, low_s2 := low * s2cc]
    one <- function(xs, lab) { d0 <- x[, c("unit", "km", "nkb", "g12", xs), with = FALSE]; d0 <- d0[stats::complete.cases(d0)]
      repeat { n0 <- nrow(d0); d0 <- d0[, if (.N > 1L) .SD, by = unit]; d0 <- d0[, if (.N > 1L) .SD, by = km]; if (nrow(d0) == n0) break }
      g1 <- as.integer(factor(d0$unit)); g2 <- as.integer(factor(d0$km)); n1 <- tabulate(g1); n2 <- tabulate(g2); Mx <- as.matrix(d0[, c("g12", xs), with = FALSE])
      for (it in 1:2000) { M0 <- Mx; Mx <- Mx - (rowsum(Mx, g1) / n1)[g1, , drop = FALSE]; Mx <- Mx - (rowsum(Mx, g2) / n2)[g2, , drop = FALSE]; if (max(abs(Mx - M0)) < 1e-8) break }
      r <- ols_cluster(Mx[, 1], Mx[, -1, drop = FALSE], d0$nkb); data.table(spec = lab, var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G) }
    ifr <- rbind(one(c("low", "mid", CTRL), "1. Пороги запасу (з 03.2022)"), one(c("low", "mid", "s2cc", CTRL), "2. + частка стадії 2"),
                 one(c("low", "mid", "s2cc", "low_s2", CTRL), "3. + запас до 5 в. п. × частка стадії 2"), one(c("low", "mid", "s2cc", "cov2c", CTRL), "4. + покриття стадії 2"))
    save_tab(ifr, "S3_B14_capital_x_ifrs9.csv", "B14_capxifrs")
  }
  # ---- рисунок: структура кредитів бізнесу за стадіями
  fl <- melt(sysm[segment == "corp", .(month, `Стадія 1` = s1, `Стадія 2` = s2, `Стадія 3` = s3, `Інші (POCI, спрощений підхід)` = oth)], id.vars = "month")
  save_fig(ggplot(fl, aes(month, value, fill = variable)) + geom_area(colour = "black", linewidth = .2) + scale_fill_grey(start = .9, end = .25) +
             labs(x = NULL, y = "% валової заборгованості", fill = NULL, caption = CAP) + theme_thesis(), "S3_F27_ifrs9_stages.png", 8.5, 4.4)
})

blk("B15 МСФЗ 9 за галузями: стадії знецінення кредитів бізнесу за секціями КВЕД", {
  # Дані: наглядова статистика НБУ Loans_stages_KVED (стадії знецінення кредитів банку за розділами КВЕД). (a) частки стадій і покриття резервами за галузями;
  # (b) зростання частки стадії 2 за галузями у воєнний шок; (c) секторальна панель: чи пояснює частка стадії 2 у клітинці «банк – КВЕД» (кредитний ризик саме
  # цих позичальників банку) ефект капіталу і чи сильніше скорочують кредити банки з малим запасом там, де ризик зріс.
  if (!exists("read_loans_stages_kved_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  sk <- tryCatch(read_loans_stages_kved_local(), error = function(e) { message("  Loans_stages_KVED: ", conditionMessage(e)); NULL })
  if (is.null(sk) || uniqueN(sk$month) < 12L) { message("  B15 пропущено: немає даних Loans_stages_KVED"); fact("b15_months", 0); return(invisible()) }
  mk <- function(m) as.integer(format(m, "%Y")) * 12L + as.integer(format(m, "%m"))
  sk <- sk[kved != "00"]; sk[, sec := kved_section(kved)]
  for (v in grep("^(gross|prov)_", names(sk), value = TRUE)) set(sk, j = v, value = f0(sk[[v]]))
  sk[, G := gross_s1 + gross_s2 + gross_s3 + gross_oth]
  LAST <- max(sk$month); FIRST <- min(sk$month)
  big <- sk[month == LAST, .(G = sum(G)), by = sec][order(-G)][G / sum(G) >= .025, sec]
  sk[, grp := fifelse(sec %in% big, sec, "Z")]; GN <- c(KVED_SECTIONS, Z = "Інші галузі")
  # ---- (a) галузі × місяць
  ag <- sk[, .(G = sum(G), s1 = sum(gross_s1), s2 = sum(gross_s2), s3 = sum(gross_s3), so = sum(gross_oth), p1 = sum(prov_s1), p2 = sum(prov_s2), p3 = sum(prov_s3)), by = .(grp, month)]
  ag[, `:=`(sh1 = 100 * s1 / G, sh2 = 100 * s2 / G, sh3 = 100 * s3 / G, sho = 100 * so / G, cov1 = 100 * p1 / s1, cov2 = 100 * p2 / s2, cov3 = 100 * p3 / s3, name = GN[grp])]
  save_tab(ag, "S3_B15_sector_stages_monthly.csv", "B15_monthly")
  # ---- (b) таблиця: на початок, пік стадії 2 до 2024 р., останню дату
  pk <- ag[month <= as.Date("2023-12-01"), .SD[which.max(sh2)], by = grp][, .(grp, peak_month = month, sh2_peak = sh2)]
  t0 <- ag[month == FIRST, .(grp, sh2_first = sh2, sh3_first = sh3)]; t1 <- ag[month == LAST, .(grp, name, G_bn = G / 1e3, sh1_last = sh1, sh2_last = sh2, sh3_last = sh3, cov2_last = cov2, cov3_last = cov3)]
  tb <- Reduce(function(a, b) merge(a, b, by = "grp"), list(t1, t0, pk)); tb[, d2_shock := sh2_peak - sh2_first]
  tot <- ag[, .(G = sum(G), s2 = sum(s2), s3 = sum(s3), p2 = sum(p2), p3 = sum(p3)), by = month]
  save_tab(tb[order(-G_bn)], "S3_B15_sector_stages_table.csv", "B15_table")
  fact("b15_months", uniqueN(sk$month)); fact("b15_first", as.character(FIRST)); fact("b15_last", as.character(LAST)); fact("b15_banks", uniqueN(sk$nkb))
  fact("b15_cover", round(sk[month == LAST, sum(G)] / 1e3, 1), "валові кредити бізнесу у файлах стадій за КВЕД на останню дату, млрд грн")
  # ---- (c) секторальна панель (з першої дати стадій): клітинкова частка стадії 2
  kv <- tryCatch(read_loans_kved_local(), error = function(e) NULL)
  if (!is.null(kv)) {
    M <- as.data.table(mac); M[, month := as.Date(month)]; setorder(M, month)
    M[, bsk := if ("fx_basket_dlog" %in% names(M)) exp(cumsum(fifelse(is.finite(fx_basket_dlog), fx_basket_dlog, 0))) else usd_eom]
    x <- kv[kved != "00" & loans > 0, .(nkb, kved, month, L = loans, Lu = pmax(f0(loans_uah), 0), Lfx = pmax(f0(loans_fx), 0))]
    x <- merge(x, M[, .(month, bsk)], by = "month"); x[, mkey := mk(month)]; x[, Lb := sum(L), by = .(nkb, month)]
    x <- merge(x, x[, .(nkb, kved, mkey = mkey - 12L, Lh = L, Luh = Lu, Lfxh = Lfx, bh = bsk)], by = c("nkb", "kved", "mkey"))
    x[, g12 := winsor(log(Luh + Lfxh * bsk / bh) - log(L))]; x <- x[L >= 20 & L / Lb >= .01]
    CTRL <- c("rr_LS_w", "rr_BS_w", "ln_lcr", "demand_share", "cod", "ln_assets")
    bk <- d[, c("nkb", "month", "headroom_total_min_pp", CTRL), with = FALSE][, mkey := mk(month) + 1L][, month := NULL]
    ck <- sk[G > 0, .(nkb, kved, mkey = mk(month) + 1L, s2cell = 10 * gross_s2 / G, s3cell = 10 * gross_s3 / G, cov2cell = fifelse(gross_s2 > 0, 10 * prov_s2 / gross_s2, NA_real_))]
    x <- merge(merge(x, bk, by = c("nkb", "mkey")), ck, by = c("nkb", "kved", "mkey"))
    x[, `:=`(low = as.numeric(headroom_total_min_pp < 5), mid = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15), unit = paste(nkb, kved), km = paste(kved, mkey))]
    x[, s2c := s2cell - mean(s2cell, na.rm = TRUE)]; x[, low_s2 := low * s2c]
    one <- function(xs, lab) { d0 <- x[, c("unit", "km", "nkb", "g12", xs), with = FALSE]; d0 <- d0[stats::complete.cases(d0)]
      repeat { n0 <- nrow(d0); d0 <- d0[, if (.N > 1L) .SD, by = unit]; d0 <- d0[, if (.N > 1L) .SD, by = km]; if (nrow(d0) == n0) break }
      if (nrow(d0) < 300L) return(NULL)
      g1 <- as.integer(factor(d0$unit)); g2 <- as.integer(factor(d0$km)); n1 <- tabulate(g1); n2 <- tabulate(g2); Mx <- as.matrix(d0[, c("g12", xs), with = FALSE])
      for (it in 1:2000) { M0 <- Mx; Mx <- Mx - (rowsum(Mx, g1) / n1)[g1, , drop = FALSE]; Mx <- Mx - (rowsum(Mx, g2) / n2)[g2, , drop = FALSE]; if (max(abs(Mx - M0)) < 1e-8) break }
      r <- ols_cluster(Mx[, 1], Mx[, -1, drop = FALSE], d0$nkb); data.table(spec = lab, var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G, cells = uniqueN(d0$unit)) }
    res <- rbindlist(list(one(c("low", "mid", CTRL), "1. Пороги запасу (вибірка зі стадіями за КВЕД)"),
                          one(c("low", "mid", "s2cell", "s3cell", CTRL), "2. + частки стадій 2 і 3 у клітинці"),
                          one(c("low", "mid", "s2c", "low_s2", "s3cell", CTRL), "3. + запас до 5 в. п. × частка стадії 2 у клітинці"),
                          one(c("low", "mid", "s2cell", "s3cell", "cov2cell", CTRL), "4. + покриття стадії 2 у клітинці")), fill = TRUE)
    save_tab(res, "S3_B15_capital_x_cell_stages.csv", "B15_cells")
  }
  # ---- рисунок: частка стадії 2 за галузями
  fg <- ag[grp != "Z"]
  save_fig(ggplot(fg, aes(month, sh2, linetype = name)) + geom_line(linewidth = .6, colour = "black") +
             labs(x = NULL, y = "Частка стадії 2, % валових кредитів галузі", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F28_sector_stage2.png", 8.5, 4.6)
})

blk("B16 Реальні наслідки: шоки пропозиції кредиту банків (Аміті–Вайнштейн) і фінансова звітність фірм", {
  # (a) Розклад Аміті–Вайнштейна (Amiti, Weinstein, 2018) на панелі «банк × КВЕД»: приріст кредитів банку b галузі s за вікно (грудень → грудень або
  #     грудень → вересень) = α_b (пропозиція банку, спільна для всіх його галузей) + β_s (попит галузі, спільний для всіх її банків). Зважений МНК з вагами –
  #     залишками на початок вікна, що відтворює моментні умови AW. Валютні кредити переоцінено за курсом початку вікна. α_b оцінено також «без галузі s»
  #     (leave-sector-out), щоб шок пропозиції галузі не містив її власного попиту.
  # (b) Шок пропозиції галузі S_s = Σ_b ω_bs·α_b(−s), ω – частки банків у кредитах галузі на початок вікна; експозиція E_s – частка кредитів галузі в банках із
  #     запасом капіталу до 5 в. п. на початок вікна.
  # (c) Фінансова звітність фірм (Держстат, data.gov.ua; firms_fin_data.py): зміни за вікно в межах одного поданого звіту (баланс: початок року → кінець періоду;
  #     потоки: звітний період до аналогічного попереднього). M1: y = β·S_s + γ·Dep + X'δ + ефекти «секція × вікно» і «область × вікно» (варіація між розділами
  #     в межах секції). M2: y = β·(S_s × Dep_f) + γ_w·Dep_f + X'δ + ефекти «розділ КВЕД × вікно» і «область × вікно»: у межах галузі порівнюються фірми з банківським
  #     кредитом на початок вікна і без нього, тому галузевий попит поглинається ефектами. M3: те саме з експозицією E_s замість S_s (скорочена форма для капіталу).
  #     Кластери – розділи КВЕД (рівень шоку); також двостороння кластеризація «розділ – область» і wild cluster bootstrap за розділами.
  if (!exists("read_loans_kved_local")) source(file.path(PROJECT_DIR, "utils_local_inputs_v6.R"), encoding = "UTF-8")
  kv <- tryCatch(read_loans_kved_local(), error = function(e) { message("  Loans_KVED: ", conditionMessage(e)); NULL })
  if (is.null(kv) || uniqueN(kv$month) < 24L) { message("  B16 пропущено: немає Loans_KVED"); fact("b16_aw", 0); return(invisible()) }
  NB16 <- as.integer(Sys.getenv("S3_NBOOT_FIRMS", "499"))
  M <- as.data.table(mac); M[, month := as.Date(month)]; setorder(M, month)
  M[, bsk := if ("fx_basket_dlog" %in% names(M)) exp(cumsum(fifelse(is.finite(fx_basket_dlog), fx_basket_dlog, 0))) else usd_eom]
  ex <- setNames(M$bsk, as.character(M$month))
  K <- kv[kved != "00" & !(kved %in% c("64", "65", "66", "84")), .(nkb, kved, month, L = f0(loans), Lu = pmax(f0(loans_uah), 0), Lfx = pmax(f0(loans_fx), 0), npl = pmax(f0(npl), 0))]
  K[, sh_perf := fifelse(L > 0, pmax(1 - npl / L, 0), 1)]
  LASTM <- max(K$month); KM <- sort(unique(K$month))
  near <- function(m) { k <- KM[which.min(abs(as.numeric(KM - m)))]; if (abs(as.numeric(k - m)) <= 31) k else as.Date(NA) }   # e.g. December 2020 is missing in Loans_KVED
  WIN <- rbindlist(c(lapply(2019:2025, function(y) data.table(win = paste0("FY", y), t0 = as.Date(sprintf("%d-12-01", y - 1)), t1 = as.Date(sprintf("%d-12-01", y)))),
                     lapply(2020:2026, function(y) data.table(win = paste0("9M", y), t0 = as.Date(sprintf("%d-12-01", y - 1)), t1 = as.Date(sprintf("%d-09-01", y))))))
  WIN <- WIN[t0 >= min(K$month) & t1 <= LASTM]
  aw_solve <- function(b, s, g, w, iters = 3000L, tol = 1e-11) {
    fb <- factor(b); fs <- factor(s); bi <- as.integer(fb); si <- as.integer(fs); al <- numeric(nlevels(fb)); be <- numeric(nlevels(fs))
    wb <- rowsum(w, bi)[, 1]; ws <- rowsum(w, si)[, 1]
    for (it in seq_len(iters)) { a0 <- al; be <- rowsum(w * (g - al[bi]), si)[, 1] / ws; al <- rowsum(w * (g - be[si]), bi)[, 1] / wb; if (max(abs(al - a0)) < tol) break }
    m <- sum(wb * al) / sum(wb); list(alpha = setNames(al - m, levels(fb)), beta = setNames(be + m, levels(fs)), wb = setNames(wb, levels(fb)), ws = setNames(ws, levels(fs))) }
  # gross loans with written-off and sold non-performing loans added back (a fall in NPL within the window is treated as a write-off): the write-off
  # of ≈150 bn UAH in December 2025 is not a change in credit supply. Variant perf = TRUE: performing loans only (robustness).
  cells_of <- function(t0, t1, perf = FALSE) { t0 <- near(t0); t1 <- near(t1); if (is.na(t0) || is.na(t1)) return(data.table())
    a <- K[month == t0, .(nkb, kved, L0 = L * if (perf) sh_perf else 1, npl0 = npl)]; b <- K[month == t1, .(nkb, kved, Lu1 = Lu, Lfx1 = Lfx, sp1 = if (perf) sh_perf else 1, npl1 = npl)]
    z <- merge(a, b, by = c("nkb", "kved"), all.x = TRUE); z <- z[nkb %in% b$nkb & L0 >= 1]          # bank present at both dates; cell at least 1 mn UAH
    z[, L1 := (f0(Lu1) + f0(Lfx1) * ex[as.character(t0)] / ex[as.character(t1)]) * fifelse(is.finite(sp1), sp1, 1)]
    if (!perf) z[, L1 := L1 + pmax(f0(npl0) - f0(npl1), 0)]
    z[, g := pmin(pmax(L1 / L0 - 1, -1), 3)]; z[] }
  AW <- list(); SS <- list(); AL <- list()
  for (i in seq_len(nrow(WIN))) { w0 <- WIN[i]; z <- cells_of(w0$t0, w0$t1); if (nrow(z) < 200L) next
    r <- aw_solve(z$nkb, z$kved, z$g, z$L0)
    agg <- z[, sum(L1) / sum(L0) - 1]; zt <- cells_of(w0$t0, w0$t1, perf = TRUE); rt <- aw_solve(zt$nkb, zt$kved, zt$g, zt$L0)
    cor_tot <- { k <- intersect(names(r$alpha), names(rt$alpha)); cov.wt(cbind(r$alpha[k], rt$alpha[k]), wt = r$wb[k] / sum(r$wb[k]), cor = TRUE)$cor[1, 2] }
    AL[[w0$win]] <- data.table(win = w0$win, t0 = near(w0$t0), nkb = names(r$alpha), alpha = r$alpha, L0b = r$wb)
    loo <- rbindlist(lapply(unique(z$kved), function(s) { zz <- z[kved != s]; rr <- aw_solve(zz$nkb, zz$kved, zz$g, zz$L0)
      zs <- z[kved == s]; zs[, a := rr$alpha[nkb]]; zs <- zs[is.finite(a)]
      data.table(kved = s, S = if (nrow(zs)) sum(zs$L0 * zs$a) / sum(zs$L0) else NA_real_, S_full = sum(z[kved == s, L0 * r$alpha[nkb]]) / sum(z[kved == s, L0]),
                 beta = r$beta[s], L0s = sum(z[kved == s, L0]), banks = nrow(z[kved == s])) }))
    hb <- d[month == near(w0$t0), .(nkb, hr = headroom_total_min_pp)]
    zz <- merge(z, hb, by = "nkb", all.x = TRUE)
    ex_s <- zz[, .(E_low = sum(L0 * (is.finite(hr) & hr < 5)) / sum(L0), E_mid = sum(L0 * (is.finite(hr) & hr >= 5 & hr < 15)) / sum(L0),
                   E_na = sum(L0 * !is.finite(hr)) / sum(L0), hhi = sum((L0 / sum(L0))^2)), by = kved]
    SS[[w0$win]] <- cbind(win = w0$win, merge(loo, ex_s, by = "kved"))
    v_sup <- z[, sum(L0 * (r$alpha[nkb])^2) / sum(L0)]; v_dem <- z[, sum(L0 * (r$beta[kved] - sum(L0 * r$beta[kved]) / sum(L0))^2) / sum(L0)]
    AW[[w0$win]] <- data.table(win = w0$win, t0 = w0$t0, t1 = w0$t1, banks = uniqueN(z$nkb), sectors = uniqueN(z$kved), cells = nrow(z), L0_bn = sum(z$L0) / 1e3,
                               agg_growth = 100 * agg, agg_growth_perf = 100 * zt[, sum(L1) / sum(L0) - 1], cor_alpha_perf = cor_tot, sd_supply = 100 * sqrt(v_sup), sd_demand = 100 * sqrt(v_dem), share_supply_var = v_sup / (v_sup + v_dem)) }
  if (!length(AW)) { message("  B16: замало клітинок для розкладу"); return(invisible()) }
  AW <- rbindlist(AW); SS <- rbindlist(SS); AL <- rbindlist(AL)
  # ---- (a2) чи нижчі шоки пропозиції в банках із малим запасом капіталу
  CTRL <- c("ln_assets", "ln_lcr", "demand_share", "cod")
  ab <- merge(AL, d[, c("nkb", "month", "headroom_total_min_pp", CTRL), with = FALSE], by.x = c("nkb", "t0"), by.y = c("nkb", "month"))
  ab[, `:=`(low = as.numeric(headroom_total_min_pp < 5), mid = as.numeric(headroom_total_min_pp >= 5 & headroom_total_min_pp < 15), a100 = 100 * winsor(alpha, .02, .98))]
  bank_reg <- function(dd, xs, lab, wt = TRUE) { dd <- dd[stats::complete.cases(dd[, c("a100", xs), with = FALSE])]; if (nrow(dd) < 30L) return(NULL)
    W <- if (wt) sqrt(dd$L0b / mean(dd$L0b)) else rep(1, nrow(dd)); Xd <- cbind(model.matrix(~ win - 1, dd), as.matrix(dd[, ..xs])) * W; r <- ols_cluster(dd$a100 * W, Xd, dd$nkb)
    j <- (ncol(Xd) - length(xs) + 1):ncol(Xd); data.table(spec = lab, var = xs, coef = r$b[j], se = r$se[j], p = r$p[j], n = r$n, banks = r$G) }
  bank_fe <- function(dd, xs, lab) { dd <- dd[stats::complete.cases(dd[, c("a100", xs), with = FALSE])]; dd <- dd[, if (.N > 1L) .SD, by = nkb]; if (nrow(dd) < 30L) return(NULL)
    Mx <- twoway_demean(as.matrix(dd[, c("a100", xs), with = FALSE]), dd$nkb, dd$win); r <- ols_cluster(Mx[, 1], Mx[, -1, drop = FALSE], dd$nkb)
    data.table(spec = lab, var = xs, coef = r$b, se = r$se, p = r$p, n = r$n, banks = r$G) }
  ab_tab <- rbindlist(list(bank_reg(ab[grepl("^FY", win)], c("low", "mid"), "1. Річні вікна, пороги запасу"),
                           bank_reg(ab[grepl("^FY", win)], c("low", "mid", CTRL), "2. Річні вікна, + контрольні змінні"),
                           bank_reg(ab[win %in% c("FY2022", "9M2022")], c("low", "mid"), "3. Воєнний шок: 2022 р."),
                           bank_reg(ab[grepl("^FY", win) & t0 < as.Date("2021-12-01")], c("low", "mid"), "4. Довоєнні вікна 2019–2021"),
                           bank_reg(ab[grepl("^FY", win) & t0 >= as.Date("2022-12-01")], c("low", "mid"), "5. Вікна 2023–2025"),
                           bank_reg(ab[grepl("^FY", win)], c("low", "mid", CTRL), "6. Річні вікна, + контрольні змінні, без зважування", wt = FALSE),
                           bank_fe(ab[grepl("^FY", win)], c("low", "mid", CTRL), "7. Річні вікна, ефекти банку і вікна (зміни запасу в межах банку)"),
                           bank_fe(ab, c("low", "mid", CTRL), "8. Річні та 9-місячні вікна, ефекти банку і вікна")))
  save_tab(AW, "S3_B16_aw_windows.csv", "B16_aw"); save_tab(ab_tab, "S3_B16_aw_supply_capital.csv", "B16_aw_cap")
  CFS <- "7. Річні вікна, ефекти банку і вікна (зміни запасу в межах банку)"   # counterfactual: the within-bank effect of a small capital headroom, as in the main panel
  b_low <- ab_tab[spec == CFS & var == "low", coef] / 100; b_mid <- ab_tab[spec == CFS & var == "mid", coef] / 100
  if (!length(b_low)) b_low <- 0; if (!length(b_mid)) b_mid <- 0
  SS[, `:=`(sec = kved_section(kved), dS_cf = -(b_low * E_low + b_mid * E_mid))]   # шок пропозиції галузі, якби банки з малим запасом поводились як інші
  save_tab(SS, "S3_B16_sector_supply_shocks.csv", "B16_sector_shocks")
  s22 <- SS[win == "FY2022"]
  if (nrow(s22)) { sec_tab <- s22[, .(S = 100 * sum(L0s * S, na.rm = TRUE) / sum(L0s[is.finite(S)]), E_low = 100 * sum(L0s * E_low) / sum(L0s), beta = 100 * sum(L0s * beta) / sum(L0s), L0_bn = sum(L0s) / 1e3), by = sec]
    sec_tab[, name := KVED_SECTIONS[sec]]; setorder(sec_tab, -L0_bn); save_tab(sec_tab, "S3_B16_sector_shocks_2022.csv", "B16_sec22")
    fact("b16_S22_sd", round(100 * s22[, sqrt(sum(L0s * (S - sum(L0s * S, na.rm = TRUE) / sum(L0s))^2, na.rm = TRUE) / sum(L0s))], 2), "SD шоку пропозиції між розділами КВЕД у 2022 р., в. п.")
    fact("b16_corr_S_Elow_22", round(s22[is.finite(S), cov.wt(cbind(S, E_low), wt = L0s / sum(L0s), cor = TRUE)$cor[1, 2]], 2)) }
  fact("b16_aw_windows", nrow(AW)); fact("b16_aw_share_supply_FY2022", round(AW[win == "FY2022", share_supply_var], 3))
  fact("b16_aw_low_coef", round(100 * b_low, 2), "різниця шоку пропозиції банків із запасом до 5 в. п., в. п. приросту за рік")
  fact("b16_aw_low_p", round(ab_tab[spec == CFS & var == "low", p], 3))
  # ---- (c) фірми
  FD <- file.path(DATA_DIR, "firms"); RAWF <- Sys.getenv("THESIS_FIRMS_RAW", file.path(LOCAL_DIR, "firms_fin")); fw <- file.path(FD, "firms_windows.parquet")
  # Source 1 (preferred): an export of annual statements firm × year (export_finrep_four_views_v4.R: r####_open / r####_close for the balance from the same annual
  # report, r#### for the income statement of the year). Found by THESIS_FIRMS_EXPORT or by the name finrep*.csv / firm_year_open_close*.csv.
  # all export files are used together (e.g. finrep_2021-2025.csv and a separate file for 2021); THESIS_FIRMS_EXPORT may list several paths separated by «;»
  find_export <- function() {
    p <- Sys.getenv("THESIS_FIRMS_EXPORT", "")
    if (nzchar(p)) { f <- trimws(strsplit(p, ";", fixed = TRUE)[[1]]); f <- f[nzchar(f) & file.exists(f)]; if (length(f)) return(unique(normalizePath(f, winslash = "/"))) }
    roots <- unique(c(PROJECT_DIR, RAWF, file.path(LOCAL_DIR, "firms_fin"), FD, DATA_DIR, dirname(PROJECT_DIR), dirname(dirname(PROJECT_DIR)),
                      file.path(dirname(dirname(PROJECT_DIR)), "data"), file.path(Sys.getenv("USERPROFILE", path.expand("~")), c("Documents", "Downloads"))))
    f <- unlist(lapply(roots[dir.exists(roots)], list.files, pattern = "^(finrep|firm_year_open_close).*\\.csv(\\.gz)?$", full.names = TRUE, ignore.case = TRUE))
    f <- f[!grepl("partial|source_errors|slim", basename(f), ignore.case = TRUE)]
    if (!length(f)) return(NULL)
    f <- unique(normalizePath(f, winslash = "/")); f[order(file.mtime(f))] }
  firms_from_export <- function(path) {
    hdrs <- lapply(path, function(p) names(fread(p, nrows = 0L))); hdr <- Reduce(union, hdrs)
    # only the lines the analysis uses (a five-year export of all firms is large: ≈2,5 млн фірм-років)
    STK <- c(ta = 1300, fa = 1010, cash = 1165, eq = 1495, ltl = 1595, ltb = 1510, stb = 1600, cplt = 1610, tp = 1615)
    FLW <- c(rev = 2000, finexp = 2250, wage = 2505)
    chr <- intersect(c("edrpou", "balance_form", "pnl_form", "firm_kved", "firm_katottg", "firm_territory", "firm_legal_form_code"), hdr)
    sel <- intersect(c(chr, "year", "employees", "net_result", "operating_result", "r1900_open", "r1900_close",
                       paste0("r", STK, "_open"), paste0("r", STK, "_close"), paste0("r", FLW)), hdr)
    need_cols <- c("edrpou", "year", "balance_form", "r1300_open", "r1300_close", "r1600_open", "r1600_close")
    for (k in seq_along(path)) if (length(miss <- setdiff(need_cols, hdrs[[k]]))) stop("у вивантаженні ", basename(path[k]), " немає стовпців: ", paste(miss, collapse = ", "))
    # files in the order of their dates: for a firm-year present in several files the newest file wins
    X <- rbindlist(lapply(seq_along(path), function(k) { x <- fread(path[k], select = intersect(sel, hdrs[[k]]), colClasses = list(character = intersect(chr, hdrs[[k]])),
                                                                 encoding = "UTF-8", showProgress = FALSE, na.strings = c("", "NA")); x[, file_k := k] }), use.names = TRUE, fill = TRUE)
    message("    файли: ", paste(basename(path), collapse = ", "), "; роки: ", paste(sort(unique(X$year)), collapse = ", "))
    X[, edrpou := sprintf("%08s", gsub("\\D", "", edrpou))]; X[, edrpou := gsub(" ", "0", edrpou)]
    X <- X[nchar(edrpou) == 8L & !is.na(balance_form) & balance_form %in% c("full", "small", "micro")]
    setorder(X, edrpou, year, -file_k); X <- unique(X, by = c("edrpou", "year")); X[, file_k := NULL]
    W <- X[, .(edrpou, year = as.integer(year), month = 12L, form = c(full = "L", small = "S", micro = "M")[balance_form], src = "finrep")]
    kv <- if ("firm_kved" %in% names(X)) trimws(X$firm_kved) else rep(NA_character_, nrow(X))
    k4 <- regmatches(kv, regexpr("\\d{2}\\.\\d{1,2}", kv)); W[, kved := NA_character_]; W[grepl("\\d{2}\\.\\d{1,2}", kv), kved := k4]
    i2 <- which(is.na(W$kved) & grepl("^\\d{2}", kv)); if (length(i2)) set(W, i = i2, j = "kved", value = substr(kv[i2], 1, 2))
    W[, div := substr(kved, 1, 2)]
    kt <- if ("firm_katottg" %in% names(X)) X$firm_katottg else rep(NA_character_, nrow(X))
    W[, obl := fifelse(grepl("^UA\\d{2}", kt), substr(kt, 1, 4), "R?")]; W[, c_reg := NA_character_]
    W[, opf := if ("firm_legal_form_code" %in% names(X)) X$firm_legal_form_code else NA_character_]
    W[, emp := if ("employees" %in% names(X)) as.numeric(X$employees) else NA_real_]
    gcol <- function(nm) if (nm %in% names(X)) as.numeric(X[[nm]]) else rep(NA_real_, nrow(X))
    for (k in names(STK)) { set(W, j = paste0(k, "_0"), value = gcol(paste0("r", STK[[k]], "_open"))); set(W, j = paste0(k, "_1"), value = gcol(paste0("r", STK[[k]], "_close"))) }
    W[is.na(ta_0), ta_0 := gcol("r1900_open")[is.na(W$ta_0)]]; W[is.na(ta_1), ta_1 := gcol("r1900_close")[is.na(W$ta_1)]]
    for (k in names(FLW)) set(W, j = paste0(k, "_1"), value = gcol(paste0("r", FLW[[k]])))
    W[, np_1 := gcol("net_result")]; W[, opprof_1 := gcol("operating_result")]
    rm(X); invisible(gc(FALSE))
    # flows of the previous year (the export holds the current year only): from the same firm's report for year − 1
    fl <- c(paste0(names(FLW), "_1"), "np_1", "opprof_1")
    prev <- W[, c("edrpou", "year", fl), with = FALSE][, year := year + 1L]; setnames(prev, fl, sub("_1$", "_0", fl))
    W <- merge(W, prev, by = c("edrpou", "year"), all.x = TRUE, sort = FALSE)
    for (j in c("_0", "_1")) { filed <- is.finite(W[[paste0("ta", j)]])
      set(W, j = paste0("bank", j), value = fifelse(filed, f0(W[[paste0("ltb", j)]]) + f0(W[[paste0("stb", j)]]), NA_real_))
      set(W, j = paste0("bank_wide", j), value = fifelse(filed, f0(W[[paste0("ltl", j)]]) + f0(W[[paste0("stb", j)]]) + f0(W[[paste0("cplt", j)]]), NA_real_)) }
    W[, `:=`(win = paste0("FY", year), date_0 = as.Date(sprintf("%d-12-01", year - 1L)), date_1 = as.Date(sprintf("%d-12-01", year)))]
    EE <- W[is.finite(emp) & emp > 0, .(edrpou, year, emp)]
    # firms the analysis never uses: finance, public administration, no KVED, tiny balance at both dates
    W <- W[!is.na(div) & !(div %in% c("64", "65", "66", "84")) & (f0(ta_0) >= 50 | f0(ta_1) >= 50)]
    invisible(gc(FALSE)); list(W = W, E = EE) }
  EXP <- find_export(); EMP <- NULL
  if (!is.null(EXP)) {
    message("  B16(c): річна звітність фірм із вивантаження: ", paste(EXP, collapse = "; "))
    FX <- firms_from_export(EXP); F <- FX$W; EMP <- FX$E; rm(FX); invisible(gc(FALSE)); fact("b16_source", paste(basename(EXP), collapse = "; "))
  } else {
    zips <- if (dir.exists(RAWF)) list.files(RAWF, "\\.zip$", full.names = TRUE, ignore.case = TRUE) else character()
    need <- !file.exists(fw) || (length(zips) && max(file.mtime(zips)) > file.mtime(fw))
    if (need && tolower(Sys.getenv("THESIS_FIRMS", "true")) != "false") {
      if (!exists("run_thesis_python")) source(file.path(PROJECT_DIR, "utils_capital_inputs_v7.R"), encoding = "UTF-8")
      tryCatch(run_thesis_python(file.path(PROJECT_DIR, "firms_fin_data.py"), PROJECT_DIR, check_packages = FALSE),
               error = function(e) message("  firms_fin_data.py: ", conditionMessage(e)))
    }
    if (!file.exists(fw)) { message("  B16(c) пропущено: немає ні вивантаження finrep*.csv, ні data_nbu/firms/firms_windows.parquet"); fact("b16_firms", 0); return(invisible()) }
    read_firms <- function(p) { if (HAS_ARROW) return(as.data.table(arrow::read_parquet(p, mmap = FALSE)))
      csv <- sub("\\.parquet$", ".csv", p)
      if (!file.exists(csv) || file.mtime(csv) < file.mtime(p)) { if (!exists("run_thesis_python")) source(file.path(PROJECT_DIR, "utils_capital_inputs_v7.R"), encoding = "UTF-8")
        run_thesis_python(file.path(PROJECT_DIR, "firms_fin_data.py"), c(PROJECT_DIR, "--to-csv"), check_packages = FALSE) }
      fread(csv, colClasses = list(character = intersect(c("edrpou", "kved", "div", "obl", "c_reg", "opf", "form", "win", "src"), names(fread(csv, nrows = 0))))) }
    F <- read_firms(fw); fe <- file.path(FD, "firms_employees.parquet")
    if (file.exists(fe)) EMP <- read_firms(fe)[, .(edrpou, year = as.integer(year), emp)]
    fact("b16_source", "data.gov.ua")
  }
  F21_RAW <- F[win %in% c("FY2021", "9M2021")]                                      # placebo: windows before the war
  # stocks at year ends for the event study: end-of-year columns, and December of the year before the first report from its opening column
  ESP <- { a <- F[month == 12L, .(edrpou, t = as.integer(year), ta = ta_1, fa = fa_1, bank = bank_1, tp = tp_1, cash = cash_1, eq = eq_1, rev = rev_1, wage = wage_1, np = np_1, form, div, obl)]
           b <- F[month == 12L, .(edrpou, t = as.integer(year) - 1L, ta = ta_0, fa = fa_0, bank = bank_0, tp = tp_0, cash = cash_0, eq = eq_0, rev = rev_0, wage = wage_0, np = np_0, form, div, obl)]
           rbind(a, b[!a, on = .(edrpou, t)])[is.finite(ta)] }
  F[, `:=`(obl = sub("^(UA|K)", "", obl), div = as.character(div))]
  # cells «window × form» with only late filings (a resource of the portal that holds filings of one calendar year only) are not used:
  # a cell is kept when it has at least a quarter of the largest number of filings of that form in any window
  cnt <- F[, .N, by = .(win, form)][, keep := N >= .25 * max(N), by = form]; okw <- cnt[keep == TRUE, paste(win, form)]
  cov <- F[, .(firms = .N, bank_dep = sum(bank_0 > 0, na.rm = TRUE), bank_0_bn = sum(bank_0, na.rm = TRUE) / 1e6, bank_1_bn = sum(bank_1, na.rm = TRUE) / 1e6,
               ta_0_bn = sum(ta_0, na.rm = TRUE) / 1e6, used = paste(win, form) %in% okw), by = .(win, form)]
  nbu <- K[, .(nbu_bn = sum(L) / 1e3), by = month]
  cov <- merge(cov, WIN[, .(win, t0, t1)], by = "win", all.x = TRUE); cov[, t0n := as.Date(vapply(t0, function(m) as.numeric(near(m)), numeric(1)), origin = "1970-01-01")]
  cov <- merge(cov, nbu[, .(t0n = month, nbu_0_bn = nbu_bn)], by = "t0n", all.x = TRUE)
  cov[, share_of_nbu := fifelse(is.finite(nbu_0_bn) & nbu_0_bn > 0, bank_0_bn / nbu_0_bn, NA_real_)]
  setorder(cov, win, form); save_tab(cov[, !"t0n"], "S3_B16_firm_coverage.csv", "B16_coverage")
  F <- F[paste(win, form) %in% okw & is.finite(ta_0) & is.finite(ta_1) & ta_0 >= 50 & ta_1 > 0 & !(div %in% c("64", "65", "66", "84")) & !is.na(div)]
  F <- merge(F, SS[, .(win, div = kved, S, E_low, E_mid, dS_cf, sec)], by = c("win", "div"))
  if (nrow(F) < 1000L) { message("  B16(c): після об'єднання з шоками лишилось ", nrow(F), " фірм"); fact("b16_firms", nrow(F)); return(invisible()) }
  rto <- function(a, b) fifelse(is.finite(a) & is.finite(b) & b > 0, a / b, NA_real_)
  lgr <- function(a, b) fifelse(is.finite(a) & is.finite(b) & a > 0 & b > 0, log(a / b), NA_real_)
  F[, `:=`(dep = as.numeric(f0(bank_0) > 0), lev_bank0 = winsor(f0(bank_0) / ta_0, 0, .99), l_ta0 = log(ta_0), cash0 = winsor(f0(cash_0) / ta_0, 0, .99),
           eq0 = winsor(rto(eq_0, ta_0), .01, .99), roa0 = winsor(rto(np_0, ta_0), .01, .99))]
  F[, `:=`(y_credit = 100 * winsor((f0(bank_1) - f0(bank_0)) / ta_0), y_credit_wide = 100 * winsor((f0(bank_wide_1) - f0(bank_wide_0)) / ta_0),
           y_stop = fifelse(dep == 1, as.numeric(f0(bank_1) == 0), NA_real_), y_lcredit = winsor(lgr(bank_1, bank_0)),
           y_fa = winsor(fifelse(is.finite(fa_0) & is.finite(fa_1), log1p(pmax(fa_1, 0)) - log1p(pmax(fa_0, 0)), NA_real_)),
           y_ta = winsor(log(ta_1 / ta_0)), y_rev = winsor(lgr(rev_1, rev_0)), y_wage = winsor(lgr(wage_1, wage_0)),
           y_tp = 100 * winsor((f0(tp_1) - f0(tp_0)) / ta_0), y_cash = 100 * winsor((f0(cash_1) - f0(cash_0)) / ta_0),
           y_rate = fifelse(form == "L" & f0(bank_0) + f0(bank_1) > 0 & is.finite(finexp_1), winsor(100 * finexp_1 / ((f0(bank_0) + f0(bank_1)) / 2), 0, .98), NA_real_))]
  if (!is.null(EMP)) { E <- copy(EMP)
    E <- E[is.finite(emp) & emp > 0]; E <- E[, .(emp = emp[1]), by = .(edrpou, year)]
    F[, year := as.integer(year)]; F <- merge(F, E[, .(edrpou, year = year + 1L, emp_prev = emp)], by = c("edrpou", "year"), all.x = TRUE)
    F[, y_emp := fifelse(month == 12, winsor(lgr(emp, emp_prev)), NA_real_)] } else F[, y_emp := NA_real_]
  F[, `:=`(Sdep = 100 * S * dep, Edep = 100 * E_low * dep, S100 = 100 * S, E100 = 100 * E_low, Slev = 100 * S * lev_bank0,
           sw = paste(sec, win), dw = paste(div, win), ow = paste(obl, win), front = obl %in% c("14", "44", "23", "65", "63", "48", "59", "74"))]
  for (w_ in unique(F$win)) set(F, j = paste0("dep_", w_), value = F$dep * (F$win == w_))
  # ROA at the start needs the previous year's result; when it is missing (the first year of an export) it is set to 0 with an indicator
  fix_roa <- function(dd) { dd[, roa_miss := as.numeric(!is.finite(roa0))]; dd[!is.finite(roa0), roa0 := 0]; invisible(dd) }
  fix_roa(F)
  DEPW <- grep("^dep_", names(F), value = TRUE); XC <- c("l_ta0", "lev_bank0", "cash0", "eq0", "roa0", "roa_miss")
  F[, fL := as.numeric(form == "L")]; F[, fS := as.numeric(form == "S")]
  tw2 <- function(Mx, g1, g2, iters = 500L, tol = 1e-7) { g1 <- as.integer(factor(g1)); g2 <- as.integer(factor(g2)); n1 <- tabulate(g1); n2 <- tabulate(g2)
    # alternating projections; convergence when the group means removed in a sweep are all below tol (no full copy of the matrix per sweep)
    for (it in seq_len(iters)) { m1 <- rowsum(Mx, g1) / n1; Mx <- Mx - m1[g1, , drop = FALSE]; m2 <- rowsum(Mx, g2) / n2; Mx <- Mx - m2[g2, , drop = FALSE]
      if (max(abs(m1)) < tol && max(abs(m2)) < tol) break }
    Mx }
  vcl <- function(X, u, XtXi, g) { g <- as.integer(factor(g)); G <- max(g); S <- crossprod(rowsum(X * u, g)); n <- nrow(X); k <- ncol(X)
    G / (G - 1) * (n - 1) / max(n - k, 1) * XtXi %*% S %*% XtXi }
  firm_reg <- function(dd, y, xs, fe1, fe2, key = xs[1], wcb = FALSE) {
    cols <- unique(c(y, xs, fe1, fe2, "div", "obl")); z <- dd[, ..cols]; z <- z[stats::complete.cases(z) & Reduce(`&`, lapply(z[, c(y, xs), with = FALSE], is.finite))]
    keepx <- xs[vapply(xs, function(v) stats::var(z[[v]]) > 0, logical(1))]; if (!(key %in% keepx) || nrow(z) < 500L) return(NULL)
    Mx <- tw2(as.matrix(z[, c(y, keepx), with = FALSE]), z[[fe1]], z[[fe2]]); yy <- Mx[, 1]; X <- Mx[, -1, drop = FALSE]
    keep <- which(colSums(X^2) > 1e-8 * nrow(X)); X <- X[, keep, drop = FALSE]; keepx <- keepx[keep]
    XtXi <- pinv(crossprod(X)); b <- drop(XtXi %*% crossprod(X, yy)); u <- drop(yy - X %*% b); j <- match(key, keepx)
    V1 <- vcl(X, u, XtXi, z$div); Vo <- vcl(X, u, XtXi, z$obl); V12 <- vcl(X, u, XtXi, paste(z$div, z$obl)); V2 <- V1 + Vo - V12
    G <- uniqueN(z$div); se1 <- sqrt(max(V1[j, j], 0)); se2 <- sqrt(max(V2[j, j], V1[j, j], 0))
    p_wcb <- NA_real_
    if (wcb && NB16 > 0) { Xr <- X[, -j, drop = FALSE]; br <- drop(pinv(crossprod(Xr)) %*% crossprod(Xr, yy)); fr <- drop(Xr %*% br); ur <- yy - fr
      gi <- as.integer(factor(z$div)); t0 <- b[j] / se1
      ts <- vapply(seq_len(NB16), function(r) { ys <- fr + ur * sample(c(-1, 1), G, TRUE)[gi]; bs <- drop(XtXi %*% crossprod(X, ys)); us <- ys - drop(X %*% bs)
        bs[j] / sqrt(max(vcl(X, us, XtXi, gi)[j, j], 1e-300)) }, numeric(1)); p_wcb <- mean(abs(ts) >= abs(t0)) }
    out <- data.table(var = key, coef = b[j], se = se1, p = 2 * pt(-abs(b[j] / se1), G - 1), se_2way = se2, p_2way = 2 * pt(-abs(b[j] / se2), G - 1), p_wcb = p_wcb,
               n = nrow(z), firms = nrow(z), clusters = G, mean_y = mean(dd[[y]], na.rm = TRUE), r2_within = 1 - sum(u^2) / sum(yy^2))
    rm(Mx, X, z); invisible(gc(FALSE)); out }
  OUT <- c(y_credit = "Зміна банківського кредиту, % активів на початок", y_stop = "Втрата банківського кредиту (частка фірм із кредитом)",
           y_lcredit = "Зміна логарифма банківського кредиту (фірми з кредитом)", y_tp = "Зміна кредиторської заборгованості за товари, % активів",
           y_fa = "Зміна логарифма основних засобів", y_ta = "Зміна логарифма активів", y_rev = "Зміна логарифма чистого доходу",
           y_wage = "Зміна логарифма витрат на оплату праці (форма 1)", y_emp = "Зміна логарифма кількості працівників", y_rate = "Фінансові витрати, % середнього банківського кредиту (форма 1)")
  run_specs <- function(dd, tag, wcb_main = FALSE) rbindlist(lapply(names(OUT), function(y) {
    m2x <- c("Sdep", DEPW, XC, "fL", "fS"); onlydep <- y %in% c("y_stop", "y_lcredit", "y_rate")
    if (onlydep) m2x <- c("S100", XC, "fL", "fS")                            # outcomes defined only for firms with bank credit: compare across divisions
    cb <- function(model, r) if (is.null(r)) NULL else cbind(sample = tag, model = model, outcome = y, r)
    rbindlist(list(
      cb("M1. S галузі; секція×вікно, область×вікно", firm_reg(dd[if (onlydep) dep == 1 else TRUE], y, c("S100", "dep", XC, "fL", "fS"), "sw", "ow")),
      if (!onlydep) cb("M2. S × залежність від банків; розділ×вікно, область×вікно", firm_reg(dd, y, m2x, "dw", "ow", wcb = wcb_main && y %in% c("y_credit", "y_fa", "y_rev"))),
      if (!onlydep) cb("M3. Експозиція до банків із запасом до 5 в. п. × залежність; розділ×вікно, область×вікно", firm_reg(dd, y, c("Edep", DEPW, XC, "fL", "fS"), "dw", "ow")),
      # M4: only borrowers – all of them report under the same incentives of the bank's assessment of the borrower (NBU Regulation No. 351),
      #     so a difference in reporting behaviour between borrowers and non-borrowers does not enter the comparison
      if (!onlydep) cb("M4. Лише фірми з кредитом: S галузі; секція×вікно, область×вікно", firm_reg(dd[dep == 1], y, c("S100", XC, "fL", "fS"), "sw", "ow")),
      if (!onlydep) cb("M4E. Лише фірми з кредитом: експозиція до банків із запасом до 5 в. п.; секція×вікно, область×вікно",
                       firm_reg(dd[dep == 1], y, c("E100", XC, "fL", "fS"), "sw", "ow"))), fill = TRUE) }), fill = TRUE)
  res <- run_specs(F, "Усі вікна", wcb_main = TRUE)
  res <- rbind(res, run_specs(F[win %in% c("FY2022", "9M2022")], "Воєнний шок 2022 р."), fill = TRUE)
  res[, label := OUT[outcome]]
  save_tab(res, "S3_B16_firm_effects.csv", "B16_firms")
  # ---- неоднорідність (M2, основні результати)
  het <- rbindlist(lapply(list(list("Великі й середні (форма 1)", quote(form == "L")), list("Малі (форма 1-м)", quote(form == "S")), list("Мікро (форма 1-мс)", quote(form == "M")),
                               list("Області поблизу фронту", quote(front == TRUE)), list("Інші області", quote(front == FALSE)),
                               list("Вікна 2023–2026", quote(!(win %in% c("FY2022", "9M2022")))),
                               list("Неперервна залежність: кредит / активи", NULL)), function(h) {
    rbindlist(lapply(c("y_credit", "y_fa", "y_rev", "y_tp"), function(y) {
      if (is.null(h[[2]])) r <- firm_reg(F, y, c("Slev", "lev_bank0", XC[-2], "fL", "fS"), "dw", "ow") else r <- firm_reg(F[eval(h[[2]])], y, c("Sdep", DEPW, XC, "fL", "fS"), "dw", "ow")
      if (is.null(r)) NULL else cbind(group = h[[1]], outcome = y, label = OUT[y], r) })) }), fill = TRUE)
  save_tab(het, "S3_B16_firm_heterogeneity.csv", "B16_het")
  # ---- плацебо: звітність 2021 р. (до війни) на шок 2022 р.
  pl <- NULL
  F21 <- F21_RAW
  if (nrow(F21) >= 2000L) {
    F21[, `:=`(obl = sub("^(UA|K)", "", obl), div = as.character(div), win_s = sub("2021", "2022", win))]
    F21 <- merge(F21[is.finite(ta_0) & is.finite(ta_1) & ta_0 >= 50 & ta_1 > 0], SS[, .(win_s = win, div = kved, S, sec)], by = c("win_s", "div"))
    F21[, `:=`(dep = as.numeric(f0(bank_0) > 0), lev_bank0 = winsor(f0(bank_0) / ta_0, 0, .99), l_ta0 = log(ta_0), cash0 = winsor(f0(cash_0) / ta_0, 0, .99),
               eq0 = winsor(rto(eq_0, ta_0), .01, .99), roa0 = winsor(rto(np_0, ta_0), .01, .99), fL = as.numeric(form == "L"), fS = as.numeric(form == "S"))]
    F21[, `:=`(y_credit = 100 * winsor((f0(bank_1) - f0(bank_0)) / ta_0), y_fa = winsor(fifelse(is.finite(fa_0) & is.finite(fa_1), log1p(pmax(fa_1, 0)) - log1p(pmax(fa_0, 0)), NA_real_)),
               y_rev = winsor(lgr(rev_1, rev_0)), Sdep = 100 * S * dep, dw = paste(div, win), ow = paste(obl, win))]
    fix_roa(F21)
    pl <- rbindlist(lapply(c("y_credit", "y_fa", "y_rev"), function(y) { r <- firm_reg(F21, y, c("Sdep", "dep", XC, "fL", "fS"), "dw", "ow"); if (is.null(r)) NULL else cbind(outcome = y, label = OUT[y], r) }))
    if (nrow(pl)) save_tab(pl, "S3_B16_firm_placebo_2021.csv", "B16_placebo") }
  fact("b16_placebo_n", if (is.null(pl) || !nrow(pl)) 0 else max(pl$n))
  # ---- контрфактичний розрахунок: якби банки з малим запасом капіталу мали такий самий шок пропозиції, як інші (за M2)
  cf <- rbindlist(lapply(c("FY2022", sort(setdiff(unique(F[grepl("^FY", win)]$win), "FY2022"))), function(w_) {
    z <- F[win == w_ & dep == 1]; if (!nrow(z)) return(NULL)
    # only an estimate with the sign the supply channel implies (better supply -> more) and p < 0.10 enters; otherwise the effect is set to 0
    b <- function(y) { r <- res[sample == "Усі вікна" & outcome == y & grepl("^M2", model)]; if (nrow(r) && is.finite(r$coef[1]) && r$coef[1] > 0 && r$p[1] < .10) r$coef[1] else 0 }
    dS <- 100 * z$dS_cf
    data.table(win = w_, firms = nrow(z), dS_mean = mean(dS), credit_bn = sum(b("y_credit") / 100 * dS * z$ta_0) / 1e6,
               fa_bn = sum((exp(b("y_fa") * dS) - 1) * pmax(z$fa_0, 0), na.rm = TRUE) / 1e6, rev_bn = sum((exp(b("y_rev") * dS) - 1) * pmax(z$rev_0, 0), na.rm = TRUE) / 1e6,
               b_credit = b("y_credit"), b_fa = b("y_fa"), b_rev = b("y_rev"), bank_0_bn = sum(z$bank_0) / 1e6, fa_0_bn = sum(pmax(z$fa_0, 0), na.rm = TRUE) / 1e6, rev_0_bn = sum(pmax(z$rev_0, 0), na.rm = TRUE) / 1e6) }))
  if (nrow(cf)) save_tab(cf, "S3_B16_firm_counterfactual.csv", "B16_cf")
  # ---- (d) динаміка після шоку: довгі різниці від грудня 2021 р. до грудня t (t = 2020 – попередній період, 2022–2025 – після шоку).
  #      y_f(t) − y_f(2021) = β_t·(S_s,2022 × Dep_f,2021) + γ_t·Dep_f,2021 + X_f,2021'δ_t + ефекти розділу КВЕД і області + ε; S_s,2022 – шок пропозиції галузі у 2022 р.,
  #      Dep, KVED, область і контрольні змінні – на кінець 2021 р. (до війни). Окремі регресії для кожного t; кластери – розділи КВЕД.
  #      Також: вихід (фірма не подала звіт за рік t), отримання кредиту фірмами без кредиту у 2021 р., збалансована вибірка (фірми з усіма роками).
  es_tab <- NULL; s22d <- SS[win == "FY2022", .(div = kved, S22 = S, E22 = E_low, sec)]
  if (nrow(s22d) && ESP[t == 2021L, .N] >= 1000L) {
    base <- ESP[t == 2021L & is.finite(ta) & ta >= 50 & !(div %in% c("64", "65", "66", "84")) & !is.na(div)]
    base <- merge(base, s22d, by = "div")
    base[, `:=`(obl = sub("^(UA|K)", "", obl), dep = as.numeric(f0(bank) > 0), l_ta0 = log(ta), lev_bank0 = winsor(f0(bank) / ta, 0, .99), cash0 = winsor(f0(cash) / ta, 0, .99),
                eq0 = winsor(rto(eq, ta), .01, .99), roa0 = winsor(rto(np, ta), .01, .99), fL = as.numeric(form == "L"), fS = as.numeric(form == "S"))]
    base[, `:=`(Sdep = 100 * S22 * dep, Edep = 100 * E22 * dep, S100 = 100 * S22)]
    fix_roa(base)
    if (!is.null(EMP)) base <- merge(base, EMP[year == 2021L, .(edrpou, emp21 = emp)], by = "edrpou", all.x = TRUE) else base[, emp21 := NA_real_]
    TT <- setdiff(sort(unique(ESP$t)), 2021L); TT <- TT[TT >= 2019L]
    present <- ESP[, .(edrpou, t)]
    allyrs <- ESP[t %in% c(2021L, TT[TT > 2021L]), .N, by = edrpou][N == 1L + sum(TT > 2021L), edrpou]
    es_tab <- rbindlist(lapply(TT, function(tt) {
      cur <- ESP[t == tt, .(edrpou, ta_t = ta, fa_t = fa, bank_t = bank, tp_t = tp, rev_t = rev, wage_t = wage)]
      z <- merge(base, cur, by = "edrpou", all.x = TRUE)
      if (!is.null(EMP)) z <- merge(z, EMP[year == tt, .(edrpou, emp_t = emp)], by = "edrpou", all.x = TRUE) else z[, emp_t := NA_real_]
      z[, `:=`(y_credit = 100 * winsor((f0(bank_t) - f0(bank)) / ta), y_tp = 100 * winsor((f0(tp_t) - f0(tp)) / ta),
               y_fa = winsor(fifelse(is.finite(fa) & is.finite(fa_t), log1p(pmax(fa_t, 0)) - log1p(pmax(fa, 0)), NA_real_)),
               y_ta = winsor(lgr(ta_t, ta)), y_rev = winsor(lgr(rev_t, rev)), y_wage = winsor(lgr(wage_t, wage)), y_emp = winsor(lgr(emp_t, emp21)))]
      for (v in c("y_credit", "y_tp", "y_fa", "y_ta", "y_rev", "y_wage", "y_emp")) set(z, i = which(!is.finite(z$ta_t)), j = v, value = NA_real_)
      if (tt > 2021L) { z[, y_exit := as.numeric(!is.finite(ta_t))]; z[, y_new := fifelse(dep == 0 & is.finite(ta_t), as.numeric(f0(bank_t) > 0), NA_real_)] }
      z[, `:=`(dw = div, ow = obl)]
      one <- function(y, xs, fe1, dd = z, lab) { r <- firm_reg(dd, y, xs, fe1, "ow"); if (is.null(r)) NULL else cbind(t = tt, spec = lab, outcome = y, r) }
      X0 <- c("dep", XC, "fL", "fS")
      rbindlist(c(lapply(c("y_credit", "y_tp", "y_fa", "y_ta", "y_rev", "y_wage", "y_emp"), function(y) rbindlist(list(
                     one(y, c("Sdep", X0), "dw", lab = "S × Dep"),
                     one(y, c("Edep", X0), "dw", lab = "E(до 5 в. п.) × Dep"),
                     one(y, c("Sdep", X0), "dw", dd = z[edrpou %in% allyrs], lab = "S × Dep, збалансована вибірка")), fill = TRUE)),
                   if (tt > 2021L) list(one("y_exit", c("Sdep", X0), "dw", lab = "S × Dep"),
                                        one("y_new", c("S100", XC[-2], "fL", "fS"), "sec", dd = z[dep == 0], lab = "S (фірми без кредиту у 2021 р.)"))), fill = TRUE) }), fill = TRUE)
    if (nrow(es_tab)) {
      es_tab[, label := c(OUT, y_exit = "Вихід: немає звіту за рік t", y_new = "Отримали банківський кредит (фірми без кредиту у 2021 р.)")[outcome]]
      save_tab(es_tab, "S3_B16_event_study.csv", "B16_es")
      fact("b16_es_years", paste(sort(unique(es_tab$t)), collapse = ", ")); fact("b16_es_base_firms", nrow(base)); fact("b16_es_balanced", length(allyrs))
      fe_ <- es_tab[spec == "S × Dep" & outcome %in% c("y_credit", "y_tp", "y_fa", "y_rev", "y_emp", "y_exit")]
      fe_ <- rbind(fe_, unique(fe_[, .(outcome, label)])[, `:=`(t = 2021L, coef = 0, se = 0)], fill = TRUE)
      fe_[, k := fifelse(outcome %in% c("y_credit", "y_tp"), 1, 100)]
      fe_[, `:=`(est = coef * k, lo = (coef - 1.96 * se) * k, hi = (coef + 1.96 * se) * k)]
      fe_[, lab := fifelse(k == 1 | outcome == "y_exit", paste0(label, ", в. п."), paste0(label, ", %"))]
      save_fig(ggplot(fe_, aes(t, est)) + geom_hline(yintercept = 0, linetype = "dashed") + geom_vline(xintercept = 2021.5, linetype = "dotted") +
                 geom_errorbar(aes(ymin = lo, ymax = hi), width = .15) + geom_point(size = 2) + geom_line() + facet_wrap(~ lab, ncol = 2, scales = "free_y") +
                 scale_x_continuous(breaks = sort(unique(fe_$t)), labels = as.character) +
                 labs(x = NULL, y = "Реакція на шок пропозиції галузі 2022 р. +1 в. п.", caption = "Джерело: розрахунки автора за даними НБУ і фінансової звітності підприємств.") +
                 theme_thesis(), "S3_F30_firm_event_study.png", 8.5, 6.4) } }
  # ---- (e) звітні стимули позичальників. Банк оцінює кредитний ризик боржника – юридичної особи за його фінансовою звітністю (клас боржника, Положення НБУ № 351),
  #      тому фірма, що має або планує кредит, зацікавлена показати кращий фінансовий результат, а фірма без кредиту – мінімізувати оподатковуваний прибуток.
  #      (1) розподіл рентабельності активів навколо нуля для фірм із кредитом і без нього (стрибок над нулем – уникнення звітного збитку; Burgstahler, Dichev, 1997);
  #      (2) зміна звітної рентабельності в рік перед отриманням першого банківського кредиту, у рік отримання і в рік повного погашення.
  rp <- F[grepl("^FY", win) & is.finite(ta_0) & ta_0 >= 50 & is.finite(np_1) & is.finite(ta_1) & ta_1 > 0,
          .(edrpou, year = as.integer(year), win, form, div, obl, sec, dep, l_ta0, ta_0, ta_1, np_1, np_0, bank_0, bank_1)]
  if (nrow(rp) >= 5000L) {
    rp[, roa := np_1 / ta_0]
    br <- seq(-0.05, 0.05, by = 0.005); rp[, bin := findInterval(roa, br, left.open = FALSE)]
    rp[, grp := fifelse(dep == 1, "Фірми з банківським кредитом", "Фірми без банківського кредиту")]
    hb <- rp[bin >= 1 & bin < length(br), .N, by = .(grp, bin)][order(grp, bin)]
    hb[, `:=`(lo = br[bin], hi = br[bin + 1L])]; hb[, share := N / sum(N), by = grp]
    bd_stat <- function(h, k) { h <- h[order(bin)]; Nt <- sum(h$N); p <- h$N / Nt; i <- match(k, h$bin)
      if (is.na(i) || i == 1L || i == nrow(h)) return(NA_real_)
      exp_ <- (h$N[i - 1L] + h$N[i + 1L]) / 2; pp <- p[i - 1L] + p[i + 1L]
      (h$N[i] - exp_) / sqrt(Nt * p[i] * (1 - p[i]) + .25 * Nt * pp * (1 - pp)) }
    k_below <- findInterval(-0.0025, br); k_above <- findInterval(0.0025, br)
    bunch <- hb[, .(firms_years = sum(N), below_0 = N[bin == k_below], above_0 = N[bin == k_above], ratio_above_below = N[bin == k_above] / N[bin == k_below],
                    bd_below = bd_stat(.SD, k_below), bd_above = bd_stat(.SD, k_above)), by = grp]
    bunch <- merge(bunch, rp[, .(share_loss = 100 * mean(np_1 < 0), share_small_profit = 100 * mean(roa >= 0 & roa < .005), roa_median = 100 * median(roa)), by = grp], by = "grp")
    save_tab(hb, "S3_B16_roa_distribution.csv", "B16_roa_hist"); save_tab(bunch, "S3_B16_reporting_bunching.csv", "B16_bunching")
    fact("b16_bunch_ratio_dep", round(bunch[grepl("^Фірми з", grp), ratio_above_below], 2), "фірми з кредитом: кількість у [0; 0,5 %) ROA / у [−0,5 %; 0)")
    fact("b16_bunch_ratio_nodep", round(bunch[grepl("^Фірми без", grp), ratio_above_below], 2))
    # (2) the year before the first loan, the year of the first loan, the year of full repayment
    rp[, `:=`(droa = winsor(np_1 / ta_1 - rto(np_0, ta_0)), new_now = as.numeric(f0(bank_0) == 0 & f0(bank_1) > 0), repaid = as.numeric(f0(bank_0) > 0 & f0(bank_1) == 0))]
    nxt <- rp[, .(edrpou, year = year - 1L, new_next = new_now)]
    rp <- merge(rp, nxt, by = c("edrpou", "year"), all.x = TRUE)
    rp[, `:=`(dw = paste(div, win), ow = paste(obl, win), fL = as.numeric(form == "L"), fS = as.numeric(form == "S"))]
    nb <- rp[f0(bank_0) == 0]
    ev <- rbindlist(list(
      cbind(test = "Рік перед першим кредитом (фірми без кредиту на початок року)", firm_reg(nb[is.finite(new_next)], "droa", c("new_next", "new_now", "l_ta0", "fL", "fS"), "dw", "ow")),
      cbind(test = "Рік отримання першого кредиту (фірми без кредиту на початок року)", firm_reg(nb, "droa", c("new_now", "l_ta0", "fL", "fS"), "dw", "ow")),
      cbind(test = "Рік повного погашення кредиту (фірми з кредитом на початок року)", firm_reg(rp[f0(bank_0) > 0], "droa", c("repaid", "l_ta0", "fL", "fS"), "dw", "ow"))), fill = TRUE)
    if (nrow(ev)) { ev[, coef_pp := 100 * coef]; ev[, se_pp := 100 * se]; save_tab(ev, "S3_B16_reporting_events.csv", "B16_rep_events") }
    hb[, mid := 100 * (lo + hi) / 2]
    save_fig(ggplot(hb, aes(mid, 100 * share)) + geom_col(width = .45, fill = "grey55", colour = "black", linewidth = .2) + geom_vline(xintercept = 0, linetype = "dashed") +
               facet_wrap(~ grp, ncol = 2) + labs(x = "Чистий фінансовий результат, % активів на початок року", y = "Частка фірм-років, %", caption = "Джерело: розрахунки автора за фінансовою звітністю підприємств.") + theme_thesis(),
             "S3_F31_roa_near_zero.png", 8.5, 3.6) }
  # ---- описова статистика вибірки
  dsc <- F[, .(firms = .N, bank_dep = 100 * mean(dep), lev_bank_dep = 100 * median(lev_bank0[dep == 1]), ta_med_mn = median(ta_0) / 1e3,
               y_credit = mean(y_credit, na.rm = TRUE), y_fa = mean(y_fa, na.rm = TRUE), y_rev = mean(y_rev, na.rm = TRUE), S_mean = 100 * mean(S), E_low = 100 * mean(E_low)), by = .(win, form)][order(win, form)]
  save_tab(dsc, "S3_B16_firm_sample.csv", "B16_sample")
  fact("b16_firms", uniqueN(F$edrpou)); fact("b16_obs", nrow(F)); fact("b16_windows", paste(sort(unique(F$win)), collapse = ", "))
  fact("b16_div", uniqueN(F$div)); fact("b16_bank_dep", round(100 * mean(F$dep), 1))
  # ---- рисунок: оцінки M2 за результатами (95% довірчі інтервали, кластери за розділами КВЕД); логарифмічні результати ×100, тобто у відсотках
  fg <- res[grepl("^M2", model) & is.finite(coef) & outcome %in% c("y_credit", "y_tp", "y_fa", "y_rev", "y_wage", "y_emp")]
  if (nrow(fg)) { fg[, k := fifelse(outcome %in% c("y_credit", "y_tp"), 1, 100)]
    fg[, `:=`(est = coef * k, lo = (coef - 1.96 * se) * k, hi = (coef + 1.96 * se) * k, lab = sub(", % активів.*$|^Зміна ", "", label))]
    fg[, lab := paste0(toupper(substr(lab, 1, 1)), substring(lab, 2), fifelse(k == 1, ", в. п. активів", ", %"))]
    save_fig(ggplot(fg, aes(x = est, y = sample)) + geom_vline(xintercept = 0, linetype = "dashed") +
               geom_errorbarh(aes(xmin = lo, xmax = hi), height = .25) + geom_point(size = 2) + facet_wrap(~ lab, ncol = 2, scales = "free_x") +
               labs(x = "Реакція фірми з банківським кредитом на шок пропозиції галузі +1 в. п.", y = NULL, caption = "Джерело: розрахунки автора за даними НБУ і Держстату.") +
               theme_thesis(), "S3_F29_firm_effects.png", 8.5, 5.2) }
})

# =============================== 3.3 ===========================================
cf <- est[month == max(est$month)]; Zc <- design(cf); s0 <- as.matrix(cf[, ..ALT]); Pv <- cf$P; W <- Pv / sum(Pv)
k_new <- function(dt, mode) if (mode == "buffers") PAR$k_base_2027 + PAR$buf_cons + fifelse(f0(as.numeric(dt$systemic_flag)) > 0, PAR$buf_sys, 0) else dt$kreq
SC <- list(A = list(name = "Зниження облікової ставки на 300 б. п.", dyS = -.03, dyB = -.03 * PAR$pass12, dyL = -.03 * PAR$pass12, dcod = -.03 * PAR$pass12, dcc = 0, dk = "current"),
           B = list(name = "Підвищення облікової ставки на 300 б. п.", dyS = .03, dyB = .03 * PAR$pass12, dyL = .03 * PAR$pass12, dcod = .03 * PAR$pass12, dcc = 0, dk = "current"),
           C = list(name = "Зниження ставки за ДС на 200 б. п. за незмінної облікової ставки", dyS = -.02, dyB = 0, dyL = 0, dcod = 0, dcc = 0, dk = "current"),
           D = list(name = "Зниження відносної дохідності ОВДП на 100 б. п.", dyS = 0, dyB = -.01, dyL = 0, dcod = 0, dcc = 0, dk = "current"),
           E = list(name = "Зростання вартості кредитного ризику на 200 б. п.", dyS = 0, dyB = 0, dyL = 0, dcod = 0, dcc = .02, dk = "current"),
           F = list(name = "Буфери капіталу 2027 р.", dyS = 0, dyB = 0, dyL = 0, dcod = 0, dcc = 0, dk = "buffers"),
           G = list(name = "Зниження облікової ставки на 300 б. п. за буферів 2027 р.", dyS = -.03, dyB = -.03 * PAR$pass12, dyL = -.03 * PAR$pass12, dcod = -.03 * PAR$pass12, dcc = 0, dk = "buffers"),
           H = list(name = "Зниження ставки на 300 б. п. і зростання вартості ризику на 200 б. п.", dyS = -.03, dyB = -.03 * PAR$pass12, dyL = -.03 * PAR$pass12, dcod = -.03 * PAR$pass12, dcc = .02, dk = "current"))
target <- function(th, sc) { c2 <- copy(cf); c2[, L1_rr_LS_w := L1_rr_LS_w + (sc$dyL - sc$dcc - sc$dyS)]; c2[, L1_rr_BS_w := L1_rr_BS_w + (sc$dyB - sc$dyS)]
  su <- pmax(s0 + probs(th, design(c2)) - probs(th, Zc), 0); su / rowSums(su) }
project <- function(su, sc) { out <- su; capb <- short <- liqb <- rep(FALSE, nrow(cf)); kn <- k_new(cf, sc$dk)
  for (i in seq_len(nrow(cf))) { K <- cf$reg_capital_mn[i]; RE <- cf$risk_exposure_implied_mn[i]
    rho <- cf$credit_rwa_mn[i] / max(cf$A_L[i] + PAR$rw_other * cf$A_O[i], 1e-9); rho <- if (is.finite(rho)) min(max(rho, .5), 1.5) else 1
    A <- cbind(rep(1, 4), diag(4)); b <- c(1, rep(0, 4)); meq <- 1; hascap <- is.finite(K) && is.finite(RE) && K > 0
    if (hascap) { room <- (K / kn[i] - RE) / (rho * Pv[i]); base <- s0[i, 1] + PAR$rw_other * s0[i, 4]; A <- cbind(A, -c(1, 0, 0, PAR$rw_other)); b <- c(b, -(base + room)); short[i] <- room < -1e-9 }
    lcr <- cf$lcr_all_pct[i] / 100; if (is.finite(lcr) && lcr > 0) { h0 <- s0[i, 2] + s0[i, 3] + PAR$h_other * s0[i, 4]; A <- cbind(A, c(0, 1, 1, PAR$h_other)); b <- c(b, h0 / lcr) }
    q <- tryCatch(quadprog::solve.QP(diag(4), su[i, ], A, b, meq = meq), error = function(e) NULL)
    if (!is.null(q)) { out[i, ] <- pmax(q$solution, 0); if (hascap) capb[i] <- (6 %in% q$iact) && max(abs(out[i, ] - su[i, ])) > 1e-6; liqb[i] <- (ncol(A) %in% q$iact) && is.finite(lcr) && max(abs(out[i, ] - su[i, ])) > 1e-6 } }
  list(s = out, cap = capb, short = short, liq = liqb) }
nii_change <- function(s1, sc) { yL <- fifelse(is.finite(cf$y_L), cf$y_L, median(cf$y_L, na.rm = TRUE)); yB <- fifelse(is.finite(cf$y_B), cf$y_B, median(cf$y_B, na.rm = TRUE)); cc <- f0(cf$cc)
  r0 <- cbind(yL - cc, yB, cf$y_S_alt, .03); r1 <- cbind(yL + sc$dyL - cc - sc$dcc, yB + sc$dyB, cf$y_S_alt + sc$dyS, .03)
  list(price = rowSums(r1 * s0) * Pv - rowSums(r0 * s0) * Pv - sc$dcod * f0(cf$liab_cust), realloc = rowSums(r1 * s1) * Pv - rowSums(r1 * s0) * Pv) }
nii_base <- d[month > seq(max(est$month), by = "-12 months", length.out = 2)[2] & month <= max(est$month) & nkb %in% cf$nkb, sum(nii_m, na.rm = TRUE)]
CFB <- NULL
blk("C1 контрфактичні сценарії", {
  rows <- list(); bank <- list()
  for (code in names(SC)) { sc <- SC[[code]]; su <- target(theta, sc); pj <- project(su, sc); s1 <- pj$s; nc <- nii_change(s1, sc)
    bl <- if (!is.null(BOOT) && nrow(BOOT)) t(apply(BOOT[seq_len(min(nrow(BOOT), 200)), , drop = FALSE], 1, function(th) colSums((target(th, sc) - s0) * W) * 100)) else matrix(NA_real_, 1, 4)
    du <- colSums((su - s0) * W) * 100; dc <- colSums((s1 - s0) * W) * 100
    rows[[code]] <- data.table(code = code, scenario = sc$name, n_banks = nrow(cf), dL_unc_pp = du[1], dB_unc_pp = du[2], dS_unc_pp = du[3], dO_unc_pp = du[4], dL_pp = dc[1], dB_pp = dc[2], dS_pp = dc[3], dO_pp = dc[4],
                               dL_lo = quantile(bl[, 1], .05, na.rm = TRUE), dL_hi = quantile(bl[, 1], .95, na.rm = TRUE), dB_lo = quantile(bl[, 2], .05, na.rm = TRUE), dB_hi = quantile(bl[, 2], .95, na.rm = TRUE),
                               dS_lo = quantile(bl[, 3], .05, na.rm = TRUE), dS_hi = quantile(bl[, 3], .95, na.rm = TRUE),
                               dL_bn = sum((s1[, 1] - s0[, 1]) * Pv) / 1e3, dB_bn = sum((s1[, 2] - s0[, 2]) * Pv) / 1e3, dS_bn = sum((s1[, 3] - s0[, 3]) * Pv) / 1e3,
                               cap_binding = sum(pj$cap), cap_shortfall = sum(pj$short), liq_binding = sum(pj$liq), dNII_price_pct = sum(nc$price) / nii_base * 100, dNII_realloc_pct = sum(nc$realloc) / nii_base * 100)
    bank[[code]] <- data.table(code = code, nkb = cf$nkb, fullname = cf$fullname, owner_ua = cf$owner_ua, P = Pv, sL0 = s0[, 1], sB0 = s0[, 2], sS0 = s0[, 3], sL_unc = su[, 1], sL1 = s1[, 1], sB1 = s1[, 2], sS1 = s1[, 3],
                               cap_binding = pj$cap, cap_shortfall = pj$short, dNII_price = nc$price, dNII_realloc = nc$realloc) }
  save_tab(rbindlist(rows), "S3_C1_counterfactual_system.csv", "C1_system"); CFB <<- rbindlist(bank); save_tab(CFB, "S3_C1_counterfactual_banks.csv", "C1_banks")
  save_tab(CFB[, .(dL_pp = sum((sL1 - sL0) * P) / sum(P) * 100, dB_pp = sum((sB1 - sB0) * P) / sum(P) * 100, dS_pp = sum((sS1 - sS0) * P) / sum(P) * 100, dL_bn = sum((sL1 - sL0) * P) / 1e3, dNII_price_bn = sum(dNII_price) / 1e3, n = .N), by = .(code, owner_ua)],
           "S3_C1_counterfactual_groups.csv", "C1_groups")
  fact("cf_month", as.character(max(est$month))); fact("cf_banks", nrow(cf)); fact("cf_share_of_portfolio", round(sum(Pv) / d[month == max(est$month), sum(P)], 4)); fact("nii_base_bn", round(nii_base / 1e3, 1))
})

blk("C2 динаміка та сітка коридору", {
  lm <- LAM[h == 12, setNames(lambda_monthly, asset)]
  save_tab(rbindlist(lapply(names(SC)[1:5], function(sc_code) { g <- CFB[CFB[["code"]] == sc_code]; w <- g$P / sum(g$P); full <- c(L = sum((g$sL1 - g$sL0) * w), B = sum((g$sB1 - g$sB0) * w), S = sum((g$sS1 - g$sS0) * w)) * 100
    data.table(code = sc_code, t = 0:36, dL = full["L"] * (1 - (1 - lm["s_L"])^(0:36)), dB = full["B"] * (1 - (1 - lm["s_B"])^(0:36)), dS = full["S"] * (1 - (1 - lm["s_S"])^(0:36)), full_L = full["L"], full_B = full["B"], full_S = full["S"]) })),
    "S3_C2_dynamic_paths.csv", "C2_paths")
  grid <- rbindlist(lapply(seq(0, -.06, by = -.005), function(x) { sc <- list(dyS = x, dyB = 0, dyL = 0, dcod = 0, dcc = 0, dk = "current"); su <- target(theta, sc); s1 <- project(su, sc)$s; nc <- nii_change(s1, sc)
    data.table(d_cd_rate_pp = x * 100, dL_pp = sum((s1[, 1] - s0[, 1]) * W) * 100, dB_pp = sum((s1[, 2] - s0[, 2]) * W) * 100, dS_pp = sum((s1[, 3] - s0[, 3]) * W) * 100, dL_bn = sum((s1[, 1] - s0[, 1]) * Pv) / 1e3,
               dNII_pct = (sum(nc$price) + sum(nc$realloc)) / nii_base * 100, cost_per_bn_loans = if (abs(sum((s1[, 1] - s0[, 1]) * Pv)) > 1) -(sum(nc$price) + sum(nc$realloc)) / sum((s1[, 1] - s0[, 1]) * Pv) else NA_real_) }))
  save_tab(grid, "S3_C2_corridor_grid.csv", "C2_corridor")
  grid2 <- rbindlist(lapply(seq(-.05, .05, by = .01), function(x) { sc <- list(dyS = x, dyB = x * PAR$pass12, dyL = x * PAR$pass12, dcod = x * PAR$pass12, dcc = 0, dk = "current"); su <- target(theta, sc); s1 <- project(su, sc)$s; nc <- nii_change(s1, sc)
    data.table(d_policy_pp = x * 100, dL_pp = sum((s1[, 1] - s0[, 1]) * W) * 100, dB_pp = sum((s1[, 2] - s0[, 2]) * W) * 100, dS_pp = sum((s1[, 3] - s0[, 3]) * W) * 100, dNII_price_pct = sum(nc$price) / nii_base * 100, dNII_realloc_pct = sum(nc$realloc) / nii_base * 100) }))
  save_tab(grid2, "S3_C2_policy_rate_grid.csv", "C2_policy_grid")
})

capb <- d[month == LAST & is.finite(reg_capital_mn) & is.finite(risk_exposure_implied_mn) & A_L > 0]
capb[, `:=`(rho = { r <- credit_rwa_mn / (A_L + PAR$rw_other * A_O); fifelse(is.finite(r), pmin(pmax(r, .5), 1.5), 1) }, hqla = A_B + A_S + PAR$h_other * A_O, lcr = pmax(f0(lcr_all_pct) / 100, 1))]
blk("C3 кредитна спроможність", {
  out <- rbindlist(lapply(c("current", "buffers"), function(mode) { kn <- k_new(capb, mode); rbindlist(lapply(c(0, .025, .05, .075, .10), function(loss) {
    gk <- pmax(((capb$reg_capital_mn - loss * capb$A_L) / kn - capb$risk_exposure_implied_mn) / (capb$rho * capb$A_L), 0); gl <- pmax(capb$hqla * (1 - 1 / capb$lcr) / capb$A_L, 0)
    rbindlist(lapply(seq(0, 1, .1), function(gt) data.table(mode = mode, loss = loss, target = gt, achieved_capital = sum(pmin(gt, gk) * capb$A_L) / sum(capb$A_L), achieved_both = sum(pmin(gt, gk, gl) * capb$A_L) / sum(capb$A_L),
                                                            banks_cap = sum(gk < gt), banks_liq = sum(gl < gt), loans_share_cap = sum(capb$A_L[gk < gt]) / sum(capb$A_L), n = nrow(capb)))) })) }))
  save_tab(out, "S3_C3_lending_capacity.csv", "C3_capacity")
  room <- rbindlist(lapply(c("current", "buffers"), function(mode) { kn <- k_new(capb, mode); capb[, .(mode = mode, nkb, fullname, owner_ua, k_req = kn, room_mn = reg_capital_mn / kn - risk_exposure_implied_mn, A_L, P, ratio = total_ratio_pct, reg_capital_mn, risk_exposure_implied_mn, rho, lcr = lcr_all_pct)] }))
  save_tab(room, "S3_C3_capital_room_banks.csv", "C3_room_banks")
  save_tab(room[, .(room_bn = sum(pmax(room_mn, 0)) / 1e3, shortfall_bn = sum(pmax(-room_mn, 0)) / 1e3, banks_short = sum(room_mn < 0), loans_bn = sum(A_L) / 1e3, median_room_to_loans = median(room_mn / A_L)), by = .(mode, owner_ua)],
           "S3_C3_capital_room.csv", "C3_room")
})

blk("C4 ROE і стале зростання", {
  if (!all(c("fin_profit_m", "fin_equity") %in% names(d))) stop("немає fin_profit_m / fin_equity у вітрині")
  pm <- d[month > seq(LAST, by = "-12 months", length.out = 2)[2] & month <= LAST, .(profit12 = sum(fin_profit_m, na.rm = TRUE) * 12 / max(sum(is.finite(fin_profit_m)), 1), eqty = mean(fin_equity, na.rm = TRUE)), by = nkb]
  cb <- merge(capb, pm, by = "nkb"); cb[, roe := profit12 / fifelse(eqty > 0, eqty, NA_real_)]
  out <- rbindlist(lapply(c("current", "buffers"), function(mode) { kn <- k_new(cb, mode); rbindlist(lapply(c(0, .3, .5, .7, 1), function(po) { gi <- pmax(cb$profit12, 0) * (1 - po) / (kn * cb$rho * cb$A_L)
    gr <- pmax((cb$reg_capital_mn / kn - cb$risk_exposure_implied_mn) / (cb$rho * cb$A_L), 0)
    rbindlist(lapply(c(1, 3), function(yr) { gt <- (gr + yr * gi) / yr; data.table(mode = mode, payout = po, years = yr, g_internal_sys = sum(gi * cb$A_L) / sum(cb$A_L), g_internal_median = median(gi),
                                                                                  banks_below_15 = sum(gt < .15), loans_share_below_15 = sum(cb$A_L[gt < .15]) / sum(cb$A_L), banks_below_30 = sum(gt < .30), loans_share_below_30 = sum(cb$A_L[gt < .30]) / sum(cb$A_L)) })) })) }))
  save_tab(out, "S3_C4_sustainable_growth.csv", "C4_growth")
  save_tab(rbind(cb[, .(roe = sum(profit12) / sum(eqty), roe_median = median(roe, na.rm = TRUE), profit_bn = sum(profit12) / 1e3, n = .N), by = owner_ua], data.table(owner_ua = "Система", roe = sum(cb$profit12) / sum(cb$eqty), roe_median = median(cb$roe, na.rm = TRUE), profit_bn = sum(cb$profit12) / 1e3, n = nrow(cb))),
           "S3_C4_roe_groups.csv", "C4_roe")
  save_tab(cb[, .(nkb, fullname, owner_ua, A_L, roe, profit12, eqty, reg_capital_mn)], "S3_C4_roe_banks.csv", "C4_roe_banks")
  # ROE decomposition by asset class at the latest date: contribution of each class to the margin over deposit cost
  x <- d[month == LAST & is.finite(rr_LS)]
  save_tab(x[, .(c_loans = sum((y_L - cc - cod) * A_L, na.rm = TRUE) / 1e3, c_ovdp = sum((y_B - cod) * A_B, na.rm = TRUE) / 1e3, c_cd = sum((y_S_alt - cod) * A_S, na.rm = TRUE) / 1e3, P_bn = sum(P) / 1e3), by = owner_ua][, `:=`(sh_loans = c_loans / (c_loans + c_ovdp + c_cd), sh_ovdp = c_ovdp / (c_loans + c_ovdp + c_cd), sh_cd = c_cd / (c_loans + c_ovdp + c_cd))],
           "S3_C4_margin_sources.csv", "C4_margin_sources")
})

blk("C5 розклад Шеплі", {
  GR <- list(`Відносна дохідність` = c("L1_rr_LS_w", "L1_rr_BS_w"), `Капітал і ліквідність` = c("L1_head", "L1_ln_lcr"), `Структура пасивів і розмір` = c("L1_cod", "L1_demand_share", "L1_fx_share", "L1_ln_assets"), `Монетарний режим і війна` = c("pol", "war"))
  GR <- Filter(length, lapply(GR, intersect, XCOLS))
  perms <- function(v) if (length(v) <= 1) list(v) else do.call(c, lapply(seq_along(v), function(i) lapply(perms(v[-i]), function(p) c(v[i], p))))
  shap <- function(t0, t1) { A <- est[month == t0]; B <- est[month == t1]; cm <- intersect(A$nkb, B$nkb); A <- A[match(cm, nkb)]; B <- B[match(cm, nkb)]; w <- (A$P + B$P) / sum(A$P + B$P)
    pred <- function(mix) { x <- copy(A); for (g in mix) for (v in GR[[g]]) set(x, j = v, value = B[[v]]); colSums(probs(theta, design(x)) * w) }
    ct <- setNames(lapply(names(GR), function(g) rep(0, 4)), names(GR)); pp <- perms(names(GR))
    for (p in pp) { cur <- character(0); base <- pred(cur); for (g in p) { cur <- c(cur, g); nw <- pred(cur); ct[[g]] <- ct[[g]] + (nw - base) / length(pp); base <- nw } }
    act <- colSums((as.matrix(B[, ..ALT]) - as.matrix(A[, ..ALT])) * w); mod <- pred(names(GR)) - pred(character(0))
    o <- rbindlist(c(lapply(names(GR), function(g) data.table(component = g, t(unname(ct[[g]]) * 100))), list(data.table(component = "Модель разом", t(unname(mod) * 100)), data.table(component = "Фактична зміна", t(unname(act) * 100)), data.table(component = "Непояснена частина", t(unname(act - mod) * 100)))), use.names = FALSE)
    setnames(o, c("component", ALT)); cbind(period = paste(format(t0, "%Y-%m"), "→", format(t1, "%Y-%m")), banks = length(cm), o) }
  ms <- sort(unique(est$month)); pick <- function(x) ms[which.min(abs(ms - as.Date(x)))]
  save_tab(rbind(shap(pick("2022-01-01"), pick("2023-12-01")), shap(pick("2023-12-01"), max(ms)), shap(pick("2019-12-01"), pick("2022-01-01"))), "S3_C5_shapley.csv", "C5_shapley")
})

blk("C6 ефективна межа", {
  ms <- d[month >= as.Date("2019-01-01"), .(rL = (sum(f0(ii_loans_m)) - sum(col0(.SD, "alloc_prov_m"))) * 12 / sum(f0(avg_loans_all)), rB = sum(col0(.SD, "inc_refin")) * 12 / sum(f0(avg_ovdp_osb)),
                                                     rS = sum(col0(.SD, "inc_cd")) * 12 / sum(f0(avg_cd_osb)), cod = wmean(cod4_total, P)), by = month][order(month)]
  R <- as.matrix(ms[, .(rL - cod, rB - cod, rS - cod)]); R <- R[stats::complete.cases(R), ]; Rq <- apply(R, 2, function(x) stats::filter(x, rep(1 / 3, 3), sides = 1)); Rq <- Rq[stats::complete.cases(Rq), ]
  mu <- colMeans(Rq); Sg <- cov(Rq); es <- function(w, a = .9) { p <- Rq %*% w; -mean(p[p <= quantile(p, 1 - a)]) }
  g <- CJ(wL = seq(0, 1, .05), wB = seq(0, 1, .05))[wL + wB <= 1 + 1e-9]; g[, wS := 1 - wL - wB]
  g[, c("mean", "sd", "es90") := { W3 <- cbind(wL, wB, wS); list(drop(W3 %*% mu), sqrt(rowSums((W3 %*% Sg) * W3)), apply(W3, 1, es)) }]
  save_tab(g, "S3_C6_frontier_grid.csv", "C6_grid")
  eff <- function(risk) { f <- g[order(get(risk))]; f[, best := cummax(mean)]; f[mean >= best - 1e-12] }
  save_tab(eff("sd")[, .(wL, wB, wS, mean, sd, es90)], "S3_C6_frontier_sd.csv", "C6_frontier_sd"); save_tab(eff("es90")[, .(wL, wB, wS, mean, sd, es90)], "S3_C6_frontier_es.csv", "C6_frontier_es")
  pt <- function(lab, w) { w <- w / sum(w); data.table(portfolio = lab, wL = w[1], wB = w[2], wS = w[3], mean = sum(w * mu), sd = sqrt(drop(t(w) %*% Sg %*% w)), es90 = es(w)) }
  ms2 <- sort(unique(d$month)); pick <- function(x) ms2[which.min(abs(ms2 - as.Date(x)))]
  P1 <- rbindlist(c(lapply(list(c("Система, січень 2022 р.", "2022-01-01"), c("Система, грудень 2023 р.", "2023-12-01")), function(z) { x <- d[month == pick(z[2])]; pt(z[1], c(sum(x$A_L), sum(x$A_B), sum(x$A_S))) }),
                    list({ x <- d[month == LAST]; pt("Система, остання дата", c(sum(x$A_L), sum(x$A_B), sum(x$A_S))) }),
                    lapply(c("Державні", "Іноземні", "Приватні"), function(o) { x <- d[month == LAST & owner_ua == o]; pt(paste0(o, ", остання дата"), c(sum(x$A_L), sum(x$A_B), sum(x$A_S))) }),
                    list({ r <- g[which.min(sd)]; pt("Мінімальна дисперсія", c(r$wL, r$wB, r$wS)) }, { r <- g[which.min(es90)]; pt("Мінімальний очікуваний хвостовий збиток", c(r$wL, r$wB, r$wS)) }, { r <- g[which.max(mean)]; pt("Максимальна середня маржа", c(r$wL, r$wB, r$wS)) })))
  P1[, `:=`(mean_at_same_sd = sapply(sd, function(s) g[sd <= s + 1e-9, max(mean)]), mean_at_same_es = sapply(es90, function(s) g[es90 <= s + 1e-9, max(mean)]))]
  save_tab(P1, "S3_C6_frontier_points.csv", "C6_points")
  save_tab(data.table(asset = c("Кредити після ризику", "ОВДП", "Сертифікати НБУ"), mean = mu, sd = sqrt(diag(Sg)), min = apply(Rq, 2, min), q10 = apply(Rq, 2, quantile, .1), corr_L = cor(Rq)[1, ], corr_B = cor(Rq)[2, ], months = nrow(Rq)), "S3_C6_return_moments.csv", "C6_moments")
  bk <- d[month == LAST & (A_L + A_B + A_S) > 0, { w <- c(A_L, A_B, A_S) / (A_L + A_B + A_S); sdv <- sqrt(drop(t(w) %*% Sg %*% w)); mn <- sum(w * mu); .(wL = w[1], wB = w[2], wS = w[3], mean = mn, sd = sdv, gap = g[sd <= sdv + 1e-9, max(mean)] - mn, P = P) }, by = .(nkb, fullname, owner_ua)]
  save_tab(bk, "S3_C6_frontier_banks.csv", "C6_banks")
  save_tab(bk[, .(gap_median = median(pmax(gap, 0)), gap_weighted = wmean(pmax(gap, 0), P), mean = wmean(mean, P), sd = wmean(sd, P), n = .N), by = owner_ua], "S3_C6_frontier_gap_groups.csv", "C6_gap_groups")
  # the same frontier on sub-periods: before the war and since March 2022
  sp <- rbindlist(lapply(list(c("До березня 2022 р.", "2019-01-01", "2022-02-28"), c("Із березня 2022 р.", "2022-03-01", "2099-01-01")), function(z) { ok <- ms$month >= as.Date(z[2]) & ms$month <= as.Date(z[3]); Rz <- as.matrix(ms[ok, .(rL - cod, rB - cod, rS - cod)]); Rz <- Rz[stats::complete.cases(Rz), ]
    data.table(period = z[1], asset = c("Кредити після ризику", "ОВДП", "Сертифікати НБУ"), mean = colMeans(Rz), sd = apply(Rz, 2, sd), months = nrow(Rz)) }))
  save_tab(sp, "S3_C6_return_moments_periods.csv", "C6_moments_periods")
})

# =============================== 3.4 поглиблений аналіз ==========================
# Блоки D не змінюють результатів A–C: вони додають зрізи, перевірки стійкості та проєкції для тексту розділу.
ols_hc <- function(y, X) { X <- cbind(const = 1, as.matrix(X)); ok <- is.finite(y) & apply(is.finite(X), 1, all); y <- y[ok]; X <- X[ok, , drop = FALSE]; XtXi <- pinv(crossprod(X))
  b <- drop(XtXi %*% crossprod(X, y)); u <- drop(y - X %*% b); V <- XtXi %*% crossprod(X * u) %*% XtXi * nrow(X) / max(nrow(X) - ncol(X), 1); se <- sqrt(pmax(diag(V), 0))
  data.table(var = colnames(X), coef = b, se = se, p = 2 * pt(-abs(b / se), max(nrow(X) - ncol(X), 1)), n = nrow(X), r2 = 1 - sum(u^2) / sum((y - mean(y))^2)) }
MS_ALL <- sort(unique(d$month)); pick_m <- function(x) MS_ALL[which.min(abs(MS_ALL - as.Date(x)))]
M12 <- seq(LAST, by = "-11 months", length.out = 2)[2]
hh_share <- function(x) col0(x, "loans_hh") / pmax(col0(x, "loans_hh") + col0(x, "loans_le"), 1)
fxl_share <- function(x) { fx <- col0(x, "loans_corp_all_fx") + col0(x, "loans_hh_all_fx"); fx / pmax(fx + col0(x, "loans_corp_all_uah") + col0(x, "loans_hh_all_uah"), 1) }

blk("D1 сортування банків за вартістю і структурою депозитів", {
  per <- list(c("Березень 2021 – лютий 2022", "2021-03-01", "2022-02-28"), c("Останні 12 місяців", as.character(M12), as.character(LAST)))
  bavg <- function(z) d[month >= as.Date(z[2]) & month <= as.Date(z[3]), .(cod = mean(cod, na.rm = TRUE), demand_share = mean(demand_share, na.rm = TRUE), fx_share = mean(fx_share, na.rm = TRUE),
      s_L = sum(A_L) / sum(P), s_B = sum(A_B) / sum(P), s_S = sum(A_S) / sum(P), s_O = sum(A_O) / sum(P), rr_LS = mean(rr_LS, na.rm = TRUE), y_L = mean(y_L, na.rm = TRUE), m_S = mean(y_S_alt - cod, na.rm = TRUE),
      head = mean(headroom_total_min_pp, na.rm = TRUE), hh = mean(hh_share(.SD)), P = mean(P), owner_ua = owner_ua[.N], months = .N), by = nkb][is.finite(cod) & months >= 6]
  srt <- function(w, v, lab, pl) { w <- copy(w)[is.finite(get(v))]; w[, q := pmin(ceiling(4 * rank(get(v), ties.method = "first") / .N), 4)]
    w[, .(period = pl, sort = lab, banks = .N, value = mean(get(v)), share_P = sum(P) / sum(w$P), s_L = sum(s_L * P) / sum(P), s_B = sum(s_B * P) / sum(P), s_S = sum(s_S * P) / sum(P), s_O = sum(s_O * P) / sum(P),
          s_L_mean = mean(s_L), s_S_mean = mean(s_S), s_B_mean = mean(s_B), rr_LS_median = median(rr_LS, na.rm = TRUE), m_S = mean(m_S, na.rm = TRUE), head_median = median(head, na.rm = TRUE), hh = mean(hh),
          state = sum(owner_ua == "Державні", na.rm = TRUE), foreign = sum(owner_ua == "Іноземні", na.rm = TRUE), private = sum(owner_ua == "Приватні", na.rm = TRUE)), by = q][order(q)] }
  W <- lapply(per, bavg)
  save_tab(rbindlist(lapply(seq_along(per), function(i) rbind(srt(W[[i]], "cod", "Вартість депозитів", per[[i]][1]), srt(W[[i]], "demand_share", "Частка коштів на вимогу", per[[i]][1])))), "S3_D1_sort_funding.csv", "D1_sort")
  w <- W[[2]]; sp <- function(a, b) { ct <- suppressWarnings(cor.test(w[[a]], w[[b]], method = "spearman", exact = FALSE)); data.table(x = a, y = b, rho = unname(ct$estimate), p = ct$p.value, n = sum(is.finite(w[[a]]) & is.finite(w[[b]]))) }
  save_tab(rbindlist(list(sp("cod", "s_L"), sp("cod", "s_S"), sp("cod", "s_B"), sp("demand_share", "s_L"), sp("demand_share", "s_S"), sp("demand_share", "s_B"), sp("cod", "rr_LS"), sp("head", "s_L"), sp("head", "s_S"), sp("hh", "rr_LS"), sp("hh", "s_L"))),
           "S3_D1_rank_correlations.csv", "D1_spearman")
  w[, `:=`(lnP = log(P), state = as.numeric(owner_ua == "Державні"), foreign = as.numeric(owner_ua == "Іноземні"))]
  save_tab(rbindlist(lapply(c("s_L", "s_B", "s_S"), function(y) cbind(dep = y, ols_hc(w[[y]], w[, .(cod, demand_share, fx_share, hh, lnP, head = head / 100, state, foreign)])))), "S3_D1_cross_regression.csv", "D1_cross_reg")
})

blk("D2 джерела міжбанківських відмінностей відносної дохідності", {
  x <- d[month >= M12 & month <= LAST & is.finite(rr_LS) & is.finite(y_L) & is.finite(cc), .(y_L = mean(y_L), cc = mean(cc), cap = mean(cap_charge), y_S = mean(y_S_alt), rr = mean(rr_LS), hh = mean(hh_share(.SD)), fxl = mean(fxl_share(.SD)),
                                                                                         lnP = log(mean(P)), A_L = mean(A_L), owner_ua = owner_ua[.N], months = .N), by = nkb][months >= 6]
  v <- var(x$rr); save_tab(data.table(component = c("Дохідність кредитів", "Вартість кредитного ризику", "Плата за капітал", "Дохідність сертифікатів НБУ"), sd_pp = 100 * c(sd(x$y_L), sd(x$cc), sd(x$cap), sd(x$y_S)),
                                      share = c(cov(x$y_L, x$rr), cov(-x$cc, x$rr), cov(-x$cap, x$rr), cov(-x$y_S, x$rr)) / v, sd_rr_pp = 100 * sqrt(v), banks = nrow(x)), "S3_D2_rr_variance.csv", "D2_variance")
  x[, `:=`(state = as.numeric(owner_ua == "Державні"), foreign = as.numeric(owner_ua == "Іноземні"))]
  save_tab(rbind(cbind(dep = "rr_LS", ols_hc(x$rr, x[, .(hh, fxl, lnP, state, foreign)])), cbind(dep = "y_L", ols_hc(x$y_L, x[, .(hh, fxl, lnP, state, foreign)])), cbind(dep = "cc", ols_hc(x$cc, x[, .(hh, fxl, lnP, state, foreign)]))), "S3_D2_rr_cross_regression.csv", "D2_rr_reg")
  save_tab(D0[is.finite(rr_LS) & !is.na(owner_ua), .(rr_LS = wmean(rr_LS, A_L), rr_median = median(rr_LS), share_neg = mean(rr_LS < 0), banks = uniqueN(nkb)), by = .(phase, owner_ua)][order(phase, owner_ua)], "S3_D2_rr_phase_owner.csv", "D2_phase_owner")
})

blk("D3 тривалість від'ємної відносної дохідності", {
  w <- d[month > seq(LAST, by = "-36 months", length.out = 2)[2] & month <= LAST & is.finite(rr_LS), .(months = .N, neg = sum(rr_LS < 0), A_L = A_L[.N], P = P[.N], s_L = s_L[.N], s_S = s_S[.N], last = max(month), owner_ua = owner_ua[.N]), by = nkb][months >= 24 & last == LAST]
  w[, grp := cut(neg / months, c(-.01, 0, .25, .5, .75, .9999, 1), labels = c("Жодного місяця", "До 25% місяців", "25–50%", "50–75%", "Понад 75%", "Усі місяці"))]
  save_tab(w[, .(banks = .N, share_banks = .N / nrow(w), share_loans = sum(A_L) / sum(w$A_L), share_P = sum(P) / sum(w$P), s_L = sum(s_L * P) / sum(P), s_S = sum(s_S * P) / sum(P), state = sum(owner_ua == "Державні", na.rm = TRUE), foreign = sum(owner_ua == "Іноземні", na.rm = TRUE), private = sum(owner_ua == "Приватні", na.rm = TRUE)), by = grp][order(grp)],
           "S3_D3_negative_duration.csv", "D3_duration")
})

blk("D4 зміна структури: всередині банків і між банками", {
  dec <- function(t0, t1, lab) { A <- d[month == pick_m(t0)]; B <- d[month == pick_m(t1)]; cm <- intersect(A$nkb, B$nkb); a <- A[match(cm, nkb)]; b <- B[match(cm, nkb)]
    wa <- a$P / sum(A$P); wb <- b$P / sum(B$P)
    rbindlist(lapply(c("s_L", "s_B", "s_S", "s_O"), function(k) { tot <- sum(B[[k]] * B$P) / sum(B$P) - sum(A[[k]] * A$P) / sum(A$P); within <- sum((wa + wb) / 2 * (b[[k]] - a[[k]])); between <- sum((b[[k]] + a[[k]]) / 2 * (wb - wa))
      data.table(period = lab, asset = k, total = 100 * tot, within = 100 * within, between = 100 * between, entry_exit = 100 * (tot - within - between), banks_both = length(cm), banks_exit = nrow(A) - length(cm), banks_entry = nrow(B) - length(cm),
                 banks_down = sum(b[[k]] < a[[k]]), share_P_down = sum(a$P[b[[k]] < a[[k]]]) / sum(a$P)) })) }
  save_tab(rbind(dec("2019-12-01", "2022-01-01", "Грудень 2019 – січень 2022"), dec("2022-01-01", "2023-12-01", "Січень 2022 – грудень 2023"), dec("2023-12-01", LAST, "Грудень 2023 – остання дата")), "S3_D4_within_between.csv", "D4_within_between")
})

blk("D5 стійкість оцінок моделі розподілу", {
  nb <- min(100L, NBOOT)
  fitspec <- function(e, xc, vs, lab) { X <- as.matrix(e[, ..xc]); mu <- colMeans(X); sdv <- apply(X, 2, sd); sdv[!is.finite(sdv) | sdv == 0] <- 1
    dsg <- function(M) cbind(1, sweep(sweep(M, 2, mu), 2, sdv, "/")); Z <- dsg(X); Y <- as.matrix(e[, ..ALT]); th <- fit_fmnl(Z, Y)
    apef <- function(t1, M) sapply(vs, function(v) { M2 <- M; M2[, v] <- M2[, v] + .01; colMeans(probs(t1, dsg(M2)) - probs(t1, dsg(M))) })
    a0 <- apef(th, X); idx <- split(seq_len(nrow(e)), e$nkb); bk <- names(idx); bb <- array(NA_real_, c(nb, 4, 2))
    for (b in seq_len(nb)) { ii <- unlist(idx[sample(bk, length(bk), TRUE)], use.names = FALSE); tb <- tryCatch(fit_fmnl(Z[ii, ], Y[ii, ], th), error = function(x) NULL); if (!is.null(tb)) bb[b, , ] <- apef(tb, X[ii, , drop = FALSE]) }
    se <- apply(bb, c(2, 3), sd, na.rm = TRUE)
    data.table(spec = lab, n = nrow(e), banks = length(bk), LS_L = 100 * a0[1, 1], se_LS_L = 100 * se[1, 1], LS_B = 100 * a0[2, 1], se_LS_B = 100 * se[2, 1], LS_S = 100 * a0[3, 1], se_LS_S = 100 * se[3, 1],
               BS_L = 100 * a0[1, 2], se_BS_L = 100 * se[1, 2], BS_B = 100 * a0[2, 2], se_BS_B = 100 * se[2, 2], BS_S = 100 * a0[3, 2], se_BS_S = 100 * se[3, 2]) }
  vs0 <- c("L1_rr_LS_w", "L1_rr_BS_w"); out <- list(fitspec(est, XCOLS, vs0, "Базова специфікація"))
  out[[2]] <- fitspec(est, XCOLS[!grepl("^M_", XCOLS)], vs0, "Без середніх Мундлака")
  out[[3]] <- fitspec(est[owner != "State"], setdiff(XCOLS, "state"), vs0, "Без державних банків")
  out[[4]] <- fitspec(est[!(month >= as.Date("2022-03-01") & month <= as.Date("2022-12-31"))], XCOLS, vs0, "Без березня – грудня 2022 р.")
  e5 <- copy(est); yrs <- sort(unique(format(e5$month, "%Y")))[-1]; for (y in yrs) set(e5, j = paste0("yr_", y), value = as.numeric(format(e5$month, "%Y") == y))
  out[[5]] <- fitspec(e5, c(setdiff(XCOLS, c("pol", "war")), paste0("yr_", yrs)), vs0, "Ефекти року замість ставки та індикатора війни")
  nmax <- est[, .N, by = nkb]; out[[6]] <- fitspec(est[nkb %in% nmax[N >= .9 * max(N), nkb]], XCOLS, vs0, "Банки, наявні весь період")
  e7 <- copy(d); for (v in XV) e7[, paste0("L3_", v) := shift(get(v), 3L), by = nkb]; x7 <- c(paste0("L3_", XV), "pol", "war", "state", "foreign")
  e7 <- e7[Reduce(`&`, lapply(c(x7, ALT), function(v) is.finite(as.numeric(e7[[v]]))))]; m7 <- paste0("L3_", sub("^L1_", "", MUND)); for (v in m7) e7[, paste0("M_", v) := mean(get(v)), by = nkb]
  out[[7]] <- fitspec(e7, c(x7, paste0("M_", m7)), c("L3_rr_LS_w", "L3_rr_BS_w"), "Лаг три місяці")
  e8 <- copy(d); e8[, `:=`(rs_LS = winsor(y_L - cc - cap_charge - y_S_sys12), rs_BS = winsor(y_B - y_S_sys12))]; e8[, `:=`(L1_rs_LS = shift(rs_LS), L1_rs_BS = shift(rs_BS)), by = nkb]
  x8 <- c("L1_rs_LS", "L1_rs_BS", setdiff(LX, vs0), "pol", "war", "state", "foreign"); e8 <- e8[Reduce(`&`, lapply(c(x8, ALT), function(v) is.finite(as.numeric(e8[[v]]))))]
  m8 <- c("L1_rs_LS", "L1_rs_BS", setdiff(MUND, vs0)); for (v in m8) e8[, paste0("M_", v) := mean(get(v)), by = nkb]
  out[[8]] <- fitspec(e8, c(x8, paste0("M_", m8)), c("L1_rs_LS", "L1_rs_BS"), "Єдина для системи ставка сертифікатів")
  save_tab(rbindlist(out), "S3_D5_fmnl_robustness.csv", "D5_robustness")
  xs <- intersect(c("L1_rr_LS_w", "L1_rr_BS_w", "L1_head", "L1_ln_lcr", "L1_demand_share", "L1_cod", "L1_ln_assets"), names(d))
  save_tab(rbindlist(lapply(c("s_L", "s_B", "s_S"), function(y) cbind(dep = y, fe_reg(d, y, xs)))), "S3_D5_fe_levels.csv", "D5_fe_levels")
})

blk("D6 використання депозитів на довшому горизонті", {
  if (!"g_dep" %in% names(d)) stop("потрібен блок B7")
  add_lead(d, "g_dep", -12L, "g_dep_l12"); ok <- is.finite(d$P_lag12) & d$P_lag12 > 0
  o1 <- rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(spec = "12 місяців з лагом приросту депозитів", asset = v, fe_reg(d[ok], paste0("g_", v), c("g_dep", "g_dep_l12")))))
  for (v in c("A_L", "A_B", "A_S", "A_O", "dep", "P")) { add_lead(d, v, -24L, "lg"); set(d, j = paste0("h_", v), value = d[[v]] - d$lg); if (v == "P") set(d, j = "P_lag24", value = d$lg) }
  d[, lg := NULL]; for (v in c("A_L", "A_B", "A_S", "A_O", "dep")) set(d, j = paste0("h_", v), value = winsor(d[[paste0("h_", v)]] / d$P_lag24))
  o2 <- rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(spec = "24 місяці", asset = v, fe_reg(d[is.finite(P_lag24) & P_lag24 > 0], paste0("h_", v), "h_dep"))))
  o3 <- rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(spec = "24 місяці, із березня 2022 р.", asset = v, fe_reg(d[is.finite(P_lag24) & P_lag24 > 0 & month >= as.Date("2024-03-01")], paste0("h_", v), "h_dep"))))
  save_tab(rbind(o1, o2, o3), "S3_D6_deposit_use_horizons.csv", "D6_horizons")
  byper <- function(lo, hi, lab) rbindlist(lapply(c("A_L", "A_B", "A_S", "A_O"), function(v) cbind(period = lab, asset = v, fe_reg(d[ok & month >= as.Date(lo) & month <= as.Date(hi)], paste0("g_", v), "g_dep"))))
  save_tab(rbind(byper("2019-01-01", "2020-12-31", "2019–2020"), byper("2021-01-01", "2022-02-28", "Січень 2021 – лютий 2022"), byper("2022-03-01", "2023-06-30", "Березень 2022 – червень 2023"),
                 byper("2023-07-01", "2024-12-31", "Липень 2023 – грудень 2024"), byper("2025-01-01", "2099-01-01", "Із січня 2025 р.")), "S3_D6_deposit_use_periods.csv", "D6_periods")
})

blk("D7 запас капіталу і подальша зміна кредитування: групування", {
  x <- d[is.finite(ds_L12f) & is.finite(headroom_total_min_pp)]
  x[, `:=`(r_L = ds_L12f - mean(ds_L12f), r_S = ds_S12f - mean(ds_S12f, na.rm = TRUE), r_g = dln_L12f - mean(dln_L12f, na.rm = TRUE)), by = month]
  x[, bin := cut(headroom_total_min_pp, c(-Inf, 2.5, 5, 7.5, 10, 15, 20, 30, Inf), labels = c("до 2,5", "2,5–5", "5–7,5", "7,5–10", "10–15", "15–20", "20–30", "понад 30"))]
  save_tab(x[, .(n = .N, banks = uniqueN(nkb), d_sL = 100 * mean(r_L), se_sL = 100 * sd(r_L) / sqrt(uniqueN(nkb)), d_sS = 100 * mean(r_S, na.rm = TRUE), se_sS = 100 * sd(r_S, na.rm = TRUE) / sqrt(uniqueN(nkb)),
                 dln_L = 100 * mean(r_g, na.rm = TRUE), s_L = 100 * mean(s_L), s_S = 100 * mean(s_S)), by = bin][order(bin)], "S3_D7_headroom_bins.csv", "D7_bins")
})

blk("D8 внески у скорочення та відновлення кредитування", {
  own_last <- d[order(month), .(own = owner_ua[.N]), by = nkb]          # група власності на останню дату: зміна власника не має виглядати як зміна кредитування групи
  seg <- function(m) { x <- merge(d[month == pick_m(m)], own_last, by = "nkb"); x <- x[!is.na(own)]; x[, .(corp = sum(col0(.SD, "loans_le")) / 1e3, hh = sum(col0(.SD, "loans_hh")) / 1e3), by = .(owner_ua = own)] }
  one <- function(t0, t1, lab) { a <- melt(seg(t0), id.vars = "owner_ua", value.name = "level0"); b <- melt(seg(t1), id.vars = "owner_ua", value.name = "level1"); x <- merge(a, b, by = c("owner_ua", "variable"))
    x[, `:=`(period = lab, change = level1 - level0, growth_pct = 100 * (level1 / level0 - 1))]; x[, contribution_pct := 100 * change / sum(change)]; x[] }
  save_tab(rbind(one("2022-01-01", "2023-12-01", "Січень 2022 – грудень 2023"), one("2023-12-01", LAST, "Грудень 2023 – остання дата")), "S3_D8_loan_recovery.csv", "D8_recovery")
  A <- d[month == pick_m("2023-12-01"), .(nkb, L0 = A_L)]; B <- d[month == LAST, .(nkb, fullname, owner_ua, L1 = A_L)]; x <- merge(A, B, by = "nkb"); x[, ch := L1 - L0]; setorder(x, -ch); tot <- sum(x$ch)
  save_tab(data.table(item = c("banks", "total_change_bn", "top5_share", "top10_share", "banks_decline", "median_growth_pct", "state_share", "foreign_share", "private_share"),
                      value = c(nrow(x), tot / 1e3, sum(x$ch[1:5]) / tot, sum(x$ch[1:10]) / tot, sum(x$ch < 0), 100 * median(x$L1 / pmax(x$L0, 1) - 1), sum(x$ch[x$owner_ua == "Державні"]) / tot, sum(x$ch[x$owner_ua == "Іноземні"]) / tot, sum(x$ch[x$owner_ua == "Приватні"]) / tot)),
           "S3_D8_loan_recovery_concentration.csv", "D8_concentration")
  save_tab(x[1:15, .(fullname, owner_ua, L0_bn = L0 / 1e3, L1_bn = L1 / 1e3, change_bn = ch / 1e3, growth_pct = 100 * (L1 / pmax(L0, 1) - 1), share_of_total = ch / tot)], "S3_D8_loan_recovery_top.csv", "D8_top")
})

blk("D9 проєкція кредитної спроможності на три роки", {
  if (!all(c("fin_profit_m", "fin_equity") %in% names(d))) stop("немає fin_profit_m / fin_equity у вітрині")
  pm <- d[month >= M12 & month <= LAST, .(profit12 = sum(fin_profit_m, na.rm = TRUE) * 12 / max(sum(is.finite(fin_profit_m)), 1), eqty = mean(fin_equity, na.rm = TRUE)), by = nkb]
  cb <- merge(capb, pm, by = "nkb"); cb[, roe := pmin(pmax(profit12 / fifelse(eqty > 0, eqty, NA_real_), 0), .4)]; cb[!is.finite(roe), roe := 0]
  sim <- function(g, loss, po, mode) { K <- cb$reg_capital_mn; L <- cb$A_L; RE <- cb$risk_exposure_implied_mn; E <- pmax(cb$eqty, 0); kn <- k_new(cb, mode); res <- list()
    for (yr in 1:3) { ret <- (1 - po) * cb$roe * E; ls <- loss * L; K <- K + ret - ls; E <- pmax(E + ret - ls, 0)
      gmax <- pmax((K / kn - RE) / (cb$rho * L), 0); gi <- pmin(g, gmax); dL <- gi * L; L0 <- L; RE <- RE + cb$rho * dL; L <- L + dL; con <- gmax < g - 1e-9
      res[[yr]] <- data.table(mode = mode, g_target = g, loss = loss, payout = po, year = yr, growth = sum(dL) / sum(L0), loans_index = sum(L) / sum(cb$A_L), banks_constrained = sum(con), loans_share_constrained = sum(L0[con]) / sum(L0),
                              banks_zero = sum(gmax <= 1e-9), ratio_sys = 100 * sum(K) / sum(RE),
                              growth_state = sum(dL[cb$owner_ua == "Державні"]) / sum(L0[cb$owner_ua == "Державні"]), growth_foreign = sum(dL[cb$owner_ua == "Іноземні"]) / sum(L0[cb$owner_ua == "Іноземні"]), growth_private = sum(dL[cb$owner_ua == "Приватні"]) / sum(L0[cb$owner_ua == "Приватні"])) }
    rbindlist(res) }
  gr <- CJ(mode = c("current", "buffers"), g = c(.15, .25), loss = c(0, .02, .04), po = c(.3, .5, 1))
  save_tab(rbindlist(lapply(seq_len(nrow(gr)), function(i) sim(gr$g[i], gr$loss[i], gr$po[i], gr$mode[i]))), "S3_D9_capacity_path.csv", "D9_path"); fact("d9_banks", nrow(cb))
})

# =============================== figures =======================================
blk("F рисунки", {
  .need(c("ggplot2")); library(ggplot2)
  # стовпчики й площі без суцільної темної заливки: класи активів розрізняються штрихуванням і світлими тонами (як у рисунках розділу)
  .bw_old <- if (exists("BW_FILL", envir = globalenv())) list(f = get("BW_FILL", envir = globalenv()), p = get("BW_PATTERN", envir = globalenv())) else NULL
  if (!is.null(.bw_old)) { assign("BW_FILL", c("white", "grey82", "#FFFFFF", "#FEFEFE", "grey92", "#FDFDFD", "grey65", "#FCFCFC"), envir = globalenv())
                           assign("BW_PATTERN", c("45", "none", "cross", "none", "none", "-45", "none", "horiz"), envir = globalenv()) }
  rt <- function(f) fread(file.path(TAB, f), encoding = "UTF-8")
  dm <- function(x) { x[, month := as.Date(month)]; x }
  ln <- function(dl, ylab, f, h = 4.6) save_fig(ggplot(dl, aes(month, value, linetype = variable, colour = variable)) + geom_line(linewidth = .7) + scale_colour_grey(start = 0, end = .55) +
                                                  labs(x = NULL, y = ylab, colour = NULL, linetype = NULL, caption = CAP) + theme_thesis(), f, 8.5, h)
  s <- dm(rt("S3_A2_system_monthly.csv"))
  ln(melt(s[, .(month, `Кредити після ризику та капіталу` = 100 * (y_L - cc - cap_charge), `Сертифікати НБУ` = 100 * y_S, `ОВДП` = 100 * y_B, `Вартість депозитів` = 100 * cod)], id.vars = "month"), "% річних", "S3_F01_returns.png")
  save_fig(ggplot(s, aes(month)) + geom_ribbon(aes(ymin = 100 * q25, ymax = 100 * q75), fill = "grey85") + geom_line(aes(y = 100 * q50), linetype = "22", colour = "grey40") + geom_line(aes(y = 100 * rr_LS), linewidth = .8) +
             geom_hline(yintercept = 0, linewidth = .3) + labs(x = NULL, y = "в. п.", caption = CAP) + theme_thesis(), "S3_F02_relative_return.png", 8.5, 4.6)
  save_fig(ggplot(melt(s[, .(month, `Кредити (чисті)` = 100 * s_L, `ОВДП` = 100 * s_B, `Сертифікати НБУ` = 100 * s_S, `Інші ліквідні активи` = 100 * s_O)], id.vars = "month"), aes(month, value, fill = variable)) +
             geom_area(colour = "black", linewidth = .2) + scale_fill_grey(start = .1, end = .95) + labs(x = NULL, y = "% портфеля", fill = NULL, caption = CAP) + theme_thesis(), "S3_F03_allocation.png", 8.5, 4.6)
  o <- dm(rt("S3_A1_structure_owner_monthly.csv"))
  save_fig(ggplot(melt(o[, .(month, owner_ua, `Кредити` = 100 * s_L, `ОВДП` = 100 * s_B, `Сертифікати НБУ` = 100 * s_S)], id.vars = c("month", "owner_ua")), aes(month, value, linetype = owner_ua)) + geom_line(linewidth = .6) +
             facet_wrap(~variable) + labs(x = NULL, y = "% портфеля", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F04_structure_owner.png", 10, 4.4)
  b <- rt("S3_A2_banks_latest.csv")[is.finite(rr_LS)]
  save_fig(ggplot(b, aes(100 * rr_LS, 100 * s_L, shape = owner_ua, size = sqrt(P))) + geom_vline(xintercept = 0, linewidth = .3) + geom_point(fill = "grey70", stroke = .5) + scale_shape_manual(values = c(22, 24, 21)) + guides(size = "none") +
             coord_cartesian(xlim = c(-25, 27)) + labs(x = "Відносна дохідність кредитів до ДС, в. п.", y = "Частка кредитів, %", shape = NULL, caption = CAP) + theme_thesis(), "S3_F05_cross_section.png", 8.5, 5)
  mp <- dm(rt("S3_A3_market_premium_monthly.csv"))
  ln(melt(mp[, .(month, `Кредити бізнесу до ставки ДС` = 100 * prem_nfc_cd, `Кредити бізнесу до кривої ОВДП (1 рік)` = 100 * prem_nfc_zc1, `Первинна дохідність ОВДП до ставки ДС` = 100 * ovdp_cd)], id.vars = "month")[is.finite(value)], "в. п.", "S3_F06_market_premium.png")
  sg <- dm(rt("S3_A5_segments_monthly.csv"))
  ln(melt(sg[, .(month, `Кредити населенню` = 100 * y_hh_12, `Кредити бізнесу` = 100 * y_corp_12, `Сертифікати НБУ` = 100 * cd_12)], id.vars = "month")[is.finite(value)], "% річних", "S3_F07_segments.png")
  if (file.exists(file.path(TAB, "S3_A6_economic_cost_monthly.csv"))) { e <- dm(rt("S3_A6_economic_cost_monthly.csv"))
    ln(melt(e[, .(month, `Кредити покривають бар'єрну ставку` = 100 * share_clear, `Сертифікати НБУ покривають бар'єрну ставку` = 100 * share_cd_clear)], id.vars = "month"), "% банків", "S3_F08_hurdle.png") }
  p <- rt("S3_A7_rr_path_after_shock.csv")
  save_fig(ggplot(melt(p[, .(t, `Сертифікати НБУ` = d_cd, `Кредити бізнесу` = d_loan_corp, `Кредити разом` = d_loan, `Відносна дохідність кредитів` = d_rr)], id.vars = "t"), aes(t, value, linetype = variable)) + geom_hline(yintercept = 0, linewidth = .3) + geom_line(linewidth = .7) +
             labs(x = "Місяців після підвищення облікової ставки на 1 в. п.", y = "в. п.", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F09_rr_path.png", 8.5, 4.6)
  a <- rt("S3_B1_fmnl_ape.csv")[1:2]; al <- rbindlist(lapply(ALT, function(k) data.table(shock = a$label, asset = c(s_L = "Кредити", s_B = "ОВДП", s_S = "Сертифікати НБУ", s_O = "Інші ліквідні")[k], ape = a[[paste0("ape_", k)]], se = a[[paste0("se_", k)]])))
  al[, asset := factor(asset, levels = c("Кредити", "ОВДП", "Сертифікати НБУ", "Інші ліквідні"))]
  save_fig(ggplot(al, aes(asset, ape, fill = shock)) + geom_col(position = position_dodge(.8), width = .7, colour = "black", linewidth = .3) + geom_errorbar(aes(ymin = ape - 1.645 * se, ymax = ape + 1.645 * se), position = position_dodge(.8), width = .2) +
             geom_hline(yintercept = 0, linewidth = .3) + scale_fill_grey(start = .2, end = .8) + labs(x = NULL, y = "Зміна частки, в. п.", fill = NULL, caption = CAP) + theme_thesis(), "S3_F10_ape.png", 8.5, 4.6)
  g <- rt("S3_B3_threshold_grid.csv")
  save_fig(ggplot(g, aes(cutoff_pp, 100 * coef)) + geom_ribbon(aes(ymin = 100 * (coef - 1.96 * se), ymax = 100 * (coef + 1.96 * se)), fill = "grey85") + geom_line() + geom_point(size = 1) + geom_hline(yintercept = 0, linewidth = .3) +
             labs(x = "Поріг запасу капіталу, в. п.", y = "Δ частки кредитів за рік, в. п.", caption = CAP) + theme_thesis(), "S3_F11_threshold.png", 8.5, 4.4)
  l <- rt("S3_B5_local_projections.csv")[spec == "symmetric" & ((asset == "S" & var == "dpx_s_S") | (asset == "L" & var == "dpx_head"))]
  l[, panel := fifelse(asset == "S", "Сертифікати НБУ × початкова частка", "Кредити × запас капіталу")]
  save_fig(ggplot(l, aes(h, coef)) + geom_ribbon(aes(ymin = coef - 1.645 * se, ymax = coef + 1.645 * se), fill = "grey85") + geom_line() + geom_point(size = 1) + geom_hline(yintercept = 0, linewidth = .3) + facet_wrap(~panel) +
             labs(x = "Місяців після зміни ставки", y = "в. п. частки на 1 в. п. ставки", caption = CAP) + theme_thesis(), "S3_F12_local_projections.png", 9, 4.2)
  sl <- rt("S3_B5_system_lp.csv"); sl[, asset := c(s_L = "Кредити", s_B = "ОВДП", s_S = "Сертифікати НБУ")[asset]]
  save_fig(ggplot(sl, aes(h, coef, linetype = asset)) + geom_hline(yintercept = 0, linewidth = .3) + geom_errorbar(aes(ymin = coef - 1.645 * se, ymax = coef + 1.645 * se), width = .3, linetype = "solid") + geom_line() + geom_point(size = 1) +
             labs(x = "Місяців після зміни ставки", y = "в. п. частки на 1 в. п. ставки", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F13_system_lp.png", 8.5, 4.6)
  ev <- rt("S3_B6_event_cd3m.csv")[asset == "s_S" & k < 98]; ev <- rbind(ev[, .(k, coef, se)], data.table(k = -1L, coef = 0, se = 0))[order(k)]
  save_fig(ggplot(ev, aes(k, coef)) + geom_ribbon(aes(ymin = coef - 1.645 * se, ymax = coef + 1.645 * se), fill = "grey85") + geom_line() + geom_point(size = 1) + geom_hline(yintercept = 0, linewidth = .3) + geom_vline(xintercept = -.5, linetype = "22") +
             labs(x = "Місяців від запровадження тримісячних сертифікатів", y = "в. п. частки сертифікатів", caption = CAP) + theme_thesis(), "S3_F14_event_cd3m.png", 8.5, 4.4)
  m7 <- rt("S3_B7_marginal_use_of_deposits.csv")[var == "g_dep" & sample %in% c("Уся вибірка", "До березня 2022 р.", "Із березня 2022 р.", "Державні", "Іноземні", "Приватні")]
  m7[, `:=`(asset = factor(c(A_L = "Кредити", A_B = "ОВДП", A_S = "Сертифікати НБУ", A_O = "Інші ліквідні")[asset], levels = c("Кредити", "ОВДП", "Сертифікати НБУ", "Інші ліквідні")), sample = factor(sample, levels = unique(sample)))]
  save_fig(ggplot(m7, aes(sample, 100 * coef, fill = asset)) + geom_col(position = position_dodge(.85), width = .8, colour = "black", linewidth = .3) + geom_errorbar(aes(ymin = 100 * (coef - 1.645 * se), ymax = 100 * (coef + 1.645 * se)), position = position_dodge(.85), width = .2) +
             geom_hline(yintercept = 0, linewidth = .3) + scale_fill_grey(start = .15, end = .95) + labs(x = NULL, y = "Копійок із гривні приросту депозитів", fill = NULL, caption = CAP) + theme_thesis(), "S3_F15_marginal_use.png", 9.5, 4.8)
  ff <- rt("S3_B7_system_flow_of_funds.csv"); ff[, phase := sub("^\\d\\. ", "", phase)]; ff[, phase := factor(sub(" (\\d{4}–\\d{4})$", "\n\\1", phase), levels = sub(" (\\d{4}–\\d{4})$", "\n\\1", phase))]
  save_fig(ggplot(melt(ff[, .(phase, `Кредити` = d_L, `ОВДП` = d_B, `Сертифікати НБУ` = d_S, `Інші ліквідні` = d_O)], id.vars = "phase"), aes(phase, value, fill = variable)) + geom_col(colour = "black", linewidth = .3) +
             geom_point(data = ff, aes(phase, d_dep), inherit.aes = FALSE, shape = 23, fill = "white", size = 2.5) + geom_hline(yintercept = 0, linewidth = .3) + scale_fill_grey(start = .15, end = .95) +
             labs(x = NULL, y = "млрд грн", fill = NULL, caption = CAP) + theme_thesis(), "S3_F16_flow_of_funds.png", 9.5, 4.8)
  cs <- rt("S3_C1_counterfactual_system.csv")[code %in% c("A", "B", "C", "D", "E")]
  save_fig(ggplot(melt(cs[, .(code, `Кредити` = dL_pp, `ОВДП` = dB_pp, `Сертифікати НБУ` = dS_pp)], id.vars = "code"), aes(code, value, fill = variable)) + geom_col(position = position_dodge(.8), width = .7, colour = "black", linewidth = .3) +
             geom_hline(yintercept = 0, linewidth = .3) + scale_fill_grey(start = .15, end = .95) + labs(x = "Сценарій", y = "Зміна частки, в. п.", fill = NULL, caption = CAP) + theme_thesis(), "S3_F17_counterfactual.png", 8.5, 4.6)
  dp <- rt("S3_C2_dynamic_paths.csv")[code %in% c("A", "C")]
  save_fig(ggplot(melt(dp[, .(code, t, `Кредити` = dL, `ОВДП` = dB, `Сертифікати НБУ` = dS)], id.vars = c("code", "t")), aes(t, value, linetype = variable)) + geom_hline(yintercept = 0, linewidth = .3) + geom_line(linewidth = .7) + facet_wrap(~code) +
             labs(x = "Місяців після зміни", y = "Зміна частки, в. п.", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F18_dynamic_paths.png", 9, 4.2)
  cg <- rt("S3_C2_corridor_grid.csv")
  save_fig(ggplot(melt(cg[, .(x = -d_cd_rate_pp, `Приріст кредитів, млрд грн` = dL_bn, `Втрата ЧПД, %` = -dNII_pct)], id.vars = "x"), aes(x, value, linetype = variable)) + geom_line(linewidth = .7) +
             labs(x = "Зниження ставки сертифікатів за незмінної облікової ставки, в. п.", y = NULL, linetype = NULL, caption = CAP) + theme_thesis(), "S3_F19_corridor.png", 8.5, 4.4)
  cp <- rt("S3_C3_lending_capacity.csv")[loss %in% c(0, .05, .1)]; cp[, `:=`(mode = fifelse(mode == "current", "Чинні вимоги", "Вимоги з буферами 2027 р."), loss = paste0("Втрати ", 100 * loss, "% кредитів"))]
  save_fig(ggplot(cp, aes(100 * target, 100 * achieved_both, linetype = loss)) + geom_abline(colour = "grey70") + geom_line(linewidth = .7) + facet_wrap(~mode) + coord_cartesian(xlim = c(0, 100), ylim = c(0, 100)) +
             labs(x = "Цільове зростання кредитів, %", y = "Досяжне зростання, %", linetype = NULL, caption = CAP) + theme_thesis(), "S3_F20_capacity.png", 9, 4.4)
  sh <- rt("S3_C5_shapley.csv")[!component %in% c("Модель разом", "Фактична зміна")]; act <- rt("S3_C5_shapley.csv")[component == "Фактична зміна"]
  save_fig(ggplot(sh, aes(period, s_L, fill = component)) + geom_col(colour = "black", linewidth = .3) + geom_point(data = act, aes(period, s_L), inherit.aes = FALSE, shape = 23, fill = "white", size = 3) + geom_hline(yintercept = 0, linewidth = .3) +
             scale_fill_grey(start = .1, end = .95) + labs(x = NULL, y = "Зміна частки кредитів, в. п.", fill = NULL, caption = CAP) + theme_thesis(), "S3_F21_shapley.png", 9, 4.8)
  fg <- rt("S3_C6_frontier_grid.csv"); fe <- rt("S3_C6_frontier_sd.csv"); fp <- rt("S3_C6_frontier_points.csv")[!grepl("^М", portfolio)]
  save_fig(ggplot(fg, aes(100 * sd, 100 * mean)) + geom_point(colour = "grey80", size = .6) + geom_line(data = fe, linewidth = .8) + geom_point(data = fp, aes(shape = portfolio), size = 3, fill = "grey50") + scale_shape_manual(values = c(21, 22, 24, 23, 25, 8)) +
             labs(x = "Стандартне відхилення маржі, в. п.", y = "Середня маржа над вартістю депозитів, в. п.", shape = NULL, caption = CAP) + theme_thesis(), "S3_F22_frontier.png", 8.5, 5.2)
  ms <- rt("S3_C4_margin_sources.csv")
  save_fig(ggplot(melt(ms[, .(owner_ua, `Кредити після ризику` = 100 * sh_loans, `ОВДП` = 100 * sh_ovdp, `Сертифікати НБУ` = 100 * sh_cd)], id.vars = "owner_ua"), aes(owner_ua, value, fill = variable)) + geom_col(colour = "black", linewidth = .3, width = .6) +
             scale_fill_grey(start = .15, end = .95) + labs(x = NULL, y = "% маржі над вартістю депозитів", fill = NULL, caption = CAP) + theme_thesis(), "S3_F23_margin_sources.png", 8, 4.4)
  if (file.exists(file.path(TAB, "S3_B10_bls_factors_by_phase.csv"))) {   # B10a: чинники стандартів кредитування бізнесу за оцінками банків, середнє за фазу
    bf <- rt("S3_B10_bls_factors_by_phase.csv")[phase != "Увесь період"]
    bf[, phase := sub("^\\d\\. ", "", phase)]; bf[, phase := sub("Воєнний шок, ставка 25%", "Воєнний шок 2022–2023", phase, fixed = TRUE)]; bf[, phase := factor(sub(" (\\d{4}–\\d{4})$", "\n\\1", phase), levels = sub(" (\\d{4}–\\d{4})$", "\n\\1", phase))]
    bl <- melt(bf[, .(phase, `Капіталізація банку` = bls_std_nfc_cap, `Ліквідна позиція банку` = bls_std_nfc_liq, `Ризик: економіка, галузь, застава` = (bls_std_nfc_econ + bls_std_nfc_ind + bls_std_nfc_coll) / 3,
                      `Конкуренція з іншими банками` = bls_std_nfc_comp)], id.vars = "phase")
    save_fig(ggplot(bl, aes(phase, value, fill = variable)) + geom_col(position = position_dodge(.8), width = .75, colour = "black", linewidth = .3) +
               geom_point(data = bf, aes(phase, bls_std_nfc), inherit.aes = FALSE, shape = 23, fill = "white", size = 2.6) + geom_hline(yintercept = 0, linewidth = .3) +
               scale_fill_grey(start = .15, end = .95) + labs(x = NULL, y = "Баланс відповідей, %", fill = NULL, caption = CAP) + theme_thesis(), "S3_F24_bls_factors.png", 9.5, 4.8) }
  if (!is.null(.bw_old)) { assign("BW_FILL", .bw_old$f, envir = globalenv()); assign("BW_PATTERN", .bw_old$p, envir = globalenv()) }
})

# =============================== output ========================================
fwrite(FACTS, file.path(OUT, "S3_facts.csv")); fwrite(STATUS, file.path(OUT, "S3_status.csv"))
tryCatch(write_workbook("Section_3.xlsx"), error = function(e) message("xlsx: ", conditionMessage(e)))
writeLines(jsonlite::toJSON(list(version = PIPELINE_VERSION, last_month = as.character(LAST), nboot = NBOOT, par = PAR, status = STATUS, minutes = round(as.numeric(difftime(Sys.time(), t0_all, units = "mins")), 1)), auto_unbox = TRUE, pretty = TRUE),
           file.path(OUT, "S3_run_log.json"))
tryCatch({ old <- setwd(OUTPUT_DIR); on.exit(setwd(old)); utils::zip(file.path(OUTPUT_DIR, "section_3_results.zip"), files = list.files("section_3", recursive = TRUE, full.names = TRUE), flags = "-q -r9X") }, error = function(e) message("zip: ", conditionMessage(e)))
print(STATUS)
message(sprintf("Розділ 3: готово за %.1f хв. Надішліть output_nbu/section_3_results.zip (або папку output_nbu/section_3).", as.numeric(difftime(Sys.time(), t0_all, units = "mins"))))
