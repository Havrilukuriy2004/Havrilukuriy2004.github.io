import pandas as pd, numpy as np, matplotlib, sys; matplotlib.use('Agg'); import matplotlib.pyplot as plt
T, out = sys.argv[1:3]
D = pd.read_csv(f'{T}/S3_B18_class_distribution.csv'); R = pd.read_csv(f'{T}/S3_B18_class_credit.csv')
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10})
fig, ax = plt.subplots(1, 2, figsize=(12.5, 4.3))
for b, lab, st in [(True, 'фірми з банківським кредитом', 'o-'), (False, 'фірми без кредиту', 's--')]:
    q = D[D.borrower == b]; ax[0].plot(q.year, q.mean_class, st, label=lab, lw=1.8)
ax[0].set_xticks(sorted(D.year.unique())); ax[0].set_ylabel('середній клас (1 — найкращий, 9 — найгірший)')
ax[0].set_title('Клас боржника за Положенням № 351\n(розраховано за річною звітністю)'); ax[0].legend(frameon=False); ax[0].grid(alpha=.3)
q = R[R.spec.str.startswith('dlbank: class x credit year')].set_index('term')
k = np.arange(2, 10)
b0 = q.loc[[f'c{i}' for i in k], 'coef'].values
for off, suf, lab in [(-.15, None, 'кредит у 2024–2025 рр.'), (0, '_y22', 'кредит у 2022 р. (клас на кінець 2021 р.)'), (.15, '_y23', 'кредит у 2023 р. (клас на кінець 2022 р.)')]:
    if suf is None:
        ax[1].errorbar(k + off, b0, 1.96 * q.loc[[f'c{i}' for i in k], 'se'].values, fmt='s', label=lab, capsize=3)
    else:
        ax[1].errorbar(k + off, b0 + q.loc[[f'c{i}{suf}' for i in k], 'coef'].values, 1.96 * q.loc[[f'c{i}{suf}' for i in k], 'se'].values, fmt='o', label=lab, capsize=3)
ax[1].axhline(0, color='k', lw=.8); ax[1].set_xticks(k); ax[1].set_xlabel('клас боржника на кінець року (база — клас 1)')
ax[1].set_ylabel('зміна log банківського кредиту наступного року'); ax[1].set_title('Клас і кредит наступного року\n(ефекти розділу КВЕД × рік)')
ax[1].legend(frameon=False); ax[1].grid(alpha=.3)
plt.tight_layout(); plt.savefig(out, dpi=200)
