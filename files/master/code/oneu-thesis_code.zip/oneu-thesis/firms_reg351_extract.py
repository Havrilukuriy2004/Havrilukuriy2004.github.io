# -*- coding: utf-8 -*-
"""Slim extract of the v5 export (all lines used by NBU Reg. 351 Annex 7 / p.162 and Res. 23).
Whole file:   python firms_reg351_extract.py ../finrep_2021-2025-FIN.csv data_nbu/firms/finrep_v5_slim.csv.gz
By byte part: python firms_reg351_extract.py SRC OUT_PREFIX k n   (part k of n; parts are concatenated afterwards)"""
import pandas as pd, sys, io, gzip, os, collections
SRC, OUT = sys.argv[1:3]
k, n = (int(sys.argv[3]), int(sys.argv[4])) if len(sys.argv) > 4 else (0, 1)
META = ['edrpou', 'year', 'balance_form', 'pnl_form', 'employees', 'firm_kved', 'firm_katottg', 'operating_result', 'net_result', 'pretax_result']
BAL = [1000, 1002, 1012, 1011, 1030, 1035, 1040, 1045, 1050, 1090, 1100, 1110, 1125, 1155, 1160, 1165, 1190, 1195, 1300, 1495, 1510, 1515,
       1595, 1600, 1610, 1615, 1690, 1695]
PNL = [2000, 2010, 2050, 2070, 2090, 2095, 2120, 2160, 2165, 2180, 2190, 2195, 2220, 2240, 2250, 2270, 2290, 2295, 2350, 2355, 2505, 2515]
want = set(META) | {f'r{r}_{s}' for r in BAL for s in ('open', 'close')} | {f'r{r}' for r in PNL}
size = os.path.getsize(SRC)
a, b = size * k // n, size * (k + 1) // n
cnt = collections.Counter()
with open(SRC, 'rb') as f:
    header = f.readline()
    cols = [c.lstrip('﻿') for c in header.decode('utf-8-sig').rstrip('\r\n').split(',')]
    use = [c for c in cols if c in want]
    if k == 0:
        print('columns used', len(use), '| not in export:', sorted(want - set(use)), flush=True)
    if a > 0:
        f.seek(a); f.readline()                      # move to the first full line of this part
    out = f'{OUT}.part{k:02d}.csv.gz' if n > 1 else OUT
    with gzip.open(out, 'wt', encoding='utf-8', newline='') as g:
        first = True
        while f.tell() <= b:
            buf = []
            while len(buf) < 100000:
                pos = f.tell()
                if pos > b: break
                line = f.readline()
                if not line: break
                buf.append(line)
            if not buf: break
            ch = pd.read_csv(io.BytesIO(header + b''.join(buf)), usecols=lambda c: c.lstrip('﻿') in want,
                             dtype={'﻿edrpou': str, 'edrpou': str, 'firm_kved': str, 'firm_katottg': str}, low_memory=False)
            ch.columns = [c.lstrip('﻿') for c in ch.columns]
            ch = ch[use]
            ch.to_csv(g, index=False, header=first and k == 0)
            first = False
            cnt.update(ch.year.value_counts().to_dict())
            if not line: break
print('part', k, 'rows by year', dict(sorted(cnt.items())), flush=True)
