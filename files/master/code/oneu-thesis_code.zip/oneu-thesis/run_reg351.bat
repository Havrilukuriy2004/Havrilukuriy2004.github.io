@echo off
rem B17-B18: NBU Reg. 351 / Res. 23 thresholds and borrower class (run from code\oneu-thesis)
set T=output_nbu\section_3\tables
set P=data_nbu\firms\reg351_panel_v5.parquet
rem the slim extract (about 5 min) is made once; delete data_nbu\firms\finrep_v5_slim.csv.gz to redo it after a new export
if not exist data_nbu\firms\finrep_v5_slim.csv.gz python -X utf8 firms_reg351_extract.py ..\finrep_2021-2025-FIN.csv data_nbu\firms\finrep_v5_slim.csv.gz || exit /b 1
python -X utf8 firms_reg351_build_v5.py data_nbu\firms\finrep_v5_slim.csv.gz %P% || exit /b 1
python -X utf8 firms_reg351_tests.py %P% %T% || exit /b 1
python -X utf8 firms_reg351_icr_all.py %P% %T% || exit /b 1
python -X utf8 firms_reg351_scoring.py %P% %T% || exit /b 1
python -X utf8 firms_reg351_class_analysis.py %P% %T% || exit /b 1
python -X utf8 firms_reg351_class_exposure.py %P% %T%\S3_B16_sector_supply_shocks.csv %T% || exit /b 1
python -X utf8 firms_reg351_bins.py %P% %T%\S3_B17_threshold_bins.csv || exit /b 1
rem figures in the thesis style (R): S3_F32-F34
Rscript -e "source('17_firms_reg351_figures.R', encoding = 'UTF-8')" || echo Rscript is not on PATH: run 17_firms_reg351_figures.R in RStudio
