# -*- coding: utf-8 -*-
"""Firm-year panel FY2021-FY2025 with NBU Regulation 351 / Resolution 23 debt-burden ratios."""
import pandas as pd, numpy as np, sys
# run from code/oneu-thesis:  python firms_reg351_build.py data_nbu/firms/reg351_panel.parquet [slim_2022_2025.csv.gz] [finrep_2021.csv]
OUT = sys.argv[1]
SLIM = sys.argv[2] if len(sys.argv) > 2 else 'data_nbu/firms/finrep_slim_2022_2025.csv.gz'
F21 = sys.argv[3] if len(sys.argv) > 3 else '../finrep_test_2021.csv'
C = ['edrpou', 'year', 'balance_form', 'employees', 'firm_kved', 'firm_katottg', 'operating_result', 'net_result',
     'r1300_open', 'r1300_close', 'r1495_close', 'r1165_open', 'r1165_close', 'r1510_open', 'r1510_close', 'r1515_open', 'r1515_close',
     'r1595_open', 'r1595_close', 'r1600_open', 'r1600_close', 'r1610_open', 'r1610_close', 'r1615_close', 'r1195_close', 'r1695_close', 'r1125_close', 'r1100_close',
     'r2000', 'r2050', 'r2120', 'r2250', 'r2515']
a = pd.read_csv(SLIM, dtype={'edrpou': str, 'firm_kved': str}, usecols=lambda c: c in C)
b = pd.read_csv(F21, dtype={'edrpou': str, 'firm_kved': str}, usecols=lambda c: c.lstrip('﻿') in C + ['r2190', 'r2195'])
b.columns = [c.lstrip('﻿') for c in b.columns]
chk = b[(b.balance_form == 'full') & b.r2190.notna()]
print('2021 check operating_result == r2190-r2195:', np.mean(np.isclose(chk.operating_result, chk.r2190.fillna(0) - chk.r2195.fillna(0))))
b = b[b.year == 2021].drop(columns=['r2190', 'r2195'])
d = pd.concat([b, a], ignore_index=True)
d = d.drop_duplicates(['edrpou', 'year'], keep='last')
d['div'] = pd.to_numeric(d.firm_kved.str.split('.').str[0], errors='coerce')
d = d[~d['div'].isin([64, 65, 66, 84]) & (d.r1300_close >= 50)]
z = lambda s: d[s].fillna(0)
full = d.balance_form.eq('full')
# Net liabilities ("чисті короткострокові та довгострокові зобов'язання"), 351 Annex 7 Table 3 / p.162(4)
d['nd'] = np.where(full, z('r1510_close') + z('r1515_close') + z('r1600_close') + z('r1610_close') - z('r1165_close'),
                   z('r1595_close') + z('r1600_close') + z('r1610_close') - z('r1165_close'))
d['sales'] = d.r2000
# Operating profit before amortization: full = 2190-2195+2515; small/micro = 2000-2050 (sales profit; p.162(4))
d['ebitda'] = np.where(full, d.operating_result + z('r2515'), d.r2000.fillna(0) - d.r2050.fillna(0))
d['finexp'] = np.where(full, d.r2250, np.nan)
d['bank_close'] = z('r1510_close') + z('r1600_close')
d['bank_open'] = z('r1510_open') + z('r1600_open')
d['borrower'] = (d.bank_close > 0) | (d.bank_open > 0)
d['nd_sales'] = np.where(d.sales > 0, d.nd / d.sales, np.nan)
d['nd_ebitda'] = np.where(d.ebitda > 0, d.nd / d.ebitda, np.nan)
d['icr'] = np.where(d.finexp > 0, d.ebitda / d.finexp, np.nan)
d['s1'] = d.nd_sales > 2.5
d['s2'] = (d.ebitda <= 0) | (d.nd_ebitda > 5)
d['hcr'] = d.s1 & d.s2 & (d.sales > 0)            # 351 p.162(4): class not better than 9
d['dflt23'] = full & (d.finexp > 0) & (d.icr < 1)  # Res.23 p.2-9(7) (proxy: past finance costs, unadjusted)
d['roa'] = d.net_result / d.r1300_open.where(d.r1300_open > 0)
d['full'] = full
keep = ['edrpou', 'year', 'balance_form', 'full', 'div', 'firm_katottg', 'employees', 'r1300_open', 'r1300_close', 'r1495_close', 'nd', 'sales', 'ebitda',
        'finexp', 'bank_open', 'bank_close', 'borrower', 'nd_sales', 'nd_ebitda', 'icr', 's1', 's2', 'hcr', 'dflt23', 'roa', 'operating_result', 'r2515', 'r2000', 'r2050', 'r2250', 'r1195_close', 'r1695_close', 'r1125_close', 'r1100_close', 'r1615_close', 'r1510_close', 'r1515_close', 'r1600_close', 'r1610_close', 'r1165_close', 'r1595_close']
d[keep].to_parquet(OUT, index=False)
print(d.groupby('year').size())
