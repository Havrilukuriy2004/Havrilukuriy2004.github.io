# -*- coding: utf-8 -*-
"""Density-discontinuity helpers (log-linear local fit on binned counts, firm-cluster bootstrap)."""
import numpy as np, pandas as pd
rng = np.random.default_rng(7)
B = 300


def disc(x, c, h, w, deg=1):
    """log density jump at c (right minus left) from binned counts, local polynomial each side."""
    x = x[(x >= c - h) & (x < c + h)]
    edges = np.arange(c - h, c + h + 1e-12, w)
    n, _ = np.histogram(x, edges)
    mid = (edges[:-1] + edges[1:]) / 2 - c
    L, R = mid < 0, mid > 0
    ln = np.log(n + .5)   # log-linear (exponential) local fit: robust to the convex decline of ratio densities
    fl = np.polyval(np.polyfit(mid[L], ln[L], deg), 0)
    fr = np.polyval(np.polyfit(mid[R], ln[R], deg), 0)
    return fr - fl, int(x.size), np.exp(fl), np.exp(fr)


def boot(df, var, c, h, w, groups):
    """theta per group and difference of the first two groups, firm-cluster bootstrap."""
    firms = df.edrpou.unique()
    idx = {f: i for i, f in enumerate(firms)}
    df = df.assign(fid=df.edrpou.map(idx))
    est = {g: disc(df.loc[m, var].values, c, h, w) for g, m in groups.items()}
    draws = {g: [] for g in groups}
    byf = df.groupby('fid').indices
    for _ in range(B):
        pick = rng.integers(0, len(firms), len(firms))
        rows = np.concatenate([byf[f] for f in pick])
        xv = df[var].values[rows]
        for g, m in groups.items():
            draws[g].append(disc(xv[m.values[rows]], c, h, w)[0])
    res = []
    for g in groups:
        th, n, fl, fr = est[g]; se = np.std(draws[g])
        res.append(dict(group=g, theta=th, se=se, z=th / se if se > 0 else np.nan, n_window=n, f_left=fl, f_right=fr))
    g1, g2 = list(groups)[:2]
    dd = np.array(draws[g1]) - np.array(draws[g2])
    th = est[g1][0] - est[g2][0]
    res.append(dict(group=f'{g1} minus {g2}', theta=th, se=dd.std(), z=th / dd.std(), n_window=np.nan))
    return pd.DataFrame(res)


