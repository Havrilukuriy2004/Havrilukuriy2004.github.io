# -*- coding: utf-8 -*-
"""Do banks with thin capital headroom cut riskier borrowers first? Borrower class (Reg. 351) x sector exposure to banks
with headroom < 5 pp (E_low, B16), within division: next-year bank credit of firms with bank debt.
python firms_reg351_class_exposure.py data_nbu/firms/reg351_panel_v5.parquet output_nbu/section_3/tables/S3_B16_sector_supply_shocks.csv OUTDIR"""
import pandas as pd, numpy as np, sys, os
from scipy.stats import norm
P, SH, OUT = sys.argv[1:4]
d = pd.read_parquet(P); d = d[d.class351.notna()].copy(); d['cls'] = d.class351.astype(int)
sh = pd.read_csv(SH, dtype={'kved': str}); sh = sh[sh.win.str.startswith('FY')].copy()
sh['year'] = sh.win.str[2:].astype(int) - 1          # window FY(t+1) = Dec t -> Dec t+1, exposure at Dec t
sh['div'] = pd.to_numeric(sh.kved, errors='coerce')
nx = d[['edrpou', 'year', 'bank_close', 'r1300_close']].copy(); nx['year'] -= 1
s = d.merge(nx.rename(columns={'bank_close': 'bank_next', 'r1300_close': 'ta_next'}), on=['edrpou', 'year'], how='left')
s = s[(s.bank_close > 0) & s.ta_next.notna()].merge(sh[['year', 'div', 'E_low', 'S']], on=['year', 'div'], how='inner')
s['dlbank'] = np.log1p(s.bank_next.clip(lower=0)) - np.log1p(s.bank_close)
s['lost'] = (s.bank_next <= 0).astype(float)
s['lta'] = np.log(s.r1300_close); s['lbank'] = np.log1p(s.bank_close)
s['risky'] = (s.cls >= 5).astype(float)            # classes 5-9
s['E100'] = 100 * s.E_low
s['risky_E'] = s.risky * s.E100
s['cls_E'] = s.cls * s.E100
s['divf'] = s['div'].astype(int).astype(str) + '_' + s.year.astype(str)
for k in range(2, 10): s[f'c{k}'] = (s.cls == k).astype(float)


def ols_fe(s, y, xs, fe='divf', cl='div'):
    s = s.dropna(subset=[y] + xs)
    g = pd.factorize(s[fe])[0]; n = np.bincount(g)
    M = np.column_stack([s[y].values] + [s[x].values for x in xs]).astype(float)
    M = M - (np.vstack([np.bincount(g, M[:, j]) for j in range(M.shape[1])]).T / n[:, None])[g]
    Y, X = M[:, 0], M[:, 1:]
    b = np.linalg.lstsq(X, Y, rcond=None)[0]; e = Y - X @ b
    c = pd.factorize(s[cl])[0]; XtXi = np.linalg.pinv(X.T @ X)
    S = np.vstack([np.bincount(c, X[:, j] * e) for j in range(X.shape[1])]).T
    G = c.max() + 1; V = XtXi @ (S.T @ S) @ XtXi * G / (G - 1)
    se = np.sqrt(np.diag(V))
    return pd.DataFrame(dict(term=xs, coef=b, se=se, p=2 * norm.sf(np.abs(b / se)), n=len(s), clusters=G, mean_y=s[y].mean()))


R = []
for yr, lab in [(2021, 'Dec 2021 -> Dec 2022 (war)'), (2022, 'Dec 2022 -> Dec 2023'), (2023, 'Dec 2023 -> Dec 2024'), (2024, 'Dec 2024 -> Dec 2025')]:
    q = s[s.year == yr]
    for y in ['dlbank', 'lost']:
        for xs, nm in [(['risky', 'risky_E', 'lta', 'lbank'], 'class 5-9 x E_low'), (['cls', 'cls_E', 'lta', 'lbank'], 'class (1-9) x E_low')]:
            r = ols_fe(q, y, xs); r['window'] = lab; r['outcome'] = y; r['spec'] = nm + ', division FE, clusters: division'; R.append(r)
R = pd.concat(R, ignore_index=True)
R.to_csv(f'{OUT}/S3_B18_class_x_exposure.csv', index=False)
print(R[R.term.isin(['risky', 'risky_E', 'cls', 'cls_E'])].round(4).to_string())
