# ============================================================================
# utils_i18n_v7.R — Ukrainian / English outputs
# ----------------------------------------------------------------------------
# Every figure is drawn twice by save_fig(): figures/ (українською) and
# figures_en/ (English). Tables, workbooks and the Word tables are translated
# after the models have run (i18n_export_all(), called from run_all_v6.R):
#   <section>/tables/*.csv  -> <section>/tables_en/*.csv
#   <section>/*.xlsx        -> <section>/*_EN.xlsx
#   thesis_tables/*.docx    -> thesis_tables/*_EN.docx
# Translations come from i18n/uk_en_dictionary.csv (exact strings) and
# i18n/uk_en_patterns.csv (regular expressions for strings that contain numbers,
# dates or bank names). Anything still in Cyrillic is transliterated and listed in
# output_nbu/logs/i18n_missing_en.csv, so a new label never breaks the run.
# Switch off English with Sys.setenv(THESIS_LANGS = "uk").
# ============================================================================
.need(c("zip", "xml2", "stringi"))
I18N_LANGS <- strsplit(Sys.getenv("THESIS_LANGS", unset = "uk,en"), ",")[[1]]
I18N_DIR   <- file.path(PROJECT_DIR, "i18n")
I18N_MISSING_FILE <- file.path(LOG_DIR, "i18n_missing_en.csv")
.CYR <- "[Ѐ-ӿ]"
has_cyr <- function(x) grepl(.CYR, x, perl = TRUE)

.i18n_env <- new.env()
.i18n_load <- function() {
  if (isTRUE(.i18n_env$loaded)) return(invisible(TRUE))
  rd <- function(f) { p <- file.path(I18N_DIR, f)
    if (file.exists(p)) data.table::fread(p, encoding = "UTF-8", colClasses = "character", na.strings = NULL) else data.table::data.table() }
  d <- rd("uk_en_dictionary.csv"); pt <- rd("uk_en_patterns.csv")
  .i18n_env$dict <- if (nrow(d)) setNames(d$en, d$uk) else character()
  if (nrow(pt)) pt[, replacement := gsub("}}", "\002", gsub("{{", "\001", replacement, fixed = TRUE), fixed = TRUE)]
  .i18n_env$pat  <- if (nrow(pt)) pt else data.table::data.table(pattern = character(), replacement = character())
  .i18n_env$terms <- if (nrow(d)) { t <- d[nchar(uk) >= 2 & !grepl("^[[:space:]]|[[:space:]]$", uk) & !grepl("%", uk, fixed = TRUE)]; t[order(-nchar(uk))] } else d
  .i18n_env$cache <- new.env(hash = TRUE)
  .i18n_env$missing <- character()
  .i18n_env$loaded <- TRUE
  invisible(TRUE)
}
i18n_reload <- function() { .i18n_env$loaded <- FALSE; .i18n_load() }

# Ukrainian national transliteration (Cabinet of Ministers, 2010) — last resort only
.TRL <- c("А"="A","Б"="B","В"="V","Г"="H","Ґ"="G","Д"="D","Е"="E","Є"="Ye","Ж"="Zh","З"="Z","И"="Y","І"="I","Ї"="Yi","Й"="Y",
          "К"="K","Л"="L","М"="M","Н"="N","О"="O","П"="P","Р"="R","С"="S","Т"="T","У"="U","Ф"="F","Х"="Kh","Ц"="Ts","Ч"="Ch",
          "Ш"="Sh","Щ"="Shch","Ь"="","Ю"="Yu","Я"="Ya","Ё"="Yo","Ы"="Y","Э"="E","Ъ"="",
          "а"="a","б"="b","в"="v","г"="h","ґ"="g","д"="d","е"="e","є"="ie","ж"="zh","з"="z","и"="y","і"="i","ї"="i","й"="i",
          "к"="k","л"="l","м"="m","н"="n","о"="o","п"="p","р"="r","с"="s","т"="t","у"="u","ф"="f","х"="kh","ц"="ts","ч"="ch",
          "ш"="sh","щ"="shch","ь"="","ю"="iu","я"="ia","ё"="io","ы"="y","э"="e","ъ"="","’"="","'"="")
translit_uk <- function(x) vapply(x, function(s) {
  ch <- strsplit(s, "")[[1]]; hit <- ch %in% names(.TRL); ch[hit] <- .TRL[ch[hit]]; paste(ch, collapse = "") }, "", USE.NAMES = FALSE)

# decimal comma -> point, typographic minus kept
.en_numbers <- function(s) gsub("(?<=[0-9]),(?=[0-9])", ".", s, perl = TRUE)

.tr_one <- function(s) {
  if (is.na(s) || !nzchar(s)) return(s)
  if (!has_cyr(s)) return(.en_numbers(s))
  d <- .i18n_env$dict; hit <- d[s]; if (!is.na(hit)) return(.en_numbers(unname(hit)))
  st <- trimws(s); if (!identical(st, s)) { hit <- d[st]; if (!is.na(hit)) return(.en_numbers(unname(hit))) }
  # same label with the other first-letter case ("кредити" / "Кредити")
  f1 <- substr(st, 1, 1); alt <- paste0(if (f1 == toupper(f1)) tolower(f1) else toupper(f1), substring(st, 2))
  hit <- d[alt]; if (!is.na(hit)) { e <- unname(hit); e1 <- substr(e, 1, 1)
    return(.en_numbers(paste0(if (f1 == toupper(f1)) toupper(e1) else tolower(e1), substring(e, 2)))) }
  out <- s
  pt <- .i18n_env$pat
  for (i in seq_len(nrow(pt))) if (grepl(pt$pattern[i], out, perl = TRUE)) {
    out <- gsub(pt$pattern[i], pt$replacement[i], out, perl = TRUE)
    # \003name\004 — a proper name (bank): dictionary form or transliteration, not reported as missing
    while (grepl("\003[^\003\004]*\004", out, perl = TRUE)) {
      m <- regmatches(out, regexpr("\003[^\003\004]*\004", out, perl = TRUE)); inner <- substr(m, 2, nchar(m) - 1)
      hit <- d[inner]; out <- sub(m, if (!is.na(hit)) unname(hit) else translit_uk(inner), out, fixed = TRUE) }
    # pattern outputs may contain {…} placeholders whose content is translated recursively
    # {{…}} in the replacement is turned into \001…\002 on loading, so braces inside formulas (y_{it}) cannot clash
    while (grepl("\001[^\001\002]*\002", out, perl = TRUE)) {
      m <- regmatches(out, regexpr("\001[^\001\002]*\002", out, perl = TRUE)); inner <- substr(m, 2, nchar(m) - 1)
      out <- sub(m, .tr_one(inner), out, fixed = TRUE) }
    if (!has_cyr(out)) return(.en_numbers(out))
  }
  hit <- d[out]; if (!is.na(hit)) return(.en_numbers(unname(hit)))
  # compositional fallback: replace known terms (longest first) inside the string
  tm <- .i18n_env$terms
  # only the terms that occur in the string (one vectorised scan instead of a loop over the whole dictionary)
  cand <- if (nrow(tm)) which(if (requireNamespace("stringi", quietly = TRUE)) stringi::stri_detect_fixed(out, tm$uk) else
    vapply(tm$uk, grepl, NA, x = out, fixed = TRUE, USE.NAMES = FALSE)) else integer()
  for (i in cand) {
    if (!has_cyr(out)) break
    u <- tm$uk[i]; if (grepl(u, out, fixed = TRUE)) out <- gsub(paste0("(?<![\\p{L}])\\Q", u, "\\E(?![\\p{L}])"), gsub("\\\\", "\\\\\\\\", tm$en[i]), out, perl = TRUE)
  }
  if (has_cyr(out)) { .i18n_env$missing <- c(.i18n_env$missing, s); out <- translit_uk(out) }
  .en_numbers(out)
}
tr_en <- function(x) {
  .i18n_load()
  if (is.factor(x)) { levels(x) <- tr_en(levels(x)); return(x) }
  if (!is.character(x)) return(x)
  u <- unique(x[!is.na(x)]); if (!length(u)) return(x)
  cache <- .i18n_env$cache
  val <- vapply(u, function(s) { if (!nzchar(s)) return(s); v <- cache[[s]]; if (is.null(v)) { v <- .tr_one(s); assign(s, v, envir = cache) }; v }, "", USE.NAMES = FALSE)
  out <- val[match(x, u)]; out[is.na(x)] <- NA_character_
  # two different Ukrainian labels must stay different in English (legend keys, factor levels)
  out
}
i18n_flush_missing <- function() {
  m <- unique(gsub("[\r\n]+", " ", .i18n_env$missing)); if (!length(m)) return(invisible(0L))
  old <- if (file.exists(I18N_MISSING_FILE)) readLines(I18N_MISSING_FILE, encoding = "UTF-8", warn = FALSE)[-1] else character()
  writeLines(c("uk", sort(unique(c(old, m)))), I18N_MISSING_FILE, useBytes = TRUE)   # one untranslated label per line
  .i18n_env$missing <- character(); invisible(length(m))
}

# ------------------------------ figures ----------------------------------------
.tr_df <- function(d) {
  if (!is.data.frame(d)) return(d)
  for (v in names(d)) if (is.character(d[[v]]) || is.factor(d[[v]])) d[[v]] <- tr_en(d[[v]])
  d
}
.tr_label <- function(x) {
  if (is.null(x) || inherits(x, "waiver") || is.expression(x) || is.call(x) || is.name(x) || is.function(x)) return(x)
  if (is.character(x)) { nm <- names(x); x <- tr_en(x); names(x) <- if (!is.null(nm)) tr_en(nm) else NULL }
  x
}
.gg_raw <- function(f) if (inherits(f, "ggproto_method")) environment(f)$f else f   # unwrap a ggproto method
.gg_copy <- function(o) {   # shallow copy of a ggproto object (layers have no $clone())
  n <- list2env(as.list.environment(o, all.names = TRUE), parent = parent.env(o)); attributes(n) <- attributes(o); n }
i18n_plot <- function(p) {
  q <- p
  for (n in seq_along(q$labels)) if (!is.null(q$labels[[n]])) q$labels[n] <- list(.tr_label(q$labels[[n]]))
  q$data <- .tr_df(q$data)
  for (i in seq_along(q$layers)) {
    lay <- .gg_copy(q$layers[[i]])
    if (is.data.frame(lay$data)) lay$data <- .tr_df(lay$data)
    for (a in names(lay$aes_params)) if (is.character(lay$aes_params[[a]])) lay$aes_params[[a]] <- tr_en(lay$aes_params[[a]])
    q$layers[[i]] <- lay
  }
  sc <- q$scales$clone()
  for (k in seq_along(sc$scales)) {
    s <- sc$scales[[k]]$clone()
    s$name <- .tr_label(s$name)
    ax <- tryCatch(s$secondary.axis, error = function(e) NULL)   # second y axis (e.g. policy rate on the right)
    if (inherits(ax, "AxisSecondary")) { ax <- .gg_copy(ax); ax$name <- .tr_label(ax$name)
      if (is.character(ax$labels)) ax$labels <- tr_en(ax$labels); s$secondary.axis <- ax }
    if (is.character(s$labels)) s$labels <- .tr_label(s$labels)
    # keys computed inside aes() (e.g. colour = LAB[code]) are not in the data: translate them when the legend is drawn
    else if (inherits(s, "ScaleDiscrete") && inherits(s$labels, "waiver")) s$labels <- function(x) tr_en(as.character(x))
    else if (inherits(s, "ScaleDiscrete") && is.function(s$labels)) s$labels <- local({ f0 <- .gg_raw(s$labels); function(x) tr_en(as.character(f0(x))) })
    if (is.character(s$breaks)) s$breaks <- tr_en(s$breaks)
    if (is.character(s$limits)) s$limits <- tr_en(s$limits)
    if (!is.null(s$palette.cache)) s$palette.cache <- NULL
    pal <- .gg_raw(s$palette); if (!is.function(pal)) pal <- function() NULL
    if (!is.null(environment(pal)) && exists("values", envir = environment(pal), inherits = FALSE)) {
      vals <- get("values", envir = environment(pal))
      if (!is.null(names(vals)) && any(has_cyr(names(vals)))) {
        e2 <- new.env(parent = environment(pal)); en <- tr_en(names(vals)); nv <- c(vals, setNames(vals, en)[!en %in% names(vals)]); assign("values", nv, envir = e2)
        environment(pal) <- e2; s$palette <- pal
        if (is.function(.gg_raw(s$limits))) s$limits <- local({ lv <- names(nv); function(x) intersect(x, lv) }) }
    }
    sc$scales[[k]] <- s
  }
  q$scales <- sc
  if (!is.null(q$guides) && is.list(q$guides)) for (g in names(q$guides)) if (is.list(q$guides[[g]]) && is.character(q$guides[[g]]$title)) q$guides[[g]]$title <- tr_en(q$guides[[g]]$title)
  q
}
i18n_lang_dir <- function(dir, lang) if (lang == "uk") dir else paste0(sub("/+$", "", dir), "_", lang)

# ------------------------------ tables -----------------------------------------
i18n_csv <- function(src, dst) {
  x <- data.table::fread(src, encoding = "UTF-8", colClasses = "character", na.strings = NULL)
  data.table::setnames(x, tr_en(names(x)))
  for (v in names(x)) { col <- x[[v]]; idx <- which(has_cyr(col) | grepl("[0-9],[0-9]", col))
    if (length(idx)) data.table::set(x, idx, v, tr_en(col[idx])) }
  data.table::fwrite(x, dst, bom = grepl("captions", basename(src)))
}
.xml_unesc <- function(x) { x <- gsub("&lt;", "<", x, fixed = TRUE); x <- gsub("&gt;", ">", x, fixed = TRUE)
  x <- gsub("&quot;", "\"", x, fixed = TRUE); x <- gsub("&apos;", "'", x, fixed = TRUE); gsub("&amp;", "&", x, fixed = TRUE) }
.xml_esc <- function(x) { x <- gsub("&", "&amp;", x, fixed = TRUE); x <- gsub("<", "&lt;", x, fixed = TRUE); gsub(">", "&gt;", x, fixed = TRUE) }
i18n_xlsx <- function(src, dst) {
  # Text cells live in the shared-string table: translating it once is fast and keeps
  # formulas, number formats, styles and column widths untouched.
  wb <- openxlsx::loadWorkbook(src)
  ss <- wb$sharedStrings
  if (length(ss)) {
    at <- attributes(ss)
    txt <- vapply(regmatches(ss, gregexpr("<t[^>]*>[^<]*</t>|<t[^>]*/>", ss)), function(v)
      paste(.xml_unesc(sub("^<t[^>]*>", "", sub("</t>$", "", v[!grepl("/>$", v)]))), collapse = ""), "")
    hit <- which(has_cyr(txt))
    if (length(hit)) ss[hit] <- paste0("<si><t xml:space=\"preserve\">", .xml_esc(tr_en(txt[hit])), "</t></si>")
    attributes(ss) <- at; wb$sharedStrings <- ss
  }
  sheets <- openxlsx::sheets(wb)
  new <- make.unique(substr(gsub("[][*?/\\\\:]", " ", tr_en(sheets)), 1, 28), sep = "_")
  for (k in seq_along(sheets)) if (!identical(new[k], sheets[k])) openxlsx::renameWorksheet(wb, sheets[k], new[k])
  openxlsx::saveWorkbook(wb, dst, overwrite = TRUE)
}
i18n_docx <- function(src, dst) {
  # Paragraph-level translation on the raw WordprocessingML (fast for documents with
  # thousands of table cells): the whole paragraph text goes into its first run,
  # the other runs of that paragraph are emptied, run formatting is kept.
  tmp <- tempfile("docx_"); dir.create(tmp); utils::unzip(src, exdir = tmp)
  for (part in list.files(file.path(tmp, "word"), pattern = "^(document|header[0-9]*|footer[0-9]*)\\.xml$", full.names = TRUE)) {
    x <- readChar(part, file.info(part)$size, useBytes = TRUE); Encoding(x) <- "UTF-8"
    # split at paragraph ends (fixed string — fast even for 30 MB tables documents)
    pc <- strsplit(x, "</w:p>", fixed = TRUE)[[1]]
    np <- if (endsWith(x, "</w:p>")) length(pc) else length(pc) - 1L      # pieces that end a paragraph
    idx <- which(seq_along(pc) <= np & (has_cyr(pc) | grepl("[0-9],[0-9]", pc)))
    if (length(idx)) {
      st <- stringi::stri_locate_last_regex(pc[idx], "<w:p[ >]")[, 1]
      ok <- !is.na(st); idx <- idx[ok]; st <- st[ok]
      head <- substr(pc[idx], 1, st - 1L); P <- substring(pc[idx], st)
      tre <- "<w:t(?: [^>]*)?>([^<]*)</w:t>|<w:t(?: [^>]*)?/>"
      txt <- vapply(regmatches(P, gregexpr(tre, P, perl = TRUE)), function(v)
        paste(.xml_unesc(sub("</w:t>$", "", sub("^<w:t(?: [^>]*)?>", "", v[!grepl("/>$", v)], perl = TRUE))), collapse = ""), "")
      hit <- which(has_cyr(txt))
      if (length(hit)) {
        en <- tr_en(txt[hit])
        P[hit] <- vapply(seq_along(hit), function(k) {
          q <- P[hit[k]]; tt <- gregexpr(tre, q, perl = TRUE); seg <- regmatches(q, tt)[[1]]
          regmatches(q, tt) <- list(c(paste0("<w:t xml:space=\"preserve\">", .xml_esc(en[k]), "</w:t>"), rep("<w:t/>", length(seg) - 1L))); q }, "")
      }
      num <- setdiff(which(grepl("[0-9],[0-9]", txt)), hit)
      if (length(num)) P[num] <- gsub("(?<=>)([^<]*?[0-9]),(?=[0-9])", "\\1.", P[num], perl = TRUE)
      pc[idx] <- paste0(head, P)
    }
    x <- paste0(paste(pc[seq_len(np)], collapse = "</w:p>"), "</w:p>", if (np < length(pc)) pc[length(pc)] else "")
    con <- file(part, "wb"); writeChar(x, con, eos = NULL, useBytes = TRUE); close(con)
  }
  if (file.exists(dst)) unlink(dst)
  zip::zip(file.path(normalizePath(dirname(dst)), basename(dst)), files = list.files(tmp, recursive = TRUE, all.files = TRUE), root = tmp)
  unlink(tmp, recursive = TRUE)
}

# translate every table output of one section folder (idempotent)
i18n_export_dir <- function(dir) {
  if (!"en" %in% I18N_LANGS || !dir.exists(dir)) return(invisible(0L))
  n <- 0L
  for (td in list.dirs(dir, recursive = FALSE)) {
    if (!basename(td) %in% c("tables")) next
    out <- i18n_lang_dir(td, "en"); unlink(out, recursive = TRUE); dir.create(out, showWarnings = FALSE)
    for (f in list.files(td, pattern = "\\.csv$", full.names = TRUE)) { tryCatch({ i18n_csv(f, file.path(out, basename(f))); n <- n + 1L },
      error = function(e) log_msg("i18n: ", basename(f), " not translated: ", conditionMessage(e))) }
    for (f in list.files(td, pattern = "\\.(json|txt)$", full.names = TRUE)) file.copy(f, out, overwrite = TRUE)
  }
  for (f in list.files(dir, pattern = "\\.csv$", full.names = TRUE)) if (!grepl("_EN\\.csv$", f))
    tryCatch(i18n_csv(f, sub("\\.csv$", "_EN.csv", f)), error = function(e) log_msg("i18n: ", basename(f), ": ", conditionMessage(e)))
  for (f in list.files(dir, pattern = "\\.xlsx$", full.names = TRUE)) if (!grepl("_EN\\.xlsx$", f))
    tryCatch({ i18n_xlsx(f, sub("\\.xlsx$", "_EN.xlsx", f)); n <- n + 1L }, error = function(e) log_msg("i18n: ", basename(f), ": ", conditionMessage(e)))
  for (f in list.files(dir, pattern = "\\.docx$", full.names = TRUE)) if (!grepl("_EN\\.docx$", f))
    tryCatch({ i18n_docx(f, sub("\\.docx$", "_EN.docx", f)); n <- n + 1L }, error = function(e) log_msg("i18n: ", basename(f), ": ", conditionMessage(e)))
  i18n_flush_missing()
  invisible(n)
}

I18N_SECTIONS <- c("section_2_1_v2", "section_2_2", "section_2_3", "section_2_4", "section_3", "expectations_money", "ou_dynamics", "capital", "thesis_tables")

# all sections + language bundles output_nbu/Results_UA.zip and Results_EN.zip
i18n_export_all <- function() {
  if (file.exists(I18N_MISSING_FILE)) unlink(I18N_MISSING_FILE)
  for (s in I18N_SECTIONS) i18n_export_dir(file.path(OUTPUT_DIR, s))
  rv <- file.path(PROJECT_DIR, "review"); if (dir.exists(rv)) {
    out <- file.path(rv, "en"); dir.create(out, showWarnings = FALSE)
    for (f in list.files(rv, pattern = "\\.csv$", full.names = TRUE)) tryCatch(i18n_csv(f, file.path(out, basename(f))), error = function(e) NULL) }
  i18n_flush_missing()
  bundle <- function(lang) {
    files <- unlist(lapply(I18N_SECTIONS, function(s) {
      d <- file.path(OUTPUT_DIR, s); if (!dir.exists(d)) return(character())
      fd <- if (lang == "uk") c("figures", "tables") else c("figures_en", "tables_en")
      inner <- unlist(lapply(fd, function(x) if (dir.exists(file.path(d, x))) file.path(s, x, list.files(file.path(d, x), recursive = TRUE)) else character()))
      top <- list.files(d, pattern = "\\.(xlsx|docx|csv)$"); top <- if (lang == "uk") top[!grepl("_EN\\.", top)] else top[grepl("_EN\\.", top)]
      c(inner, if (length(top)) file.path(s, top)) }))
    if (!length(files)) return(invisible(NULL))
    target <- file.path(OUTPUT_DIR, paste0("Results_", toupper(if (lang == "uk") "UA" else lang), ".zip"))
    if (file.exists(target)) unlink(target)
    zip::zip(target, files = files, root = OUTPUT_DIR)
    log_msg("i18n: ", basename(target), " — ", length(files), " files")
  }
  for (l in I18N_LANGS) bundle(l)
  n_miss <- if (file.exists(I18N_MISSING_FILE)) max(length(readLines(I18N_MISSING_FILE, warn = FALSE)) - 1L, 0L) else 0L
  log_msg("i18n: English outputs ready; strings without a dictionary entry: ", n_miss, if (n_miss) paste0(" (see ", I18N_MISSING_FILE, ")") else "")
  invisible(n_miss)
}
