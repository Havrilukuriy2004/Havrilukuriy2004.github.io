# -*- coding: utf-8 -*-
"""Transmission block shared by the funding (12) and assets (18) tools: when the effect of a policy-rate change is strongest,
the impulse response (IRF) at the peak, inertia (immediate pass-through, half-life, months to 90 %), system and selected bank.
System: panel local projections of section 2.2 (S22_P1_P5, specification "base"), mean-group ECM of S22_P9.
Bank: error-correction model of section 2.2 (S22_P8a) and of section 3 (S3_A7):  Δy_t = β0 Δi_t + φ (y_{t-1} - θ i_{t-1}),
so the response to a permanent 1 p.p. change of the policy rate is  y_h = θ + (β0 - θ)(1 + φ)^h."""
import csv, os, math
from collections import defaultdict
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import LineChart, Reference, Series
from openpyxl.formatting.rule import CellIsRule
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import Paragraph, ParagraphProperties, CharacterProperties, Font as DFont

A10 = Font(name="Arial", size=10); A10B = Font(name="Arial", size=10, bold=True); A10I = Font(name="Arial", size=10, italic=True)
A9 = Font(name="Arial", size=9); A9I = Font(name="Arial", size=9, italic=True); INP = Font(name="Arial", size=10, color="0000FF")
LINKF = Font(name="Arial", size=10, color="008000")
FILL_IN = PatternFill("solid", fgColor="FFF2CC"); FILL_KEY = PatternFill("solid", fgColor="F2F2F2"); FILL_HEAD = PatternFill("solid", fgColor="DDEBF7")
PEAKF = PatternFill("solid", fgColor="FCE4D6")
TH = Side(style="thin", color="000000"); BOX = Border(left=TH, right=TH, top=TH, bottom=TH); TOPB = Border(top=TH)
CEN = Alignment(horizontal="center", vertical="center", wrap_text=True); LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)
LNW = Alignment(horizontal="left", vertical="center", wrap_text=False); RIGHT = Alignment(horizontal="right", vertical="center")
N0 = '#,##0;\\–#,##0;"–"'; N1 = '#,##0.0;\\–#,##0.0;"–"'; N2 = '#,##0.00;\\–#,##0.00;"–"'; N3 = '0.000;\\–0.000;"–"'; P0 = '0%;\\–0%;"–"'


def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def num(x, d=None):
    try:
        v = float(x); return v if v == v else d
    except (TypeError, ValueError):
        return d


def put(ws, r, c, v, font=A10, fmt=None, al=None, border=None, fill=None):
    cell = ws.cell(r, c, v); cell.font = font
    if fmt: cell.number_format = fmt
    if al: cell.alignment = al
    if border: cell.border = border
    if fill: cell.fill = fill
    return cell


def header(ws, r, c0, labels, height=None, numbers=True):
    for j, lab in enumerate(labels):
        put(ws, r, c0 + j, lab, al=CEN, border=BOX, fill=FILL_HEAD)
    if height: ws.row_dimensions[r].height = height
    r += 1
    if numbers:
        for j in range(len(labels)):
            put(ws, r, c0 + j, j + 1, A9, al=CEN, border=BOX)
        r += 1
    ws.row_dimensions[r].height = 6
    return r + 1


def axis_font(ch):
    rt = RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=CharacterProperties(latin=DFont(typeface="Arial"), sz=900)), endParaRPr=CharacterProperties())])
    for ax in (ch.x_axis, ch.y_axis):
        ax.txPr = rt; ax.delete = False
    if ch.legend is not None:
        ch.legend.txPr = rt; ch.legend.position = "b"


H = 24          # horizon of the system LP, months
HB = 36         # horizon of the bank ECM path


def build(wb, out_root, sheet_name, data_sys, data_bank, sys_keys, bank_keys, bank_rows, bank_cell, title_no, title, src_note, a7_products=()):
    """sys_keys: [(key, label)] system LP series; bank_keys: [(key, label)] keys of S22_P8a; a7_products: [label] products of S3_A7.
    bank_rows: list of (nkb, bank name) in the order of the tool's own bank list; bank_cell: absolute reference of the selected bank name."""
    T22 = os.path.join(out_root, "section_2_2", "tables"); T3 = os.path.join(out_root, "section_3", "tables")
    lp = [r for r in rd(os.path.join(T22, "S22_P1_P5_panel_local_projections.csv")) if r["spec"] == "base" and r["term"] == ".s"]
    LP = defaultdict(dict); LPse = defaultdict(dict)
    for r in lp:
        LP[r["key"]][int(float(r["h"]))] = num(r["b"]); LPse[r["key"]][int(float(r["h"]))] = num(r["se"])
    SUM = {r["key"]: r for r in rd(os.path.join(T22, "S22_P9_summary_repricing.csv"))}
    E8 = {(r["nkb"], r["key"]): r for r in rd(os.path.join(T22, "S22_P8a_ecm_bank_level.csv"))}
    A7 = {}
    p7 = os.path.join(T3, "S3_A7_bank_transmission.csv")
    if os.path.exists(p7):
        A7 = {(r["nkb"], r["product"]): r for r in rd(p7)}
    # ---------------- data sheet: system LP (rows h, columns key b / se) and helper flags
    DS = wb.create_sheet(data_sys); DS.sheet_view.showGridLines = False; DS.sheet_properties.tabColor = "808080"
    put(DS, 1, 1, f"{data_sys}. Відгук ставок на зміну облікової ставки на 1 в.п.: панельні локальні проєкції (п. 2.2), система (не редагувати)", A10B)
    put(DS, 2, 1, "(β_h: зміна ставки статті через h місяців у в.п.; se: стандартна похибка; специфікація base)", A10)
    put(DS, 4, 1, "h, міс.", al=CEN, border=BOX)
    for j, (k, lab) in enumerate(sys_keys):
        put(DS, 4, 2 + 2 * j, f"{lab}: β_h", al=CEN, border=BOX); put(DS, 4, 3 + 2 * j, f"{lab}: se", al=CEN, border=BOX)
    DS.row_dimensions[4].height = 54
    D0 = 5
    for h in range(H + 1):
        put(DS, D0 + h, 1, h, fmt=N0, al=CEN)
        for j, (k, lab) in enumerate(sys_keys):
            put(DS, D0 + h, 2 + 2 * j, LP[k].get(h), fmt=N3); put(DS, D0 + h, 3 + 2 * j, LPse[k].get(h), fmt=N3)
    DL = D0 + H
    for c in range(2, 2 + 2 * len(sys_keys)): DS.column_dimensions[CL(c)].width = 11
    DS.freeze_panes = "B5"
    # ---------------- data sheet: bank ECM
    DB = wb.create_sheet(data_bank); DB.sheet_view.showGridLines = False; DB.sheet_properties.tabColor = "808080"
    put(DB, 1, 1, f"{data_bank}. Параметри моделі виправлення помилки за банками: β0, θ, φ, період напіврозпаду (п. 2.2, розділ 3; не редагувати)", A10B)
    put(DB, 2, 1, "(модель: Δy_t = β0 Δi_t + φ (y_{t-1} - θ i_{t-1}); y і i в п.п.; порожньо: оцінка недоступна або ряд банку закороткий)", A10)
    cols = [("nkb", "Код"), ("bank", "Банк")]
    allk = [(k, lab, "p8") for k, lab in bank_keys] + [(p, p, "a7") for p in a7_products]
    for k, lab, src in allk:
        for par, pl in (("beta0", "β0"), ("theta", "θ"), ("phi", "φ")):
            cols.append((f"{src}:{k}:{par}", f"{lab}: {pl}"))
    for j, (c, lab) in enumerate(cols):
        put(DB, 4, 1 + j, lab, al=CEN, border=BOX)
    DB.row_dimensions[4].height = 66
    B0 = 5
    for n, (nkb, name) in enumerate(bank_rows):
        q = B0 + n
        put(DB, q, 1, nkb); put(DB, q, 2, name)
        j = 3
        for k, lab, src in allk:
            rr = E8.get((nkb, k)) if src == "p8" else A7.get((nkb, k))
            for par in ("beta0", "theta", "phi"):
                v = num(rr.get(par)) if rr else None
                if src == "a7" and rr and str(rr.get("active", "True")).lower() in ("false", "0"):
                    v = None
                put(DB, q, j, v, fmt=N3); j += 1
    BL = B0 + len(bank_rows) - 1
    DB.column_dimensions["B"].width = 34
    for c in range(3, 1 + len(cols)): DB.column_dimensions[CL(c)].width = 10
    DB.freeze_panes = "C5"
    colof = {c: 1 + j for j, (c, _) in enumerate(cols)}
    # ---------------- analysis sheet
    ws = wb.create_sheet(sheet_name); ws.sheet_view.showGridLines = False; ws.sheet_properties.tabColor = "1F4E79"
    put(ws, 1, 1, title_no, A10B, al=LNW); put(ws, 2, 1, title, A10B, al=LNW)
    put(ws, 3, 1, "(відгук на постійне підвищення облікової ставки на 1 в.п.; в.п. зміни ставки статті; блакитна клітинка на жовтому тлі: вибір статті для графіка)", A10, al=LNW)
    put(ws, 4, 1, f'="Банк: "&{bank_cell}', A10I)
    r = 6
    put(ws, r, 1, "Стаття для графіка", al=LEFT, border=BOX)
    labs_all = [lab for _, lab in sys_keys]
    put(ws, r, 2, labs_all[0], INP, al=LEFT, border=BOX, fill=FILL_IN); SEL = f"'{sheet_name}'!$B${r}"
    put(ws, r, 3, "Оберіть статтю: графік показує відгук системи (локальні проєкції) і обраного банку (модель виправлення помилки).", A9, al=LNW)
    r += 1
    put(ws, r, 1, "Рядок банку", al=LEFT, border=BOX)
    put(ws, r, 2, f"=MATCH({bank_cell},'{data_bank}'!$B${B0}:$B${BL},0)", fmt=N0, al=RIGHT, border=BOX, fill=FILL_KEY); BROW = f"'{sheet_name}'!$B${r}"
    r += 2
    # --- A. system
    put(ws, r, 1, f"{title_no.split('.')[0]}.{sheet_name.split('.')[-1]}.1. Система: коли ефект найсильніший і наскільки інертна передача (локальні проєкції, п. 2.2)", A10B); r += 1
    labsA = ["Стаття", "Пік: місяць", "IRF на піку, в.п.", "β0 (місяць шоку)", "β через 1 міс.", "β через 3 міс.", "β через 6 міс.", "β через 12 міс.", "β через 24 міс.",
             "Місяців до 50 % піку", "Частка піку в місяць шоку", "Довгострокова передача θ (ECM)", "Швидкість φ (ECM)", "Період напіврозпаду, міс. (ECM)"]
    A0 = header(ws, r, 1, labsA, height=66)
    for j, (k, lab) in enumerate(sys_keys):
        q = A0 + j
        col = CL(2 + 2 * j); rng = f"'{data_sys}'!${col}${D0}:${col}${DL}"; hr = f"'{data_sys}'!$A${D0}:$A${DL}"
        put(ws, q, 1, lab, al=LNW)
        put(ws, q, 3, f"=IF(MAX({rng})>=-MIN({rng}),MAX({rng}),MIN({rng}))", A10B, N3, RIGHT, fill=PEAKF)
        put(ws, q, 2, f"=INDEX({hr},MATCH(C{q},{rng},0))", A10B, N0, CEN, fill=PEAKF)
        for jj, h in enumerate((0, 1, 3, 6, 12, 24)):
            put(ws, q, 4 + jj, f"=INDEX({rng},{h + 1})", fmt=N3, al=RIGHT)
        # first month with |β_h| >= 0.5 |peak|: SUMPRODUCT of the first index (no array formula needed)
        put(ws, q, 10, f'=IFERROR(MATCH(1,INDEX(--(ABS({rng})>=0.5*ABS(C{q})),0),0)-1,"…")', fmt=N0, al=CEN)
        put(ws, q, 11, f'=IFERROR(D{q}/C{q},"…")', fmt=P0, al=RIGHT)
        s9 = SUM.get(k, {})
        th_, ph_ = num(s9.get("theta_mg")), num(s9.get("phi_mg"))
        put(ws, q, 12, th_, fmt=N3, al=RIGHT); put(ws, q, 13, ph_, fmt=N3, al=RIGHT)
        put(ws, q, 14, f'=IFERROR(IF(AND(M{q}<0,M{q}>-1),LN(0.5)/LN(1+M{q}),"…"),"…")', fmt=N1, al=RIGHT)
    AL = A0 + len(sys_keys) - 1
    r = AL + 2
    # --- B. bank
    put(ws, r, 1, f"{title_no.split('.')[0]}.{sheet_name.split('.')[-1]}.2. Обраний банк: модель виправлення помилки", A10B); r += 1
    labsB = ["Стаття", "β0: передача в місяць шоку", "θ: довгострокова передача", "φ: швидкість виправлення", "Інертність 1 + φ: частка розриву, що зберігається за місяць",
             "Період напіврозпаду, міс.", "Місяців до 90 % θ", "Частка θ у місяць шоку", "IRF через 3 міс.", "IRF через 6 міс.", "IRF через 12 міс.", "Пік: місяць (90 % θ, якщо відгук монотонний)", "IRF на піку", "Надійність оцінки"]
    B_0 = header(ws, r, 1, labsB, height=78)
    for j, (k, lab, src) in enumerate(allk):
        q = B_0 + j
        cb, ct, cp = (CL(colof[f"{src}:{k}:{p}"]) for p in ("beta0", "theta", "phi"))
        g = lambda c: f"INDEX('{data_bank}'!${c}${B0}:${c}${BL},{BROW})"
        put(ws, q, 1, lab if src == "p8" else f"{lab} (розділ 3)", al=LNW)
        put(ws, q, 2, f'=IF(ISNUMBER({g(cb)}),{g(cb)},"…")', LINKF, N3, RIGHT)
        put(ws, q, 3, f'=IF(ISNUMBER({g(ct)}),{g(ct)},"…")', LINKF, N3, RIGHT)
        put(ws, q, 4, f'=IF(ISNUMBER({g(cp)}),{g(cp)},"…")', LINKF, N3, RIGHT)
        put(ws, q, 5, f'=IFERROR(1+D{q},"…")', fmt=N3, al=RIGHT)
        put(ws, q, 6, f'=IFERROR(IF(AND(D{q}<0,D{q}>-1),LN(0.5)/LN(1+D{q}),"…"),"…")', A10B, N1, RIGHT)
        put(ws, q, 7, f'=IFERROR(IF(AND(D{q}<0,D{q}>-1,(1-B{q}/C{q})>0.1),LN(0.1/(1-B{q}/C{q}))/LN(1+D{q}),0),"…")', fmt=N1, al=RIGHT)
        put(ws, q, 8, f'=IFERROR(B{q}/C{q},"…")', fmt=P0, al=RIGHT)
        for jj, h in enumerate((3, 6, 12)):
            put(ws, q, 9 + jj, f'=IFERROR(C{q}+(B{q}-C{q})*(1+D{q})^{h},"…")', fmt=N3, al=RIGHT)
        # peak over 0..36 of the closed-form path: either month 0 (overshoot) or the horizon end
        put(ws, q, 13, f'=IFERROR(IF(ABS(B{q})>=ABS(C{q}+(B{q}-C{q})*(1+D{q})^{HB}),B{q},C{q}+(B{q}-C{q})*(1+D{q})^{HB}),"…")', A10B, N3, RIGHT, fill=PEAKF)
        put(ws, q, 12, f'=IFERROR(IF(ABS(B{q})>=ABS(C{q}+(B{q}-C{q})*(1+D{q})^{HB}),0,IF(G{q}>{HB},{HB},MAX(0,ROUNDUP(G{q},0)))),"…")', A10B, N0, CEN, fill=PEAKF)
        put(ws, q, 14, f'=IF(AND(ISNUMBER(C{q}),ISNUMBER(D{q})),IF(OR(C{q}<0,C{q}>1.5,D{q}>=0,D{q}<=-1,F{q}>36),"неточна","прийнятна"),"немає оцінки")', fmt=None, al=CEN)
    BLR = B_0 + len(allk) - 1
    ws.conditional_formatting.add(f"N{B_0}:N{BLR}", CellIsRule(operator="equal", formula=['"неточна"'], fill=PatternFill("solid", fgColor="FFEB9C")))
    r = BLR + 2
    # --- C. paths for the chart
    put(ws, r, 1, f"{title_no.split('.')[0]}.{sheet_name.split('.')[-1]}.3. Траєкторії відгуку обраної статті", A10B); r += 1
    C0 = header(ws, r, 1, ["h, міс.", "Система: β_h (локальні проєкції)", "Нижня межа 90 %", "Верхня межа 90 %", "Банк: y_h (модель виправлення помилки)"], height=54)
    syscol = f"MATCH({SEL},$A${A0}:$A${AL},0)"
    for h in range(HB + 1):
        q = C0 + h
        put(ws, q, 1, h, fmt=N0, al=CEN)
        if h <= H:
            bcell = f"INDEX('{data_sys}'!$B${D0 + h}:${CL(1 + 2 * len(sys_keys))}${D0 + h},2*{syscol}-1)"
            scell = f"INDEX('{data_sys}'!$B${D0 + h}:${CL(1 + 2 * len(sys_keys))}${D0 + h},2*{syscol})"
            put(ws, q, 2, f'=IFERROR({bcell},NA())', fmt=N3); put(ws, q, 3, f'=IFERROR({bcell}-1.645*{scell},NA())', fmt=N3)
            put(ws, q, 4, f'=IFERROR({bcell}+1.645*{scell},NA())', fmt=N3)
        bk = f"MATCH({SEL},$A${B_0}:$A${BLR},0)"
        put(ws, q, 5, f'=IFERROR(INDEX($C${B_0}:$C${BLR},{bk})+(INDEX($B${B_0}:$B${BLR},{bk})-INDEX($C${B_0}:$C${BLR},{bk}))*(1+INDEX($D${B_0}:$D${BLR},{bk}))^A{q},NA())', fmt=N3)
    CL_ = C0 + HB
    ch = LineChart(); ch.title = "Відгук обраної статті на підвищення облікової ставки на 1 в.п."
    for col, nmx, clr, w in ((2, "система", "1F4E79", 22000), (3, "межі 90 %", "A6A6A6", 9000), (4, "межі 90 %", "A6A6A6", 9000), (5, "банк", "C00000", 22000)):
        s_ = Series(Reference(ws, min_col=col, min_row=C0, max_row=CL_), title=nmx); s_.graphicalProperties.line.solidFill = clr
        s_.graphicalProperties.line.width = w; s_.smooth = False
        if col in (3, 4): s_.graphicalProperties.line.dashStyle = "dash"
        ch.series.append(s_)
    ch.set_categories(Reference(ws, min_col=1, min_row=C0, max_row=CL_))
    ch.y_axis.number_format = "0.00"; ch.x_axis.tickLblPos = "low"; ch.x_axis.tickLblSkip = 3; ch.height = 9; ch.width = 18; axis_font(ch)
    ws.add_chart(ch, f"P{A0}")
    dv = DataValidation(type="list", formula1=f"$A${A0}:$A${AL}", allow_blank=False); ws.add_data_validation(dv); dv.add("B6")
    ws.column_dimensions["A"].width = 40
    for c in range(2, 15): ws.column_dimensions[CL(c)].width = 12
    r = CL_ + 2
    notes = ["Як читати. Пік: місяць, на який зміна ставки статті після підвищення облікової на 1 в.п. найбільша (в межах 24 міс. для системи). IRF на піку: величина цієї зміни у в.п.",
             "Інертність. β0 і частка піку (θ) в місяць шоку показують миттєву передачу. Період напіврозпаду: за скільки місяців закривається половина розриву до довгострокового рівня θ; 1 + φ: частка розриву, що зберігається щомісяця.",
             "Модель банку: Δy_t = β0 Δi_t + φ (y_{t-1} - θ i_{t-1}); траєкторія відгуку y_h = θ + (β0 - θ)(1 + φ)^h. Пік банку досягається або в місяць шоку (якщо β0 перевищує θ), або поступово наближається до θ.",
             "Надійність: оцінка банку позначена як неточна, якщо θ поза межами від 0 до 1,5, φ не від'ємна або період напіврозпаду понад 36 міс. (короткий або шумний ряд банку); тоді орієнтуйтеся на системні оцінки.",
             src_note]
    for t in notes:
        put(ws, r, 1, t, A9I, al=LNW); r += 1
    ws.freeze_panes = "B6"
    return ws, DS, DB
