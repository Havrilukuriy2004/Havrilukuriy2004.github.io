# -*- coding: utf-8 -*-
"""
18_bank_assets_tool.py — динамічний Excel-інструмент «Банк: розподіл активів, відносна дохідність, капітал і трансмісія» (розділ 3).
Стиль — як у таблицях НБУ: Arial 10, заголовки розділів жирним, шапка в тонких рамках з номерами граф, без сітки.
Читає результати розділу 3 (output_nbu/section_3/tables: S3_A2, S3_A7, S3_B9, S3_C1, S3_C3, S3_C4, S3_C6), п. 2.2 (S22_*) і
вітрину mart_bank_assets_v6 (історія банку) і пише output_nbu/bank_excel/Bank_Assets_Tool.xlsx та Bank_Assets_Tool_EN.xlsx.
Запуск:  python3 18_bank_assets_tool.py [OUTPUT_DIR]
"""
import csv, os, sys, re, datetime as dt
from copy import copy
from collections import defaultdict
import pandas as pd
from openpyxl import Workbook
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule, CellIsRule, ColorScaleRule
from openpyxl.chart import BarChart, LineChart, Reference, Series
from openpyxl.styles import PatternFill
from xl_trans import (put, header, axis_font, num, rd, A10, A10B, A10I, A9, A9I, INP, LINKF, FILL_IN, FILL_KEY, FILL_HEAD, BOX, TOPB, CEN, LEFT, LNW, RIGHT,
                      N0, N1, N2, N3, build as build_trans)
from xl_common import save_both
from bank_names import clean_bank_name

OUT_ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "output_nbu")
PROJ = os.path.dirname(os.path.abspath(OUT_ROOT))
T3 = os.path.join(OUT_ROOT, "section_3", "tables"); T23 = os.path.join(OUT_ROOT, "section_2_3", "tables")
DEST = os.path.join(OUT_ROOT, "bank_excel"); os.makedirs(DEST, exist_ok=True)
FILE = os.path.join(DEST, "Bank_Assets_Tool.xlsx")
P3 = '0.000%;\\–0.000%;"–"'; P1 = '0.0%;\\–0.0%;"–"'; P2 = '0.00%;\\–0.00%;"–"'
from openpyxl.styles import Font
A10L = Font(name="Arial", size=10, underline="single", color="0000FF")
SEL_FILL = PatternFill("solid", fgColor="FCE4D6"); RED = PatternFill("solid", fgColor="F8CBAD"); GREEN = PatternFill("solid", fgColor="C6EFCE")

# ============================================================ data
A2 = sorted(rd(os.path.join(T3, "S3_A2_banks_latest.csv")), key=lambda r: -num(r["P"], 0))
C4 = {r["nkb"]: r for r in rd(os.path.join(T3, "S3_C4_roe_banks.csv"))}
C3 = {(r["mode"], r["nkb"]): r for r in rd(os.path.join(T3, "S3_C3_capital_room_banks.csv"))}
C6 = {r["nkb"]: r for r in rd(os.path.join(T3, "S3_C6_frontier_banks.csv"))}
B9 = {r["nkb"]: r for r in rd(os.path.join(T3, "S3_B9_clusters_banks.csv"))}
C1 = {(r["code"], r["nkb"]): r for r in rd(os.path.join(T3, "S3_C1_counterfactual_banks.csv"))}
C1S = rd(os.path.join(T3, "S3_C1_counterfactual_system.csv"))
SCEN = [(r["code"], r["scenario"]) for r in C1S]
CLUSTER = {"1": "Кредитні банки", "2": "Універсальні банки з валютною ліквідністю", "3": "Банки з розміщенням у сертифікати НБУ", "4": "Роздрібні банки з портфелем ОВДП"}
banks = A2; NB = len(banks)
HIST = pd.read_parquet(os.path.join(PROJ, "data_nbu", "parquet", "mart_bank_assets_v6.parquet"))
HIST["month"] = pd.to_datetime(HIST["month"])
MONTHS = sorted(HIST["month"].unique())[-60:]
LATEST = pd.Timestamp(MONTHS[-1]).strftime("%m.%Y")

# ============================================================ workbook
wb = Workbook(); wb.remove(wb.active)
NAMES = {}


def sheet(n, tab=None):
    ws = wb.create_sheet(n); ws.sheet_view.showGridLines = False
    if tab: ws.sheet_properties.tabColor = tab
    return ws


def titles(ws, sub, note=None):
    put(ws, 1, 1, "18. Інструмент аналізу активів банку", A10B, al=LNW); put(ws, 2, 1, sub, A10B, al=LNW)
    if note: put(ws, 3, 1, note, A10, al=LNW)
    return 5


def foot(ws, r, lines=()):
    r += 1
    put(ws, r, 1, "«–» — явища не було; «…» — даних немає або показник не визначений.", A9I); r += 1
    for t in lines:
        put(ws, r, 1, t, A9I, al=LNW); r += 1
    put(ws, r, 1, "Джерело: розрахунки автора за даними НБУ (розділ 3: блоки A2, A7, B9, C1, C3, C4, C6; п. 2.2); скрипт 18_bank_assets_tool.py.", A9I)
    return r + 1


S0 = sheet("18"); S1 = sheet("18.1", "1F4E79"); S2 = sheet("18.2", "1F4E79"); S3 = sheet("18.3"); S5 = sheet("18.5")
D1 = sheet("Д1", "808080"); D2 = sheet("Д2", "808080")

# ------------------------------------------------------------ Д1 bank cross-section
put(D1, 1, 1, f"Д1. Активи, дохідність, капітал і контрфактичні сценарії банків на {LATEST} (вхід для формул; не редагувати)", A10B)
put(D1, 2, 1, "(млн грн; дохідності, частки і ставки — частки одиниці; Н2 і запас — % і в.п.)", A10)
COLS = [("nkb", "Код"), ("bank", "Банк"), ("owner", "Власність"), ("cl", "Тип бізнес-моделі"), ("P", "Розподільний портфель"),
        ("s_L", "Частка кредитів"), ("s_B", "Частка ОВДП"), ("s_S", "Частка сертифікатів НБУ"), ("s_O", "Частка інших активів"),
        ("y_L", "Дохідність кредитів"), ("cc", "Вартість ризику"), ("cod", "Вартість депозитів"), ("y_S", "Дохідність сертифікатів НБУ"), ("y_B", "Дохідність ОВДП"),
        ("rar_L", "Ризик-скоригована маржа кредитів"), ("m_S", "Маржа сертифікатів"), ("rr_LS", "Відносна дохідність кредитів до сертифікатів"),
        ("rr_BS", "Відносна дохідність ОВДП до сертифікатів"), ("cc_be", "Беззбиткова вартість ризику"), ("car", "Н2, %"), ("head", "Запас Н2, в.п."),
        ("lcr", "LCR, %"), ("nsfr", "NSFR, %"), ("roe", "ROE"), ("p12", "Чистий прибуток за 12 міс."), ("eq", "Капітал балансовий"),
        ("rc", "Регулятивний капітал"), ("rwa", "Загальна ризикова експозиція"), ("room", "Вільний простір капіталу: ризикова експозиція"),
        ("room_b", "Те саме за буферів 2027 р."), ("k_b", "Вимога Н2 за буферів 2027 р."), ("rho", "Щільність ризику кредитів"),
        ("wL", "Межа: частка кредитів"), ("wB", "Межа: частка ОВДП"), ("wS", "Межа: частка сертифікатів"), ("gap", "Втрата маржі до межі"),
        ("A_L", "Кредити"), ("eve_b", "ΔEVE, % Tier 1 (поведінкова модель)"), ("eve_c", "ΔEVE, % Tier 1 (договірна модель)"), ("rg12", "Розрив переоцінки 12 міс., % активів (виявлений)"),
        ("pcov", "Резерви до кредитів, частка")]
for code, _ in SCEN:
    COLS += [(f"sL1_{code}", f"Сценарій {code}: частка кредитів"), (f"sB1_{code}", f"Сценарій {code}: частка ОВДП"), (f"sS1_{code}", f"Сценарій {code}: частка сертифікатів"),
             (f"dp_{code}", f"Сценарій {code}: ΔЧПД ціновий ефект"), (f"dr_{code}", f"Сценарій {code}: ΔЧПД перерозподіл"), (f"cb_{code}", f"Сценарій {code}: обмеження капіталу")]
for j, (k, lab) in enumerate(COLS):
    put(D1, 3, j + 1, k, A9, al=CEN, border=BOX); put(D1, 4, j + 1, lab, al=CEN, border=BOX)
D1.row_dimensions[4].height = 80
DC = {k: j + 1 for j, (k, _) in enumerate(COLS)}
R3 = {r["nkb"]: r for r in rd(os.path.join(T23, "S23_R3_bank_gaps_latest.csv"))}
_hl = HIST[HIST["month"] == MONTHS[-1]].copy()
_hl["_cov"] = (_hl["prov_le"].abs().fillna(0) + _hl["prov_hh"].abs().fillna(0)) / (_hl["loans_le"].fillna(0) + _hl["loans_hh"].fillna(0)).where(lambda x: x > 0)
PCOV = dict(zip(_hl["nkb"].astype(str), _hl["_cov"]))
R1 = 5
for n, b in enumerate(banks):
    r = R1 + n; k = b["nkb"]
    c4 = C4.get(k, {}); c3 = C3.get(("current", k), {}); c3b = C3.get(("buffers", k), {}); c6 = C6.get(k, {}); b9 = B9.get(k, {})
    v = {"nkb": k, "bank": clean_bank_name(b["fullname"]), "owner": b["owner_ua"], "cl": CLUSTER.get(b9.get("cluster", ""), "…"), "P": num(b["P"]),
         "s_L": num(b["s_L"]), "s_B": num(b["s_B"]), "s_S": num(b["s_S"]), "s_O": num(b["s_O"]), "y_L": num(b["y_L"]), "cc": num(b["cc"]), "cod": num(b["cod"]),
         "y_S": num(b["y_S"]), "y_B": num(b["y_B"]), "rar_L": num(b["rar_L"]), "m_S": num(b["m_S"]), "rr_LS": num(b["rr_LS"]), "rr_BS": num(b["rr_BS"]),
         "cc_be": num(b["cc_breakeven"]), "car": num(b["total_ratio_pct"]), "head": num(b["headroom_total_min_pp"]), "lcr": num(b["lcr_all_pct"]), "nsfr": num(b["nsfr_pct"]),
         "roe": num(c4.get("roe")), "p12": num(c4.get("profit12")), "eq": num(c4.get("eqty")), "rc": num(c3.get("reg_capital_mn")), "rwa": num(c3.get("risk_exposure_implied_mn")),
         "room": num(c3.get("room_mn")), "room_b": num(c3b.get("room_mn")), "k_b": num(c3b.get("k_req")), "rho": num(c3.get("rho")),
         "wL": num(c6.get("wL")), "wB": num(c6.get("wB")), "wS": num(c6.get("wS")), "gap": num(c6.get("gap")), "A_L": num(c3.get("A_L")),
         "eve_b": num(R3.get(k, {}).get("dEVE_b_t1")), "eve_c": num(R3.get(k, {}).get("dEVE_c_t1")), "rg12": num(R3.get(k, {}).get("RG12_pp")),
         "pcov": (lambda x: None if x is None or x != x else float(x))(PCOV.get(k))}
    for code, _ in SCEN:
        c1 = C1.get((code, k), {})
        v[f"sL1_{code}"] = num(c1.get("sL1")); v[f"sB1_{code}"] = num(c1.get("sB1")); v[f"sS1_{code}"] = num(c1.get("sS1"))
        v[f"dp_{code}"] = num(c1.get("dNII_price")); v[f"dr_{code}"] = num(c1.get("dNII_realloc"))
        v[f"cb_{code}"] = ("так" if str(c1.get("cap_binding")).upper() == "TRUE" else "ні") if c1 else None
    for key, j in DC.items():
        x = v.get(key)
        fmt = P2 if key in ("s_L", "s_B", "s_S", "s_O", "y_L", "cc", "cod", "y_S", "y_B", "rar_L", "m_S", "rr_LS", "rr_BS", "cc_be", "roe", "wL", "wB", "wS", "gap", "k_b", "pcov") or key.startswith(("sL1", "sB1", "sS1")) \
            else N2 if key in ("rho",) else N1 if j > 4 else None
        put(D1, r, j, x, fmt=fmt)
RL = R1 + NB - 1
D1.freeze_panes = "C5"; D1.column_dimensions["B"].width = 34; D1.column_dimensions["D"].width = 22
for j in range(5, len(COLS) + 1): D1.column_dimensions[CL(j)].width = 11
rng = lambda k: f"'Д1'!${CL(DC[k])}${R1}:${CL(DC[k])}${RL}"

# ------------------------------------------------------------ Д2 history (long: bank × month)
put(D2, 1, 1, "Д2. Історія активів і дохідності банків за останні 60 місяців (вхід для 18.3; не редагувати)", A10B)
put(D2, 2, 1, "(залишки — млн грн; дохідності — частки річних)", A10)
HC = [("nkb", "Код"), ("month", "Місяць"), ("loans_le", "Кредити СГ"), ("loans_hh", "Кредити ФО"), ("ovdp", "ОВДП"), ("cd", "Депозитні сертифікати НБУ"),
      ("sec_oth", "Інші цінні папери"), ("cash_nbu", "Готівка і кошти в НБУ"), ("ib", "Кошти в інших банках"), ("assets", "Активи"),
      ("cust", "Кошти клієнтів"), ("bnk", "Кошти банків і НБУ"), ("debt", "Боргові цінні папери і субборг"), ("loth", "Інші зобов'язання"), ("equity", "Власний капітал"),
      ("ii_m", "Процентні доходи за місяць"), ("ie_m", "Процентні витрати за місяць"), ("nii_m", "Чистий процентний дохід за місяць"), ("prov_m", "Відрахування в резерви за місяць"),
      ("iea", "Процентні активи"),
      ("y_le", "Дохідність кредитів СГ"), ("y_hh", "Дохідність кредитів ФО"), ("y_sec", "Дохідність цінних паперів"), ("y_cd", "Дохідність сертифікатів НБУ"),
      ("nim", "Чиста процентна маржа"), ("cod", "Вартість депозитів")]
HK = [c for c, _ in HC]; YK = ("y_le", "y_hh", "y_sec", "y_cd", "nim", "cod")
for j, (k, lab) in enumerate(HC):
    put(D2, 4, j + 1, lab, al=CEN, border=BOX)
D2.row_dimensions[4].height = 40
H0 = 5
hh = HIST[HIST["month"].isin(MONTHS) & HIST["nkb"].astype(str).isin([b["nkb"] for b in banks])].sort_values(["nkb", "month"])
sd = lambda a, b: (a / b) if (pd.notna(a) and pd.notna(b) and b) else None
rowsH = 0
for _, x in hh.iterrows():
    q = H0 + rowsH; rowsH += 1
    ann = x["ann"] if pd.notna(x["ann"]) else 12.0
    s0 = lambda *ks: sum(float(x[k_]) for k_ in ks if pd.notna(x[k_])) if any(pd.notna(x[k_]) for k_ in ks) else None
    vals = [str(x["nkb"]), x["month"].date(), x["loans_le"], x["loans_hh"], x["ovdp_osb"], x["cd_osb"], x["sec_other"], s0("cash", "due_nbu"), x["other_banks"], x["assets"],
            x["liab_cust"], s0("liab_banks", "liab_nbu"), s0("liab_debtsec", "liab_sub"), x["liab_oth"], x["equity"], x["ii_m"], x["ie_m"], x["nii_m"], x["alloc_prov_m"], x["iea"],
            x["y_loans_corp_osb"], x["y_loans_hh_osb"], sd(x["ii_sec_m"] * ann if pd.notna(x["ii_sec_m"]) else None, x["avg_sec_all"]),
            sd(x["inc_cd"] * ann if pd.notna(x["inc_cd"]) else None, x["avg_cd_osb"]), sd(x["nii_m"] * ann if pd.notna(x["nii_m"]) else None, x["avg_iea"]), x["cod4_total"]]
    for j, v_ in enumerate(vals):
        if isinstance(v_, float) and v_ != v_: v_ = None
        put(D2, q, j + 1, v_, fmt=("mm.yyyy" if j == 1 else P2 if HK[j] in YK else N1 if j >= 2 else None))
HL = H0 + rowsH - 1
D2.freeze_panes = "C5"
for j in range(1, len(HC) + 1): D2.column_dimensions[CL(j)].width = 12
hr = lambda k: f"'Д2'!${CL(HK.index(k) + 1)}${H0}:${CL(HK.index(k) + 1)}${HL}"

# ------------------------------------------------------------ 18.1 profile: switches
r = titles(S1, "18.1. Профіль банку: структура активів, дохідність і відносна дохідність, капітал, бізнес-модель, контрфактичний сценарій",
           f"(дані на {LATEST}; млн грн, ставки — % річних; блакитні клітинки на жовтому тлі — перемикачі і ручні заміни; порожня заміна — фактичне значення)")
r = header(S1, r, 1, ["Перемикач", "Значення", "Пояснення"], numbers=False)
SW0 = r
SW = [("bank", "Банк", clean_bank_name(banks[0]["fullname"]), None, "Оберіть банк (впорядковано за розподільним портфелем)."),
      ("prem", "Премія власного капіталу над вартістю депозитів", 0.10, P1, "Ціна капіталу у плату за капітал: вимога Н2 x вага ризику x премія (розділ 3, п. 3.1)."),
      ("kreq", "Вимога до достатності капіталу для плати за капітал", 0.10, P1, "Загальний мінімум Н2 10 %; для буферів 2027 р. задайте вищу вимогу."),
      ("rw", "Вага ризику кредитів", 1.00, P1, "Стандартизований підхід: 100 % для корпоративних кредитів без рейтингу."),
      ("yL_in", "Дохідність кредитів (ручна заміна)", None, P2, "Порожньо: фактична книжкова дохідність кредитів банку."),
      ("cc_in", "Вартість ризику (ручна заміна)", None, P2, "Порожньо: фактичні відрахування в резерви до кредитів за 12 міс."),
      ("yS_in", "Дохідність сертифікатів НБУ (ручна заміна)", None, P2, "Порожньо: фактична дохідність розміщень у сертифікати."),
      ("yB_in", "Дохідність ОВДП (ручна заміна)", None, P2, "Порожньо: фактична дохідність ОВДП банку."),
      ("cod_in", "Вартість депозитів (ручна заміна)", None, P2, "Порожньо: фактична книжкова вартість депозитів."),
      ("scen", "Контрфактичний сценарій (розділ 3, п. 3.3)", SCEN[0][1], None, "Оберіть сценарій зміни ставок, дохідності або вимог до капіталу.")]
for k, (key, lab, val, fmt, expl) in enumerate(SW):
    q = SW0 + k
    put(S1, q, 1, lab, al=LEFT, border=BOX); put(S1, q, 2, val, INP, fmt, RIGHT if fmt else LEFT, BOX, FILL_IN); put(S1, q, 3, expl, A9, al=LNW)
    NAMES[key] = f"'18.1'!$B${q}"
q = SW0 + len(SW)
put(S1, q, 1, "Рядок банку в даних", al=LEFT, border=BOX); put(S1, q, 2, f"=MATCH(bank,{rng('bank')},0)", fmt=N0, al=RIGHT, border=BOX, fill=FILL_KEY); NAMES["row"] = f"'18.1'!$B${q}"
q += 1
put(S1, q, 1, "Код сценарію", al=LEFT, border=BOX)
put(S1, q, 2, "=INDEX({" + ",".join(f'"{c}"' for c, _ in SCEN) + "},MATCH(scen,{" + ",".join(f'"{s}"' for _, s in SCEN) + "},0))", al=RIGHT, border=BOX, fill=FILL_KEY)
NAMES["scode"] = f"'18.1'!$B${q}"
r = q + 2
g = lambda k: f"INDEX({rng(k)},row)"
# --- 18.1.1 structure
put(S1, r, 1, "18.1.1. Структура розподільного портфеля і процентних активів", A10B); r += 1
r = header(S1, r, 1, ["Клас активів", "Залишок, млн грн", "Частка банку", "Частка: середня системи (зважена)", "Частка: медіана банків", "Частка на ефективній межі"], height=40)
ST0 = r
for k, (lab, key, wkey) in enumerate([("Кредити", "s_L", "wL"), ("ОВДП", "s_B", "wB"), ("Сертифікати НБУ", "s_S", "wS"), ("Інші активи розподільного портфеля", "s_O", None)]):
    q = ST0 + k
    put(S1, q, 1, lab, al=LNW); put(S1, q, 2, f"={g(key)}*{g('P')}", fmt=N1, al=RIGHT); put(S1, q, 3, f"={g(key)}", A10B, P1, RIGHT)
    put(S1, q, 4, f"=SUMPRODUCT({rng(key)},{rng('P')})/SUM({rng('P')})", fmt=P1, al=RIGHT); put(S1, q, 5, f"=MEDIAN({rng(key)})", fmt=P1, al=RIGHT)
    put(S1, q, 6, f'=IF(ISNUMBER({g(wkey)}),{g(wkey)},"…")' if wkey else "…", fmt=P1, al=RIGHT)
q = ST0 + 4
put(S1, q, 1, "Розподільний портфель", A10B, al=LNW, border=TOPB); put(S1, q, 2, f"={g('P')}", A10B, N1, RIGHT, TOPB); put(S1, q, 3, f"=SUM(C{ST0}:C{q - 1})", A10B, P1, RIGHT, TOPB)
for c in (4, 5, 6): put(S1, q, c, None, border=TOPB)
r = q + 2
put(S1, r, 1, "Баланс банку, млн грн", A10I); r += 1
put(S1, r, 1, "Звітна дата і та сама дата роком раніше", al=LEFT, border=BOX); put(S1, r, 2, pd.Timestamp(MONTHS[-1]).date(), fmt="mm.yyyy", al=RIGHT, border=BOX, fill=FILL_KEY); NAMES["mlast"] = f"'18.1'!$B${r}"
put(S1, r, 3, "=EDATE(mlast,-12)", fmt="mm.yyyy", al=RIGHT, border=BOX, fill=FILL_KEY); NAMES["mprev"] = f"'18.1'!$C${r}"; r += 2
r = header(S1, r, 1, ["Стаття", "На звітну дату", "12 міс. тому", "Зміна, %", "Частка в активах"], height=30)
nk = f"INDEX({rng('nkb')},row)"
hv = lambda k, m: f"SUMIFS({hr(k)},{hr('nkb')},{nk},{hr('month')},{m})"
BAL0 = r
BAL = [("Кредити СГ", ["loans_le"]), ("Кредити ФО", ["loans_hh"]), ("ОВДП", ["ovdp"]), ("Депозитні сертифікати НБУ", ["cd"]), ("Інші цінні папери", ["sec_oth"]),
       ("Готівка і кошти в НБУ", ["cash_nbu"]), ("Кошти в інших банках", ["ib"])]
for k, (lab, ks) in enumerate(BAL):
    q = BAL0 + k
    put(S1, q, 1, lab, al=LNW)
    for c, m in ((2, "mlast"), (3, "mprev")):
        put(S1, q, c, "=" + "+".join(hv(k_, m) for k_ in ks), fmt=N1, al=RIGHT)
q = BAL0 + len(BAL)
put(S1, q, 1, "Інші активи (за мінусом резервів)", al=LNW)
for c, m in ((2, "mlast"), (3, "mprev")):
    put(S1, q, c, f"={hv('assets', m)}-SUM({CL(c)}{BAL0}:{CL(c)}{q - 1})", fmt=N1, al=RIGHT)
TA = q + 1
put(S1, TA, 1, "Активи, усього", A10B, al=LNW, border=TOPB)
for c, m in ((2, "mlast"), (3, "mprev")):
    put(S1, TA, c, f"={hv('assets', m)}", A10B, N1, RIGHT, TOPB)
q = TA + 1
LIA = [("Кошти клієнтів", "cust"), ("Кошти банків і НБУ", "bnk"), ("Боргові цінні папери і субординований борг", "debt"), ("Інші зобов'язання", "loth")]
L0 = q
for k, (lab, k_) in enumerate(LIA):
    put(S1, q + k, 1, lab, al=LNW)
    for c, m in ((2, "mlast"), (3, "mprev")):
        put(S1, q + k, c, "=" + hv(k_, m), fmt=N1, al=RIGHT)
q += len(LIA)
put(S1, q, 1, "Інші пасиви (балансуюча стаття)", al=LNW)
for c, m in ((2, "mlast"), (3, "mprev")):
    put(S1, q, c, f"={CL(c)}{TA}-SUM({CL(c)}{L0}:{CL(c)}{q - 1})-{hv('equity', m)}", fmt=N1, al=RIGHT)
q += 1
put(S1, q, 1, "Власний капітал", A10B, al=LNW, border=TOPB)
for c, m in ((2, "mlast"), (3, "mprev")):
    put(S1, q, c, "=" + hv("equity", m), A10B, N1, RIGHT, TOPB)
for qq in range(BAL0, q + 1):
    put(S1, qq, 4, f'=IFERROR(B{qq}/C{qq}-1,"…")', copy(S1.cell(qq, 1).font), P1, RIGHT, copy(S1.cell(qq, 2).border))
    put(S1, qq, 5, f'=IFERROR(B{qq}/$B${TA},"…")', copy(S1.cell(qq, 1).font), P1, RIGHT, copy(S1.cell(qq, 2).border))
r = q + 2
put(S1, r, 1, "Фінансовий результат від процентної діяльності за останні 12 місяців, млн грн", A10I); r += 1
r = header(S1, r, 1, ["Показник", "За 12 міс. до звітної дати", "За попередні 12 міс.", "Зміна, %", "До середніх процентних активів"], height=30)
sm = lambda k, m1, m0: f'SUMIFS({hr(k)},{hr("nkb")},{nk},{hr("month")},">"&{m0},{hr("month")},"<="&{m1})'
PL0 = r
PL = [("Процентні доходи", "ii_m", 1), ("Процентні витрати", "ie_m", -1), ("Чистий процентний дохід", "nii_m", 1), ("Відрахування в резерви", "prov_m", -1)]
for k, (lab, k_, sg) in enumerate(PL):
    q = PL0 + k; bold = k_ == "nii_m"
    put(S1, q, 1, lab, A10B if bold else A10, al=LNW)
    put(S1, q, 2, f"={'-' if sg < 0 else ''}{sm(k_, 'mlast', 'mprev')}", A10B if bold else A10, N1, RIGHT)
    put(S1, q, 3, f"={'-' if sg < 0 else ''}{sm(k_, 'mprev', 'EDATE(mprev,-12)')}", A10B if bold else A10, N1, RIGHT)
q = PL0 + len(PL)
put(S1, q, 1, "Чистий процентний дохід після резервів", A10B, al=LNW, border=TOPB)
put(S1, q, 2, f"=B{PL0 + 2}+B{PL0 + 3}", A10B, N1, RIGHT, TOPB); put(S1, q, 3, f"=C{PL0 + 2}+C{PL0 + 3}", A10B, N1, RIGHT, TOPB)
avg_iea = f'AVERAGEIFS({hr("iea")},{hr("nkb")},{nk},{hr("month")},">"&mprev,{hr("month")},"<="&mlast)'
for qq in range(PL0, q + 1):
    put(S1, qq, 4, f'=IFERROR(B{qq}/C{qq}-1,"…")', fmt=P1, al=RIGHT, border=copy(S1.cell(qq, 2).border))
    put(S1, qq, 5, f'=IFERROR(B{qq}/{avg_iea},"…")', fmt=P2, al=RIGHT, border=copy(S1.cell(qq, 2).border))
put(S1, q + 1, 1, "Витрати і відрахування в резерви показано зі знаком мінус; дані оборотно-сальдових балансів банків.", A9I)
r = q + 3
# --- 18.1.2 returns
put(S1, r, 1, "18.1.2. Дохідність і відносна дохідність активів: фактично і з ручними замінами", A10B); r += 1
r = header(S1, r, 1, ["Показник", "Фактично", "З урахуванням замін", "Медіана банків", "Середня системи (зважена)", "Формула"], height=40)
RT0 = r
used = {"yL": f"IF(ISNUMBER(yL_in),yL_in,{g('y_L')})", "cc": f"IF(ISNUMBER(cc_in),cc_in,{g('cc')})", "yS": f"IF(ISNUMBER(yS_in),yS_in,{g('y_S')})",
        "yB": f"IF(ISNUMBER(yB_in),yB_in,{g('y_B')})", "cod": f"IF(ISNUMBER(cod_in),cod_in,{g('cod')})"}
RET = [("Дохідність кредитів", g("y_L"), "=" + used["yL"], "y_L", "y_L"),
       ("Вартість ризику", g("cc"), "=" + used["cc"], "cc", "cc"),
       ("Плата за капітал", "kreq*rw*prem", "=kreq*rw*prem", None, "Н2 x вага x премія"),
       ("Вартість депозитів", g("cod"), "=" + used["cod"], "cod", "cod"),
       ("Ризик-скоригована маржа кредитів", g("rar_L"), "=C{0}-C{1}-C{3}-C{2}", "rar_L", "y_L - cc - cod - плата за капітал"),
       ("Дохідність сертифікатів НБУ", g("y_S"), "=" + used["yS"], "y_S", "y_S"),
       ("Маржа сертифікатів", g("m_S"), "=C{5}-C{3}", "m_S", "y_S - cod"),
       ("Дохідність ОВДП", g("y_B"), "=" + used["yB"], "y_B", "y_B"),
       ("Відносна дохідність кредитів до сертифікатів (RR_LS)", g("rr_LS"), "=C{0}-C{1}-C{2}-C{5}", "rr_LS", "y_L - cc - плата за капітал - y_S"),
       ("Відносна дохідність ОВДП до сертифікатів (RR_BS)", g("rr_BS"), "=C{7}-C{5}", "rr_BS", "y_B - y_S"),
       ("Беззбиткова вартість ризику", g("cc_be"), "=C{0}-C{2}-C{5}", "cc_be", "y_L - плата за капітал - y_S")]
for k, (lab, f0, f1, key, formula) in enumerate(RET):
    q = RT0 + k
    rows_ = [RT0 + i for i in range(len(RET))]
    bold = key in ("rr_LS", "rr_BS", "rar_L")
    put(S1, q, 1, lab, A10B if bold else A10, al=LNW, border=BOX)
    put(S1, q, 2, "=" + f0, A10B if bold else A10, P2, RIGHT, BOX)
    put(S1, q, 3, f1.format(*rows_).replace("C{", "C").replace("}", "") if "{" in f1 else f1, A10B if bold else A10, P2, RIGHT, BOX, FILL_KEY)
    put(S1, q, 4, f"=MEDIAN({rng(key)})" if key else "=kreq*rw*prem", fmt=P2, al=RIGHT, border=BOX)
    put(S1, q, 5, f"=SUMPRODUCT({rng(key)},{rng('A_L' if key in ('y_L', 'cc', 'rar_L', 'rr_LS', 'cc_be') else 'P')})/SUM({rng('A_L' if key in ('y_L', 'cc', 'rar_L', 'rr_LS', 'cc_be') else 'P')})" if key else "=kreq*rw*prem",
        fmt=P2, al=RIGHT, border=BOX)
    put(S1, q, 6, formula, A9, al=LNW, border=BOX)
RR_ROW = RT0 + 8
S1.conditional_formatting.add(f"B{RT0 + 8}:C{RT0 + 9}", CellIsRule(operator="lessThan", formula=["0"], fill=RED))
S1.conditional_formatting.add(f"B{RT0 + 8}:C{RT0 + 9}", CellIsRule(operator="greaterThanOrEqual", formula=["0"], fill=GREEN))
r = RT0 + len(RET) + 1
put(S1, r, 1, '=IF(C' + str(RR_ROW) + '>=0,"Кредитування вигідніше за розміщення в сертифікати НБУ після вартості ризику і капіталу.","Розміщення в сертифікати НБУ вигідніше за кредитування після вартості ризику і капіталу.")', A10I, al=LNW)
r += 2
# --- 18.1.3 capital, liquidity, profitability
put(S1, r, 1, "18.1.3. Капітал, ліквідність, прибутковість і кредитний потенціал", A10B); r += 1
r = header(S1, r, 1, ["Показник", "Банк", "Медіана банків", "Пояснення"], height=30)
CP0 = r
CAP = [("Н2, %", g("car"), f"=MEDIAN({rng('car')})", N1, "Достатність регулятивного капіталу"),
       ("Запас до мінімуму Н2, в.п.", g("head"), f"=MEDIAN({rng('head')})", N1, "Н2 мінус загальний мінімум 10 %"),
       ("LCR за всіма валютами, %", g("lcr"), f"=MEDIAN({rng('lcr')})", N0, "Коефіцієнт покриття ліквідністю"),
       ("NSFR, %", g("nsfr"), f"=MEDIAN({rng('nsfr')})", N0, "Коефіцієнт чистого стабільного фінансування"),
       ("ROE", g("roe"), f"=MEDIAN({rng('roe')})", P1, "Чистий прибуток за 12 міс. до середнього капіталу"),
       ("Чистий прибуток за 12 міс., млн грн", g("p12"), f"=MEDIAN({rng('p12')})", N1, ""),
       ("Регулятивний капітал, млн грн", g("rc"), f"=MEDIAN({rng('rc')})", N1, ""),
       ("Вільний простір капіталу: додаткова ризикова експозиція, млн грн", g("room"), f"=MEDIAN({rng('room')})", N1, "Регулятивний капітал / вимога мінус поточна ризикова експозиція"),
       ("Кредитний потенціал за поточної щільності ризику, млн грн", f'IFERROR({g("room")}/{g("rho")},"…")', "…", N1, "Вільний простір / щільність ризику кредитів"),
       ("Кредитний потенціал, % поточних кредитів", f'IFERROR({g("room")}/{g("rho")}/{g("A_L")},"…")', "…", P1, ""),
       ("Вільний простір за буферів 2027 р., млн грн", g("room_b"), f"=MEDIAN({rng('room_b')})", N1, "Вимога Н2 за повного набору буферів 2027 р."),
       ("Вимога Н2 за буферів 2027 р.", g("k_b"), "…", P1, "")]
for k, (lab, f, med, fmt, expl) in enumerate(CAP):
    q = CP0 + k
    put(S1, q, 1, lab, al=LNW, border=BOX); put(S1, q, 2, "=" + f, A10B, fmt, RIGHT, BOX); put(S1, q, 3, med, fmt=fmt, al=RIGHT, border=BOX); put(S1, q, 4, expl, A9, al=LNW, border=BOX)
S1.conditional_formatting.add(f"B{CP0 + 1}", CellIsRule(operator="lessThan", formula=["5"], fill=RED))
S1.conditional_formatting.add(f"B{CP0 + 10}", CellIsRule(operator="lessThan", formula=["0"], fill=RED))
r = CP0 + len(CAP) + 1
# --- 18.1.4 business model
put(S1, r, 1, "18.1.4. Бізнес-модель і ефективна межа «маржа - ризик»", A10B); r += 1
put(S1, r, 1, "Тип бізнес-моделі (розділ 3, п. 3.2)", al=LNW, border=BOX); put(S1, r, 2, f"={g('cl')}", A10B, al=LEFT, border=BOX); S1.merge_cells(start_row=r, start_column=2, end_row=r, end_column=4); r += 1
put(S1, r, 1, "Втрата маржі до ефективної межі, в.п. портфеля", al=LNW, border=BOX); put(S1, r, 2, f'=IFERROR({g("gap")}*100,"…")', A10B, N2, RIGHT, BOX); r += 2
# --- 18.1.5 counterfactual
put(S1, r, 1, '="18.1.5. Контрфактичний сценарій: "&scen', A10B); r += 1
r = header(S1, r, 1, ["Показник", "Фактично", "За сценарію", "Зміна"], height=30)
CF0 = r
cf = lambda base: f'INDEX({rng(base + "_A").replace("_A", "")},row)'
for k, (lab, base, cur) in enumerate([("Частка кредитів", "sL1", "s_L"), ("Частка ОВДП", "sB1", "s_B"), ("Частка сертифікатів НБУ", "sS1", "s_S")]):
    q = CF0 + k
    put(S1, q, 1, lab, al=LNW, border=BOX); put(S1, q, 2, f"={g(cur)}", fmt=P1, al=RIGHT, border=BOX)
    put(S1, q, 3, "=IFERROR(INDEX(" + "CHOOSE(MATCH(scode,{" + ",".join(f'"{c}"' for c, _ in SCEN) + "},0)," + ",".join(rng(f"{base}_{c}") for c, _ in SCEN) + "),row),\"…\")",
        A10B, P1, RIGHT, BOX)
    put(S1, q, 4, f'=IFERROR((C{q}-B{q})*100,"…")', fmt=N2, al=RIGHT, border=BOX)
q = CF0 + 3
for k, (lab, base, fmt) in enumerate([("ΔЧПД: ціновий ефект, млн грн", "dp", N1), ("ΔЧПД: ефект перерозподілу, млн грн", "dr", N1), ("Обмеження капіталу діє", "cb", None)]):
    put(S1, q + k, 1, lab, al=LNW, border=BOX)
    put(S1, q + k, 3, "=IFERROR(INDEX(" + "CHOOSE(MATCH(scode,{" + ",".join(f'"{c}"' for c, _ in SCEN) + "},0)," + ",".join(rng(f"{base}_{c}") for c, _ in SCEN) + "),row),\"…\")",
        A10B, fmt, RIGHT if fmt else CEN, BOX)
    put(S1, q + k, 2, None, border=BOX); put(S1, q + k, 4, None, border=BOX)
put(S1, q + 3, 4, "Зміна часток: в.п.", A9I)
r = q + 5
S1.column_dimensions["A"].width = 56; S1.column_dimensions["B"].width = 24; S1.column_dimensions["C"].width = 18
for c in "DEF": S1.column_dimensions[c].width = 16
S1.freeze_panes = "A5"
foot(S1, r, ["Відносна дохідність кредитів до сертифікатів НБУ: дохідність кредитів мінус вартість ризику і плата за капітал мінус дохідність сертифікатів, яку банк отримав би, розмістивши той самий ресурс у НБУ.",
             "Контрфактичні сценарії: прогноз структури портфеля дробовою мультиноміальною логіт-моделлю з проєкцією на обмеження капіталу і LCR (розділ 3, п. 3.3)."])
dv = DataValidation(type="list", formula1=f"'Д1'!$B${R1}:$B${RL}", allow_blank=False); S1.add_data_validation(dv); dv.add(f"B{SW0}")
dvs = DataValidation(type="list", formula1=f"'18.5'!$B$7:$B${6 + len(SCEN)}", allow_blank=False); S1.add_data_validation(dvs); dvs.add(f"B{SW0 + 9}")
# structure chart
bc = BarChart(); bc.type = "col"; bc.grouping = "clustered"; bc.title = "Структура портфеля: банк, система, ефективна межа"
for col, nmx, clr in ((3, "банк", "1F4E79"), (4, "система", "A6A6A6"), (6, "межа", "C00000")):
    s_ = Series(Reference(S1, min_col=col, min_row=ST0, max_row=ST0 + 2), title=nmx); s_.graphicalProperties.solidFill = clr; bc.series.append(s_)
bc.set_categories(Reference(S1, min_col=1, min_row=ST0, max_row=ST0 + 2))
bc.y_axis.number_format = "0%"; bc.height = 8; bc.width = 15; axis_font(bc)
S1.add_chart(bc, "H5")
rc = BarChart(); rc.type = "bar"; rc.title = "Розклад відносної дохідності кредитів, % річних"
rc.add_data(Reference(S1, min_col=3, min_row=RT0, max_row=RT0 + 8), titles_from_data=False)
rc.set_categories(Reference(S1, min_col=1, min_row=RT0, max_row=RT0 + 8))
rc.series[0].graphicalProperties.solidFill = "1F4E79"; rc.legend = None; rc.x_axis.scaling.orientation = "maxMin"; rc.y_axis.number_format = "0%"
rc.height = 8; rc.width = 15; axis_font(rc)
S1.add_chart(rc, "H23")

# ------------------------------------------------------------ 18.2 comparison of banks
r = titles(S2, "18.2. Порівняння банків: структура активів, відносна дохідність, капітал і кредитний потенціал",
           "(обраний на 18.1 банк виділено; ставки — % річних; млн грн)")
labs = ["Банк", "Тип бізнес-моделі", "Портфель", "Частка кредитів", "Частка ОВДП", "Частка сертифікатів", "Дохідність кредитів", "Вартість ризику",
        "RR кредитів до сертифікатів", "RR ОВДП до сертифікатів", "Н2, %", "Запас Н2, в.п.", "Кредитний потенціал, млн грн", "ROE", "Ранг за RR кредитів"]
R20 = header(S2, r, 1, labs, height=54)
for n in range(NB):
    q = R20 + n; d = R1 + n
    ref = lambda k: f"='Д1'!{CL(DC[k])}{d}"
    put(S2, q, 1, ref("bank"), al=LNW); put(S2, q, 2, ref("cl"), A9, al=LNW); put(S2, q, 3, ref("P"), fmt=N0, al=RIGHT)
    for j, k in enumerate(("s_L", "s_B", "s_S", "y_L", "cc", "rr_LS", "rr_BS")):
        put(S2, q, 4 + j, ref(k), fmt=P1, al=RIGHT)
    put(S2, q, 11, ref("car"), fmt=N1, al=RIGHT); put(S2, q, 12, ref("head"), fmt=N1, al=RIGHT)
    put(S2, q, 13, f"=IFERROR('Д1'!{CL(DC['room'])}{d}/'Д1'!{CL(DC['rho'])}{d},\"…\")", fmt=N0, al=RIGHT); put(S2, q, 14, ref("roe"), fmt=P1, al=RIGHT)
    put(S2, q, 15, f'=IFERROR(RANK(I{q},$I${R20}:$I${R20 + NB - 1},0),"…")', fmt=N0, al=CEN)
R2L = R20 + NB - 1
S2.conditional_formatting.add(f"A{R20}:O{R2L}", FormulaRule(formula=[f"$A{R20}=bank"], fill=SEL_FILL))
S2.conditional_formatting.add(f"I{R20}:I{R2L}", ColorScaleRule(start_type="num", start_value=-0.1, start_color="F8696B", mid_type="num", mid_value=0, mid_color="FFFFFF", end_type="num", end_value=0.1, end_color="63BE7B"))
S2.column_dimensions["A"].width = 34; S2.column_dimensions["B"].width = 26
for j in range(3, 16): S2.column_dimensions[CL(j)].width = 11
S2.freeze_panes = f"B{R20}"; S2.auto_filter.ref = f"A{R20 - 3}:O{R2L}"
foot(S2, R2L + 1, ["RR: відносна дохідність. Ранг 1: найвища відносна дохідність кредитів до сертифікатів НБУ."])

# ------------------------------------------------------------ 18.3 history of the selected bank
r = titles(S3, "18.3. Динаміка активів і дохідності обраного банку за останні 60 місяців", "(млн грн; дохідності — % річних)")
put(S3, 4, 1, '="Банк: "&bank', A10I)
labs = ["Місяць"] + [lab for k, lab in HC[2:]]
R30 = header(S3, r, 1, labs, height=42)
for n, m in enumerate(MONTHS):
    q = R30 + n
    put(S3, q, 1, pd.Timestamp(m).date(), fmt="mm.yyyy", al=CEN)
    for j, (k, lab) in enumerate(HC[2:]):
        f = f'=IFERROR(1/(1/SUMIFS({hr(k)},{hr("nkb")},INDEX({rng("nkb")},row),{hr("month")},$A{q})),NA())' if k in YK else \
            f'=SUMIFS({hr(k)},{hr("nkb")},INDEX({rng("nkb")},row),{hr("month")},$A{q})'
        put(S3, q, 2 + j, f, fmt=P2 if k in YK else N1, al=RIGHT)
R3L = R30 + len(MONTHS) - 1
S3.column_dimensions["A"].width = 10
for j in range(2, len(labs) + 1): S3.column_dimensions[CL(j)].width = 12
S3.freeze_panes = f"B{R30}"
lc = LineChart(); lc.title = "Дохідність активів і вартість депозитів, % річних"
HCOL = lambda k: 2 + HK[2:].index(k)
for col, nmx, clr in ((HCOL("y_le"), "кредити СГ", "1F4E79"), (HCOL("y_hh"), "кредити ФО", "5B9BD5"), (HCOL("y_sec"), "цінні папери", "A6A6A6"), (HCOL("y_cd"), "сертифікати НБУ", "C00000"), (HCOL("cod"), "депозити", "000000")):
    s_ = Series(Reference(S3, min_col=col, min_row=R30, max_row=R3L), title=nmx); s_.graphicalProperties.line.solidFill = clr; s_.graphicalProperties.line.width = 19000; s_.smooth = False
    lc.series.append(s_)
lc.set_categories(Reference(S3, min_col=1, min_row=R30, max_row=R3L)); lc.y_axis.number_format = "0%"; lc.x_axis.number_format = "mm.yy"
lc.x_axis.tickLblPos = "low"; lc.x_axis.tickLblSkip = 6; lc.height = 9; lc.width = 20; axis_font(lc)
S3.add_chart(lc, "R5")
sc = BarChart(); sc.type = "col"; sc.grouping = "stacked"; sc.overlap = 100; sc.title = "Структура процентних активів, млн грн"
for col, nmx, clr in ((HCOL("loans_le"), "кредити СГ", "1F4E79"), (HCOL("loans_hh"), "кредити ФО", "5B9BD5"), (HCOL("ovdp"), "ОВДП", "A6A6A6"), (HCOL("cd"), "сертифікати НБУ", "C00000"), (HCOL("sec_oth"), "інші ЦП", "7F7F7F"), (HCOL("cash_nbu"), "кошти в НБУ", "FFC000"), (HCOL("ib"), "кошти в банках", "70AD47")):
    s_ = Series(Reference(S3, min_col=col, min_row=R30, max_row=R3L), title=nmx); s_.graphicalProperties.solidFill = clr; sc.series.append(s_)
sc.set_categories(Reference(S3, min_col=1, min_row=R30, max_row=R3L)); sc.x_axis.number_format = "mm.yy"; sc.x_axis.tickLblPos = "low"; sc.x_axis.tickLblSkip = 6
sc.gapWidth = 30; sc.height = 9; sc.width = 20; axis_font(sc)
S3.add_chart(sc, "R25")
foot(S3, R3L + 1, ["Дохідності: процентні доходи за місяць, приведені до річних, до середніх залишків; для кредитів — оцінки за оборотно-сальдовим балансом."])

# ------------------------------------------------------------ 18.4 transmission (shared block)
SYS_KEYS = [("y_iea", "Дохідність процентних активів"), ("y_le", "Дохідність кредитів СГ"), ("y_hh", "Дохідність кредитів ФО"),
            ("y_refin", "Дохідність ОВДП (рефінансовані ЦП)"), ("y_cd", "Дохідність депсертифікатів НБУ"), ("nim", "Чиста процентна маржа")]
BANK_KEYS = [("y_iea", "Дохідність процентних активів"), ("y_le", "Дохідність кредитів СГ"), ("y_cd", "Дохідність депсертифікатів НБУ")]
build_trans(wb, OUT_ROOT, "18.4", "Д3", "Д4", SYS_KEYS, BANK_KEYS, [(b["nkb"], clean_bank_name(b["fullname"])) for b in banks], NAMES["bank"],
            "18. Інструмент аналізу активів банку", "18.4. Трансмісія облікової ставки в дохідність активів: коли ефект найсильніший, IRF на піку, інертність",
            "Джерело: розрахунки автора за даними НБУ; локальні проєкції і моделі виправлення помилки п. 2.2 (S22_P1_P5, S22_P8a, S22_P9) і розділу 3 (S3_A7).",
            a7_products=["Кредити СГ, грн", "Кредити ФО, грн"])

# ------------------------------------------------------------ 18.5 methodology, scenarios and sources
r = titles(S5, "18.5. Методологія, сценарії і джерела")
put(S5, r, 1, "Контрфактичні сценарії (розділ 3, п. 3.3)", A10B); r += 1
put(S5, r, 1, "Код", al=CEN, border=BOX, fill=FILL_HEAD); put(S5, r, 2, "Сценарій", al=CEN, border=BOX, fill=FILL_HEAD)
put(S5, r, 3, "Зміна частки кредитів системи, в.п.", al=CEN, border=BOX, fill=FILL_HEAD); put(S5, r, 4, "Зміна ЧПД: ціновий ефект, %", al=CEN, border=BOX, fill=FILL_HEAD); r += 1
assert r == 7
for k, row_ in enumerate(C1S):
    q = r + k
    put(S5, q, 1, row_["code"], al=CEN, border=BOX); put(S5, q, 2, row_["scenario"], al=LEFT, border=BOX)
    put(S5, q, 3, num(row_["dL_pp"]), fmt=N2, al=RIGHT, border=BOX); put(S5, q, 4, num(row_["dNII_price_pct"]) / 100 if num(row_["dNII_price_pct"]) is not None else None, fmt=P2, al=RIGHT, border=BOX)
r = r + len(C1S) + 2
TXT = ["Розподільний портфель: кредити, ОВДП, депозитні сертифікати НБУ та інші ліквідні активи (кошти в банках, на рахунках у НБУ). Частки рахуються від портфеля.",
       "Вартість ризику: відрахування в резерви до кредитів за 12 міс. до середніх кредитів. Плата за капітал: вимога Н2 x вага ризику x премія власного капіталу.",
       "Відносна дохідність (RR): перевищення ризик-скоригованої дохідності кредитів (або дохідності ОВДП) над дохідністю сертифікатів НБУ, тобто альтернативною вартістю ліквідності.",
       "Ефективна межа: портфелі з найвищою середньою маржею за заданого ризику (Марковіц); втрата маржі: відстань фактичного портфеля до межі.",
       "Тип бізнес-моделі: кластеризація банків методом k-середніх за структурою активів і пасивів (розділ 3, п. 3.2).",
       "Вільний простір капіталу: регулятивний капітал, поділений на вимогу до Н2, мінус поточна загальна ризикова експозиція; кредитний потенціал: той самий простір, поділений на щільність ризику кредитів.",
       "Трансмісія (18.4): відгук дохідності на зміну облікової ставки на 1 в.п.; пік і IRF для системи з панельних локальних проєкцій, для банку з моделі виправлення помилки.",
       "Для кого: практикам банків для порівняння з конкурентами і аналізу «що, якщо»; студентам для розуміння зв'язку дохідності, ризику і капіталу; дослідникам для перевірки гіпотез про розподіл активів."]
for t in TXT:
    put(S5, r, 1, t, al=LEFT); S5.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6); S5.row_dimensions[r].height = 30; r += 1
S5.column_dimensions["A"].width = 8; S5.column_dimensions["B"].width = 60; S5.column_dimensions["C"].width = 16; S5.column_dimensions["D"].width = 16
foot(S5, r)

# ------------------------------------------------------------ 18.6 shadow price of capital (model of the article)
S6 = sheet("18.6", "1F4E79"); S7 = sheet("18.7", "1F4E79")
r = titles(S6, "18.6. Тіньова ціна капіталу: капітальний клин, мінімальна ставка кредиту і реакції кредитної пропозиції (мікроекономічна модель)",
           "(модель: банк максимізує очікуваний прибуток за стохастичного шоку капіталу ε ~ N(0, σ^2); якщо норматив після шоку нижчий за мінімум, банк несе втрати C; банк обирається на 18.1)")
r = header(S6, r, 1, ["Параметр", "Значення", "Пояснення"], numbers=False)
QP0 = r
QP = [("q_sig", "Стандартне відхилення шоку нормативу σ, в.п.", 3.0, N2, "Непередбачені збитки, валютна переоцінка, донарахування резервів"),
      ("q_csh", "Втрати від порушення нормативу C, частка ресурсу F", 0.02, P1, "Обмеження діяльності, докапіталізація нижче справедливої ціни, втрата франшизи"),
      ("q_kap", "Ризикова вага кредиту κ", 1.0, P1, "Стандартизований підхід: корпоративний кредит без рейтингу"),
      ("q_bet", "Нахил граничного доходу кредиту β (на весь ресурс F)", 1.0, N2, "Калібрування: за β = 1 приріст кредиту на гривню капіталу в банках із запасом до 5 в.п. близький до емпіричної оцінки 1,03 грн"),
      ("q_o", "Операційні витрати на кредит o", 0.02, P1, ""),
      ("q_pd", "Імовірність дефолту p", 0.03, P1, "Середній позичальник"),
      ("q_lgd", "Втрати в разі дефолту λ", 0.45, P1, ""),
      ("q_c1", "Покриття резервами: стадія 1", 0.02, P1, "Кредити бізнесу, середнє по системі"),
      ("q_c2", "Покриття резервами: стадія 2", 0.096, P1, ""),
      ("q_s", "Частка кредитів, що переходить у стадію 2", 0.10, P1, "Сценарій міграції"),
      ("q_tau", "Ставка податку на прибуток", 0.25, P1, "2023, 2024 і 2026 рр.: 50 %")]
for k_, (key, lab, val, fmt, expl) in enumerate(QP):
    q = QP0 + k_
    put(S6, q, 1, lab, al=LNW, border=BOX); put(S6, q, 2, val, INP, fmt, RIGHT, BOX, FILL_IN); put(S6, q, 3, expl, A9, al=LNW, border=BOX)
    NAMES[key] = f"'18.6'!$B${q}"
r = QP0 + len(QP) + 1
put(S6, r, 1, '="18.6.1. Обраний банк: "&bank', A10B); r += 1
r = header(S6, r, 1, ["Показник", "Значення", "Формула або пояснення"], numbers=False)
QB0 = r
QB = [("q_K", "Норматив достатності капіталу K", f"={g('car')}/100", P2, "Н2"),
      ("q_H", "Запас H", f"={g('head')}/100", P2, "K мінус мінімальна вимога"),
      ("q_kb", "Мінімальна вимога", "=q_K-q_H", P2, ""),
      ("q_R", "Загальна ризикова експозиція R, млн грн", f"={g('rwa')}", N1, ""),
      ("q_E", "Регулятивний капітал E = K x R, млн грн", "=q_K*q_R", N1, ""),
      ("q_F", "Ресурс для розміщення F, млн грн", f"={g('P')}", N1, "Розподільний портфель"),
      ("q_L", "Кредити L, млн грн", f"={g('A_L')}", N1, ""),
      ("q_Om", "Інші ризикові активи Ω = R - κL, млн грн", "=MAX(0,q_R-q_kap*q_L)", N1, ""),
      ("q_i", "Дохідність альтернативи i (сертифікати НБУ)", f"={g('y_S')}", P2, ""),
      ("q_C", "Втрати від порушення C, млн грн", "=q_csh*q_F", N1, "C = частка x F"),
      ("q_z", "Запас у стандартних відхиленнях H/σ", "=q_H/(q_sig/100)", N2, ""),
      ("q_phi", "Щільність φ(H/σ)", "=NORMDIST(q_z,0,1,FALSE)", N3, ""),
      ("q_pr", "Імовірність порушення нормативу Φ(-H/σ)", "=NORMDIST(-q_z,0,1,TRUE)", P2, ""),
      ("q_xi", "Тіньова ціна запасу ξ(H), млн грн", "=q_C/(q_sig/100)*q_phi", N1, "ξ = C/σ x φ(H/σ)"),
      ("q_m", "Капітальний клин m", "=q_xi*q_kap*q_K/q_R", P2, "m = ξ κ K / R: надбавка до ставки кредиту"),
      ("q_rmin", "Мінімальна прийнятна ставка кредиту", "=(q_i+q_o+q_pd*q_lgd+q_m)/(1-q_pd)", P2, "(i + o + pλ + m)/(1 - p)"),
      ("q_rmin0", "Те саме без капітального клину", "=(q_i+q_o+q_pd*q_lgd)/(1-q_pd)", P2, "Модель Кляйна - Монті"),
      ("q_yL", "Фактична дохідність кредитів банку", f"={g('y_L')}", P2, ""),
      ("q_gapr", "Фактична дохідність мінус мінімальна ставка", "=q_yL-q_rmin", P2, "Від'ємне значення: кредит не покриває ціну ризику і капіталу"),
      ("q_be", "Нахил граничного доходу на 1 млн грн", "=q_bet/q_F", "0.000E+00", "β / F"),
      ("q_L2", "Службово: L + приріст", "=q_L*1.001+1", N1, ""),
      ("q_K2", "Службово: K(L + приріст)", "=q_E/(q_kap*q_L2+q_Om)", P3, ""),
      ("q_m2", "Службово: m(L + приріст)", "=q_C/(q_sig/100)*NORMDIST((q_K2-q_kb)/(q_sig/100),0,1,FALSE)*q_kap*q_K2/(q_kap*q_L2+q_Om)", P3, ""),
      ("q_mL", "Зростання клину з кредитом m_L, на 1 млн грн", "=(q_m2-q_m)/(q_L2-q_L)", "0.000E+00", "Чисельна похідна"),
      ("q_mE", "Спадання клину з капіталом m_E, на 1 млн грн", "=q_C*q_kap*q_phi/((q_sig/100)*q_R^2)*(1-q_K*q_H/(q_sig/100)^2)", "0.000E+00", "")]
for k_, (key, lab, f, fmt, expl) in enumerate(QB):
    q = QB0 + k_
    aux = lab.startswith("Службово")
    put(S6, q, 1, lab, A9 if aux else A10, al=LNW, border=BOX); put(S6, q, 2, f, A9 if aux else (A10B if key in ("q_m", "q_rmin", "q_gapr") else A10), fmt, RIGHT, BOX, FILL_KEY if aux or key in ("q_m", "q_rmin") else None)
    put(S6, q, 3, expl, A9, al=LNW, border=BOX)
    NAMES[key] = f"'18.6'!$B${q}"
S6.conditional_formatting.add(NAMES["q_gapr"].split("!")[1].replace("$", ""), CellIsRule(operator="lessThan", formula=["0"], fill=RED))
r = QB0 + len(QB) + 1
put(S6, r, 1, "18.6.2. Реакції кредитної пропозиції банку (порівняльна статика)", A10B); r += 1
r = header(S6, r, 1, ["Реакція", "Значення", "Формула"], numbers=False)
QR0 = r
QR = [("q_dLdE", "Приріст кредиту на 1 грн додаткового капіталу, грн", "=-q_mE/(q_be+q_mL)", N2, "∂L/∂E = -m_E/(β + m_L)"),
      ("q_dE100", "Приріст кредиту від 100 млн грн капіталу, млн грн", "=q_dLdE*100", N1, ""),
      ("q_dkb", "Зміна кредиту від підвищення вимоги на 1 в.п., млн грн", "=-(q_C*q_kap*q_K*q_H*q_phi/((q_sig/100)^3*q_R))/(q_be+q_mL)*0.01", N1, "Ресурс переходить у сертифікати НБУ один до одного"),
      ("q_di", "Зміна кредиту від підвищення ставки i на 1 в.п. (прямий ефект), млн грн", "=-0.01/(q_be+q_mL)", N1, "Без каналу банківського капіталу"),
      ("q_mig", "Втрата капіталу від міграції в стадію 2, млн грн", "=q_s*q_L*(q_c2-q_c1)*(1-q_tau)", N1, "s L (c2 - c1)(1 - τ)"),
      ("q_dmig", "Зміна кредиту через капітал від міграції, млн грн", "=-q_dLdE*q_mig", N1, "")]
for k_, (key, lab, f, fmt, expl) in enumerate(QR):
    q = QR0 + k_
    put(S6, q, 1, lab, al=LNW, border=BOX); put(S6, q, 2, f, A10B, fmt, RIGHT, BOX); put(S6, q, 3, expl, A9, al=LNW, border=BOX)
    NAMES[key] = f"'18.6'!$B${q}"
r = QR0 + len(QR) + 1
put(S6, r, 1, "18.6.3. Капітальний клин і мінімальна ставка за класами позичальника (Положення № 351, додаток 9, група «інші»)", A10B); r += 1
r = header(S6, r, 1, ["Клас", "PD (середина діапазону)", "Резерв під час видачі c", "Клин класу m_j", "Мінімальна ставка", "Те саме без клину", "Надбавка за капітал, в.п."], height=40)
QC0 = r
PDM = [0.0085, 0.0205, 0.0345, 0.059, 0.094, 0.14, 0.205, 0.33, 0.705]
for j, pdm in enumerate(PDM):
    q = QC0 + j
    put(S6, q, 1, j + 1, al=CEN, border=BOX); put(S6, q, 2, pdm, INP, P2, RIGHT, BOX, FILL_IN)
    put(S6, q, 3, f"=B{q}*q_lgd", fmt=P2, al=RIGHT, border=BOX)
    put(S6, q, 4, f"=q_xi*(q_kap*q_K+C{q})/q_R", fmt=P2, al=RIGHT, border=BOX)
    put(S6, q, 5, f"=(q_i+q_o+B{q}*q_lgd+D{q})/(1-B{q})", A10B, P2, RIGHT, BOX)
    put(S6, q, 6, f"=(q_i+q_o+B{q}*q_lgd)/(1-B{q})", fmt=P2, al=RIGHT, border=BOX)
    put(S6, q, 7, f"=(E{q}-F{q})*100", fmt=N2, al=RIGHT, border=BOX)
r = QC0 + len(PDM) + 1
put(S6, r, 1, "Резерв під час видачі: очікувані збитки за 12 міс. (PD x LGD), які зменшують капітал; ризикова вага не залежить від класу, тому різниця клинів між класами йде через резерви.", A9I, al=LNW)
r += 2
put(S6, r, 1, "18.6.4. Капітальний клин обраного банку залежно від запасу H (за незмінних R і C)", A10B); r += 1
r = header(S6, r, 1, ["Запас H, в.п.", "Клин m, в.п.", "Імовірність порушення"], numbers=False)
QG0 = r
for j in range(51):
    q = QG0 + j; h_ = j * 0.5
    put(S6, q, 1, h_, fmt=N1, al=CEN)
    put(S6, q, 2, f"=q_C/(q_sig/100)*NORMDIST(A{q}/q_sig,0,1,FALSE)*q_kap*(q_kb+A{q}/100)/q_R*100", fmt=N2, al=RIGHT)
    put(S6, q, 3, f"=NORMDIST(-A{q}/q_sig,0,1,TRUE)", fmt=P1, al=RIGHT)
QGL = QG0 + 50
lcw = LineChart(); lcw.title = "Капітальний клин m(H), в.п. ставки"
sw_ = Series(Reference(S6, min_col=2, min_row=QG0, max_row=QGL), title="клин"); sw_.graphicalProperties.line.solidFill = "1F4E79"; sw_.graphicalProperties.line.width = 22000; sw_.smooth = False
lcw.series.append(sw_); lcw.set_categories(Reference(S6, min_col=1, min_row=QG0, max_row=QGL)); lcw.legend = None
lcw.x_axis.tickLblSkip = 10; lcw.x_axis.title = "Запас H, в.п."; lcw.height = 8; lcw.width = 15; axis_font(lcw)
S6.add_chart(lcw, "E5")
r = QGL + 2
put(S6, r, 1, "18.6.5. Капітальний клин усіх банків", A10B); r += 1
r = header(S6, r, 1, ["Банк", "Запас H, в.п.", "Клин m, в.п.", "Імовірність порушення", "Мінімальна ставка", "Фактична дохідність кредитів", "Різниця, в.п.", "Ранг за клином"], height=40)
QA0 = r
for n in range(NB):
    q = QA0 + n; d = R1 + n
    dd = lambda k: f"'Д1'!${CL(DC[k])}${d}"
    put(S6, q, 1, f"={dd('bank')}", al=LNW)
    put(S6, q, 2, f"={dd('head')}", fmt=N1, al=RIGHT)
    mf = f"q_csh*{dd('P')}/(q_sig/100)*NORMDIST({dd('head')}/q_sig,0,1,FALSE)*q_kap*{dd('car')}/100/{dd('rwa')}"
    put(S6, q, 3, f"=IFERROR({mf}*100,\"…\")", A10B, N2, RIGHT)
    put(S6, q, 4, f"=IFERROR(NORMDIST(-{dd('head')}/q_sig,0,1,TRUE),\"…\")", fmt=P1, al=RIGHT)
    put(S6, q, 5, f"=IFERROR(({dd('y_S')}+q_o+q_pd*q_lgd+C{q}/100)/(1-q_pd),\"…\")", fmt=P2, al=RIGHT)
    put(S6, q, 6, f"={dd('y_L')}", fmt=P2, al=RIGHT)
    put(S6, q, 7, f"=IFERROR((F{q}-E{q})*100,\"…\")", fmt=N2, al=RIGHT)
    put(S6, q, 8, f"=IFERROR(RANK(C{q},$C${QA0}:$C${QA0 + NB - 1},0),\"…\")", fmt=N0, al=CEN)
QAL = QA0 + NB - 1
S6.conditional_formatting.add(f"A{QA0}:H{QAL}", FormulaRule(formula=[f"$A{QA0}=bank"], fill=SEL_FILL))
S6.conditional_formatting.add(f"C{QA0}:C{QAL}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF", end_type="max", end_color="F8696B"))
S6.conditional_formatting.add(f"G{QA0}:G{QAL}", CellIsRule(operator="lessThan", formula=["0"], fill=RED))
foot(S6, QAL + 1, ["Модель: Гаврилюк Ю., Жердецька Л. «Тіньова ціна капіталу і розподіл активів банку»: твердження 1 до 6. Параметри σ і C ілюстративні; результати показують порядок величин, а не наглядову оцінку.",
                   "Перша умова оптимуму: u(L) = i + m; ∂L/∂E = -m_E/(β + m_L); m_E = Cκφ/(σR^2)(1 - KH/σ^2); підвищення вимоги: m_k = CκKHφ/(σ^3 R)."])
S6.column_dimensions["A"].width = 58; S6.column_dimensions["B"].width = 16; S6.column_dimensions["C"].width = 44
for c_ in "DEFGH": S6.column_dimensions[c_].width = 14
S6.freeze_panes = "A5"

# ------------------------------------------------------------ 18.7 early-warning scorecard
r = titles(S7, "18.7. Ранній сигнал: зведений скоринг ризиків банку (капітал, ліквідність, кредитний і процентний ризик, прибутковість, залежність від НБУ)",
           "(перцентиль ризику: частка банків з кращим значенням показника, 0 до 100 %; пороги уваги і ризику можна змінювати; банк обирається на 18.1)")
EW = [("head", "Запас Н2, в.п.", "low", 5, 2, N1, "{head}"),
      ("hb", "Запас Н2 за буферів 2027 р., в.п.", "low", 2, 0, N1, "{car}-100*{k_b}"),
      ("lcr", "LCR, %", "low", 120, 100, N0, "{lcr}"),
      ("nsfr", "NSFR, %", "low", 110, 100, N0, "{nsfr}"),
      ("cc", "Вартість ризику", "high", 0.03, 0.06, P1, "{cc}"),
      ("pcov", "Резерви до кредитів, частка", "high", 0.15, 0.30, P1, "{pcov}"),
      ("roe", "ROE", "low", 0.05, 0, P1, "{roe}"),
      ("eve", "Втрата EVE, % Tier 1 (договірна модель НБУ)", "high", 10, 15, N1, "MAX(0,-{eve_c})"),
      ("rg", "Розрив переоцінки 12 міс., модуль, % активів", "high", 15, 25, N1, "ABS({rg12})"),
      ("sS", "Частка сертифікатів НБУ в портфелі", "high", 0.40, 0.60, P1, "{s_S}"),
      ("rr", "Відносна дохідність кредитів до сертифікатів", "low", 0, -0.05, P1, "{rr_LS}"),
      ("mw", "Капітальний клин, в.п.", "high", 1, 3, N2, None)]
r = header(S7, r, 1, ["Показник", "Значення банку", "Медіана банків", "Перцентиль ризику", "Поріг уваги", "Поріг ризику", "Напрям ризику", "Статус"], height=40)
EP0 = r
r2 = EP0 + len(EW) + 3
put(S7, r2, 1, "18.7.2. Усі банки: значення показників (колір: порушення порогів) і зведений перцентиль ризику", A10B)
r2 += 1
EH = ["Банк"] + [lab for _, lab, *_ in EW] + ["Зведений перцентиль ризику", "Порушень порогу ризику", "Ранг ризику"]
EA0 = header(S7, r2, 1, EH, height=66)
EAL = EA0 + NB - 1
NC = len(EW)
for n in range(NB):
    q = EA0 + n; d = R1 + n
    put(S7, q, 1, f"='Д1'!${CL(DC['bank'])}${d}", al=LNW)
    for j, (key, lab, dirn, w_, a_, fmt, tpl) in enumerate(EW):
        if tpl is None:
            f = f"='18.6'!C{QA0 + n}"
        else:
            f = "=IFERROR(" + re.sub(r"\{(\w+)\}", lambda m_: f"N('Д1'!${CL(DC[m_.group(1)])}${d})" if m_.group(1) != "eve_c" else f"'Д1'!${CL(DC[m_.group(1)])}${d}", tpl) + ',"…")'
            src_ = {'eve': 'eve_c', 'rg': 'rg12', 'rr': 'rr_LS', 'hb': 'k_b', 'sS': 's_S'}.get(key, key)
            f = f"=IF(ISNUMBER('Д1'!${CL(DC[src_])}${d})," + f[1:] + ',"…")'
        put(S7, q, 2 + j, f, fmt=fmt, al=RIGHT)
    # oriented percentiles in hidden helper columns
    for j, (key, lab, dirn, *_rest) in enumerate(EW):
        col = CL(2 + j); hc = 2 + NC + 3 + j
        rngc = f"${col}${EA0}:${col}${EAL}"
        pr_ = f"PERCENTRANK({rngc},{col}{q})"
        put(S7, q, hc, f"=IF(ISNUMBER({col}{q}),{'1-' if dirn == 'low' else ''}{pr_},\"\")", A9, P1, RIGHT)
    hc0, hc1 = CL(2 + NC + 3), CL(2 + NC + 3 + NC - 1)
    put(S7, q, 2 + NC, f'=IFERROR(AVERAGE({hc0}{q}:{hc1}{q}),"…")', A10B, P1, RIGHT)
    flags = "+".join(f"IF(ISNUMBER({CL(2 + j)}{q}),IF({CL(2 + j)}{q}{'<=' if d_ == 'low' else '>='}$F${EP0 + j},1,0),0)" for j, (_, _, d_, *_x) in enumerate(EW))
    put(S7, q, 3 + NC, "=" + flags, fmt=N0, al=CEN)
    put(S7, q, 4 + NC, f'=IFERROR(RANK({CL(2 + NC)}{q},${CL(2 + NC)}${EA0}:${CL(2 + NC)}${EAL},0),"…")', fmt=N0, al=CEN)
put(S7, EA0 - 2, 2 + NC + 3, "Службово: перцентилі ризику за показниками", A9I)
for j in range(NC):
    S7.column_dimensions[CL(2 + NC + 3 + j)].hidden = True
# selected-bank panel
for j, (key, lab, dirn, w_, a_, fmt, tpl) in enumerate(EW):
    q = EP0 + j; col = CL(2 + j)
    rngc = f"${col}${EA0}:${col}${EAL}"
    put(S7, q, 1, lab, al=LNW, border=BOX)
    put(S7, q, 2, f"=INDEX({rngc},row)", A10B, fmt, RIGHT, BOX)
    put(S7, q, 3, f"=MEDIAN({rngc})", fmt=fmt, al=RIGHT, border=BOX)
    put(S7, q, 4, f'=IFERROR(INDEX(${CL(2 + NC + 3 + j)}${EA0}:${CL(2 + NC + 3 + j)}${EAL},row),"…")', fmt=P1, al=RIGHT, border=BOX)
    put(S7, q, 5, w_, INP, fmt, RIGHT, BOX, FILL_IN); put(S7, q, 6, a_, INP, fmt, RIGHT, BOX, FILL_IN)
    put(S7, q, 7, "нижче гірше" if dirn == "low" else "вище гірше", A9, al=CEN, border=BOX)
    cmp_a, cmp_w = ("<=", "<=") if dirn == "low" else (">=", ">=")
    put(S7, q, 8, f'=IF(NOT(ISNUMBER(B{q})),"…",IF(B{q}{cmp_a}F{q},"ризик",IF(B{q}{cmp_w}E{q},"увага","норма")))', A10B, al=CEN, border=BOX)
    S7.conditional_formatting.add(f"H{q}", CellIsRule(operator="equal", formula=['"ризик"'], fill=RED))
    S7.conditional_formatting.add(f"H{q}", CellIsRule(operator="equal", formula=['"увага"'], fill=PatternFill("solid", fgColor="FFEB9C")))
    S7.conditional_formatting.add(f"H{q}", CellIsRule(operator="equal", formula=['"норма"'], fill=GREEN))
    # colours in the all-banks matrix
    S7.conditional_formatting.add(f"{col}{EA0}:{col}{EAL}", FormulaRule(formula=[f"AND(ISNUMBER({col}{EA0}),{col}{EA0}{cmp_a}$F${q})"], fill=RED))
    S7.conditional_formatting.add(f"{col}{EA0}:{col}{EAL}", FormulaRule(formula=[f"AND(ISNUMBER({col}{EA0}),{col}{EA0}{cmp_w}$E${q})"], fill=PatternFill("solid", fgColor="FFEB9C")))
q = EP0 + NC
put(S7, q, 1, "Зведений перцентиль ризику (середнє за показниками)", A10B, al=LNW, border=TOPB)
put(S7, q, 2, f'=INDEX(${CL(2 + NC)}${EA0}:${CL(2 + NC)}${EAL},row)', A10B, P1, RIGHT, TOPB)
put(S7, q, 3, f'=MEDIAN(${CL(2 + NC)}${EA0}:${CL(2 + NC)}${EAL})', fmt=P1, al=RIGHT, border=TOPB)
put(S7, q, 4, f'="ранг "&INDEX(${CL(4 + NC)}${EA0}:${CL(4 + NC)}${EAL},row)&" з {NB}"', al=RIGHT, border=TOPB)
for c_ in range(5, 9): put(S7, q, c_, None, border=TOPB)
put(S7, q + 1, 1, "Порушень порогу ризику", al=LNW); put(S7, q + 1, 2, f'=INDEX(${CL(3 + NC)}${EA0}:${CL(3 + NC)}${EAL},row)', A10B, N0, RIGHT)
S7.conditional_formatting.add(f"A{EA0}:{CL(4 + NC)}{EAL}", FormulaRule(formula=[f"$A{EA0}=bank"], fill=SEL_FILL))
S7.conditional_formatting.add(f"{CL(2 + NC)}{EA0}:{CL(2 + NC)}{EAL}", ColorScaleRule(start_type="num", start_value=0.2, start_color="63BE7B", mid_type="num", mid_value=0.5, mid_color="FFFFFF", end_type="num", end_value=0.8, end_color="F8696B"))
foot(S7, EAL + 1, ["Перцентиль ризику: для показника, де нижче гірше, 1 мінус процентний ранг значення серед банків; для показника, де вище гірше, процентний ранг. Зведений перцентиль: середнє за наявними показниками.",
                   "Пороги: LCR і NSFR: мінімум НБУ 100 %; втрата EVE: тест на викид BCBS 15 % Tier 1; інші пороги орієнтовні, їх варто узгодити з внутрішньою політикою банку.",
                   "Дані: розділ 3 (A2, C3, C4), п. 2.3 (розрив переоцінки, ΔEVE за договірною моделлю НБУ), резерви за оборотно-сальдовими балансами; капітальний клин: аркуш 18.6."])
S7.column_dimensions["A"].width = 48
for j in range(2, 2 + NC + 3): S7.column_dimensions[CL(j)].width = 12
S7.freeze_panes = f"B{EA0}"

# ------------------------------------------------------------ contents
S0.column_dimensions["A"].width = 110
r = 2
put(S0, r, 1, "18. Інструмент аналізу активів банку: структура, відносна дохідність, капітал, бізнес-модель, контрфактичні сценарії і трансмісія", A10B); r += 2
for sh, txt in [("18.1", "18.1. Профіль банку: перемикачі, структура активів, дохідність, капітал, бізнес-модель, сценарій"),
                ("18.2", "18.2. Порівняння банків"), ("18.3", "18.3. Динаміка обраного банку за 60 місяців"),
                ("18.4", "18.4. Трансмісія облікової ставки в дохідність активів: пік, IRF, інертність (система і банк)"),
                ("18.5", "18.5. Методологія, сценарії і джерела"),
                ("18.6", "18.6. Тіньова ціна капіталу: капітальний клин, мінімальна ставка кредиту, реакції кредиту (модель статті)"),
                ("18.7", "18.7. Ранній сигнал: зведений скоринг ризиків банку і всіх банків"),
                ("Д1", f"Д1. Дані банків на {LATEST}"), ("Д2", "Д2. Історія банків"), ("Д3", "Д3. Відгук дохідності системи: локальні проєкції"), ("Д4", "Д4. Параметри передачі за банками")]:
    c = put(S0, r, 1, txt, A10L, al=LNW); c.hyperlink = f"#'{sh}'!A1"; r += 1
r += 1
put(S0, r, 1, "Як користуватися", A10B); r += 1
for t in ["1. На аркуші 18.1 оберіть банк. Усі таблиці, графіки, порівняння 18.2, динаміка 18.3 і трансмісія 18.4 перераховуються.",
          "2. Для аналізу «що, якщо» введіть власні значення дохідності, вартості ризику або вартості депозитів у блакитні клітинки; порожня клітинка означає фактичне значення.",
          "3. Оберіть контрфактичний сценарій, щоб побачити, як змінилася б структура портфеля банку і його чистий процентний дохід.",
          "4. Кольори: блакитний шрифт на жовтому тлі: вхідні дані; зелений: посилання на інший аркуш; чорний: формули; сірий фон: службові розрахунки."]:
    put(S0, r, 1, t, al=LEFT); S0.row_dimensions[r].height = 27; r += 1
put(S0, r + 1, 1, f"Згенеровано {dt.date.today().strftime('%d.%m.%Y')} скриптом 18_bank_assets_tool.py з результатів розділу 3 і п. 2.2.", A9I)

# ------------------------------------------------------------ names, order, page setup, save
import re
pat = re.compile(r"(?<![A-Za-z_'!$])(" + "|".join(sorted(map(re.escape, NAMES), key=len, reverse=True)) + r")(?![A-Za-z0-9_(])")
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.startswith("="):
                c.value = pat.sub(lambda m: NAMES[m.group(1)], c.value)
    for cf in ws.conditional_formatting:
        for rule in cf.rules:
            rule.formula = [pat.sub(lambda m: NAMES[m.group(1)], f) for f in (rule.formula or [])]
    for dv_ in ws.data_validations.dataValidation:
        if dv_.formula1 and dv_.formula1.startswith("="):
            dv_.formula1 = dv_.formula1[1:]
order = ["18", "18.1", "18.2", "18.3", "18.4", "18.6", "18.7", "18.5", "Д1", "Д2", "Д3", "Д4"]
wb._sheets = [wb[n] for n in order]
for ws in wb.worksheets:
    ws.page_setup.orientation = "landscape"; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0; ws.sheet_properties.pageSetUpPr.fitToPage = True
wb.active = 1
wb.calculation.fullCalcOnLoad = True
save_both(wb, FILE, {"Д1": "D1", "Д2": "D2", "Д3": "D3", "Д4": "D4"}, os.path.join(DEST, "i18n_missing_assets.txt"))
print("OK:", FILE, f"банків: {NB}, місяців: {len(MONTHS)}, сценаріїв: {len(SCEN)}")
