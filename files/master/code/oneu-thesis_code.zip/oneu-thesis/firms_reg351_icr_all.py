# -*- coding: utf-8 -*-
"""Res. 23 p.2-9(7) coverage threshold = 1 for all forms (v5 panel: op_res23 / (debt x NBU rate), p.2-11(3))."""
import pandas as pd, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reg351_lib import boot
P, OUT = sys.argv[1:3]
d = pd.read_parquet(P)
rows = []
for form in ['full', 'small', 'micro']:
    f = d[d.balance_form.eq(form) & d.icr_rate.notna()].reset_index(drop=True)
    for h, w in [(1.0, .1), (.6, .05)]:
        G = {'borrowers FY2023-25': f.borrower & f.year.ge(2023), 'borrowers FY2021-22': f.borrower & f.year.le(2022)}
        r = boot(f, 'icr_rate', 1.0, h, w, G); r['test'] = f'{form}: op. result before amortisation / (debt x rate) = 1, h={h}'; rows.append(r)
R = pd.concat(rows, ignore_index=True); R.to_csv(f'{OUT}/S3_B17_icr_all_forms.csv', index=False); print(R.round(3).to_string())
