import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt, sys
d=pd.read_parquet(sys.argv[1]); out=sys.argv[2]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,ax=plt.subplots(1,3,figsize=(13.5,4.2))
def hist(a,x,lo,hi,w,lab,st):
    e=np.arange(lo,hi+1e-9,w); n,_=np.histogram(x,e); a.plot((e[:-1]+e[1:])/2,n/n.sum()*100,st,label=lab,lw=1.6,ms=3)
f=d[d.full&d.icr.notna()]
hist(ax[0],f[f.borrower&f.year.le(2022)].icr,0,2,.1,'з кредитом, 2021–2022','o-')
hist(ax[0],f[f.borrower&f.year.ge(2023)].icr,0,2,.1,'з кредитом, 2023–2025','s-')
hist(ax[0],f[~f.borrower].icr,0,2,.1,'без кредиту, 2021–2025','^--')
ax[0].axvline(1,color='k',lw=.8); ax[0].set_title('EBITDA / фінансові витрати\n(поріг 1: ознака дефолту за\nпостановою № 23, звітність з 2023 р.)'); ax[0].set_ylabel('% фірм у вікні 0–2')
g=d[d.s1&d.nd_ebitda.notna()]
hist(ax[1],g[g.borrower].nd_ebitda,2,8,.5,'з кредитом','o-'); hist(ax[1],g[~g.borrower].nd_ebitda,2,8,.5,'без кредиту','^--')
ax[1].axvline(5,color='k',lw=.8); ax[1].set_title('Чистий борг / EBITDA\n(фірми з ЧБ / дохід > 2,5;\nпоріг 5: п. 162 Положення № 351)')
g=d[d.s2&d.nd_sales.notna()]
hist(ax[2],g[g.borrower].nd_sales,1,4,.25,'з кредитом','o-'); hist(ax[2],g[~g.borrower].nd_sales,1,4,.25,'без кредиту','^--')
ax[2].axvline(2.5,color='k',lw=.8); ax[2].set_title('Чистий борг / дохід\n(фірми з ЧБ / EBITDA > 5 або EBITDA ≤ 0;\nпоріг 2,5: п. 162 Положення № 351)')
for a in ax: a.legend(frameon=False,fontsize=8); a.grid(alpha=.3)
plt.tight_layout(); plt.savefig(out,dpi=200)
