# -*- coding: utf-8 -*-
"""Common helpers for the bank Excel tools (12, 13, 18, 19):
 * plain-text rule: no arrows, dashes or other special symbols in text; Greek letters are kept;
 * English version of a finished workbook: every text cell, string literal inside formulas, data-validation list,
   chart title, comment, number format and sheet name is translated with i18n/xl_tools_uk_en.json
   (exact strings) and i18n/uk_en_dictionary.csv; whatever is left in Cyrillic is transliterated and logged.
Usage at the end of a generator:
    from xl_common import save_both
    save_both(wb, "path/Tool.xlsx")      # writes Tool.xlsx (Ukrainian) and Tool_EN.xlsx (English)
"""
import csv, json, os, re, copy
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
CYR = re.compile('[А-Яа-яІіЇїЄєҐґЁё]')

# ------------------------------------------------------------------ plain text
_REPL = [
    ('«–» — явища не було; «…» — даних немає або показник не визначений.',
     'Позначки: «–» у числовій клітинці означає, що явища не було; «...» означає, що даних немає або показник не визначений.'),
    ('↑↓', 'вгору і вниз'), ('↓↑', 'вниз і вгору'), ('↑', 'вгору'), ('↓', 'вниз'), ('⬆', 'вгору'), ('⬇', 'вниз'),
    (' → ', ' до '), ('→', ' до '), ('←', ' від '), ('⇒', ', отже, '), ('↔', ' і '), ('⟶', ' до '),
    (' — ', ': '), ('—', ': '), (' – ', ': '), ('−', '-'), ('…', '...'), (' × ', ' x '), ('×', 'x'), ('·', '*'),
    ('≤', '<='), ('≥', '>='), ('≠', 'не дорівнює'), ('≈', 'приблизно'), ('±', '+/-'), ('√', 'корінь з '), ('∞', 'нескінченність'),
    ('•', ''), ('▲', 'зростання'), ('▼', 'зниження'), ('✓', 'так'), ('✗', 'ні'), ('★', ''), ('■', ''), ('●', ''),
    ('′', "'"), ('″', '"'), (' ', ' '), (' ', ' '),
]
_SUP = str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹', '0123456789')
_SUB = str.maketrans('₀₁₂₃₄₅₆₇₈₉ₜₕ', '0123456789th')


def plain(s):
    """Text without arrows, dashes and special symbols (Greek letters and the «–» number-format mark are kept)."""
    if not isinstance(s, str) or not s:
        return s
    for a, b in _REPL[:1]:
        s = s.replace(a, b)
    keep = '«–»' in s
    if keep:
        s = s.replace('«–»', '\x00')
    for a, b in _REPL:
        s = s.replace(a, b)
    s = re.sub(r'(?<=[\w)\]%.,])–(?=[\w(\[])', '-', s)       # ranges 2021–2025, O/N–1 міс.
    s = s.replace('–', '-')
    s = re.sub('[⁰¹²³⁴⁵⁶⁷⁸⁹]+', lambda m: '^' + m.group(0).translate(_SUP), s)
    s = s.translate(_SUB)
    s = re.sub(r'  +', ' ', s).replace(' ,', ',').replace(',,', ',')
    if keep:
        s = s.replace('\x00', '«–»')
    return s


_LIT = re.compile(r'"((?:[^"]|"")*)"')


def _map_literals(formula, fn):
    return _LIT.sub(lambda m: '"' + fn(m.group(1).replace('""', '"')).replace('"', '""') + '"', formula)


def _chart_texts(ch):
    """yield every rich-text run of a chart (title, axis titles)"""
    objs = [getattr(ch, 'title', None)]
    for ax in ('x_axis', 'y_axis'):
        a = getattr(ch, ax, None)
        if a is not None:
            objs.append(getattr(a, 'title', None))
    for t in objs:
        if t is None or getattr(t, 'tx', None) is None or t.tx.rich is None:
            continue
        for p in t.tx.rich.p:
            for r in (p.r or []):
                yield r


def map_workbook(wb, fn, sheet_map=None, fmt_fn=None):
    """apply fn to every text in the workbook (cells, formula literals, DV lists, chart titles and series names, comments)"""
    sheet_map = sheet_map or {}

    def fix_refs(f):
        for a, b in sheet_map.items():
            f = f.replace("'%s'!" % a, "'%s'!" % b).replace('%s!' % a, "'%s'!" % b) if a != b else f
        return f
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str):
                    if v.startswith('='):
                        c.value = fix_refs(_map_literals(v, fn))
                    else:
                        c.value = fn(v)
                if c.comment is not None:
                    c.comment.text = fn(c.comment.text)
                if fmt_fn and c.number_format and CYR.search(c.number_format):
                    c.number_format = fmt_fn(c.number_format)
                if c.hyperlink is not None:
                    if c.hyperlink.location:
                        c.hyperlink.location = fix_refs(c.hyperlink.location)
                    if c.hyperlink.target and c.hyperlink.target.startswith('#'):
                        c.hyperlink.target = fix_refs(c.hyperlink.target)
        for dv in ws.data_validations.dataValidation:
            if dv.formula1:
                if dv.formula1.startswith('"'):
                    items = dv.formula1.strip('"').split(',')
                    dv.formula1 = '"' + ','.join(fn(x) for x in items) + '"'
                else:
                    dv.formula1 = fix_refs(dv.formula1)
            if dv.prompt: dv.prompt = fn(dv.prompt)
            if dv.promptTitle: dv.promptTitle = fn(dv.promptTitle)
            if dv.error: dv.error = fn(dv.error)
        for ch in getattr(ws, '_charts', []):
            for r in _chart_texts(ch):
                r.t = fn(r.t)
            for s in ch.series:
                if s.tx is not None and s.tx.v:
                    s.tx.v = fn(s.tx.v)
                for ref in (getattr(s.val, 'numRef', None), getattr(s.cat, 'numRef', None) if s.cat else None,
                            getattr(s.cat, 'strRef', None) if s.cat else None, getattr(s.xVal, 'numRef', None) if s.xVal else None,
                            getattr(s.yVal, 'numRef', None) if s.yVal else None):
                    if ref is not None and ref.f:
                        ref.f = fix_refs(ref.f)
        for cf in ws.conditional_formatting:
            for rule in cf.rules:
                rule.formula = [fix_refs(_map_literals(f, fn)) for f in (rule.formula or [])]
    if sheet_map:
        for ws in wb.worksheets:
            if ws.title in sheet_map:
                ws.title = sheet_map[ws.title]


def plain_workbook(wb):
    map_workbook(wb, plain)


# ------------------------------------------------------------------ English
TR = str.maketrans({'а': 'a', 'б': 'b', 'в': 'v', 'г': 'h', 'ґ': 'g', 'д': 'd', 'е': 'e', 'є': 'ie', 'ж': 'zh', 'з': 'z', 'и': 'y', 'і': 'i', 'ї': 'i',
                    'й': 'i', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'kh',
                    'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ь': '', 'ю': 'iu', 'я': 'ia', "'": '', '’': '', 'ё': 'e', 'ы': 'y', 'э': 'e', 'ъ': ''})


def translit(s):
    out = []
    for ch in s:
        lo = ch.lower(); t = lo.translate(TR)
        out.append(t.capitalize() if ch != lo and t else t)
    return ''.join(out)


_DICT = None
MISSING = set()


def _load_dict():
    global _DICT
    if _DICT is None:
        _DICT = {}
        p = os.path.join(HERE, 'i18n', 'uk_en_dictionary.csv')
        if os.path.exists(p):
            with open(p, encoding='utf-8-sig', newline='') as f:
                for r in csv.DictReader(f):
                    if r.get('uk') and r.get('en'):
                        _DICT[plain(r['uk'])] = r['en']
        for fn in sorted(os.listdir(os.path.join(HERE, 'i18n'))) if os.path.isdir(os.path.join(HERE, 'i18n')) else []:
            if fn.startswith('xl_tools_uk_en') and fn.endswith('.json'):
                with open(os.path.join(HERE, 'i18n', fn), encoding='utf-8') as f:
                    for k, v in json.load(f).items():
                        _DICT[plain(k)] = v
        # abstracted keys: the same text with other numbers (dates, years) is translated by the same entry
        for k, v in list(_DICT.items()):
            nk = [x.replace(',', '.') for x in _NUM2.findall(k)]
            nv = _NUM2.findall(v)
            if nk and nk == nv:
                _DICT.setdefault('\x01' + _NUM2.sub('{n}', k), _NUM2.sub('{n}', v))
    return _DICT


_NUMPAT = re.compile(r'(\d[\d\s.,]*)')
_NUM2 = re.compile(r'\d(?:[\d.,]*\d)?')


_BUCKET = re.compile(r'^(DF |PV |)((?:> )?(?:O/N-)?[\d,]+(?:-[\d,]+)?|> \d+|O/N-1) (міс\.|р\.)$')


def _try(s, depth=0):
    """translation without logging, or None"""
    d = _load_dict()
    if not CYR.search(s):
        return s
    if s in d:
        return d[s]
    st = s.strip()
    if st != s and st in d:
        return s.replace(st, d[st])
    m2 = re.match(r'^(\d+(?:\.\d+)*\.?\s+)(.+)$', st)
    if m2 and m2.group(2) in d:
        return m2.group(1) + d[m2.group(2)]
    key = _NUMPAT.sub('{n}', st)
    if key in d:
        nums = _NUMPAT.findall(st); out = d[key]
        for n_ in nums:
            out = out.replace('{n}', n_.replace(',', '.').strip(), 1)
        return out
    k2 = '\x01' + _NUM2.sub('{n}', st)
    if k2 in d:
        out = d[k2]
        for n_ in _NUM2.findall(st):
            out = out.replace('{n}', n_.replace(',', '.'), 1)
        return out
    mb = _BUCKET.match(st)
    if mb:
        return mb.group(1) + mb.group(2).replace(',', '.') + (' m' if mb.group(3) == 'міс.' else ' y')
    if depth < 4:
        for sep in ('; ', ': ', ', '):
            if sep in st:
                parts = st.split(sep)
                tr = [_try(p_, depth + 1) for p_ in parts]
                if all(t is not None for t in tr):
                    return sep.join(tr)
        mp = re.match(r'^(.+?) \((.+)\)([.:]?)$', st)
        if mp:
            a_, b_ = _try(mp.group(1), depth + 1), _try(mp.group(2), depth + 1)
            if a_ is not None and b_ is not None:
                return f'{a_} ({b_}){mp.group(3)}'
    return None


def en(s):
    """English text for a Ukrainian string: exact dictionary, numbered and numeric patterns, bucket labels, then the same rules
    on parts split by '; ', ': ', ', ' and parentheses; anything still Cyrillic is transliterated (and logged in MISSING)."""
    if not isinstance(s, str) or not CYR.search(s):
        return s
    t = _try(s)
    if t is not None:
        return t
    st = s.strip()
    if re.match(r'^(АТ|ПАТ|ПуАТ|АКБ|АБ|ТОВ|КБ|ПрАТ)\s', st):     # bank and company names: transliteration only
        return translit(s)
    MISSING.add(st)
    return translit(s)


def _fmt_en(f):
    return f.replace('б.п.', 'bp').replace('млн грн', 'UAH m').replace('грн', 'UAH').replace('міс.', 'm').replace('р.', 'y')


def to_english(wb, sheet_map=None):
    """translate the workbook in memory (keeps charts, which openpyxl cannot reload from a saved file)"""
    sm = dict(sheet_map or {})
    for ws in wb.worksheets:
        if CYR.search(ws.title) and ws.title not in sm:
            t = en(ws.title)
            sm[ws.title] = t if not CYR.search(t) else translit(ws.title)
    map_workbook(wb, lambda t: plain(en(t)), sm, _fmt_en)


def save_both(wb, path_uk, sheet_map=None, log=None):
    """plain-text clean-up, save the Ukrainian file, then translate the same workbook and save …_EN.xlsx."""
    plain_workbook(wb)
    wb.save(path_uk)
    path_en = re.sub(r'\.xlsx$', '_EN.xlsx', path_uk)
    to_english(wb, sheet_map)
    wb.save(path_en)
    miss = sorted(MISSING)
    if log:
        with open(log, 'w', encoding='utf-8') as f:
            f.write('\n'.join(miss))
    return path_en, miss
