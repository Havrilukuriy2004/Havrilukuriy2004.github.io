# -*- coding: utf-8 -*-
"""NBU Regulation 351, Annex 7 (Tables 1-2): pooled test of firms locating on the favourable side of the scoring-model cut-offs.
Cut-offs of the firm's own model (industry group x size table) versus the same indicator's cut-offs from other models (placebo),
borrowers versus non-borrowers. Ratios in per cent, as in the Regulation."""
import pandas as pd, numpy as np, sys
import statsmodels.formula.api as smf
P, OUT = sys.argv[1:3]
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import class351 as CM
d = pd.read_parquet(P)
d['grp'] = CM.group(pd.to_numeric(d['div'], errors='coerce'))
d['tab'] = np.where(d.balance_form.eq('full'), 'T1', 'T2')
K = CM.indicators(d)
R = {}
for k, (num, den) in K.items():
    with np.errstate(divide='ignore', invalid='ignore'):
        v = 100 * num / den
    bad = (den == 0) | (den < 0) & (k in CM.ZERO)
    R[k] = v.where(~bad & np.isfinite(v))
T1 = {g: [(k, cuts, X) for k, coef, cuts, X in terms] for g, (b0, terms) in CM.T1.items()}
T2 = {g: [(k, cuts, X) for k, coef, cuts, X in terms] for g, (b0, terms) in CM.T2.items()}
APPROX = set()
rows = []
for tab, T in [('T1', T1), ('T2', T2)]:
    for g, inds in T.items():
        for k, cuts, X in inds:
            x = R[k]
            for j, c in enumerate(cuts):
                dirn = np.sign(X[j + 1] - X[j])
                if dirn == 0: continue
                h = max(0.08 * abs(c), 0.4)
                m = x.notna() & x.ne(0) & (x - c).abs().lt(h) & d.tab.eq(tab)   # exact zeros (no activity) are heaps, not choices
                if m.sum() == 0: continue
                s = d.loc[m, ['edrpou', 'year', 'grp', 'borrower', 'div']].copy()
                s['x'] = x[m]; s['above'] = (s.x >= c).astype(int)
                s['fav'] = np.where(dirn > 0, s.above, 1 - s.above)
                s['relevant'] = (s.grp == g).astype(int)
                s['ind'] = k; s['cut'] = c; s['src'] = f'{tab}-{g}'; s['tab'] = tab; s['approx'] = k in APPROX
                s['dist'] = (s.x - c).abs() / h
                rows.append(s)
L = pd.concat(rows, ignore_index=True)
# a firm-year can sit near the same cut-off value listed by two models (e.g. KLMN and OTH share tables): keep one row per firm-year-indicator-cut-off, relevant if any
L = L.sort_values('relevant', ascending=False).drop_duplicates(['edrpou', 'year', 'ind', 'cut'])
L['cell'] = L.ind + '_' + L.cut.astype(str) + '_' + L.tab
L['b'] = L.borrower.astype(int)
L['post'] = (L.year >= 2022).astype(int)
print('rows', len(L), 'relevant share', L.relevant.mean().round(3))
res = []
def demean(M, g1, g2, it=50):
    M = M.astype(float).copy()
    n1 = np.bincount(g1); n2 = np.bincount(g2)
    for _ in range(it):
        for g, n in ((g1, n1), (g2, n2)):
            mu = np.vstack([np.bincount(g, M[:, j], minlength=len(n)) for j in range(M.shape[1])]).T / n[:, None]
            M -= mu[g]
    return M
def fit(terms, s, lab):
    s = s.copy()
    cols = {'relevant': s.relevant.values, 'b': s.b.values, 'relevant:b': (s.relevant * s.b).values}
    if 'post' in terms:
        cols.update({'post': s.post.values, 'relevant:post': (s.relevant * s.post).values, 'b:post': (s.b * s.post).values, 'relevant:b:post': (s.relevant * s.b * s.post).values})
    cols = {k: v for k, v in cols.items() if k in terms}
    M = np.column_stack([s.fav.values] + list(cols.values()))
    M = demean(M, pd.factorize(s.cell)[0], pd.factorize(s.grp)[0])
    y, X = M[:, 0], M[:, 1:]
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    e = y - X @ beta
    cl = pd.factorize(s.edrpou)[0]
    XtXi = np.linalg.inv(X.T @ X)
    S = np.vstack([np.bincount(cl, X[:, j] * e) for j in range(X.shape[1])]).T
    V = XtXi @ (S.T @ S) @ XtXi
    G = cl.max() + 1; V *= G / (G - 1)
    from scipy.stats import norm
    for j, k in enumerate(cols):
        se = np.sqrt(V[j, j]); res.append(dict(spec=lab, term=k, coef=beta[j], se=se, p=2 * norm.sf(abs(beta[j] / se)), n=len(s), mean_fav=s.fav.mean()))
T3 = ['relevant', 'b', 'relevant:b']
for lab, s in [('all indicators', L), ('narrow window (|x-c| < h/2)', L[L.dist < .5]),
               ('full forms (Table 1)', L[L.tab == 'T1']), ('small forms (Table 2)', L[L.tab == 'T2'])]:
    fit(T3, s, lab)
fit(T3 + ['post', 'relevant:post', 'b:post', 'relevant:b:post'], L, 'all, wartime interaction (FY2022+)')
for lab, s in [('borrowers only', L[L.b == 1]), ('non-borrowers only', L[L.b == 0])]:
    fit(['relevant'], s, lab)
Rz = pd.DataFrame(res)
Rz.to_csv(f'{OUT}/S3_B17_scoring_cutoffs.csv', index=False)
print(Rz.round(4).to_string())
# per indicator (relevant cut-offs, borrowers vs non-borrowers share on favourable side)
P2 = L[L.relevant == 1].groupby(['tab', 'ind', 'b']).fav.agg(['mean', 'size']).unstack('b')
P2.to_csv(f'{OUT}/S3_B17_scoring_by_indicator.csv')
print(P2.round(3).to_string())
