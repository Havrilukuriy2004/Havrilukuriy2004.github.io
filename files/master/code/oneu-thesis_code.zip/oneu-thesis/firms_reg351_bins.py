# -*- coding: utf-8 -*-
"""Binned distributions around the regulatory thresholds (data for figure S3_F32, drawn in R in the thesis style)."""
import pandas as pd, numpy as np, sys
P, OUT = sys.argv[1:3]
d = pd.read_parquet(P)
rows = []
def h(x, lo, hi, w, panel, group):
    e = np.arange(lo, hi + 1e-9, w); n, _ = np.histogram(x.dropna(), e)
    for m, c in zip((e[:-1] + e[1:]) / 2, n):
        rows.append(dict(panel=panel, group=group, mid=round(m, 4), n=int(c), share=100 * c / max(n.sum(), 1)))
f = d[d.full & d.icr.notna()]
P1 = 'EBITDA / фінансові витрати (поріг 1)'
h(f[f.borrower & f.year.le(2022)].icr, 0, 2, .1, P1, 'З кредитом, 2021–2022 рр.')
h(f[f.borrower & f.year.ge(2023)].icr, 0, 2, .1, P1, 'З кредитом, 2023–2025 рр.')
h(f[~f.borrower].icr, 0, 2, .1, P1, 'Без кредиту, 2021–2025 рр.')
g = d[d.s1 & d.nd_ebitda.notna()]
P2 = 'Чистий борг / EBITDA за чистий борг / дохід > 2,5 (поріг 5)'
h(g[g.borrower].nd_ebitda, 2, 8, .5, P2, 'З кредитом, 2021–2025 рр.'); h(g[~g.borrower].nd_ebitda, 2, 8, .5, P2, 'Без кредиту, 2021–2025 рр.')
g = d[d.s2 & d.nd_sales.notna()]
P3 = 'Чистий борг / дохід за чистий борг / EBITDA > 5 або EBITDA ≤ 0 (поріг 2,5)'
h(g[g.borrower].nd_sales, 1, 4, .25, P3, 'З кредитом, 2021–2025 рр.'); h(g[~g.borrower].nd_sales, 1, 4, .25, P3, 'Без кредиту, 2021–2025 рр.')
pd.DataFrame(rows).to_csv(OUT, index=False, encoding='utf-8')
print(len(rows))
