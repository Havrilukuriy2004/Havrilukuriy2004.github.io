# -*- coding: utf-8 -*-
"""Regulatory-threshold tests: NBU Reg. 351 p.162(4) and Res. 23 p.2-9(7)."""
import pandas as pd, numpy as np, sys, os
import statsmodels.formula.api as smf
P = sys.argv[1]; OUT = sys.argv[2]; os.makedirs(OUT, exist_ok=True)
d = pd.read_parquet(P)
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from reg351_lib import disc, boot


rows = []
# A1. Res.23 p.2-9(7): EBITDA / finance costs < 1 is a default sign from FY2023 statements. Full-form firms.
f = d[d.full & d.icr.notna()].reset_index(drop=True)
for h, w in [(1.0, .1), (.6, .05)]:
    G = {'borrowers FY2023-25': f.borrower & f.year.ge(2023), 'borrowers FY2021-22': f.borrower & f.year.le(2022),
         'non-borrowers FY2023-25': ~f.borrower & f.year.ge(2023), 'non-borrowers FY2021-22': ~f.borrower & f.year.le(2022)}
    r = boot(f, 'icr', 1.0, h, w, G); r['test'] = f'EBITDA/finance costs = 1 (Res.23), h={h}, bin={w}'; rows.append(r)
    G2 = {'borrowers FY2023-25': G['borrowers FY2023-25'], 'non-borrowers FY2023-25': G['non-borrowers FY2023-25']}
    r = boot(f, 'icr', 1.0, h, w, G2); r['test'] = f'EBITDA/finance costs = 1, borrowers vs non-borrowers FY2023-25, h={h}'; rows.append(r.tail(1))
    G3 = {'non-borrowers FY2023-25': G['non-borrowers FY2023-25'], 'non-borrowers FY2021-22': G['non-borrowers FY2021-22']}
    r = boot(f, 'icr', 1.0, h, w, G3); r['test'] = f'EBITDA/finance costs = 1, non-borrowers post minus pre, h={h}'; rows.append(r.tail(1))
# A2. Reg.351 p.162(4): ND/EBITDA > 5 (given ND/Sales > 2.5)
g = d[d.s1 & d.nd_ebitda.notna()].reset_index(drop=True)
for h, w in [(2.5, .25), (2.0, .5)]:
    r = boot(g, 'nd_ebitda', 5.0, h, w, {'borrowers': g.borrower, 'non-borrowers': ~g.borrower}); r['test'] = f'ND/EBITDA = 5 | ND/Sales>2.5, h={h}'; rows.append(r)
g = d[d.nd_ebitda.notna() & d.nd_sales.le(2.5)].reset_index(drop=True)
r = boot(g, 'nd_ebitda', 5.0, 2.5, .25, {'borrowers': g.borrower, 'non-borrowers': ~g.borrower}); r['test'] = 'Placebo: ND/EBITDA = 5 | ND/Sales<=2.5'; rows.append(r)
# A3. ND/Sales > 2.5 (given ND/EBITDA>5 or EBITDA<=0)
g = d[d.s2 & d.nd_sales.notna()].reset_index(drop=True)
r = boot(g, 'nd_sales', 2.5, 1.25, .125, {'borrowers': g.borrower, 'non-borrowers': ~g.borrower}); r['test'] = 'ND/Sales = 2.5 | ND/EBITDA>5 or EBITDA<=0'; rows.append(r)
A = pd.concat(rows, ignore_index=True)
A.to_csv(f'{OUT}/S3_B17_threshold_density.csv', index=False)
print(A.round(3).to_string())

# B. Real effects: what happens to bank credit next year when the firm is on the wrong side
d = d.sort_values(['edrpou', 'year'])
nx = d[['edrpou', 'year', 'bank_close', 'r1300_close']].copy(); nx['year'] -= 1
d = d.merge(nx.rename(columns={'bank_close': 'bank_next', 'r1300_close': 'ta_next'}), on=['edrpou', 'year'], how='left')
d['present_next'] = d.ta_next.notna()
d['dlbank'] = np.log1p(d.bank_next.clip(lower=0)) - np.log1p(d.bank_close.clip(lower=0))
d['lost'] = ((d.bank_close > 0) & (d.bank_next <= 0)).astype(float)
d['lta'] = np.log(d.r1300_close)
out = []


def rd(df, var, c, h, y, label):
    s = df[(df[var] - c).abs() < h].copy()
    s['xc'] = s[var] - c; s['below'] = (s[var] < c).astype(int)
    s['wt'] = 1 - s.xc.abs() / h
    s = s[s[y].notna()]
    if len(s) < 60: return
    m = smf.wls(f'{y} ~ below + xc + below:xc + lta', s, weights=s.wt).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(s.edrpou)[0]})
    out.append(dict(test=label, outcome=y, coef_below=m.params['below'], se=m.bse['below'], p=m.pvalues['below'], n=int(m.nobs), mean_y=s[y].mean()))


bb = d[d.full & d.borrower & d.icr.notna() & (d.bank_close > 0)]
for yr in [2021, 2022, 2023, 2024]:
    s = bb[(bb.year == yr) & bb.present_next]
    for y in ['dlbank', 'lost']:
        for h in [.5, 1.0]:
            rd(s, 'icr', 1.0, h, y, f'ICR<1 in FY{yr}, h={h}' + ('' if yr >= 2023 else ' (before rule)'))
s1 = d[d.borrower & d.s1 & d.nd_ebitda.notna() & (d.bank_close > 0) & d.present_next]
for y in ['dlbank', 'lost']:
    for h in [2.5, 4.0]:
        rd(s1, 'nd_ebitda', 5.0, h, y, f'ND/EBITDA>5 | ND/Sales>2.5 (FY2021-24 pooled), h={h}')
# note: here "below" = 1 means ND/EBITDA < 5 (the safe side)
Bt = pd.DataFrame(out); Bt.to_csv(f'{OUT}/S3_B17_threshold_rd.csv', index=False)
print(Bt.round(4).to_string())

# C. Wartime forbearance, Res.23 p.2(7): the 162(4) sign is ignored if it first appears in post-24.02.2022 statements
hc = d[['edrpou', 'year', 'hcr']]
w21 = hc[hc.year == 2021].set_index('edrpou').hcr
c = d[(d.year.isin([2022, 2023])) & d.hcr & (d.bank_close > 0) & d.present_next].copy()
c['pre_war_flag'] = c.edrpou.map(w21)
c = c[c.pre_war_flag.notna()]
c['pre_war_flag'] = c.pre_war_flag.astype(int)
rows = []
for y in ['dlbank', 'lost']:
    m = smf.ols(f'{y} ~ pre_war_flag + lta + np.log1p(bank_close) + C(year)', c).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(c.edrpou)[0]})
    rows.append(dict(outcome=y, coef_pre_war_flag=m.params['pre_war_flag'], se=m.bse['pre_war_flag'], p=m.pvalues['pre_war_flag'], n=int(m.nobs),
                     n_flag_prewar=int(c.pre_war_flag.sum()), mean_new=c.loc[c.pre_war_flag == 0, y].mean(), mean_prewar=c.loc[c.pre_war_flag == 1, y].mean()))
# placebo: same comparison among firms NOT flagged now
c0 = d[(d.year.isin([2022, 2023])) & ~d.hcr & (d.bank_close > 0) & d.present_next].copy()
c0['pre_war_flag'] = c0.edrpou.map(w21); c0 = c0[c0.pre_war_flag.notna()]; c0['pre_war_flag'] = c0.pre_war_flag.astype(int)
for y in ['dlbank', 'lost']:
    m = smf.ols(f'{y} ~ pre_war_flag + lta + np.log1p(bank_close) + C(year)', c0).fit(cov_type='cluster', cov_kwds={'groups': pd.factorize(c0.edrpou)[0]})
    rows.append(dict(outcome=y + ' (placebo: not flagged now)', coef_pre_war_flag=m.params['pre_war_flag'], se=m.bse['pre_war_flag'], p=m.pvalues['pre_war_flag'],
                     n=int(m.nobs), n_flag_prewar=int(c0.pre_war_flag.sum())))
C = pd.DataFrame(rows); C.to_csv(f'{OUT}/S3_B17_forbearance.csv', index=False)
print(C.round(4).to_string())

# D. Descriptives
D = d.groupby(['year', 'full', 'borrower']).agg(n=('edrpou', 'size'), share_hcr=('hcr', 'mean'), share_ebitda_le0=('ebitda', lambda x: (x <= 0).mean()),
                                                share_icr_lt1=('dflt23', 'mean'), med_nd_ebitda=('nd_ebitda', 'median'), med_nd_sales=('nd_sales', 'median'),
                                                med_icr=('icr', 'median')).reset_index()
D.to_csv(f'{OUT}/S3_B17_ratios_by_year.csv', index=False)
d.to_parquet(f'{OUT}/panel_next.parquet', index=False)
