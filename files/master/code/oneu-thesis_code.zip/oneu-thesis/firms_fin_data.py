# -*- coding: utf-8 -*-
"""
firms_fin_data.py — фінансова звітність підприємств (Держстат, data.gov.ua): завантаження, розбір XML, панель фірм.

Набори даних (CC BY 4.0, Державна служба статистики України):
  річна      https://data.gov.ua/dataset/7436ae83-dfc1-4836-9962-8af3e831c522
  квартальна https://data.gov.ua/dataset/37f95c7e-e3a3-4b3e-9988-26db2d7afdb7

Запуск (з теки проєкту):   python -X utf8 firms_fin_data.py .            (усе: завантаження → розбір → панель)
                          python -X utf8 firms_fin_data.py . --no-download
                          python -X utf8 firms_fin_data.py . --build-only (лише панель з уже розібраних файлів)
Сирі архіви:  data_nbu/local_inputs/firms_fin/*.zip  (будь-які назви; якщо сайт не дає завантажити скрипту – завантажте браузером
              файли зі списку data_nbu/firms/firms_download_manual.txt у цю теку і запустіть ще раз)
Результат:    data_nbu/firms/filings/<форма>/*.parquet  – один рядок на поданий звіт (обрані рядки форм, тис. грн)
              data_nbu/firms/firms_windows.parquet       – фірма × звітний період: залишки на початок і кінець, потоки поточні і попередні
              data_nbu/firms/firms_stocks.parquet        – фірма × дата: залишки балансу (31.12 або 30.09), зокрема з колонки «на початок»
              data_nbu/firms/firms_parse_report.csv, firms_coverage.csv, firms_tags_unmatched.csv

Будова архівів (перевірено за відкритими парсерами цих даних): зовнішній ZIP → вкладені ZIP за формами (у назві код форми S0100115 тощо) →
один XML на поданий звіт; у XML блоки DECLARHEAD (TIN, C_DOC, C_DOC_SUB, C_DOC_VER, C_DOC_CNT, C_DOC_STAN, PERIOD_MONTH, PERIOD_YEAR, D_FILL …)
і DECLARBODY (FIRM_EDRPOU, FIRM_KVED, KATOTTG …, рядки R1010G3/R1010G4 …). Колонка 3 балансу – на початок року, 4 – на кінець періоду;
колонка 3 звіту про фінансові результати – звітний період, 4 – аналогічний період попереднього року. Працівники: S_CH (малі, мікро), N3 (форма 1).
Скрипт не покладається на назви файлів: форму і період визначає з заголовка XML, вкладеність ZIP – будь-яка.
"""
import argparse, io, json, os, re, shutil, sys, tempfile, time, zipfile, urllib.request, urllib.error
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from lxml import etree

# ------------------------------------------------------------------ sources
DATASETS = {"annual": "7436ae83-dfc1-4836-9962-8af3e831c522", "quarterly": "37f95c7e-e3a3-4b3e-9988-26db2d7afdb7"}
# links as published on 12.11.2026 (the portal renames files after each monthly update; the CKAN API is tried first)
FALLBACK = [
    ("annual", "Фінансова звітність підприємств за 2025 рік", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/fe3f6731-8a79-463b-b3af-03811d7a0e26/download/fin_zvit_2025_ric_-2026-01-01_2026-11-10.zip"),
    ("annual", "Фінансова звітність підприємств за 2024 рік", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/c58bf087-77b1-4355-9879-16d8cea35677/download/fin_zvit_2024_ric_-2026-01-01_2026-11-10.zip"),
    ("annual", "Фінансова звітність підприємств за 2023 рік", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/9e7b6a7d-eaeb-44e2-9947-e34b25ce83cf/download/fin_zvit_2023_ric_-2026-01-01_2026-10-08.zip"),
    ("annual", "Фінансова звітність підприємств за 2022 рік", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/b2e27b15-c3cc-4944-9d39-86260665c9a9/download/fin_zvit_2022_ric_-2026-01-01_2026-11-10.zip"),
    ("annual", "Фінансова звітність підприємств за 2021 рік", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/2f24df98-79ea-443f-9b89-e8cd3f1b9ae2/download/fin_zvit_2021_ric_-2026-01-01_2026-08-10.zip"),
    ("annual", "Форма 1 (рік 2022)", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/1e93dd50-f137-43f1-a165-6d7fd8f2c329/download/f-i_ric_2022.zip"),
    ("annual", "Форма 2 (рік 2022)", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/4cee01d7-a483-4b28-88fb-4dfe770afe2c/download/f-ii_ric_2022.zip"),
    ("annual", "Форма 1-м, 2-м (рік 2022)", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/70d2d63c-a3c0-4818-bb7f-f6ab5854c7b0/download/f-i-m-ii-m_ric_2022.zip"),
    ("annual", "Форма 1-мс, 2-мс (рік 2022)", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/4d214aeb-b9ae-4d80-a220-3b585bf1e90c/download/f-i-ms-ii-ms_ric_2022.zip"),
    ("annual", "Форма 1-мс, 2-мс (рік 2021)", "https://data.gov.ua/dataset/6456ef0c-985c-4bb7-bf9d-16831161b416/resource/d6c44e95-9b48-4eb9-b91e-e2a457e1dc8e/download/f-i-ms-ii-ms_ric_2022.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2026", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/47f87a51-4f45-462e-b8fa-bbe3b6f41f1e/download/fin_zvit_9-mic_26_-2026-01-01_2026-11-10.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2025", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/e378cc16-724c-4ba6-b704-9f4fb02328a8/download/fin_zvit_9-mic_25_-2026-01-01_2026-10-08.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2024", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/bd6c33b6-9bbb-48e4-91d9-c674eaba5e8a/download/fin_zvit_9-mic_24_-2026-01-01_2026-11-10.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2023", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/faf17043-2d04-4377-820b-dcf4aca4401e/download/fin_zvit_9-mic_23_-2026-01-01_2026-11-10.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2022", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/50b7f219-a88c-4aea-8301-51c23ae0b94c/download/fin_zvit_9-mic_22_-2026-01-01_2026-04-07.zip"),
    ("quarterly", "Фінансова звітність за 9 місяців 2021", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/cbccead2-efa8-4698-98c2-f460db2fba82/download/fin_zvit_9-mic_21_-2026-01-01_2026-05-06.zip"),
    ("quarterly", "Forma_I_(9_mis_2023)", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/c2347286-997d-4c74-8d02-d2f19be942d9/download/forma_i_-9_mis_2023.zip"),
    ("quarterly", "Forma_II_(9_mis_23)", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/e8e52015-56f4-4b38-b977-4b6af81f84c0/download/forma_ii_-9_mis_23.zip"),
    ("quarterly", "Forma_I-m;II-m_(9_mis_23)", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/70879ffd-fda6-4f2f-b291-05e445325863/download/forma_i-m-ii-m_-9_mis_23.zip"),
    ("quarterly", "Forma_I-ms;II-ms_(9_mis_23)", "https://data.gov.ua/dataset/36bbcbd0-ef7c-462f-85a2-c5fcab6a240a/resource/f0ad5935-e125-4a3b-9457-792bdc98fcae/download/forma_i-ms-ii-ms_-9_mis_23.zip"),
]
# which resources are needed: annual statements, 9-month statements (Dec → Sep windows), the separate form files 2021–2023
WANT = re.compile(r"(рік|ric|9.?(міс|mic|mis))", re.I)
SKIP = re.compile(r"(Форма\s*[3-6]|f-i{3}|f-iv|f-v|f-vi|forma_i{3}|forma_iv|Опис|opis)", re.I)

# ------------------------------------------------------------------ forms and lines kept
FAMILIES = {"S01001": "F1", "S01002": "F2", "S01100": "SM", "S01110": "MS"}   # balance (form 1), income (form 2), small 1-м/2-м, micro 1-мс/2-мс
KEEP_LINES = {  # balance (1xxx) and income statement (2xxx) lines used in the analysis
    1000, 1001, 1002, 1005, 1010, 1011, 1012, 1095, 1100, 1103, 1125, 1155, 1160, 1165, 1190, 1195, 1200, 1300,
    1400, 1495, 1500, 1510, 1515, 1520, 1525, 1595, 1600, 1605, 1610, 1615, 1620, 1630, 1690, 1695, 1700, 1900,
    2000, 2050, 2090, 2095, 2120, 2150, 2160, 2165, 2180, 2190, 2195, 2200, 2220, 2240, 2250, 2255, 2270, 2280, 2285,
    2290, 2295, 2300, 2350, 2355, 2500, 2505, 2510, 2515, 2520, 2550}
# line tags: simplified forms 1-м/2-м and 1-мс/2-мс – A1010_3 / B2000_4 (A = balance, B = income statement; _3/_4 = column);
# full forms 1 and 2 – A1010 / B1010 (A = column 3, B = column 4); older layouts may use R1010G3
LINE_RE = re.compile(r"^(?:R|A|B)?(\d{4})(?:G|_)([34])$")
LINE_AB = re.compile(r"^([AB])(\d{4})$")
HEAD_KEEP = ["TIN", "C_DOC", "C_DOC_SUB", "C_DOC_VER", "C_DOC_TYPE", "C_DOC_CNT", "C_DOC_STAN", "PERIOD_MONTH", "PERIOD_TYPE",
             "PERIOD_YEAR", "C_REG", "C_RAJ", "D_FILL"]
BODY_ID = re.compile(r"^(FIRM_EDRPOU|FIRM_KVED|KVED|OBL|RAY|FIRM_OPFCD|FIRM_OPF|S_CH|N3|N4|N5|.*KATOTTG.*|.*KOATUU.*|FIRM_TERR|FIRM_SPATO|FIRM_KOPFG)$", re.I)
FORM_IN_NAME = re.compile(r"(S\d{7})")
FLUSH = 100_000


def num(s):
    if s is None:
        return np.nan
    s = s.strip().replace(" ", "").replace(" ", "")
    if not s or s in ("-", "—", "–"):
        return np.nan
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()").replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        return np.nan
    return -v if neg else v


# ------------------------------------------------------------------ download
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36",
      "Accept": "*/*", "Accept-Language": "uk,en;q=0.8"}


def http(url, timeout=60):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout)


def discover():
    """current resource list from the portal API; falls back to the links above"""
    out = []
    for kind, pid in DATASETS.items():
        try:
            js = json.load(http(f"https://data.gov.ua/api/3/action/package_show?id={pid}", 30))
            for r in js["result"]["resources"]:
                out.append((kind, r.get("name") or "", r.get("url") or ""))
            print(f"  портал: {kind} – {len(js['result']['resources'])} ресурсів")
        except Exception as e:  # noqa: BLE001
            print(f"  портал недоступний для {kind} ({type(e).__name__}); використовую збережений перелік посилань")
            out += [x for x in FALLBACK if x[0] == kind]
    seen, bases, res = set(), Counter(), []
    for kind, name, url in out:
        base = url.rsplit("/", 1)[-1]
        if not url.lower().endswith(".zip") or url in seen:
            continue
        if SKIP.search(name) or SKIP.search(base) or not (WANT.search(name) or WANT.search(base)):
            continue
        seen.add(url); bases[base] += 1
        # two resources of the portal share one file name (micro forms 2021 and 2022): the later one gets its resource id as a prefix
        fn = base if bases[base] == 1 else re.search(r"/resource/([0-9a-f]{8})", url).group(1) + "_" + base
        res.append((kind, name, url, fn))
    return res


def download(raw, outdir):
    os.makedirs(raw, exist_ok=True)
    todo, manual = discover(), []
    have = {f.lower() for f in os.listdir(raw)}
    for kind, name, url, fn in todo:
        # the same resource with an older date stamp is replaced only when a newer one downloads successfully
        stem = re.sub(r"_?-?\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}", "", fn.lower())
        if fn.lower() in have:
            print(f"  є: {fn}"); continue
        dst = os.path.join(raw, fn); tmp = dst + ".part"
        try:
            with http(url, 120) as r, open(tmp, "wb") as f:
                ct = r.headers.get("Content-Type", "")
                first = r.read(1 << 16)
                if b"<html" in first[:2000].lower() or "text/html" in ct:
                    raise RuntimeError("сайт повернув сторінку замість файла (захист від автоматичного завантаження)")
                f.write(first); n = len(first)
                while True:
                    b = r.read(1 << 22)
                    if not b:
                        break
                    f.write(b); n += len(b)
            if not zipfile.is_zipfile(tmp):
                raise RuntimeError("отриманий файл не є ZIP")
            os.replace(tmp, dst); print(f"  завантажено: {fn} ({n / 1e6:.0f} МБ)")
            for old in os.listdir(raw):   # drop superseded versions of the same resource
                if old.lower() != fn.lower() and re.sub(r"_?-?\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}", "", old.lower()) == stem:
                    os.remove(os.path.join(raw, old)); print(f"    замінено стару версію {old}")
        except Exception as e:  # noqa: BLE001
            if os.path.exists(tmp):
                os.remove(tmp)
            older = [o for o in os.listdir(raw) if re.sub(r"_?-?\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}", "", o.lower()) == stem]
            print(f"  НЕ завантажено: {fn} – {e}" + (f" (буде використано наявну версію {older[0]})" if older else ""))
            if not older:
                manual.append((kind, name, url, fn))
    with open(os.path.join(outdir, "firms_download_manual.txt"), "w", encoding="utf-8") as f:
        if manual:
            f.write("Завантажте браузером ці файли у теку\n  " + os.path.abspath(raw) + "\n(назви файлів можна не змінювати) і запустіть скрипт ще раз.\n\n")
            for kind, name, url, fn in manual:
                f.write(f"{name}\n  {url}\n")
        else:
            f.write("Усі потрібні архіви є.\n")
    if manual:
        print(f"  ! {len(manual)} архів(и) треба завантажити вручну – перелік у {os.path.join(outdir, 'firms_download_manual.txt')}")
    return manual


# ------------------------------------------------------------------ parsing
PARSER = etree.XMLParser(recover=True, huge_tree=True, resolve_entities=False, no_network=True)
DECL = re.compile(rb"^\s*<\?xml[^>]*\?>", re.S)


def parse_xml(b):
    if b[:3] == b"\xef\xbb\xbf":
        b = b[3:]
    b = DECL.sub(b"", b, count=1).replace(b"\x00", b"")
    try:
        t = b.decode("utf-8"); enc = "utf-8"
    except UnicodeDecodeError:
        t = b.decode("cp1251", errors="replace"); enc = "cp1251"
    root = etree.fromstring(t.encode("utf-8"), PARSER)
    if root is None:
        raise ValueError("порожній XML")
    head, body = {}, {}
    for sec in root.iter():
        tag = etree.QName(sec).localname if isinstance(sec.tag, str) else ""
        if tag in ("DECLARHEAD", "DECLARBODY"):
            tgt = head if tag == "DECLARHEAD" else body
            for ch in sec:
                if not isinstance(ch.tag, str):
                    continue
                k = etree.QName(ch).localname
                if k in tgt:   # repeated element (table rows of other forms) – keep the first
                    continue
                tgt[k] = (ch.text or "").strip()
    if not head and not body:   # flat XML without the standard sections
        for ch in root:
            if isinstance(ch.tag, str):
                body.setdefault(etree.QName(ch).localname, (ch.text or "").strip())
    return head, body, enc


class Sink:
    """rows per form family, flushed to parquet parts"""

    def __init__(self, out, src):
        self.out, self.src, self.rows, self.part = out, src, defaultdict(list), Counter()

    def add(self, fam, row):
        self.rows[fam].append(row)
        if len(self.rows[fam]) >= FLUSH:
            self.flush(fam)

    def flush(self, fam=None):
        for f in ([fam] if fam else list(self.rows)):
            if not self.rows[f]:
                continue
            d = os.path.join(self.out, "filings", FAMILIES[f]); os.makedirs(d, exist_ok=True)
            df = pd.DataFrame(self.rows[f])
            for c in df.columns:
                if re.match(r"^L\d{4}_[34]$", c):
                    df[c] = pd.to_numeric(df[c], errors="coerce").astype("float32")
            df.to_parquet(os.path.join(d, f"{self.src}__{self.part[f]:03d}.parquet"), index=False)
            self.part[f] += 1; self.rows[f] = []


def walk_zip(zf, sink, rep, unmatched, path=""):
    for info in zf.infolist():
        name = info.filename
        if not (info.flag_bits & 0x800):
            try:
                raw_name = name.encode("cp437")
                try:
                    name = raw_name.decode("utf-8")
                except UnicodeDecodeError:
                    name = raw_name.decode("cp866")
            except Exception:  # noqa: BLE001
                pass
        low = name.lower()
        if info.is_dir():
            continue
        if low.endswith(".zip"):
            if info.file_size > 1_500_000_000:   # very large inner archive → temporary file
                with tempfile.TemporaryFile() as tf:
                    with zf.open(info) as src:
                        shutil.copyfileobj(src, tf, 1 << 24)
                    tf.seek(0)
                    with zipfile.ZipFile(tf) as inner:
                        walk_zip(inner, sink, rep, unmatched, path + name + "/")
            else:
                with zipfile.ZipFile(io.BytesIO(zf.read(info))) as inner:
                    walk_zip(inner, sink, rep, unmatched, path + name + "/")
            continue
        if not low.endswith(".xml"):
            rep["other_files"] += 1; continue
        try:
            head, body, enc = parse_xml(zf.read(info))
        except Exception as e:  # noqa: BLE001
            rep["xml_errors"] += 1
            if rep["xml_errors"] <= 20:
                rep.setdefault("_err", []).append(f"{path}{name}: {e}")
            continue
        code = (head.get("C_DOC", "") + head.get("C_DOC_SUB", "") + head.get("C_DOC_VER", "")).upper()
        if not re.match(r"^S\d{7}$", code or ""):
            m = FORM_IN_NAME.search((path + name).upper()); code = m.group(1) if m else ""
        fam = code[:6]
        rep["forms"][code or "?"] += 1; rep["enc"][enc] += 1
        if fam not in FAMILIES:
            continue
        row = {"src": sink.src, "form_code": code}
        for k in HEAD_KEEP:
            row["H_" + k] = head.get(k, "")
        for k, v in body.items():
            m = LINE_RE.match(k); col = m.group(2) if m else None
            if m is None:
                m = LINE_AB.match(k)
                if m:
                    col = "3" if m.group(1) == "A" else "4"; m = (None, m.group(2))
            if m is not None:
                ln = int(m[1])
                if ln in KEEP_LINES:
                    row[f"L{ln}_{col}"] = num(v)
            elif BODY_ID.match(k):
                row["B_" + k.upper()] = v
            elif len(unmatched[fam]) < 400:
                unmatched[fam][k] += 1
        sink.add(fam, row)
        rep["kept"][FAMILIES[fam]] += 1


def parse_all(raw, out):
    files = sorted(f for f in os.listdir(raw) if f.lower().endswith(".zip"))
    if not files:
        print("  немає архівів у " + raw); return
    done_path = os.path.join(out, "filings", "_parsed.json")
    done = json.load(open(done_path, encoding="utf-8")) if os.path.exists(done_path) else {}
    reports = []
    for fn in files:
        p = os.path.join(raw, fn); sig = f"{os.path.getsize(p)}|{int(os.path.getmtime(p))}"
        src = re.sub(r"[^0-9A-Za-z_-]+", "_", os.path.splitext(fn)[0])[:80]
        if done.get(fn) == sig:
            print(f"  розібрано раніше: {fn}"); continue
        for fam in FAMILIES.values():   # remove old parts of this source
            d = os.path.join(out, "filings", fam)
            if os.path.isdir(d):
                for q in os.listdir(d):
                    if q.startswith(src + "__"):
                        os.remove(os.path.join(d, q))
        t0 = time.time(); rep = {"file": fn, "forms": Counter(), "enc": Counter(), "kept": Counter(), "xml_errors": 0, "other_files": 0}
        unmatched = defaultdict(Counter); sink = Sink(out, src)
        try:
            with zipfile.ZipFile(p) as zf:
                walk_zip(zf, sink, rep, unmatched)
        except zipfile.BadZipFile as e:
            print(f"  ПОШКОДЖЕНИЙ архів {fn}: {e}"); continue
        sink.flush()
        n = sum(rep["forms"].values())
        print(f"  {fn}: {n} XML за {time.time() - t0:.0f} с; збережено {dict(rep['kept'])}; помилок {rep['xml_errors']}; кодування {dict(rep['enc'])}")
        for e in rep.get("_err", [])[:5]:
            print("     ", e)
        reports.append({"file": fn, "xml": n, "errors": rep["xml_errors"], "other_files": rep["other_files"],
                        "forms": json.dumps(dict(rep["forms"]), ensure_ascii=False), "kept": json.dumps(dict(rep["kept"]))})
        with open(os.path.join(out, f"firms_tags_unmatched_{src}.csv"), "w", encoding="utf-8") as f:
            f.write("family,tag,n\n")
            for fam, c in unmatched.items():
                for k, v in c.most_common():
                    f.write(f"{FAMILIES.get(fam, fam)},{k},{v}\n")
        done[fn] = sig; os.makedirs(os.path.dirname(done_path), exist_ok=True)
        json.dump(done, open(done_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if reports:
        rp = os.path.join(out, "firms_parse_report.csv")
        old = pd.read_csv(rp) if os.path.exists(rp) else pd.DataFrame()
        pd.concat([old[~old.get("file", pd.Series(dtype=str)).isin([r["file"] for r in reports])] if len(old) else old,
                   pd.DataFrame(reports)]).to_csv(rp, index=False)


# ------------------------------------------------------------------ panel
def read_family(out, fam):
    d = os.path.join(out, "filings", fam)
    if not os.path.isdir(d):
        return pd.DataFrame()
    parts = [pd.read_parquet(os.path.join(d, f)) for f in sorted(os.listdir(d)) if f.endswith(".parquet")]
    return pd.concat(parts, ignore_index=True, sort=False) if parts else pd.DataFrame()


def dfill(s):
    """D_FILL ddmmyyyy → yyyymmdd for sorting"""
    s = s.fillna("").astype(str).str.replace(r"\D", "", regex=True)
    return np.where(s.str.len() == 8, s.str[4:] + s.str[2:4] + s.str[:2], "0")


def dedup(df):
    if df.empty:
        return df, 0
    df = df.copy()
    ed = df.get("B_FIRM_EDRPOU", pd.Series("", index=df.index)).fillna("").astype(str).str.replace(r"\D", "", regex=True)
    tin = df.get("H_TIN", pd.Series("", index=df.index)).fillna("").astype(str).str.replace(r"\D", "", regex=True)
    df["edrpou"] = np.where(ed.str.len() > 0, ed, tin).astype(str)
    df["edrpou"] = df["edrpou"].str.zfill(8)
    df = df[df["edrpou"].str.len() == 8]                 # legal entities only (10-digit TIN = individuals)
    df["year"] = pd.to_numeric(df["H_PERIOD_YEAR"], errors="coerce")
    df["month"] = pd.to_numeric(df["H_PERIOD_MONTH"], errors="coerce")
    df = df[df["year"].between(2015, 2030) & df["month"].between(1, 12)]
    df["_cnt"] = pd.to_numeric(df.get("H_C_DOC_CNT"), errors="coerce").fillna(0)
    df["_fill"] = dfill(df.get("H_D_FILL", pd.Series("", index=df.index)))
    df["_stan"] = pd.to_numeric(df.get("H_C_DOC_STAN"), errors="coerce").fillna(1)
    df = df.sort_values(["edrpou", "year", "month", "_fill", "_cnt", "_stan", "src"])
    n0 = len(df)
    df = df.drop_duplicates(["edrpou", "year", "month"], keep="last")
    return df.drop(columns=["_cnt", "_fill", "_stan"]), n0 - len(df)


def g(df, ln, col):
    c = f"L{ln}_{col}"
    return df[c] if c in df.columns else pd.Series(np.nan, index=df.index)


def firstnz(*xs):
    out = xs[0].copy()
    for x in xs[1:]:
        out = out.where(out.notna() & (out != 0), x)
    return out


def harmonise(df, form):
    """firm × period with start (_0) and end (_1) values; flows: _1 current period, _0 same period a year earlier"""
    o = pd.DataFrame({"edrpou": df["edrpou"].values, "year": df["year"].values, "month": df["month"].values, "form": form,
                      "src": df["src"].values}, index=df.index)
    kv = df.get("B_FIRM_KVED", pd.Series("", index=df.index)).fillna("").astype(str).str.strip()
    o["kved"] = kv.str.extract(r"(\d{2}\.\d{1,2})", expand=False).fillna(kv.str.extract(r"(\d{2})", expand=False))
    o["div"] = o["kved"].str[:2]
    def col(c):
        return df[c].fillna("").astype(str).str.strip() if c in df.columns else pd.Series("", index=df.index)
    katottg = pd.Series(np.nan, index=df.index, dtype=object)
    for c in [c for c in df.columns if "KATOTTG" in c]:          # territory code UAxx…: the oblast is its first four characters
        katottg = katottg.fillna(col(c).str.extract(r"^(UA\d{2})", expand=False))
    koatuu = pd.Series(np.nan, index=df.index, dtype=object)
    for c in [c for c in df.columns if "KOATUU" in c or "SPATO" in c]:
        koatuu = koatuu.fillna(col(c).str.extract(r"^(\d{2})\d{8}$", expand=False))
    obl_f = col("B_OBL").str.extract(r"^(\d{2})$", expand=False)
    o["c_reg"] = col("H_C_REG")
    o["obl"] = katottg.fillna("UA" + obl_f).fillna("K" + koatuu).fillna("R" + o["c_reg"].where(o["c_reg"] != "", "?"))
    o["opf"] = df.get("B_FIRM_OPFCD", pd.Series("", index=df.index))
    emp = pd.to_numeric(df.get("B_S_CH", pd.Series(np.nan, index=df.index)), errors="coerce")
    o["emp"] = emp.where(emp.notna(), pd.to_numeric(df.get("B_N3", pd.Series(np.nan, index=df.index)), errors="coerce"))
    stocks = {"ta": 1300, "fa": 1010, "fa_gross": 1011, "intang": 1000, "ca": 1195, "cash": 1165, "inv": 1100, "rec": 1125,
              "eq": 1495, "ltl": 1595, "ltb": 1510, "oth_lt": 1515, "stb": 1600, "cplt": 1610, "tp": 1615, "cl": 1695, "cap": 1400}
    for k, ln in stocks.items():
        o[k + "_0"] = g(df, ln, 3).values; o[k + "_1"] = g(df, ln, 4).values
    flows = {"rev": 2000, "cogs": 2050, "finexp": 2250, "wage": 2505, "ssc": 2510, "depr": 2515, "mat": 2500, "opex": 2550,
             "tax": 2300, "inc_other": 2120, "exp_total_sm": 2285}
    for k, ln in flows.items():
        o[k + "_1"] = g(df, ln, 3).values; o[k + "_0"] = g(df, ln, 4).values
    for col, j in ((3, "_1"), (4, "_0")):
        np_ = g(df, 2350, col).fillna(0) - g(df, 2355, col).fillna(0)
        np_ = np_.where(g(df, 2350, col).notna() | g(df, 2355, col).notna())
        o["np" + j] = np_.values
        op = g(df, 2190, col).fillna(0) - g(df, 2195, col).fillna(0)
        o["opprof" + j] = op.where(g(df, 2190, col).notna() | g(df, 2195, col).notna()).values
    # bank credit: long-term (form 1 only) + short-term; small/micro forms show only short-term bank credit and total long-term liabilities
    for j in ("_0", "_1"):
        filed = o["ta" + j].notna()
        o["bank" + j] = (o["ltb" + j].fillna(0) + o["stb" + j].fillna(0)).where(filed)
        o["bank_wide" + j] = (o["ltl" + j].fillna(0) + o["stb" + j].fillna(0) + o["cplt" + j].fillna(0)).where(filed)
    return o


def build(out):
    f1, f2, sm, ms = (read_family(out, k) for k in ("F1", "F2", "SM", "MS"))
    log = {}
    parts = []
    if len(f1):
        f1, log["dup_F1"] = dedup(f1)
        if len(f2):
            f2, log["dup_F2"] = dedup(f2)
            keep2 = ["edrpou", "year", "month"] + [c for c in f2.columns if re.match(r"^L2\d{3}_[34]$", c)]
            f1 = f1.drop(columns=[c for c in f1.columns if re.match(r"^L2\d{3}_[34]$", c)]).merge(f2[keep2], on=["edrpou", "year", "month"], how="left")
            log["F1_with_F2"] = int(f1[[c for c in f1.columns if c.startswith("L2")]].notna().any(axis=1).sum())
        parts.append(harmonise(f1, "L")); del f1, f2
    if len(sm):
        sm, log["dup_SM"] = dedup(sm); parts.append(harmonise(sm, "S"))
    if len(ms):
        ms, log["dup_MS"] = dedup(ms); parts.append(harmonise(ms, "M"))
    if not parts:
        print("  немає розібраних звітів"); return
    w = pd.concat(parts, ignore_index=True, sort=False)
    for c in w.columns:
        if w[c].dtype == "float64":
            w[c] = w[c].astype("float32")
    # a firm that filed both a full and a simplified form for the same period: keep the full one
    w["_r"] = w["form"].map({"L": 0, "S": 1, "M": 2})
    w = w.sort_values(["edrpou", "year", "month", "_r"]).drop_duplicates(["edrpou", "year", "month"]).drop(columns="_r")
    w["win"] = np.where(w["month"] == 12, "FY" + w["year"].astype(int).astype(str), w["month"].astype(int).astype(str) + "M" + w["year"].astype(int).astype(str))
    w["date_0"] = pd.to_datetime((w["year"] - 1).astype(int).astype(str) + "-12-01")
    w["date_1"] = pd.to_datetime(w["year"].astype(int).astype(str) + "-" + w["month"].astype(int).astype(str).str.zfill(2) + "-01")
    w.to_parquet(os.path.join(out, "firms_windows.parquet"), index=False)
    # stocks panel: every balance observation, from the end column of its own period and from the start column of the next year's filing
    sc = [c[:-2] for c in w.columns if c.endswith("_1") and c[:-2] + "_0" in w.columns and c[:-2] in
          ("ta", "fa", "fa_gross", "intang", "ca", "cash", "inv", "rec", "eq", "ltl", "ltb", "oth_lt", "stb", "cplt", "tp", "cl", "cap", "bank", "bank_wide")]
    a = w[["edrpou", "form", "kved", "div", "obl", "date_1"] + [c + "_1" for c in sc]].rename(columns={"date_1": "date", **{c + "_1": c for c in sc}}); a["from_start_col"] = False
    b = w[["edrpou", "form", "kved", "div", "obl", "date_0"] + [c + "_0" for c in sc]].rename(columns={"date_0": "date", **{c + "_0": c for c in sc}}); b["from_start_col"] = True
    st = pd.concat([a, b], ignore_index=True).dropna(subset=["ta"])
    st = st.sort_values(["edrpou", "date", "from_start_col"]).drop_duplicates(["edrpou", "date"])   # own end-of-period column first
    st.to_parquet(os.path.join(out, "firms_stocks.parquet"), index=False)
    emp = w.loc[w["month"] == 12, ["edrpou", "year", "emp", "form"]].dropna(subset=["emp"])
    emp.to_parquet(os.path.join(out, "firms_employees.parquet"), index=False)
    cov = (w.assign(bank_dep=(w["bank_0"] > 0)).groupby(["win", "form"])
           .agg(firms=("edrpou", "size"), with_kved=("div", lambda s: s.notna().sum()), bank_dep=("bank_dep", "sum"),
                ta_0_bn=("ta_0", lambda s: s.sum() / 1e6), ta_1_bn=("ta_1", lambda s: s.sum() / 1e6),
                bank_0_bn=("bank_0", lambda s: s.sum() / 1e6), bank_1_bn=("bank_1", lambda s: s.sum() / 1e6),
                rev_1_bn=("rev_1", lambda s: s.sum() / 1e6), emp=("emp", "sum")).reset_index())
    cov.to_csv(os.path.join(out, "firms_coverage.csv"), index=False)
    json.dump(log, open(os.path.join(out, "firms_build_log.json"), "w"), indent=1)
    print("  панель: вікна", len(w), "| фірм", w["edrpou"].nunique(), "| залишки", len(st), "| дублікати", log)
    print(cov.to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project", nargs="?", default=".")
    ap.add_argument("--no-download", action="store_true")
    ap.add_argument("--build-only", action="store_true")
    ap.add_argument("--to-csv", action="store_true", help="copy the panels to CSV (for R without the arrow package)")
    a = ap.parse_args()
    proj = os.path.abspath(a.project)
    # raw archives (≈2 GB): data_nbu/local_inputs/firms_fin, or any folder given by THESIS_FIRMS_RAW (e.g. outside OneDrive)
    raw = os.environ.get("THESIS_FIRMS_RAW") or os.path.join(proj, "data_nbu", "local_inputs", "firms_fin"); out = os.path.join(proj, "data_nbu", "firms")
    os.makedirs(raw, exist_ok=True); os.makedirs(out, exist_ok=True)
    if a.to_csv:
        for f in ("firms_windows", "firms_employees", "firms_stocks"):
            p = os.path.join(out, f + ".parquet")
            if os.path.exists(p):
                pd.read_parquet(p).to_csv(os.path.join(out, f + ".csv"), index=False); print("  CSV:", f)
        return
    if not a.build_only:
        if not a.no_download and os.environ.get("THESIS_FIRMS_DOWNLOAD", "true").lower() not in ("0", "false", "no"):
            print("1. Завантаження архівів фінансової звітності"); download(raw, out)
        print("2. Розбір XML"); parse_all(raw, out)
    print("3. Панель фірм"); build(out)


if __name__ == "__main__":
    main()
