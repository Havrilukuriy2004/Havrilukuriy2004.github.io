# ============================================================================
# 17_firms_reg351_figures.R — рисунки блоків B17–B18 у стилі проєкту (save_fig, theme_academic, ч/б)
# ----------------------------------------------------------------------------
# Дані рахує Python (run_reg351.bat): output_nbu/section_3/tables/S3_B17_threshold_bins.csv,
#   S3_B18_class_distribution.csv, S3_B18_class_credit.csv.
# Run:  source("17_firms_reg351_figures.R", encoding = "UTF-8")
# Рисунки: S3_F32_regulatory_thresholds, S3_F33_borrower_class, S3_F34_class_credit (figures/ + pdf/emf/svg)
# ============================================================================
`%||%` <- function(a, b) if (is.null(a)) b else a
.this_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL) %||% Sys.getenv("THESIS_CODE_DIR", unset = getwd())
if (!nzchar(Sys.getenv("THESIS_LANGS"))) Sys.setenv(THESIS_LANGS = "uk")
source(file.path(.this_dir, "00_config_v6.R"), encoding = "UTF-8")
source(file.path(PROJECT_DIR, "utils_models_v6.R"), encoding = "UTF-8")
OUT <- file.path(OUTPUT_DIR, "section_3"); FIG <- file.path(OUT, "figures"); TAB <- file.path(OUT, "tables")
dir.create(FIG, recursive = TRUE, showWarnings = FALSE)
SRC <- "Джерело: розраховано автором за фінансовою звітністю підприємств."
rd <- function(f) data.table::fread(file.path(TAB, f), encoding = "UTF-8")

# ---- F32: розподіли поблизу регуляторних порогів -------------------------------------------------
b <- rd("S3_B17_threshold_bins.csv")
thr <- data.table::data.table(panel = unique(b$panel), x = c(1, 5, 2.5))
b[, panel := factor(panel, levels = unique(panel))]; thr[, panel := factor(panel, levels = levels(b$panel))]
b[, group := factor(group, levels = c("З кредитом, 2021–2022 рр.", "З кредитом, 2023–2025 рр.", "З кредитом, 2021–2025 рр.", "Без кредиту, 2021–2025 рр."))]
p32 <- ggplot(b, aes(mid, share, colour = group, linetype = group, shape = group)) +
  geom_vline(data = thr, aes(xintercept = x), linewidth = .35, linetype = "dashed", colour = "black") +
  geom_line(linewidth = .45) + geom_point(size = 1.3) +
  facet_wrap(~ panel, ncol = 1, scales = "free") +
  scale_colour_manual(values = c(PAL[1], PAL[2], PAL[1], PAL[7])) +
  scale_linetype_manual(values = c("solid", "longdash", "solid", "dotted")) + scale_shape_manual(values = c(16, 17, 16, 1)) +
  labs(x = "Значення показника", y = "Частка фірм-років у вікні, %",
       title = "Розподіл фірм поблизу порогів Положення № 351 і постанови НБУ № 23",
       subtitle = "Пунктир – регуляторний поріг; частки в межах кожної групи і вікна значень", caption = SRC) + theme_thesis()
save_fig(p32, "S3_F32_regulatory_thresholds.png", 8.5, 9.5)

# ---- F33: середній клас боржника ----------------------------------------------------------------
D <- rd("S3_B18_class_distribution.csv")
D[, grp := factor(ifelse(borrower %in% c(TRUE, "True", "TRUE"), "Фірми з банківським кредитом", "Фірми без банківського кредиту"),
                  levels = c("Фірми з банківським кредитом", "Фірми без банківського кредиту"))]
p33 <- ggplot(D, aes(year, mean_class, colour = grp, linetype = grp, shape = grp)) + geom_line(linewidth = .5) + geom_point(size = 1.8) +
  scale_x_continuous(breaks = sort(unique(D$year)), labels = function(x) as.character(x)) + scale_y_reverse() +
  scale_colour_manual(values = c(PAL[1], PAL[7])) + scale_linetype_manual(values = c("solid", "dashed")) + scale_shape_manual(values = c(16, 1)) +
  labs(x = NULL, y = "Середній клас (1 – найкращий)",
       title = "Середній клас боржника – юридичної особи за Положенням № 351, розрахований за річною звітністю",
       subtitle = "Клас за інтегральним показником (додаток 7) з урахуванням п. 162; кінець року", caption = SRC) + theme_thesis()
save_fig(p33, "S3_F33_borrower_class.png", 8.5, 3.6)

# ---- F34: клас і банківський кредит наступного року -----------------------------------------------
R <- rd("S3_B18_class_credit.csv")[spec == "dlbank: class by credit period (totals)"]
k <- 2:9
PER <- c(p22 = "Кредит у 2022 р. (клас на кінець 2021 р.)", p23 = "Кредит у 2023 р. (клас на кінець 2022 р.)", p2425 = "Кредит у 2024–2025 рр. (клас на кінець 2023–2024 рр.)")
rows <- data.table::rbindlist(lapply(k, function(i) data.table::rbindlist(lapply(names(PER), function(pp) {
  tm <- paste0("c", i, "_", pp); x <- R[R$term == tm]; data.table::data.table(cls = i, per = PER[[pp]], est = x$coef, se = x$se) }))))
rows[, per := factor(per, levels = PER)]
p34 <- ggplot(rows, aes(cls, est)) + geom_hline(yintercept = 0, linewidth = .3) +
  geom_errorbar(aes(ymin = est - 1.645 * se, ymax = est + 1.645 * se), width = 0, colour = "grey45") + geom_point(size = 1.6) +
  facet_wrap(~ per, ncol = 3) + scale_x_continuous(breaks = k) +
  labs(x = "Клас боржника на кінець року (база – клас 1)", y = "Зміна логарифма банківського кредиту",
       title = "Клас боржника і зміна банківського кредиту фірми за наступний рік",
       subtitle = "Ефекти розділу КВЕД × рік; контроль розміру активів і боргу; 90-відсоткові інтервали, кластеризація за фірмами", caption = SRC) + theme_thesis()
save_fig(p34, "S3_F34_class_credit.png", 8.5, 3.8)
message("B17–B18 figures: ", paste(c("S3_F32", "S3_F33", "S3_F34"), collapse = ", "), " -> ", FIG)
